@extends('layouts.user')
@section('content')
<style>
    
        table,
        th,
        td {
            border-collapse: collapse;
            border: 1px solid black;
            text-align: right;
            
        }
        @page: footer {
            display: none;
        }
        
        @page: header {
            display: none;
        }
        .full-height{
            margin: 15px auto;
           height: calc(100vh - 30px);
           width: calc(100vw - 30px);
        }
        p, strong, table tr, table td, table th, table *, table{
            font-size: 18px !important;
            padding: 1px;
            line-height: 1.4;
          font-family: bnazanin !important;
        }
        
      h3{
       font-family: btitrbold !important;
            font-weight: bold;
            font-size: 1.90rem;
      }

         main.py-4 {
              padding: 0 !important;
          }

        .border {
            border: double 6px !important;
        }
        p:not(.nft){
            text-align: justify;
        }
  
  		th,
        td {
          padding-right: 5px !important;
          padding-left: 5px !important;
        }
  
      .nft{
        font-family: btitrbold !important;
                font-weight: bold;
      }

        table td, table th {
            padding-top: 5px;
            padding-bottom: 5px;
        }
  

          @font-face{
            font-family: bnazanin;
            src: url(/font/BNazanin.ttf) format('truetype');
          }

          @font-face{
            font-family: btitrbold;
            src: url(/font/btitrb.ttf) format('truetype');
          }

          hr {
            margin: 0;
            border-color: black;
            }

        table span {
            letter-spacing: 5px;
            font-weight: 100;
            color: #959494;
        }

    </style>


<div class="full-height p-4 border border-dark">

            <h3 class="text-center">بسمه تعالی<br>
            مجتمع آموزشی فنی وحرفه ای آریا تهران
            </h3>
            <p class="text-center mt-3">نام دوره: <strong>{{$classCourse->course->name}}</strong> ساعت تشکیل: <strong>{{$classCourse->day}}</strong> <strong>{{$classCourse->start_time}}</strong> الی <strong>{{$classCourse->end_time}}</strong> تاریخ شروع: <strong>{{date('Y/m/d', strtotime($classCourse->begin_date))}}</strong> تاریخ پایان: ........................... نام استاد: <strong>{{$classCourse->teacher->name}}</strong> - کد دوره: <strong>{{$classCourse->course_code}}</strong></p>
            <table class="nft w-100 mt-3">
                <tr>
                    <th class="text-center">ردیف</th>
                    <th>نام و نام خانوادگی</th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                    <th>تاریخ <hr><span>.....</span></th>
                </tr>
                @php $row = 1; @endphp
                @foreach($classCourse->registers as $register)
                @if($register->leave_reason_id) @continue @endif
                <tr>
                    <td class="text-center">{{$row}}</td>
                    <th>{{$register->user->name}}</th>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                @php $row+=1; @endphp
                @endforeach
            </table>
            <p class="mt-3"><strong>تذکر:</strong> استاد گرامی با افزایش تعداد کارآموزان، اسامی کارآموزان به این لیست اضافه کرده و حتما موظف هستید هر جلسه حضور و غیاب کرده و در صورت عدم مطابقت با لیست و یا غایبن در هر جلسه به مسئولین آموزشگاه اطلاع دهید.  </p>
</div>



<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection