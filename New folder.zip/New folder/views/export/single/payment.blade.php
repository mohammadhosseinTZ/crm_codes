@extends('layouts.user')
@section('content')



<div class="content">
  <img src="{{asset('images/logo.png')}}" alt="">
</div>
<h1>قبض رسید آموزشگاه آریا تهران</h1>
<table>
  <tr>
    <th>شماره فیش:</th>
    <td>{{$payment->code}}</td>
  </tr>
  <tr>
    <th>تاریخ:</th>
    <td>
      <span class="date">{{$payment->created_at}}</span>
    </td>
  </tr>
  <tr>
    <th>مبلغ(به عدد):</th>
    <td>{{number_format($payment->gates->pluck('price')->sum())}} تومان</td>
  </tr>
  
    <tr>
    <th>مبلغ(به حروف):</th>
    <td>{{numbertoword($payment->gates->pluck('price')->sum(), 'تومان')}}</td>
  </tr>
  
  <tr>
    <th>روش پرداخت:</th>
    <td>{{implode(' و ', getPaymentCashways($payment->gates))}}</td>
  </tr>
  
    <tr>
    <th>بابت:</th>
    <td>{{$payment->paymentable->supplier->name}} @if($payment->sr->en_name == 'courses') @if($payment->paymentable->classCourse->course_code != 999) کد: {{$payment->paymentable->classCourse->course_code}} @endif @endif</td>
  </tr>
  
    <tr>
    <th>پرداخت کننده:</th>
    <td>{{$payment->paymentable->user->gender == 1 ? 'خانم' : 'آقای'}} {{$payment->paymentable->user->name}}</td>
  </tr>
  
    <tr>
    <th>پذیرنده:</th>
    <td>{{$payment->userInsert->name}}</td>
  </tr>
  <tfoot>
    <tr>
      <td>
        <i class="fa fa-globe"></i> www.aryatehran.com
      </td>
    </tr>
    <tr>
      <td>
         <i class="fa fa-paper-plane"></i> https://t.me/aryatehran
      </td>
    </tr>
    <tr>
      <td>
         <i class="fab fa-instagram"></i> @aryatehran_
      </td>
    </tr>
    <tr>
      <th>
        شماره تماس:
      </th>
      <td>
          <span class="date">66919633-7</span>
      </td>
    </tr>
  </tfoot>
</table>

<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>

<style>
img{
  width: 30%;
}
.content{
  text-align: center;
}
  h1, table{
  margin-top: 50px;
  }
h1, table, tfoot{
  text-align: right;
  direction: rtl;
  width: 100%;
}
  h1, table *{
  color: black;
  }
h1{
  font-size: 60px;
}
th{
    width: 30%;
}
th,td{
  font-size: 50px !important;
}

.date{
      direction: ltr;
    display: block;
}
  main.py-4{
  	padding: 0 !important;
  }
</style>
@endsection