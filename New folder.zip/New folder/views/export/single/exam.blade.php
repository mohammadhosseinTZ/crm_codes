<?php echo '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' ?>
<?php echo '<?mso-application progid="Word.Document"?>' ?>
<pkg:package
	xmlns:pkg="http://schemas.microsoft.com/office/2006/xmlPackage">
	<pkg:part pkg:name="/_rels/.rels" pkg:contentType="application/vnd.openxmlformats-package.relationships+xml" pkg:padding="512">
		<pkg:xmlData>
			<Relationships
				xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
				<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
				<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
				<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
			</Relationships>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/document.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml">
		<pkg:xmlData>
			<w:document
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:body>
					<w:p w14:paraId="2C4BF03D" w14:textId="5A30BBCF" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:jc w:val="center"/>
							<w:rPr>
								<w:rFonts w:cs="B Titr"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Titr" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="40"/>
								<w:szCs w:val="40"/>
								<w:rtl/>
							</w:rPr>
							<w:t>نمونه سوالات {{$exam->name}}</w:t>
						</w:r>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Titr"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
							<w:br/>
						</w:r>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Titr" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
							<w:t>آموزشگاه آریا تهران</w:t>
						</w:r>
					</w:p>
					<w:p w14:paraId="77A7BB3A" w14:textId="38436912" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
					</w:p>
            @foreach($exam->examQuestions as $key => $q)
					<w:p w14:paraId="0D22AB2A" w14:textId="418DDDB0" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Titr" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
							<w:t xml:space="preserve">{{$key + 1}}</w:t>
						</w:r>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:ascii="B Titr" w:hAnsi="B Titr" w:cs="B Titr" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
							<w:t>–</w:t>
						</w:r>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Titr" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
							<w:t xml:space="preserve">{{$q->question}}</w:t>
						</w:r>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
							<w:br/>
						</w:r>
					</w:p>
                    <w:p w14:paraId="6F81EEF5" w14:textId="3F5299D5" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Nazanin" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
                                @if($q->answer == 1)
                                <w:highlight w:val="green"/>
                                @endif
								<w:rtl/>
							</w:rPr>
							<w:t>1) {{$q->choose_1}} @if($q->answer == 1) ✓ @endif</w:t>
						</w:r>
					</w:p>
                    <w:p w14:paraId="6F81EEF5" w14:textId="3F5299D5" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Nazanin" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
                                @if($q->answer == 2)
                                <w:highlight w:val="green"/>
                                @endif
								<w:rtl/>
							</w:rPr>
							<w:t>2) {{$q->choose_2}} @if($q->answer == 2) ✓ @endif</w:t>
						</w:r>
					</w:p>
					<w:p w14:paraId="6F81EEF5" w14:textId="3F5299D5" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Nazanin" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
                                @if($q->answer == 3)
                                <w:highlight w:val="green"/>
                                @endif
								<w:rtl/>
							</w:rPr>
							<w:t>3){{$q->choose_3}} @if($q->answer == 3) ✓ @endif</w:t>
						</w:r>
					</w:p>
                    <w:p w14:paraId="6F81EEF5" w14:textId="3F5299D5" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
						<w:r w:rsidRPr="002F6726">
							<w:rPr>
								<w:rFonts w:cs="B Nazanin" w:hint="cs"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
                                @if($q->answer == 4)
                                <w:highlight w:val="green"/>
                                @endif
								<w:rtl/>
							</w:rPr>
							<w:t>4){{$q->choose_4}} @if($q->answer == 4) ✓ @endif </w:t>
						</w:r>
					</w:p>
					<w:p w14:paraId="5EE45EA3" w14:textId="658D9BA8" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
					</w:p>
					<w:p w14:paraId="09E79908" w14:textId="77777777" w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidRDefault="002F6726" w:rsidP="002F6726">
						<w:pPr>
							<w:rPr>
								<w:rFonts w:cs="B Nazanin"/>
								<w:b/>
								<w:bCs/>
								<w:sz w:val="28"/>
								<w:szCs w:val="28"/>
								<w:rtl/>
							</w:rPr>
						</w:pPr>
					</w:p>
                @endforeach
			
			
			
					<w:sectPr w:rsidR="002F6726" w:rsidRPr="002F6726" w:rsidSect="00636352">
						<w:headerReference w:type="even" r:id="rId7"/>
						<w:headerReference w:type="default" r:id="rId8"/>
						<w:footerReference w:type="even" r:id="rId9"/>
						<w:footerReference w:type="default" r:id="rId10"/>
						<w:headerReference w:type="first" r:id="rId11"/>
						<w:footerReference w:type="first" r:id="rId12"/>
						<w:pgSz w:w="11906" w:h="16838"/>
						<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/>
						<w:cols w:space="708"/>
						<w:bidi/>
						<w:rtlGutter/>
						<w:docGrid w:linePitch="360"/>
					</w:sectPr>
				</w:body>
			</w:document>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/_rels/document.xml.rels" pkg:contentType="application/vnd.openxmlformats-package.relationships+xml" pkg:padding="256">
		<pkg:xmlData>
			<Relationships
				xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
				<Relationship Id="rId8" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header2.xml"/>
				<Relationship Id="rId13" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/fontTable" Target="fontTable.xml"/>
				<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>
				<Relationship Id="rId7" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/>
				<Relationship Id="rId12" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer3.xml"/>
				<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
				<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>
				<Relationship Id="rId6" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/endnotes" Target="endnotes.xml"/>
				<Relationship Id="rId11" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header3.xml"/>
				<Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes" Target="footnotes.xml"/>
				<Relationship Id="rId10" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer2.xml"/>
				<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/webSettings" Target="webSettings.xml"/>
				<Relationship Id="rId9" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>
				<Relationship Id="rId14" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>
			</Relationships>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/footnotes.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml">
		<pkg:xmlData>
			<w:footnotes
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:footnote w:type="separator" w:id="-1">
					<w:p w14:paraId="7AF3293E" w14:textId="77777777" w:rsidR="00447D44" w:rsidRDefault="00447D44" w:rsidP="002F6726">
						<w:pPr>
							<w:spacing w:after="0" w:line="240" w:lineRule="auto"/>
						</w:pPr>
						<w:r>
							<w:separator/>
						</w:r>
					</w:p>
				</w:footnote>
				<w:footnote w:type="continuationSeparator" w:id="0">
					<w:p w14:paraId="66EC3EA0" w14:textId="77777777" w:rsidR="00447D44" w:rsidRDefault="00447D44" w:rsidP="002F6726">
						<w:pPr>
							<w:spacing w:after="0" w:line="240" w:lineRule="auto"/>
						</w:pPr>
						<w:r>
							<w:continuationSeparator/>
						</w:r>
					</w:p>
				</w:footnote>
			</w:footnotes>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/endnotes.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml">
		<pkg:xmlData>
			<w:endnotes
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:endnote w:type="separator" w:id="-1">
					<w:p w14:paraId="6CB3AD0B" w14:textId="77777777" w:rsidR="00447D44" w:rsidRDefault="00447D44" w:rsidP="002F6726">
						<w:pPr>
							<w:spacing w:after="0" w:line="240" w:lineRule="auto"/>
						</w:pPr>
						<w:r>
							<w:separator/>
						</w:r>
					</w:p>
				</w:endnote>
				<w:endnote w:type="continuationSeparator" w:id="0">
					<w:p w14:paraId="2C8F1374" w14:textId="77777777" w:rsidR="00447D44" w:rsidRDefault="00447D44" w:rsidP="002F6726">
						<w:pPr>
							<w:spacing w:after="0" w:line="240" w:lineRule="auto"/>
						</w:pPr>
						<w:r>
							<w:continuationSeparator/>
						</w:r>
					</w:p>
				</w:endnote>
			</w:endnotes>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/header1.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml">
		<pkg:xmlData>
			<w:hdr
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:p w14:paraId="1E3F07AB" w14:textId="13368753" w:rsidR="002F6726" w:rsidRDefault="00447D44">
					<w:pPr>
						<w:pStyle w:val="Header"/>
					</w:pPr>
					<w:r>
						<w:rPr>
							<w:noProof/>
						</w:rPr>
						<w:pict w14:anchorId="5FF69ECA">
							<v:shapetype id="_x0000_t136" coordsize="21600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e">
								<v:formulas>
									<v:f eqn="sum #0 0 10800"/>
									<v:f eqn="prod #0 2 1"/>
									<v:f eqn="sum 21600 0 @1"/>
									<v:f eqn="sum 0 0 @2"/>
									<v:f eqn="sum 21600 0 @3"/>
									<v:f eqn="if @0 @3 0"/>
									<v:f eqn="if @0 21600 @1"/>
									<v:f eqn="if @0 0 @2"/>
									<v:f eqn="if @0 @4 21600"/>
									<v:f eqn="mid @5 @6"/>
									<v:f eqn="mid @8 @5"/>
									<v:f eqn="mid @7 @8"/>
									<v:f eqn="mid @6 @7"/>
									<v:f eqn="sum @6 0 @5"/>
								</v:formulas>
								<v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800" o:connectangles="270,180,90,0"/>
								<v:textpath on="t" fitshape="t"/>
								<v:handles>
									<v:h position="#0,bottomRight" xrange="6629,14971"/>
								</v:handles>
								<o:lock v:ext="edit" text="t" shapetype="t"/>
							</v:shapetype>
							<v:shape id="PowerPlusWaterMarkObject23924047" o:spid="_x0000_s2050" type="#_x0000_t136" style="position:absolute;left:0;text-align:left;margin-left:0;margin-top:0;width:489.45pt;height:146.8pt;rotation:315;z-index:-251655168;mso-position-horizontal:center;mso-position-horizontal-relative:margin;mso-position-vertical:center;mso-position-vertical-relative:margin" o:allowincell="f" fillcolor="silver" stroked="f">
								<v:fill opacity=".5"/>
								<v:textpath style="font-family:&quot;Calibri&quot;;font-size:1pt" string="ARYATEHRAN"/>
								<w10:wrap anchorx="margin" anchory="margin"/>
							</v:shape>
						</w:pict>
					</w:r>
				</w:p>
			</w:hdr>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/header2.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml">
		<pkg:xmlData>
			<w:hdr
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:p w14:paraId="29D29C34" w14:textId="65B6C79C" w:rsidR="002F6726" w:rsidRDefault="00447D44">
					<w:pPr>
						<w:pStyle w:val="Header"/>
					</w:pPr>
					<w:r>
						<w:rPr>
							<w:noProof/>
						</w:rPr>
						<w:pict w14:anchorId="33BC9BEE">
							<v:shapetype id="_x0000_t136" coordsize="21600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e">
								<v:formulas>
									<v:f eqn="sum #0 0 10800"/>
									<v:f eqn="prod #0 2 1"/>
									<v:f eqn="sum 21600 0 @1"/>
									<v:f eqn="sum 0 0 @2"/>
									<v:f eqn="sum 21600 0 @3"/>
									<v:f eqn="if @0 @3 0"/>
									<v:f eqn="if @0 21600 @1"/>
									<v:f eqn="if @0 0 @2"/>
									<v:f eqn="if @0 @4 21600"/>
									<v:f eqn="mid @5 @6"/>
									<v:f eqn="mid @8 @5"/>
									<v:f eqn="mid @7 @8"/>
									<v:f eqn="mid @6 @7"/>
									<v:f eqn="sum @6 0 @5"/>
								</v:formulas>
								<v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800" o:connectangles="270,180,90,0"/>
								<v:textpath on="t" fitshape="t"/>
								<v:handles>
									<v:h position="#0,bottomRight" xrange="6629,14971"/>
								</v:handles>
								<o:lock v:ext="edit" text="t" shapetype="t"/>
							</v:shapetype>
							<v:shape id="PowerPlusWaterMarkObject23924048" o:spid="_x0000_s2051" type="#_x0000_t136" style="position:absolute;left:0;text-align:left;margin-left:0;margin-top:0;width:489.45pt;height:146.8pt;rotation:315;z-index:-251653120;mso-position-horizontal:center;mso-position-horizontal-relative:margin;mso-position-vertical:center;mso-position-vertical-relative:margin" o:allowincell="f" fillcolor="silver" stroked="f">
								<v:fill opacity=".5"/>
								<v:textpath style="font-family:&quot;Calibri&quot;;font-size:1pt" string="ARYATEHRAN"/>
								<w10:wrap anchorx="margin" anchory="margin"/>
							</v:shape>
						</w:pict>
					</w:r>
				</w:p>
			</w:hdr>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/footer1.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml">
		<pkg:xmlData>
			<w:ftr
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:p w14:paraId="367B0AC8" w14:textId="77777777" w:rsidR="002F6726" w:rsidRDefault="002F6726">
					<w:pPr>
						<w:pStyle w:val="Footer"/>
					</w:pPr>
				</w:p>
			</w:ftr>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/footer2.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml">
		<pkg:xmlData>
			<w:ftr
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:p w14:paraId="6907B019" w14:textId="77777777" w:rsidR="002F6726" w:rsidRDefault="002F6726">
					<w:pPr>
						<w:pStyle w:val="Footer"/>
					</w:pPr>
				</w:p>
			</w:ftr>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/header3.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml">
		<pkg:xmlData>
			<w:hdr
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:p w14:paraId="5E35EF93" w14:textId="396480F1" w:rsidR="002F6726" w:rsidRDefault="00447D44">
					<w:pPr>
						<w:pStyle w:val="Header"/>
					</w:pPr>
					<w:r>
						<w:rPr>
							<w:noProof/>
						</w:rPr>
						<w:pict w14:anchorId="06B06D79">
							<v:shapetype id="_x0000_t136" coordsize="21600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e">
								<v:formulas>
									<v:f eqn="sum #0 0 10800"/>
									<v:f eqn="prod #0 2 1"/>
									<v:f eqn="sum 21600 0 @1"/>
									<v:f eqn="sum 0 0 @2"/>
									<v:f eqn="sum 21600 0 @3"/>
									<v:f eqn="if @0 @3 0"/>
									<v:f eqn="if @0 21600 @1"/>
									<v:f eqn="if @0 0 @2"/>
									<v:f eqn="if @0 @4 21600"/>
									<v:f eqn="mid @5 @6"/>
									<v:f eqn="mid @8 @5"/>
									<v:f eqn="mid @7 @8"/>
									<v:f eqn="mid @6 @7"/>
									<v:f eqn="sum @6 0 @5"/>
								</v:formulas>
								<v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800" o:connectangles="270,180,90,0"/>
								<v:textpath on="t" fitshape="t"/>
								<v:handles>
									<v:h position="#0,bottomRight" xrange="6629,14971"/>
								</v:handles>
								<o:lock v:ext="edit" text="t" shapetype="t"/>
							</v:shapetype>
							<v:shape id="PowerPlusWaterMarkObject23924046" o:spid="_x0000_s2049" type="#_x0000_t136" style="position:absolute;left:0;text-align:left;margin-left:0;margin-top:0;width:489.45pt;height:146.8pt;rotation:315;z-index:-251657216;mso-position-horizontal:center;mso-position-horizontal-relative:margin;mso-position-vertical:center;mso-position-vertical-relative:margin" o:allowincell="f" fillcolor="silver" stroked="f">
								<v:fill opacity=".5"/>
								<v:textpath style="font-family:&quot;Calibri&quot;;font-size:1pt" string="ARYATEHRAN"/>
								<w10:wrap anchorx="margin" anchory="margin"/>
							</v:shape>
						</w:pict>
					</w:r>
				</w:p>
			</w:hdr>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/footer3.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml">
		<pkg:xmlData>
			<w:ftr
				xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
				xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
				xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
				xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
				xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
				xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
				xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
				xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
				xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
				xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
				xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
				xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
				xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
				xmlns:o="urn:schemas-microsoft-com:office:office"
				xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
				xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
				xmlns:v="urn:schemas-microsoft-com:vml"
				xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
				xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
				xmlns:w10="urn:schemas-microsoft-com:office:word"
				xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
				xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
				xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
				xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
				xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
				xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
				xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
				xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
				xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
				xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
				xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
				xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
				<w:p w14:paraId="3E63C6A9" w14:textId="77777777" w:rsidR="002F6726" w:rsidRDefault="002F6726">
					<w:pPr>
						<w:pStyle w:val="Footer"/>
					</w:pPr>
				</w:p>
			</w:ftr>
		</pkg:xmlData>
	</pkg:part>
	<pkg:part pkg:name="/word/theme/theme1.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.theme+xml">
		<pkg:xmlData>
			<a:theme
				xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme">
				<a:themeElements>
					<a:clrScheme name="Office">
						<a:dk1>
							<a:sysClr val="windowText" lastClr="000000"/>
						</a:dk1>
						<a:lt1>
							<a:sysClr val="window" lastClr="FFFFFF"/>
						</a:lt1>
						<a:dk2>
							<a:srgbClr val="44546A"/>
						</a:dk2>
						<a:lt2>
							<a:srgbClr val="E7E6E6"/>
						</a:lt2>
						<a:accent1>
							<a:srgbClr val="4472C4"/>
						</a:accent1>
						<a:accent2>
							<a:srgbClr val="ED7D31"/>
						</a:accent2>
						<a:accent3>
							<a:srgbClr val="A5A5A5"/>
						</a:accent3>
						<a:accent4>
							<a:srgbClr val="FFC000"/>
						</a:accent4>
						<a:accent5>
							<a:srgbClr val="5B9BD5"/>
						</a:accent5>
						<a:accent6>
							<a:srgbClr val="70AD47"/>
						</a:accent6>
						<a:hlink>
							<a:srgbClr val="0563C1"/>
						</a:hlink>
						<a:folHlink>
							<a:srgbClr val="954F72"/>
						</a:folHlink>
					</a:clrScheme>
					<a:fontScheme name="Office">
						<a:majorFont>
							<a:latin typeface="Calibri Light" panose="020F0302020204030204"/>
							<a:ea typeface=""/>
							<a:cs typeface=""/>
							<a:font script="Jpan" typeface="游ゴシック Light"/>
							<a:font script="Hang" typeface="맑은 고딕"/>
							<a:font script="Hans" typeface="等线 Light"/>
							<a:font script="Hant" typeface="新細明體"/>
							<a:font script="Arab" typeface="Times New Roman"/>
							<a:font script="Hebr" typeface="Times New Roman"/>
							<a:font script="Thai" typeface="Angsana New"/>
							<a:font script="Ethi" typeface="Nyala"/>
							<a:font script="Beng" typeface="Vrinda"/>
							<a:font script="Gujr" typeface="Shruti"/>
							<a:font script="Khmr" typeface="MoolBoran"/>
							<a:font script="Knda" typeface="Tunga"/>
							<a:font script="Guru" typeface="Raavi"/>
							<a:font script="Cans" typeface="Euphemia"/>
							<a:font script="Cher" typeface="Plantagenet Cherokee"/>
							<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>
							<a:font script="Tibt" typeface="Microsoft Himalaya"/>
							<a:font script="Thaa" typeface="MV Boli"/>
							<a:font script="Deva" typeface="Mangal"/>
							<a:font script="Telu" typeface="Gautami"/>
							<a:font script="Taml" typeface="Latha"/>
							<a:font script="Syrc" typeface="Estrangelo Edessa"/>
							<a:font script="Orya" typeface="Kalinga"/>
							<a:font script="Mlym" typeface="Kartika"/>
							<a:font script="Laoo" typeface="DokChampa"/>
							<a:font script="Sinh" typeface="Iskoola Pota"/>
							<a:font script="Mong" typeface="Mongolian Baiti"/>
							<a:font script="Viet" typeface="Times New Roman"/>
							<a:font script="Uigh" typeface="Microsoft Uighur"/>
							<a:font script="Geor" typeface="Sylfaen"/>
							<a:font script="Armn" typeface="Arial"/>
							<a:font script="Bugi" typeface="Leelawadee UI"/>
							<a:font script="Bopo" typeface="Microsoft JhengHei"/>
							<a:font script="Java" typeface="Javanese Text"/>
							<a:font script="Lisu" typeface="Segoe UI"/>
							<a:font script="Mymr" typeface="Myanmar Text"/>
							<a:font script="Nkoo" typeface="Ebrima"/>
							<a:font script="Olck" typeface="Nirmala UI"/>
							<a:font script="Osma" typeface="Ebrima"/>
							<a:font script="Phag" typeface="Phagspa"/>
							<a:font script="Syrn" typeface="Estrangelo Edessa"/>
							<a:font script="Syrj" typeface="Estrangelo Edessa"/>
							<a:font script="Syre" typeface="Estrangelo Edessa"/>
							<a:font script="Sora" typeface="Nirmala UI"/>
							<a:font script="Tale" typeface="Microsoft Tai Le"/>
							<a:font script="Talu" typeface="Microsoft New Tai Lue"/>
							<a:font script="Tfng" typeface="Ebrima"/>
						</a:majorFont>
						<a:minorFont>
							<a:latin typeface="Calibri" panose="020F0502020204030204"/>
							<a:ea typeface=""/>
							<a:cs typeface=""/>
							<a:font script="Jpan" typeface="游明朝"/>
							<a:font script="Hang" typeface="맑은 고딕"/>
							<a:font script="Hans" typeface="等线"/>
							<a:font script="Hant" typeface="新細明體"/>
							<a:font script="Arab" typeface="Arial"/>
							<a:font script="Hebr" typeface="Arial"/>
							<a:font script="Thai" typeface="Cordia New"/>
							<a:font script="Ethi" typeface="Nyala"/>
							<a:font script="Beng" typeface="Vrinda"/>
							<a:font script="Gujr" typeface="Shruti"/>
							<a:font script="Khmr" typeface="DaunPenh"/>
							<a:font script="Knda" typeface="Tunga"/>
							<a:font script="Guru" typeface="Raavi"/>
							<a:font script="Cans" typeface="Euphemia"/>
							<a:font script="Cher" typeface="Plantagenet Cherokee"/>
							<a:font script="Yiii" typeface="Microsoft Yi Baiti"/>
							<a:font script="Tibt" typeface="Microsoft Himalaya"/>
							<a:font script="Thaa" typeface="MV Boli"/>
							<a:font script="Deva" typeface="Mangal"/>
							<a:font script="Telu" typeface="Gautami"/>
							<a:font script="Taml" typeface="Latha"/>
							<a:font script="Syrc" typeface="Estrangelo Edessa"/>
							<a:font script="Orya" typeface="Kalinga"/>
							<a:font script="Mlym" typeface="Kartika"/>
							<a:font script="Laoo" typeface="DokChampa"/>
							<a:font script="Sinh" typeface="Iskoola Pota"/>
							<a:font script="Mong" typeface="Mongolian Baiti"/>
							<a:font script="Viet" typeface="Arial"/>
							<a:font script="Uigh" typeface="Microsoft Uighur"/>
							<a:font script="Geor" typeface="Sylfaen"/>
							<a:font script="Armn" typeface="Arial"/>
							<a:font script="Bugi" typeface="Leelawadee UI"/>
							<a:font script="Bopo" typeface="Microsoft JhengHei"/>
							<a:font script="Java" typeface="Javanese Text"/>
							<a:font script="Lisu" typeface="Segoe UI"/>
							<a:font script="Mymr" typeface="Myanmar Text"/>
							<a:font script="Nkoo" typeface="Ebrima"/>
							<a:font script="Olck" typeface="Nirmala UI"/>
							<a:font script="Osma" typeface="Ebrima"/>
							<a:font script="Phag" typeface="Phagspa"/>
							<a:font script="Syrn" typeface="Estrangelo Edessa"/>
							<a:font script="Syrj" typeface="Estrangelo Edessa"/>
							<a:font script="Syre" typeface="Estrangelo Edessa"/>
							<a:font script="Sora" typeface="Nirmala UI"/>
							<a:font script="Tale" typeface="Microsoft Tai Le"/>
							<a:font script="Talu" typeface="Microsoft New Tai Lue"/>
							<a:font script="Tfng" typeface="Ebrima"/>
						</a:minorFont>
					</a:fontScheme>
					<a:fmtScheme name="Office">
						<a:fillStyleLst>
							<a:solidFill>
								<a:schemeClr val="phClr"/>
							</a:solidFill>
							<a:gradFill rotWithShape="1">
								<a:gsLst>
									<a:gs pos="0">
										<a:schemeClr val="phClr">
											<a:lumMod val="110000"/>
											<a:satMod val="105000"/>
											<a:tint val="67000"/>
										</a:schemeClr>
									</a:gs>
									<a:gs pos="50000">
										<a:schemeClr val="phClr">
											<a:lumMod val="105000"/>
											<a:satMod val="103000"/>
											<a:tint val="73000"/>
										</a:schemeClr>
									</a:gs>
									<a:gs pos="100000">
										<a:schemeClr val="phClr">
											<a:lumMod val="105000"/>
											<a:satMod val="109000"/>
											<a:tint val="81000"/>
										</a:schemeClr>
									</a:gs>
								</a:gsLst>
								<a:lin ang="5400000" scaled="0"/>
							</a:gradFill>
							<a:gradFill rotWithShape="1">
								<a:gsLst>
									<a:gs pos="0">
										<a:schemeClr val="phClr">
											<a:satMod val="103000"/>
											<a:lumMod val="102000"/>
											<a:tint val="94000"/>
										</a:schemeClr>
									</a:gs>
									<a:gs pos="50000">
										<a:schemeClr val="phClr">
											<a:satMod val="110000"/>
											<a:lumMod val="100000"/>
											<a:shade val="100000"/>
										</a:schemeClr>
									</a:gs>
									<a:gs pos="100000">
										<a:schemeClr val="phClr">
											<a:lumMod val="99000"/>
											<a:satMod val="120000"/>
											<a:shade val="78000"/>
										</a:schemeClr>
									</a:gs>
								</a:gsLst>
								<a:lin ang="5400000" scaled="0"/>
							</a:gradFill>
						</a:fillStyleLst>
						<a:lnStyleLst>
							<a:ln w="6350" cap="flat" cmpd="sng" algn="ctr">
								<a:solidFill>
									<a:schemeClr val="phClr"/>
								</a:solidFill>
								<a:prstDash val="solid"/>
								<a:miter lim="800000"/>
							</a:ln>
							<a:ln w="12700" cap="flat" cmpd="sng" algn="ctr">
								<a:solidFill>
									<a:schemeClr val="phClr"/>
								</a:solidFill>
								<a:prstDash val="solid"/>
								<a:miter lim="800000"/>
							</a:ln>
							<a:ln w="19050" cap="flat" cmpd="sng" algn="ctr">
								<a:solidFill>
									<a:schemeClr val="phClr"/>
								</a:solidFill>
								<a:prstDash val="solid"/>
								<a:miter lim="800000"/>
							</a:ln>
						</a:lnStyleLst>
						<a:effectStyleLst>
							<a:effectStyle>
								<a:effectLst/>
							</a:effectStyle>
							<a:effectStyle>
								<a:effectLst/>
							</a:effectStyle>
							<a:effectStyle>
								<a:effectLst>
									<a:outerShdw blurRad="57150" dist="19050" dir="5400000" algn="ctr" rotWithShape="0">
										<a:srgbClr val="000000">
											<a:alpha val="63000"/>
										</a:srgbClr>
									</a:outerShdw>
								</a:effectLst>
							</a:effectStyle>
						</a:effectStyleLst>
						<a:bgFillStyleLst>
							<a:solidFill>
								<a:schemeClr val="phClr"/>
							</a:solidFill>
							<a:solidFill>
								<a:schemeClr val="phClr">
									<a:tint val="95000"/>
									<a:satMod val="170000"/>
								</a:schemeClr>
							</a:solidFill>
							<a:gradFill rotWithShape="1">
								<a:gsLst>
									<a:gs pos="0">
										<a:schemeClr val="phClr">
											<a:tint val="93000"/>
											<a:satMod val="150000"/>
											<a:shade val="98000"/>
											<a:lumMod val="102000"/>
										</a:schemeClr>
									</a:gs>
									<a:gs pos="50000">
										<a:schemeClr val="phClr">
											<a:tint val="98000"/>
											<a:satMod val="130000"/>
											<a:shade val="90000"/>
											<a:lumMod val="103000"/>
										</a:schemeClr>
									</a:gs>
									<a:gs pos="100000">
										<a:schemeClr val="phClr">
											<a:shade val="63000"/>
											<a:satMod val="120000"/>
										</a:schemeClr>
									</a:gs>
								</a:gsLst>
								<a:lin ang="5400000" scaled="0"/>
							</a:gradFill>
						</a:bgFillStyleLst>
					</a:fmtScheme>
				</a:themeElements>
				<a:objectDefaults/>
				<a:extraClrSchemeLst/>
				<a:extLst>
					<a:ext uri="{05A4C25C-085E-4340-85A3-A5531E510DB2}">
						<thm15:themeFamily
							xmlns:thm15="http://schemas.microsoft.com/office/thememl/2012/main" name="Office Theme" id="{62F939B6-93AF-4DB8-9C6B-D6C7DFDC589F}" vid="{4A3C46E8-61CC-4603-A589-7422A47A8E4A}"/>
						</a:ext>
					</a:extLst>
				</a:theme>
			</pkg:xmlData>
		</pkg:part>
		<pkg:part pkg:name="/word/settings.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml">
			<pkg:xmlData>
				<w:settings
					xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
					xmlns:o="urn:schemas-microsoft-com:office:office"
					xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
					xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
					xmlns:v="urn:schemas-microsoft-com:vml"
					xmlns:w10="urn:schemas-microsoft-com:office:word"
					xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
					xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
					xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
					xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
					xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
					xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
					xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
					xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
					xmlns:sl="http://schemas.openxmlformats.org/schemaLibrary/2006/main" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh">
					<w:zoom w:percent="100"/>
					<w:proofState w:spelling="clean" w:grammar="clean"/>
					<w:defaultTabStop w:val="720"/>
					<w:characterSpacingControl w:val="doNotCompress"/>
					<w:hdrShapeDefaults>
						<o:shapedefaults v:ext="edit" spidmax="2052"/>
						<o:shapelayout v:ext="edit">
							<o:idmap v:ext="edit" data="2"/>
						</o:shapelayout>
					</w:hdrShapeDefaults>
					<w:footnotePr>
						<w:footnote w:id="-1"/>
						<w:footnote w:id="0"/>
					</w:footnotePr>
					<w:endnotePr>
						<w:endnote w:id="-1"/>
						<w:endnote w:id="0"/>
					</w:endnotePr>
					<w:compat>
						<w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/>
						<w:compatSetting w:name="overrideTableStyleFontSizeAndJustification" w:uri="http://schemas.microsoft.com/office/word" w:val="1"/>
						<w:compatSetting w:name="enableOpenTypeFeatures" w:uri="http://schemas.microsoft.com/office/word" w:val="1"/>
						<w:compatSetting w:name="doNotFlipMirrorIndents" w:uri="http://schemas.microsoft.com/office/word" w:val="1"/>
						<w:compatSetting w:name="differentiateMultirowTableHeaders" w:uri="http://schemas.microsoft.com/office/word" w:val="1"/>
						<w:compatSetting w:name="useWord2013TrackBottomHyphenation" w:uri="http://schemas.microsoft.com/office/word" w:val="0"/>
					</w:compat>
					<w:rsids>
						<w:rsidRoot w:val="002F6726"/>
						<w:rsid w:val="002F6726"/>
						<w:rsid w:val="0033621A"/>
						<w:rsid w:val="00447D44"/>
						<w:rsid w:val="0059333E"/>
						<w:rsid w:val="00636352"/>
						<w:rsid w:val="00C64B66"/>
					</w:rsids>
					<m:mathPr>
						<m:mathFont m:val="Cambria Math"/>
						<m:brkBin m:val="before"/>
						<m:brkBinSub m:val="--"/>
						<m:smallFrac m:val="0"/>
						<m:dispDef/>
						<m:lMargin m:val="0"/>
						<m:rMargin m:val="0"/>
						<m:defJc m:val="centerGroup"/>
						<m:wrapIndent m:val="1440"/>
						<m:intLim m:val="subSup"/>
						<m:naryLim m:val="undOvr"/>
					</m:mathPr>
					<w:themeFontLang w:val="en-US" w:bidi="fa-IR"/>
					<w:clrSchemeMapping w:bg1="light1" w:t1="dark1" w:bg2="light2" w:t2="dark2" w:accent1="accent1" w:accent2="accent2" w:accent3="accent3" w:accent4="accent4" w:accent5="accent5" w:accent6="accent6" w:hyperlink="hyperlink" w:followedHyperlink="followedHyperlink"/>
					<w:shapeDefaults>
						<o:shapedefaults v:ext="edit" spidmax="2052"/>
						<o:shapelayout v:ext="edit">
							<o:idmap v:ext="edit" data="1"/>
						</o:shapelayout>
					</w:shapeDefaults>
					<w:decimalSymbol w:val="."/>
					<w:listSeparator w:val="؛"/>
					<w14:docId w14:val="56F5DB05"/>
					<w15:chartTrackingRefBased/>
					<w15:docId w15:val="{4D657246-2A0C-4276-BA22-018D7622C121}"/>
				</w:settings>
			</pkg:xmlData>
		</pkg:part>
		<pkg:part pkg:name="/word/numbering.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml">
			<pkg:xmlData>
				<w:numbering
					xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
					xmlns:cx="http://schemas.microsoft.com/office/drawing/2014/chartex"
					xmlns:cx1="http://schemas.microsoft.com/office/drawing/2015/9/8/chartex"
					xmlns:cx2="http://schemas.microsoft.com/office/drawing/2015/10/21/chartex"
					xmlns:cx3="http://schemas.microsoft.com/office/drawing/2016/5/9/chartex"
					xmlns:cx4="http://schemas.microsoft.com/office/drawing/2016/5/10/chartex"
					xmlns:cx5="http://schemas.microsoft.com/office/drawing/2016/5/11/chartex"
					xmlns:cx6="http://schemas.microsoft.com/office/drawing/2016/5/12/chartex"
					xmlns:cx7="http://schemas.microsoft.com/office/drawing/2016/5/13/chartex"
					xmlns:cx8="http://schemas.microsoft.com/office/drawing/2016/5/14/chartex"
					xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
					xmlns:aink="http://schemas.microsoft.com/office/drawing/2016/ink"
					xmlns:am3d="http://schemas.microsoft.com/office/drawing/2017/model3d"
					xmlns:o="urn:schemas-microsoft-com:office:office"
					xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
					xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
					xmlns:v="urn:schemas-microsoft-com:vml"
					xmlns:wp14="http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing"
					xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
					xmlns:w10="urn:schemas-microsoft-com:office:word"
					xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
					xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
					xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
					xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
					xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
					xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
					xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
					xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex"
					xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
					xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
					xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
					xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh wp14">
					<w:abstractNum w:abstractNumId="0" w15:restartNumberingAfterBreak="0">
						<w:nsid w:val="10A41968"/>
						<w:multiLevelType w:val="hybridMultilevel"/>
						<w:tmpl w:val="A98E345C"/>
						<w:lvl w:ilvl="0" w:tplc="04090011">
							<w:start w:val="3"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%1)"/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="720" w:hanging="360"/>
							</w:pPr>
							<w:rPr>
								<w:rFonts w:hint="default"/>
							</w:rPr>
						</w:lvl>
						<w:lvl w:ilvl="1" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%2."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="1440" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="2" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%3."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="2160" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="3" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%4."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="2880" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="4" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%5."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="3600" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="5" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%6."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="4320" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="6" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%7."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="5040" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="7" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%8."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="5760" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="8" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%9."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="6480" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
					</w:abstractNum>
					<w:abstractNum w:abstractNumId="1" w15:restartNumberingAfterBreak="0">
						<w:nsid w:val="42144721"/>
						<w:multiLevelType w:val="hybridMultilevel"/>
						<w:tmpl w:val="7C30E48A"/>
						<w:lvl w:ilvl="0" w:tplc="DD9056E2">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%1-"/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="1080" w:hanging="360"/>
							</w:pPr>
							<w:rPr>
								<w:rFonts w:hint="default"/>
							</w:rPr>
						</w:lvl>
						<w:lvl w:ilvl="1" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%2."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="1800" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="2" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%3."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="2520" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="3" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%4."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="3240" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="4" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%5."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="3960" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="5" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%6."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="4680" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="6" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%7."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="5400" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="7" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%8."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="6120" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="8" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%9."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="6840" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
					</w:abstractNum>
					<w:abstractNum w:abstractNumId="2" w15:restartNumberingAfterBreak="0">
						<w:nsid w:val="5E787C21"/>
						<w:multiLevelType w:val="hybridMultilevel"/>
						<w:tmpl w:val="A5A07B54"/>
						<w:lvl w:ilvl="0" w:tplc="509026E6">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%1-"/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="720" w:hanging="360"/>
							</w:pPr>
							<w:rPr>
								<w:rFonts w:hint="default"/>
							</w:rPr>
						</w:lvl>
						<w:lvl w:ilvl="1" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%2."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="1440" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="2" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%3."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="2160" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="3" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%4."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="2880" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="4" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%5."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="3600" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="5" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%6."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="4320" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="6" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%7."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="5040" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="7" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%8."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="5760" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="8" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%9."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="6480" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
					</w:abstractNum>
					<w:abstractNum w:abstractNumId="3" w15:restartNumberingAfterBreak="0">
						<w:nsid w:val="68DD24D3"/>
						<w:multiLevelType w:val="hybridMultilevel"/>
						<w:tmpl w:val="95FE9532"/>
						<w:lvl w:ilvl="0" w:tplc="04090011">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%1)"/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="360" w:hanging="360"/>
							</w:pPr>
							<w:rPr>
								<w:rFonts w:hint="default"/>
							</w:rPr>
						</w:lvl>
						<w:lvl w:ilvl="1" w:tplc="04090019">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%2."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="1157" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="2" w:tplc="0409001B">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%3."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="1877" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="3" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%4."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="2597" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="4" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%5."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="3317" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="5" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%6."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="4037" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="6" w:tplc="0409000F" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="decimal"/>
							<w:lvlText w:val="%7."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="4757" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="7" w:tplc="04090019" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerLetter"/>
							<w:lvlText w:val="%8."/>
							<w:lvlJc w:val="left"/>
							<w:pPr>
								<w:ind w:left="5477" w:hanging="360"/>
							</w:pPr>
						</w:lvl>
						<w:lvl w:ilvl="8" w:tplc="0409001B" w:tentative="1">
							<w:start w:val="1"/>
							<w:numFmt w:val="lowerRoman"/>
							<w:lvlText w:val="%9."/>
							<w:lvlJc w:val="right"/>
							<w:pPr>
								<w:ind w:left="6197" w:hanging="180"/>
							</w:pPr>
						</w:lvl>
					</w:abstractNum>
					<w:num w:numId="1">
						<w:abstractNumId w:val="2"/>
					</w:num>
					<w:num w:numId="2">
						<w:abstractNumId w:val="1"/>
					</w:num>
					<w:num w:numId="3">
						<w:abstractNumId w:val="3"/>
					</w:num>
					<w:num w:numId="4">
						<w:abstractNumId w:val="0"/>
					</w:num>
				</w:numbering>
			</pkg:xmlData>
		</pkg:part>
		<pkg:part pkg:name="/word/styles.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml">
			<pkg:xmlData>
				<w:styles
					xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
					xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
					xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
					xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
					xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
					xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
					xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
					xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
					xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
					xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh">
					<w:docDefaults>
						<w:rPrDefault>
							<w:rPr>
								<w:rFonts w:asciiTheme="minorHAnsi" w:eastAsiaTheme="minorHAnsi" w:hAnsiTheme="minorHAnsi" w:cstheme="minorBidi"/>
								<w:sz w:val="22"/>
								<w:szCs w:val="22"/>
								<w:lang w:val="en-US" w:eastAsia="en-US" w:bidi="fa-IR"/>
							</w:rPr>
						</w:rPrDefault>
						<w:pPrDefault>
							<w:pPr>
								<w:spacing w:after="160" w:line="259" w:lineRule="auto"/>
							</w:pPr>
						</w:pPrDefault>
					</w:docDefaults>
					<w:latentStyles w:defLockedState="0" w:defUIPriority="99" w:defSemiHidden="0" w:defUnhideWhenUsed="0" w:defQFormat="0" w:count="376">
						<w:lsdException w:name="Normal" w:uiPriority="0" w:qFormat="1"/>
						<w:lsdException w:name="heading 1" w:uiPriority="9" w:qFormat="1"/>
						<w:lsdException w:name="heading 2" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="heading 3" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="heading 4" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="heading 5" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="heading 6" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="heading 7" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="heading 8" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="heading 9" w:semiHidden="1" w:uiPriority="9" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="index 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 6" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 7" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 8" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index 9" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 1" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 2" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 3" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 4" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 5" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 6" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 7" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 8" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toc 9" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Normal Indent" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="footnote text" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="annotation text" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="header" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="footer" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="index heading" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="caption" w:semiHidden="1" w:uiPriority="35" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="table of figures" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="envelope address" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="envelope return" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="footnote reference" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="annotation reference" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="line number" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="page number" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="endnote reference" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="endnote text" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="table of authorities" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="macro" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="toa heading" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Bullet" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Number" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Bullet 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Bullet 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Bullet 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Bullet 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Number 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Number 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Number 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Number 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Title" w:uiPriority="10" w:qFormat="1"/>
						<w:lsdException w:name="Closing" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Signature" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Default Paragraph Font" w:semiHidden="1" w:uiPriority="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text Indent" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Continue" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Continue 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Continue 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Continue 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="List Continue 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Message Header" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Subtitle" w:uiPriority="11" w:qFormat="1"/>
						<w:lsdException w:name="Salutation" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Date" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text First Indent" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text First Indent 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Note Heading" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text Indent 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Body Text Indent 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Block Text" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Hyperlink" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="FollowedHyperlink" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Strong" w:uiPriority="22" w:qFormat="1"/>
						<w:lsdException w:name="Emphasis" w:uiPriority="20" w:qFormat="1"/>
						<w:lsdException w:name="Document Map" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Plain Text" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="E-mail Signature" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Top of Form" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Bottom of Form" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Normal (Web)" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Acronym" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Address" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Cite" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Code" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Definition" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Keyboard" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Preformatted" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Sample" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Typewriter" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="HTML Variable" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Normal Table" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="annotation subject" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="No List" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Outline List 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Outline List 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Outline List 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Simple 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Simple 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Simple 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Classic 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Classic 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Classic 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Classic 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Colorful 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Colorful 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Colorful 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Columns 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Columns 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Columns 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Columns 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Columns 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 6" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 7" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid 8" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 4" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 5" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 6" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 7" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table List 8" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table 3D effects 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table 3D effects 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table 3D effects 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Contemporary" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Elegant" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Professional" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Subtle 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Subtle 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Web 1" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Web 2" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Web 3" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Balloon Text" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Table Grid" w:uiPriority="39"/>
						<w:lsdException w:name="Table Theme" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Placeholder Text" w:semiHidden="1"/>
						<w:lsdException w:name="No Spacing" w:uiPriority="1" w:qFormat="1"/>
						<w:lsdException w:name="Light Shading" w:uiPriority="60"/>
						<w:lsdException w:name="Light List" w:uiPriority="61"/>
						<w:lsdException w:name="Light Grid" w:uiPriority="62"/>
						<w:lsdException w:name="Medium Shading 1" w:uiPriority="63"/>
						<w:lsdException w:name="Medium Shading 2" w:uiPriority="64"/>
						<w:lsdException w:name="Medium List 1" w:uiPriority="65"/>
						<w:lsdException w:name="Medium List 2" w:uiPriority="66"/>
						<w:lsdException w:name="Medium Grid 1" w:uiPriority="67"/>
						<w:lsdException w:name="Medium Grid 2" w:uiPriority="68"/>
						<w:lsdException w:name="Medium Grid 3" w:uiPriority="69"/>
						<w:lsdException w:name="Dark List" w:uiPriority="70"/>
						<w:lsdException w:name="Colorful Shading" w:uiPriority="71"/>
						<w:lsdException w:name="Colorful List" w:uiPriority="72"/>
						<w:lsdException w:name="Colorful Grid" w:uiPriority="73"/>
						<w:lsdException w:name="Light Shading Accent 1" w:uiPriority="60"/>
						<w:lsdException w:name="Light List Accent 1" w:uiPriority="61"/>
						<w:lsdException w:name="Light Grid Accent 1" w:uiPriority="62"/>
						<w:lsdException w:name="Medium Shading 1 Accent 1" w:uiPriority="63"/>
						<w:lsdException w:name="Medium Shading 2 Accent 1" w:uiPriority="64"/>
						<w:lsdException w:name="Medium List 1 Accent 1" w:uiPriority="65"/>
						<w:lsdException w:name="Revision" w:semiHidden="1"/>
						<w:lsdException w:name="List Paragraph" w:uiPriority="34" w:qFormat="1"/>
						<w:lsdException w:name="Quote" w:uiPriority="29" w:qFormat="1"/>
						<w:lsdException w:name="Intense Quote" w:uiPriority="30" w:qFormat="1"/>
						<w:lsdException w:name="Medium List 2 Accent 1" w:uiPriority="66"/>
						<w:lsdException w:name="Medium Grid 1 Accent 1" w:uiPriority="67"/>
						<w:lsdException w:name="Medium Grid 2 Accent 1" w:uiPriority="68"/>
						<w:lsdException w:name="Medium Grid 3 Accent 1" w:uiPriority="69"/>
						<w:lsdException w:name="Dark List Accent 1" w:uiPriority="70"/>
						<w:lsdException w:name="Colorful Shading Accent 1" w:uiPriority="71"/>
						<w:lsdException w:name="Colorful List Accent 1" w:uiPriority="72"/>
						<w:lsdException w:name="Colorful Grid Accent 1" w:uiPriority="73"/>
						<w:lsdException w:name="Light Shading Accent 2" w:uiPriority="60"/>
						<w:lsdException w:name="Light List Accent 2" w:uiPriority="61"/>
						<w:lsdException w:name="Light Grid Accent 2" w:uiPriority="62"/>
						<w:lsdException w:name="Medium Shading 1 Accent 2" w:uiPriority="63"/>
						<w:lsdException w:name="Medium Shading 2 Accent 2" w:uiPriority="64"/>
						<w:lsdException w:name="Medium List 1 Accent 2" w:uiPriority="65"/>
						<w:lsdException w:name="Medium List 2 Accent 2" w:uiPriority="66"/>
						<w:lsdException w:name="Medium Grid 1 Accent 2" w:uiPriority="67"/>
						<w:lsdException w:name="Medium Grid 2 Accent 2" w:uiPriority="68"/>
						<w:lsdException w:name="Medium Grid 3 Accent 2" w:uiPriority="69"/>
						<w:lsdException w:name="Dark List Accent 2" w:uiPriority="70"/>
						<w:lsdException w:name="Colorful Shading Accent 2" w:uiPriority="71"/>
						<w:lsdException w:name="Colorful List Accent 2" w:uiPriority="72"/>
						<w:lsdException w:name="Colorful Grid Accent 2" w:uiPriority="73"/>
						<w:lsdException w:name="Light Shading Accent 3" w:uiPriority="60"/>
						<w:lsdException w:name="Light List Accent 3" w:uiPriority="61"/>
						<w:lsdException w:name="Light Grid Accent 3" w:uiPriority="62"/>
						<w:lsdException w:name="Medium Shading 1 Accent 3" w:uiPriority="63"/>
						<w:lsdException w:name="Medium Shading 2 Accent 3" w:uiPriority="64"/>
						<w:lsdException w:name="Medium List 1 Accent 3" w:uiPriority="65"/>
						<w:lsdException w:name="Medium List 2 Accent 3" w:uiPriority="66"/>
						<w:lsdException w:name="Medium Grid 1 Accent 3" w:uiPriority="67"/>
						<w:lsdException w:name="Medium Grid 2 Accent 3" w:uiPriority="68"/>
						<w:lsdException w:name="Medium Grid 3 Accent 3" w:uiPriority="69"/>
						<w:lsdException w:name="Dark List Accent 3" w:uiPriority="70"/>
						<w:lsdException w:name="Colorful Shading Accent 3" w:uiPriority="71"/>
						<w:lsdException w:name="Colorful List Accent 3" w:uiPriority="72"/>
						<w:lsdException w:name="Colorful Grid Accent 3" w:uiPriority="73"/>
						<w:lsdException w:name="Light Shading Accent 4" w:uiPriority="60"/>
						<w:lsdException w:name="Light List Accent 4" w:uiPriority="61"/>
						<w:lsdException w:name="Light Grid Accent 4" w:uiPriority="62"/>
						<w:lsdException w:name="Medium Shading 1 Accent 4" w:uiPriority="63"/>
						<w:lsdException w:name="Medium Shading 2 Accent 4" w:uiPriority="64"/>
						<w:lsdException w:name="Medium List 1 Accent 4" w:uiPriority="65"/>
						<w:lsdException w:name="Medium List 2 Accent 4" w:uiPriority="66"/>
						<w:lsdException w:name="Medium Grid 1 Accent 4" w:uiPriority="67"/>
						<w:lsdException w:name="Medium Grid 2 Accent 4" w:uiPriority="68"/>
						<w:lsdException w:name="Medium Grid 3 Accent 4" w:uiPriority="69"/>
						<w:lsdException w:name="Dark List Accent 4" w:uiPriority="70"/>
						<w:lsdException w:name="Colorful Shading Accent 4" w:uiPriority="71"/>
						<w:lsdException w:name="Colorful List Accent 4" w:uiPriority="72"/>
						<w:lsdException w:name="Colorful Grid Accent 4" w:uiPriority="73"/>
						<w:lsdException w:name="Light Shading Accent 5" w:uiPriority="60"/>
						<w:lsdException w:name="Light List Accent 5" w:uiPriority="61"/>
						<w:lsdException w:name="Light Grid Accent 5" w:uiPriority="62"/>
						<w:lsdException w:name="Medium Shading 1 Accent 5" w:uiPriority="63"/>
						<w:lsdException w:name="Medium Shading 2 Accent 5" w:uiPriority="64"/>
						<w:lsdException w:name="Medium List 1 Accent 5" w:uiPriority="65"/>
						<w:lsdException w:name="Medium List 2 Accent 5" w:uiPriority="66"/>
						<w:lsdException w:name="Medium Grid 1 Accent 5" w:uiPriority="67"/>
						<w:lsdException w:name="Medium Grid 2 Accent 5" w:uiPriority="68"/>
						<w:lsdException w:name="Medium Grid 3 Accent 5" w:uiPriority="69"/>
						<w:lsdException w:name="Dark List Accent 5" w:uiPriority="70"/>
						<w:lsdException w:name="Colorful Shading Accent 5" w:uiPriority="71"/>
						<w:lsdException w:name="Colorful List Accent 5" w:uiPriority="72"/>
						<w:lsdException w:name="Colorful Grid Accent 5" w:uiPriority="73"/>
						<w:lsdException w:name="Light Shading Accent 6" w:uiPriority="60"/>
						<w:lsdException w:name="Light List Accent 6" w:uiPriority="61"/>
						<w:lsdException w:name="Light Grid Accent 6" w:uiPriority="62"/>
						<w:lsdException w:name="Medium Shading 1 Accent 6" w:uiPriority="63"/>
						<w:lsdException w:name="Medium Shading 2 Accent 6" w:uiPriority="64"/>
						<w:lsdException w:name="Medium List 1 Accent 6" w:uiPriority="65"/>
						<w:lsdException w:name="Medium List 2 Accent 6" w:uiPriority="66"/>
						<w:lsdException w:name="Medium Grid 1 Accent 6" w:uiPriority="67"/>
						<w:lsdException w:name="Medium Grid 2 Accent 6" w:uiPriority="68"/>
						<w:lsdException w:name="Medium Grid 3 Accent 6" w:uiPriority="69"/>
						<w:lsdException w:name="Dark List Accent 6" w:uiPriority="70"/>
						<w:lsdException w:name="Colorful Shading Accent 6" w:uiPriority="71"/>
						<w:lsdException w:name="Colorful List Accent 6" w:uiPriority="72"/>
						<w:lsdException w:name="Colorful Grid Accent 6" w:uiPriority="73"/>
						<w:lsdException w:name="Subtle Emphasis" w:uiPriority="19" w:qFormat="1"/>
						<w:lsdException w:name="Intense Emphasis" w:uiPriority="21" w:qFormat="1"/>
						<w:lsdException w:name="Subtle Reference" w:uiPriority="31" w:qFormat="1"/>
						<w:lsdException w:name="Intense Reference" w:uiPriority="32" w:qFormat="1"/>
						<w:lsdException w:name="Book Title" w:uiPriority="33" w:qFormat="1"/>
						<w:lsdException w:name="Bibliography" w:semiHidden="1" w:uiPriority="37" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="TOC Heading" w:semiHidden="1" w:uiPriority="39" w:unhideWhenUsed="1" w:qFormat="1"/>
						<w:lsdException w:name="Plain Table 1" w:uiPriority="41"/>
						<w:lsdException w:name="Plain Table 2" w:uiPriority="42"/>
						<w:lsdException w:name="Plain Table 3" w:uiPriority="43"/>
						<w:lsdException w:name="Plain Table 4" w:uiPriority="44"/>
						<w:lsdException w:name="Plain Table 5" w:uiPriority="45"/>
						<w:lsdException w:name="Grid Table Light" w:uiPriority="40"/>
						<w:lsdException w:name="Grid Table 1 Light" w:uiPriority="46"/>
						<w:lsdException w:name="Grid Table 2" w:uiPriority="47"/>
						<w:lsdException w:name="Grid Table 3" w:uiPriority="48"/>
						<w:lsdException w:name="Grid Table 4" w:uiPriority="49"/>
						<w:lsdException w:name="Grid Table 5 Dark" w:uiPriority="50"/>
						<w:lsdException w:name="Grid Table 6 Colorful" w:uiPriority="51"/>
						<w:lsdException w:name="Grid Table 7 Colorful" w:uiPriority="52"/>
						<w:lsdException w:name="Grid Table 1 Light Accent 1" w:uiPriority="46"/>
						<w:lsdException w:name="Grid Table 2 Accent 1" w:uiPriority="47"/>
						<w:lsdException w:name="Grid Table 3 Accent 1" w:uiPriority="48"/>
						<w:lsdException w:name="Grid Table 4 Accent 1" w:uiPriority="49"/>
						<w:lsdException w:name="Grid Table 5 Dark Accent 1" w:uiPriority="50"/>
						<w:lsdException w:name="Grid Table 6 Colorful Accent 1" w:uiPriority="51"/>
						<w:lsdException w:name="Grid Table 7 Colorful Accent 1" w:uiPriority="52"/>
						<w:lsdException w:name="Grid Table 1 Light Accent 2" w:uiPriority="46"/>
						<w:lsdException w:name="Grid Table 2 Accent 2" w:uiPriority="47"/>
						<w:lsdException w:name="Grid Table 3 Accent 2" w:uiPriority="48"/>
						<w:lsdException w:name="Grid Table 4 Accent 2" w:uiPriority="49"/>
						<w:lsdException w:name="Grid Table 5 Dark Accent 2" w:uiPriority="50"/>
						<w:lsdException w:name="Grid Table 6 Colorful Accent 2" w:uiPriority="51"/>
						<w:lsdException w:name="Grid Table 7 Colorful Accent 2" w:uiPriority="52"/>
						<w:lsdException w:name="Grid Table 1 Light Accent 3" w:uiPriority="46"/>
						<w:lsdException w:name="Grid Table 2 Accent 3" w:uiPriority="47"/>
						<w:lsdException w:name="Grid Table 3 Accent 3" w:uiPriority="48"/>
						<w:lsdException w:name="Grid Table 4 Accent 3" w:uiPriority="49"/>
						<w:lsdException w:name="Grid Table 5 Dark Accent 3" w:uiPriority="50"/>
						<w:lsdException w:name="Grid Table 6 Colorful Accent 3" w:uiPriority="51"/>
						<w:lsdException w:name="Grid Table 7 Colorful Accent 3" w:uiPriority="52"/>
						<w:lsdException w:name="Grid Table 1 Light Accent 4" w:uiPriority="46"/>
						<w:lsdException w:name="Grid Table 2 Accent 4" w:uiPriority="47"/>
						<w:lsdException w:name="Grid Table 3 Accent 4" w:uiPriority="48"/>
						<w:lsdException w:name="Grid Table 4 Accent 4" w:uiPriority="49"/>
						<w:lsdException w:name="Grid Table 5 Dark Accent 4" w:uiPriority="50"/>
						<w:lsdException w:name="Grid Table 6 Colorful Accent 4" w:uiPriority="51"/>
						<w:lsdException w:name="Grid Table 7 Colorful Accent 4" w:uiPriority="52"/>
						<w:lsdException w:name="Grid Table 1 Light Accent 5" w:uiPriority="46"/>
						<w:lsdException w:name="Grid Table 2 Accent 5" w:uiPriority="47"/>
						<w:lsdException w:name="Grid Table 3 Accent 5" w:uiPriority="48"/>
						<w:lsdException w:name="Grid Table 4 Accent 5" w:uiPriority="49"/>
						<w:lsdException w:name="Grid Table 5 Dark Accent 5" w:uiPriority="50"/>
						<w:lsdException w:name="Grid Table 6 Colorful Accent 5" w:uiPriority="51"/>
						<w:lsdException w:name="Grid Table 7 Colorful Accent 5" w:uiPriority="52"/>
						<w:lsdException w:name="Grid Table 1 Light Accent 6" w:uiPriority="46"/>
						<w:lsdException w:name="Grid Table 2 Accent 6" w:uiPriority="47"/>
						<w:lsdException w:name="Grid Table 3 Accent 6" w:uiPriority="48"/>
						<w:lsdException w:name="Grid Table 4 Accent 6" w:uiPriority="49"/>
						<w:lsdException w:name="Grid Table 5 Dark Accent 6" w:uiPriority="50"/>
						<w:lsdException w:name="Grid Table 6 Colorful Accent 6" w:uiPriority="51"/>
						<w:lsdException w:name="Grid Table 7 Colorful Accent 6" w:uiPriority="52"/>
						<w:lsdException w:name="List Table 1 Light" w:uiPriority="46"/>
						<w:lsdException w:name="List Table 2" w:uiPriority="47"/>
						<w:lsdException w:name="List Table 3" w:uiPriority="48"/>
						<w:lsdException w:name="List Table 4" w:uiPriority="49"/>
						<w:lsdException w:name="List Table 5 Dark" w:uiPriority="50"/>
						<w:lsdException w:name="List Table 6 Colorful" w:uiPriority="51"/>
						<w:lsdException w:name="List Table 7 Colorful" w:uiPriority="52"/>
						<w:lsdException w:name="List Table 1 Light Accent 1" w:uiPriority="46"/>
						<w:lsdException w:name="List Table 2 Accent 1" w:uiPriority="47"/>
						<w:lsdException w:name="List Table 3 Accent 1" w:uiPriority="48"/>
						<w:lsdException w:name="List Table 4 Accent 1" w:uiPriority="49"/>
						<w:lsdException w:name="List Table 5 Dark Accent 1" w:uiPriority="50"/>
						<w:lsdException w:name="List Table 6 Colorful Accent 1" w:uiPriority="51"/>
						<w:lsdException w:name="List Table 7 Colorful Accent 1" w:uiPriority="52"/>
						<w:lsdException w:name="List Table 1 Light Accent 2" w:uiPriority="46"/>
						<w:lsdException w:name="List Table 2 Accent 2" w:uiPriority="47"/>
						<w:lsdException w:name="List Table 3 Accent 2" w:uiPriority="48"/>
						<w:lsdException w:name="List Table 4 Accent 2" w:uiPriority="49"/>
						<w:lsdException w:name="List Table 5 Dark Accent 2" w:uiPriority="50"/>
						<w:lsdException w:name="List Table 6 Colorful Accent 2" w:uiPriority="51"/>
						<w:lsdException w:name="List Table 7 Colorful Accent 2" w:uiPriority="52"/>
						<w:lsdException w:name="List Table 1 Light Accent 3" w:uiPriority="46"/>
						<w:lsdException w:name="List Table 2 Accent 3" w:uiPriority="47"/>
						<w:lsdException w:name="List Table 3 Accent 3" w:uiPriority="48"/>
						<w:lsdException w:name="List Table 4 Accent 3" w:uiPriority="49"/>
						<w:lsdException w:name="List Table 5 Dark Accent 3" w:uiPriority="50"/>
						<w:lsdException w:name="List Table 6 Colorful Accent 3" w:uiPriority="51"/>
						<w:lsdException w:name="List Table 7 Colorful Accent 3" w:uiPriority="52"/>
						<w:lsdException w:name="List Table 1 Light Accent 4" w:uiPriority="46"/>
						<w:lsdException w:name="List Table 2 Accent 4" w:uiPriority="47"/>
						<w:lsdException w:name="List Table 3 Accent 4" w:uiPriority="48"/>
						<w:lsdException w:name="List Table 4 Accent 4" w:uiPriority="49"/>
						<w:lsdException w:name="List Table 5 Dark Accent 4" w:uiPriority="50"/>
						<w:lsdException w:name="List Table 6 Colorful Accent 4" w:uiPriority="51"/>
						<w:lsdException w:name="List Table 7 Colorful Accent 4" w:uiPriority="52"/>
						<w:lsdException w:name="List Table 1 Light Accent 5" w:uiPriority="46"/>
						<w:lsdException w:name="List Table 2 Accent 5" w:uiPriority="47"/>
						<w:lsdException w:name="List Table 3 Accent 5" w:uiPriority="48"/>
						<w:lsdException w:name="List Table 4 Accent 5" w:uiPriority="49"/>
						<w:lsdException w:name="List Table 5 Dark Accent 5" w:uiPriority="50"/>
						<w:lsdException w:name="List Table 6 Colorful Accent 5" w:uiPriority="51"/>
						<w:lsdException w:name="List Table 7 Colorful Accent 5" w:uiPriority="52"/>
						<w:lsdException w:name="List Table 1 Light Accent 6" w:uiPriority="46"/>
						<w:lsdException w:name="List Table 2 Accent 6" w:uiPriority="47"/>
						<w:lsdException w:name="List Table 3 Accent 6" w:uiPriority="48"/>
						<w:lsdException w:name="List Table 4 Accent 6" w:uiPriority="49"/>
						<w:lsdException w:name="List Table 5 Dark Accent 6" w:uiPriority="50"/>
						<w:lsdException w:name="List Table 6 Colorful Accent 6" w:uiPriority="51"/>
						<w:lsdException w:name="List Table 7 Colorful Accent 6" w:uiPriority="52"/>
						<w:lsdException w:name="Mention" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Smart Hyperlink" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Hashtag" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Unresolved Mention" w:semiHidden="1" w:unhideWhenUsed="1"/>
						<w:lsdException w:name="Smart Link" w:semiHidden="1" w:unhideWhenUsed="1"/>
					</w:latentStyles>
					<w:style w:type="paragraph" w:default="1" w:styleId="Normal">
						<w:name w:val="Normal"/>
						<w:qFormat/>
						<w:pPr>
							<w:bidi/>
						</w:pPr>
					</w:style>
					<w:style w:type="character" w:default="1" w:styleId="DefaultParagraphFont">
						<w:name w:val="Default Paragraph Font"/>
						<w:uiPriority w:val="1"/>
						<w:semiHidden/>
						<w:unhideWhenUsed/>
					</w:style>
					<w:style w:type="table" w:default="1" w:styleId="TableNormal">
						<w:name w:val="Normal Table"/>
						<w:uiPriority w:val="99"/>
						<w:semiHidden/>
						<w:unhideWhenUsed/>
						<w:tblPr>
							<w:tblInd w:w="0" w:type="dxa"/>
							<w:tblCellMar>
								<w:top w:w="0" w:type="dxa"/>
								<w:left w:w="108" w:type="dxa"/>
								<w:bottom w:w="0" w:type="dxa"/>
								<w:right w:w="108" w:type="dxa"/>
							</w:tblCellMar>
						</w:tblPr>
					</w:style>
					<w:style w:type="numbering" w:default="1" w:styleId="NoList">
						<w:name w:val="No List"/>
						<w:uiPriority w:val="99"/>
						<w:semiHidden/>
						<w:unhideWhenUsed/>
					</w:style>
					<w:style w:type="paragraph" w:styleId="ListParagraph">
						<w:name w:val="List Paragraph"/>
						<w:basedOn w:val="Normal"/>
						<w:uiPriority w:val="34"/>
						<w:qFormat/>
						<w:rsid w:val="002F6726"/>
						<w:pPr>
							<w:ind w:left="720"/>
							<w:contextualSpacing/>
						</w:pPr>
					</w:style>
					<w:style w:type="paragraph" w:styleId="Header">
						<w:name w:val="header"/>
						<w:basedOn w:val="Normal"/>
						<w:link w:val="HeaderChar"/>
						<w:uiPriority w:val="99"/>
						<w:unhideWhenUsed/>
						<w:rsid w:val="002F6726"/>
						<w:pPr>
							<w:tabs>
								<w:tab w:val="center" w:pos="4513"/>
								<w:tab w:val="right" w:pos="9026"/>
							</w:tabs>
							<w:spacing w:after="0" w:line="240" w:lineRule="auto"/>
						</w:pPr>
					</w:style>
					<w:style w:type="character" w:customStyle="1" w:styleId="HeaderChar">
						<w:name w:val="Header Char"/>
						<w:basedOn w:val="DefaultParagraphFont"/>
						<w:link w:val="Header"/>
						<w:uiPriority w:val="99"/>
						<w:rsid w:val="002F6726"/>
					</w:style>
					<w:style w:type="paragraph" w:styleId="Footer">
						<w:name w:val="footer"/>
						<w:basedOn w:val="Normal"/>
						<w:link w:val="FooterChar"/>
						<w:uiPriority w:val="99"/>
						<w:unhideWhenUsed/>
						<w:rsid w:val="002F6726"/>
						<w:pPr>
							<w:tabs>
								<w:tab w:val="center" w:pos="4513"/>
								<w:tab w:val="right" w:pos="9026"/>
							</w:tabs>
							<w:spacing w:after="0" w:line="240" w:lineRule="auto"/>
						</w:pPr>
					</w:style>
					<w:style w:type="character" w:customStyle="1" w:styleId="FooterChar">
						<w:name w:val="Footer Char"/>
						<w:basedOn w:val="DefaultParagraphFont"/>
						<w:link w:val="Footer"/>
						<w:uiPriority w:val="99"/>
						<w:rsid w:val="002F6726"/>
					</w:style>
				</w:styles>
			</pkg:xmlData>
		</pkg:part>
		<pkg:part pkg:name="/word/webSettings.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.webSettings+xml">
			<pkg:xmlData>
				<w:webSettings
					xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
					xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
					xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
					xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
					xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
					xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
					xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
					xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
					xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
					xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh">
					<w:optimizeForBrowser/>
					<w:allowPNG/>
				</w:webSettings>
			</pkg:xmlData>
		</pkg:part>
		<pkg:part pkg:name="/word/fontTable.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml">
			<pkg:xmlData>
				<w:fonts
					xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
					xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
					xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
					xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
					xmlns:w15="http://schemas.microsoft.com/office/word/2012/wordml"
					xmlns:w16cex="http://schemas.microsoft.com/office/word/2018/wordml/cex"
					xmlns:w16cid="http://schemas.microsoft.com/office/word/2016/wordml/cid"
					xmlns:w16="http://schemas.microsoft.com/office/word/2018/wordml"
					xmlns:w16sdtdh="http://schemas.microsoft.com/office/word/2020/wordml/sdtdatahash"
					xmlns:w16se="http://schemas.microsoft.com/office/word/2015/wordml/symex" mc:Ignorable="w14 w15 w16se w16cid w16 w16cex w16sdtdh">
					<w:font w:name="Times New Roman">
						<w:panose1 w:val="02020603050405020304"/>
						<w:charset w:val="00"/>
						<w:family w:val="roman"/>
						<w:pitch w:val="variable"/>
						<w:sig w:usb0="E0002EFF" w:usb1="C000785B" w:usb2="00000009" w:usb3="00000000" w:csb0="000001FF" w:csb1="00000000"/>
					</w:font>
					<w:font w:name="Calibri">
						<w:panose1 w:val="020F0502020204030204"/>
						<w:charset w:val="00"/>
						<w:family w:val="swiss"/>
						<w:pitch w:val="variable"/>
						<w:sig w:usb0="E4002EFF" w:usb1="C000247B" w:usb2="00000009" w:usb3="00000000" w:csb0="000001FF" w:csb1="00000000"/>
					</w:font>
					<w:font w:name="Arial">
						<w:panose1 w:val="020B0604020202020204"/>
						<w:charset w:val="00"/>
						<w:family w:val="swiss"/>
						<w:pitch w:val="variable"/>
						<w:sig w:usb0="E0002EFF" w:usb1="C000785B" w:usb2="00000009" w:usb3="00000000" w:csb0="000001FF" w:csb1="00000000"/>
					</w:font>
					<w:font w:name="B Titr">
						<w:panose1 w:val="00000700000000000000"/>
						<w:charset w:val="B2"/>
						<w:family w:val="auto"/>
						<w:pitch w:val="variable"/>
						<w:sig w:usb0="00002001" w:usb1="80000000" w:usb2="00000008" w:usb3="00000000" w:csb0="00000040" w:csb1="00000000"/>
					</w:font>
					<w:font w:name="B Nazanin">
						<w:panose1 w:val="00000400000000000000"/>
						<w:charset w:val="B2"/>
						<w:family w:val="auto"/>
						<w:pitch w:val="variable"/>
						<w:sig w:usb0="00002001" w:usb1="80000000" w:usb2="00000008" w:usb3="00000000" w:csb0="00000040" w:csb1="00000000"/>
					</w:font>
					<w:font w:name="Sakkal Majalla">
						<w:panose1 w:val="02000000000000000000"/>
						<w:charset w:val="00"/>
						<w:family w:val="auto"/>
						<w:pitch w:val="variable"/>
						<w:sig w:usb0="A0002027" w:usb1="80000000" w:usb2="00000108" w:usb3="00000000" w:csb0="000000D3" w:csb1="00000000"/>
					</w:font>
					<w:font w:name="Calibri Light">
						<w:panose1 w:val="020F0302020204030204"/>
						<w:charset w:val="00"/>
						<w:family w:val="swiss"/>
						<w:pitch w:val="variable"/>
						<w:sig w:usb0="E4002EFF" w:usb1="C000247B" w:usb2="00000009" w:usb3="00000000" w:csb0="000001FF" w:csb1="00000000"/>
					</w:font>
				</w:fonts>
			</pkg:xmlData>
		</pkg:part>
		<pkg:part pkg:name="/docProps/core.xml" pkg:contentType="application/vnd.openxmlformats-package.core-properties+xml" pkg:padding="256">
			<pkg:xmlData>
				<cp:coreProperties
					xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"
					xmlns:dc="http://purl.org/dc/elements/1.1/"
					xmlns:dcterms="http://purl.org/dc/terms/"
					xmlns:dcmitype="http://purl.org/dc/dcmitype/"
					xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
					<dc:title/>
					<dc:subject/>
					<dc:creator>aryatehran</dc:creator>
					<cp:keywords/>
					<dc:description/>
					<cp:lastModifiedBy>aryatehran</cp:lastModifiedBy>
					<cp:revision>2</cp:revision>
					<dcterms:created xsi:type="dcterms:W3CDTF">2024-09-11T14:02:00Z</dcterms:created>
					<dcterms:modified xsi:type="dcterms:W3CDTF">2024-09-11T14:02:00Z</dcterms:modified>
				</cp:coreProperties>
			</pkg:xmlData>
		</pkg:part>
		<pkg:part pkg:name="/docProps/app.xml" pkg:contentType="application/vnd.openxmlformats-officedocument.extended-properties+xml" pkg:padding="256">
			<pkg:xmlData>
				<Properties
					xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
					xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
					<Template>Normal.dotm</Template>
					<TotalTime>1</TotalTime>
					<Pages>1</Pages>
					<Words>57</Words>
					<Characters>331</Characters>
					<Application>Microsoft Office Word</Application>
					<DocSecurity>0</DocSecurity>
					<Lines>2</Lines>
					<Paragraphs>1</Paragraphs>
					<ScaleCrop>false</ScaleCrop>
					<Company/>
					<LinksUpToDate>false</LinksUpToDate>
					<CharactersWithSpaces>387</CharactersWithSpaces>
					<SharedDoc>false</SharedDoc>
					<HyperlinksChanged>false</HyperlinksChanged>
					<AppVersion>16.0000</AppVersion>
				</Properties>
			</pkg:xmlData>
		</pkg:part>
	</pkg:package>