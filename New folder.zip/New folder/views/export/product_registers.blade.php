@extends('layouts.user')
@section('content')
<div class="container">

<table class="table table-bordered">
    <tr>
        <th>تاریخ ثبت نام</th>
        <th>نام</th>
        <th>تلفن</th>
        <th>محصول</th>
        <th>هزینه</th>
        <th>هزینه پرداخت شده</th>
        <th>وضعیت انصرافی</th>
        <th>ثبت کننده</th>
        <th>توضیحات</th>
    </tr>
    @foreach($data as $register)
        <tr>
            <th>{{$register->created_at}}</th>
            <th>{{$register->user->name}}</th>
            <th>{{$register->user->phone}}</th>
            <th>{{$register->supplier->name}}</th>
            <th>{{$register->price}}</th>
            <th>{{calcPyamentPrices($register->approvedPayments)}}</th>
            <th>{{$register->leaveReason ? $register->leaveReason->option_value : ''}}</th>
            <th>{{$register->userInsert->name}}</th>
            <th>{{$register->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection