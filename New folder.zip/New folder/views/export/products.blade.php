@extends('layouts.user')
@section('content')
<div class="container">

<table class="table table-bordered">
    <tr>
        <th>ردیف</th>
        <th>بارکد</th>
        <th>نام</th>
        <th>تعداد موجودی</th>
        <th>واحد</th>
        <th>هزینه خرید</th>
        <th>هزینه فروش</th>
        <th>ارزش موجودی خرید</th>
        <th>ارزش موجودی فروش</th>
        <th>ارزش موجودی میانگین قیمت خرید</th>

        <th>دسته بندی</th>
        <th>شعبه</th>
        
        <th>تعداد فروش</th>
        <th>تعداد اولیه</th>
        <th>دفعات خرید</th>

    </tr>
    @foreach($data['data'] as $key => $product)
        <tr>
            <td>{{++$key}}</td>
            <td>{{$product->code}}</td>
            <td>{{$product->name}}</td>
            <td>{{$product->is_infinite ? 'فروش بی نهایت' : $product->quantity}}</td>
            <td>{{__($product->unit)}}</td>
            <td>{{number_format($product->buy_price)}}</td>
            <td>{{number_format($product->price)}}</td>
            <td>{{!$product->is_infinite ? number_format($product->buy_price * $product->quantity) : null}}</td>
            <td>{{!$product->is_infinite ? number_format($product->price * $product->quantity) : null}}</td>
            <td>{{!$product->is_infinite ? number_format(round($product->cost()->avg('price')) * $product->quantity) : null}}</td>

            <td>{{$product->category->pluck('name')->join(' و ')}}</td>
            <td>{{$product->branches->pluck('name')->join(' و ')}}</td>
            
            <td>{{$product->registers()->count()}}</td>
            <td>{{$product->primitive_quantity}}</td>
            <td>{{$product->cost()->count()}}</td>
 
        </tr>
    @endforeach
</table>
<table class="table table-bordered">
    <tr v-if="statistics">
        @foreach($data['statistics'] as $sp)
        <th>{{$sp['name']}}</th>
        @endforeach
    </tr>
    <tr>
        @foreach($data['statistics'] as $sp)
        <td>{{$sp['price']}}</td>
        @endforeach
    </tr>
</table>

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection