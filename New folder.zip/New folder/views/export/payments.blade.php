@extends('layouts.user')
@section('content')
<div class="container">

<table class="table table-bordered">
    <tr>
        <th>ردیف</th>
        <th>کد فیش</th>
        <th>تاریخ</th>
        <th>نام</th>
        <th>تلفن</th>
        <th>هزینه</th>
        <th>روش پرداخت</th>
        <th>برای</th>
        <th>وضعیت</th>
        <th>ثبت کننده</th>
        <th>توضیحات</th>
    </tr>
    @foreach($data['data'] as $key => $payment)
        <tr>
            <td>{{$key + 1}}</td>
            <td>{{$payment->code}}</td>
            <td dir="ltr">{{$payment->created_at}}</td>
            <td>{{$payment->paymentable->user->name}}</td>
            <td>{{$payment->paymentable->user->phone}}</td>
            <td>{{number_format($payment->gates->pluck('price')->sum())}}</td>
            <td>{{implode(' و ', getPaymentCashways($payment->gates))}}</td>
            <td>{{$payment->paymentable->supplier->name}}</td>
            <td>{{$payment->status ? 'تایید' : 'عدم تایید'}}</td>
            <th>{{$payment->userInsert->name}}</th>
            <th width="150">{{$payment->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>
<table class="table table-bordered">
    <tr v-if="statistics">
        @foreach($data['statistics'] as $sp)
        <th>{{$sp['option_value']}}</th>
        @endforeach
    </tr>
    <tr>
        @foreach($data['statistics'] as $sp)
        <td>{{$sp['price']}}</td>
        @endforeach
    </tr>
</table>

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection