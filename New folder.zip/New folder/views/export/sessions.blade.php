@extends('layouts.user')
@section('content')
<div class="container">

<table class="table table-bordered">
    <tr>
     <th>نام کلاس</th>
     <th>دوره</th>
     <th>مدرس</th>
     <th>وضعیت</th>
     <th>ساعت برگذاری</th>
     <th>ساعت پایان</th>
     <th>توضیحات</th>
    </tr>
    @foreach($data as $session)
        <tr>
            <td>{{$session->class->name}}</td>
            <td>{{$session->classCourse->course->name}}</td>
            <td>{{$session->teacher->name}}</td>
            <td>{{__($session->statusopt->option_value)}}</td>
            <td>{{$session->from}}</td>
            <td>{{$session->to}}</td>
            <th>{{$session->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection