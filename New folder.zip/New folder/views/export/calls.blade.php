@extends('layouts.user')
@section('content')
<div class="container">

<table class="table table-bordered">
    <tr>
        <th>تاریخ</th>
        <th>نام</th>
        <th>تلفن</th>
        <th>دوره</th>
        <th>دسته</th>
        <th>پیگیری</th>
        <th>ثبت کننده</th>
        <th>توضیحات</th>
    </tr>
    @foreach($data as $call)
        <tr>
            <th>{{$call->created_at}}</th>
            <th>{{$call->user->name}}</th>
            <th>{{$call->user->phone}}</th>
            <th>{{$call->callable->name}}</th>
            <th>{{$call->subject->name}} {{$call->pursuit_date ? '(پیگیری)' : null}}</th>
            <th>{{$call->pursuit_date}}</th>
            <th>{{$call->userInsert->name}}</th>
            <th>{{$call->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection