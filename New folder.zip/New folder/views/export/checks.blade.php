@extends('layouts.user')
@section('content')
<div class="container">

<table class="table table-bordered">
    <tr>
        <th>وضعیت</th>
        <th>تاریخ ثبت</th>
        <th>سریال چک</th>
        <th>صیاد</th>
        <th>هزینه</th>
        <th>تاریخ وصول</th>
        <th>بانک</th>
        <th>فیش</th>
        <th>نام</th>
        <th>تلفن</th>
        <th>برای</th>
        <th>ثبت کننده</th>
        <th>توضیحات</th>
    </tr>
    @foreach($data as $check)
        <tr>
            <td>{{ $check->status ? '✔' : '✖'}}</td>
            <th>{{$check->created_at}}</th>
            <th>{{$check->serial}}</th>
            <th>{{$check->saiyad}}</th>
            <th>{{$check->price}}</th>
            <th>{{$check->receipt}}</th>
            <th>{{$check->bank->option_value}}</th>
            <th>{{$check->payment->code}}</th>
            <th>{{$check->payment->paymentable->user->name}}</th>
            <th>{{$check->payment->paymentable->user->phone}}</th>
            <th>{{$check->payment->paymentable->course->name}}</th>
            <th>{{$check->payment->userInsert->name}}</th>
            <th>{{$check->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection