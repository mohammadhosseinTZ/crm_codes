@extends('layouts.user')
@section('content')
<div class="container">

<table class="table table-bordered">
    <tr>
        <th>ردیف</th>
        <th>وضعیت</th>
        <th>تاریخ</th>
        <th>هزینه برای</th>
        <th>نوع هزینه</th>
        <th>تنخواه|منبع مالی</th>
        <th>شعبه</th>
        <th>کدرهگیری</th>
        <th>کدپیگیری</th>
        <th>هزینه جز</th>
        <th>هزینه کل</th>
        <th>تعداد</th>
        <th>هزینه پرداخت شده</th>
        <th>روش پرداخت</th>
        <th>ثبت کننده</th>
        <th>فروشنده</th>
        <th>توضیحات</th>
    </tr>
    @foreach($data['data'] as $key => $cost)
        <tr>
            <td>{{$key + 1}}</td>
            <td>{{$cost->status ? 'تایید' : 'عدم تایید'}}</td>
            <td dir="ltr">{{$cost->created_at}}</td>
            <td>{{$cost->items->pluck('costableName')->join(' و ')}}</td>
            <td>{{$cost->items->pluck('key.name')->join(' و ')}}</td>
            <td>{{$cost->fund_card->label}}</td>
            <td>{{$cost->branch->name}}</td>
            <td>{{$cost->transaction_id}}</td>
            <td>{{$cost->order_id}}</td>
            <td>{{number_format($cost->items->pluck('price')->sum())}}</td>
            <td>{{number_format($cost->items->map(function($item){
                return $item->price * $item->quantity;   
            })->sum())}}</td>
            <td>{{$cost->items->pluck('quantity')->sum()}}</td>
            <td>{{number_format($cost->gates->pluck('price')->sum())}}</td>
            <td>{{implode(' و ', getPaymentCashways($cost->gates))}}</td>
            <th>{{$cost->userInsert->name}}</th>
            <th>{{$cost->seller ? $cost->seller->name : null}}</th>
            <th width="150">{{$cost->comment}}</th>
        </tr>
    @endforeach
</table>
<table class="table table-bordered">
    <tr v-if="statistics">
        @foreach($data['statistics'] as $sp)
        <th>{{$sp['option_value']}}</th>
        @endforeach
    </tr>
    <tr>
        @foreach($data['statistics'] as $sp)
        <td>{{$sp['price']}}</td>
        @endforeach
    </tr>
</table>

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection