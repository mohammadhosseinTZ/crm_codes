<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>پورتال آموزشگاهی</title>
 <!-- Scripts -->
 <script>
    window.local = @php echo file_get_contents(resource_path() . "/lang/en.json") @endphp;
    window.csrf = '{{csrf_token()}}';
    @auth()
     window.user = @json(auth()->user());
     window.api_token = '{{auth()->user()->api_token}}';
     window.PURSUIT_ID = {{PURSUIT_ID}}
     window.COURSE_ID_CAT = {{COURSE_ID_CAT}}
     window.CASTORDER = @json(CASTORDER);
     window.fdate = '{{date('Y/m/d H:i')}}'
     
     window.CANCELED_STATUS = {{CANCELED_STATUS}}
     window.DECLINED_STATUS = {{DECLINED_STATUS}}
    //  get main data

    window.calendarEvents = @json(getCalendarEvents());
    window.courses = @json(getCourses());
    window.costables = @json(getCostables());
    window.classRooms = @json(getClassRooms());
    window.categories = @json(getOptionSegment('category'));
    window.stores = @json(getOptionSegment('store'));
    window.gateWays = @json(getOptionSegment('payment_gates'));
    window.acquaintances = @json(getOptionSegment('acquaintance'));
    window.evidences = @json(getOptionSegment('evidence'));
    window.jobs = @json(getOptionSegment('job'));
    window.leaveReasons = @json(getOptionSegment('leave_reason'));
    window.return_reasons = @json(getOptionSegment('return_reason'));
    window.stores = @json(\App\Models\Store::all());
    window.places = @json(getOptionSegment('place'));
    window.reasons = @json(getOptionSegment('reason'));
    window.discountFor = @json(getOptionSegment('discount_for'));
    window.disciplines = @json(getOptionSegment('discipline'));
    window.statuses = @json(getOptionSegment('status'));
    window.classCourses = @json(getClassCourses());
    window.banks = @json(getOptionSegment('bank'));
    window.allPermissions = @json(getOptionSegment('permission'));
    window.optionTypes = @json(getOptionTypes());
    window.roles = @json(getOptionSegment('role'));
    window.person_messages = @json(PERSON_MESSAGES);
    window.branches = @json(getBranches());
    window.serviceList = @json(getServiceLists());
    window.services = @json(getServices());
    window.defined_enums = @json(config('enums'));
    window.keys = @json(getKeyLists());
    window.contracts = @json(getContracts());
    @foreach(getServiceLists() as $serviceItem)
    window.{{$serviceItem->en_name}}Category = @json(getCategoriesSegments($serviceItem->en_name));
    @endforeach
    @if(auth()->user()->role())
    window.permissions = @json(auth()->user()->role()->permissions->pluck('option_value'));
    @endif
     @endauth
    </script>

    @guest
        <script src="{{ asset('js/login.js') }}?ver={{env('APP_VERSION')}}" defer></script>
    @endguest


    <!-- Scripts -->
        <script src="{{ asset('js/app.js') }}?ver={{env('APP_VERSION')}}" defer></script>
   
    <!-- Fonts -->
    <link rel="stylesheet" href="{{ asset('css/font-awesome.css') }}" />

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}?ver={{env('APP_VERSION')}}" rel="stylesheet">
    @if(\Request::route()->getName() != 'user.export' && \Request::route()->getName() != 'single-export')
    <link href="{{ asset('css/front-v2.css') }}?ver={{env('APP_VERSION')}}" rel="stylesheet">
    @endif
    
</head>
<body>
    <div id="app">
        <loading></loading>
        <notifications></notifications>

        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                @auth
                <div id="nav-user-info">
                    <a href="" class="nav-user-img">
                        @if(Auth::user()->getMeta('personal_image', true)) <img class="user-image" src="{{get_image(Auth::user()->getMeta('personal_image', true))}}"> @endif
                    </a>
                    <a class="navbar-brand d-block text-center" href="{{ url('/') }}">
                        <small><b>{{ Auth::user()->name }}</b></small> 
                        @if(Auth::user()->role())
                        <br>
                        <small>{{Auth::user()->role()->label_value}}</small>
                        <br>
                        <small>شعبه: <b>{{Auth::user()->branch->name}}</b></small>
                        @endif
                    </a>
                    @if(Auth::user()->branch->market_url)
                    <a class="btn btn-sm btn-success d-flex align-items-center justify-content-center w-100 mb-3" target="_blank" href="{{ Auth::user()->branch->market_url }}">
                        ورود به سایت 
                        <span class="material-symbols-rounded">
                        store
                        </span>
                    </a>
                    @endif

                    <a class="btn btn-sm btn-danger d-flex align-items-center  justify-content-center d-block w-100 mb-3" target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSeJIZPAn1eNNwUjaAEmY1HZdTaCot2Lva9nTQ2dSn00S8umbQ/viewform?usp=sf_link">  
                    گزارش مشکلات و ارائه پیشنهادات
                    <span class="material-symbols-rounded">
                        edit_note
                        </span>  
                    </a>
                </div>
                @endauth
                <pursuitbutton></pursuitbutton>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto align-items-center">
                        <!-- Authentication Links -->
                        @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">
                                <div>
                                    ورود
                                    <span class="material-symbols-rounded"> login </span>    
                                </div>
                                </a>
                            </li>
                        @else
                    
                            <li class="nav-item"><router-link v-if="can('expert') || can('is_teacher')" class="nav-link" to="/">
                               <div>
                               پیشخوان
                               <span class="material-symbols-rounded"> dashboard </span>    
                               </div>
                            </router-link></li>
                            <li class="nav-item"><router-link v-if="can('expert')" class="nav-link" to="/calls">
                                <div>
                                تماس ها
                                <span class="material-symbols-rounded"> phone_callback </span>    
                            </div>
                            </router-link></li>

                            <li class="nav-item"><router-link v-if="can('see_uploads')" class="nav-link" to="/uploads">
                                <div>
                                 آپلود ها و مدارک
                                <span class="material-symbols-rounded"> upload </span>    
                            </div>
                            </router-link></li>
                            
                            <li class="nav-item dropdown" v-if="can('expert')">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <div>
                                        مشتریان
                                        <span class="material-symbols-rounded">supervisor_account</span>
                                    </div>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right text-right" aria-labelledby="navbarDropdown">
                                <router-link v-if="can('expert')" class="dropdown-item" to="/registers">ثبت نامی ها</router-link>
                                <router-link v-if="can('expert')" class="dropdown-item" to="/product-registers">خرید ها</router-link>
                                <router-link v-if="can('expert')" class="dropdown-item" to="/service-registers">خدمات</router-link>

                                </div>
                            </li>
                            
                            <li class="nav-item dropdown" v-if="can('expert')">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                   <div>
                                   تعاریف
                                   <span class="material-symbols-rounded"> apps </span>
                                   </div>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right text-right" aria-labelledby="navbarDropdown">
                                    <router-link class="dropdown-item" v-if="can('see_category')" to="/categories">دسته بندی ها</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_courses')" to="/courses">دوره ها</router-link>
                                    <router-link v-if="can('see_products')" class="dropdown-item" to="/products">محصولات</router-link>
                                    <router-link v-if="can('see_products')" class="dropdown-item" to="/static-products">کالای های ثابت  و مصرفی</router-link>
                                    <router-link v-if="can('see_services')" class="dropdown-item" to="/services">خدمات</router-link>
                                    <router-link class="dropdown-item" v-if="can('admin')" to="/classes">کلاس ها</router-link>
                                </div>
                            </li>

                            <li class="nav-item dropdown"  v-if="can('expert')">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <div>
                                    آموزشگاهی
                                    <span class="material-symbols-rounded"> event_note <span>
                                    </div>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right text-right" aria-labelledby="navbarDropdown">
                                    <router-link class="dropdown-item" v-if="can('see_sessions')" to="/sessions">جلسات</router-link>
                                    <router-link class="dropdown-item" v-if="can('manage_calendar')" to="/calendar">تقویم</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_class_course')" to="/classes-course">دوره و کلاس ها</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_phonebook')" to="/phonebook">دفترچه تلفن</router-link>
                                    <div v-if="can('see_exams') || can('see_user_exams')" class="dropdown-divider"></div>
                                    <router-link class="dropdown-item" v-if="can('see_exams')" to="/exams">آزمون ها</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_user_exams')" to="/user-exams">آزمون کاربران</router-link>

                                </div>
                            </li>
                            <li class="nav-item dropdown" v-if="can('expert') || can('see_payments') || can('see_costs') || can('add_check') || can('accounting_salary') || can('see_bank') || can('see_allocation')">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <div>
                                    مالی
                                    <span class="material-symbols-rounded"> payments </span>
                                    </div>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right text-right"  aria-labelledby="navbarDropdown">
                                    <router-link class="dropdown-item" v-if="can('see_payments')" to="/payments">فیش ها</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_costs')" to="/costs">هزینه ها</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_allocation')" to="/allocations">تقسیم بندی هزینه ها</router-link>
                                    <router-link class="dropdown-item" v-if="can('add_check')" to="/checks">چک ها</router-link>
                                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>حسابداری</a>

                                        <div class="dropdown-menu dropdown-menu-right text-right" aria-labelledby="navbarDropdown">
                                            <router-link v-if="can('accounting_salary')" class="dropdown-item" to="/accounting/salary/teachers-schema">حقوق مدرسین</router-link>
                                            <router-link v-if="can('see_bank')" class="dropdown-item" to="/accounting/banks">بانک ها و منابع مالی</router-link>
                                        </div>
                                </div>
                            </li>

                            <li class="nav-item dropdown" v-if="can('see_employee')">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <div>
                                    پرسنلی
                                    <span class="material-symbols-rounded"> groups </span>
                                    </div>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right text-right"  aria-labelledby="navbarDropdown">
                                    <router-link class="dropdown-item" v-if="can('see_employee')" to="/employees">فهرست پرسنل</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_employee')" to="/employees/rollcalls">گزارش حضور غیاب و مرخصی</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_employee')" to="/employee/salary"> حقوق و دستمزد</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_employee')" to="#">رویداد های پرسنلی</router-link>
                                    <router-link class="dropdown-item" v-if="can('see_employee')" to="#">قرارد های پرسنلی</router-link>
                                </div>
                            </li>

                            <li class="nav-item dropdown" v-if="can('admin')">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <div>
                                    ادمین
                                    <span class="material-symbols-rounded"> admin_panel_settings </span>
                                    </div>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right text-right" aria-labelledby="navbarDropdown">
                                    <router-link class="dropdown-item" to="/admin/branch">شعبات</router-link>
                                    <router-link class="dropdown-item" to="/admin/work-types">حوزه های فعالیت</router-link>
                                    <router-link class="dropdown-item" to="/admin/work-sections">بخش های کاری</router-link>
                                    <router-link class="dropdown-item" to="/admin/jobs">مشاغل</router-link>
                                    <router-link class="dropdown-item" to="/admin/definition">مدیریت تعاریف</router-link>
                                    <router-link class="dropdown-item" to="/cost-types">مدیریت هزینه ها</router-link>
                                    <router-link class="dropdown-item" to="/admin/reports">گزارشات</router-link>
                                    <router-link class="dropdown-item" to="/admin/survey">نظرسنجی</router-link>
                                    <router-link class="dropdown-item" to="/admin/survey-comments">نظرات نظرسنجی</router-link>
                                    <router-link v-if="can('see_complaint')" class="dropdown-item" to="/complaint">شکایت ها</router-link>
                                </div>
                            </li>

                            <li class="nav-item  dropdown">

                                <a class="nav-link" href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    <div>
                                    خروج
                                    <span class="material-symbols-rounded"> logout </span>
                                    </div>
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                           
                            </li>
                        @endguest
                        
                      
                    </ul>
                </div>
            </div>
        </nav>

        <section class="main-content w-100">
            <section id="mot-header">

                <h1 class="title">پورتال آموزشگاهی</h1>

                <button class="mot-navbar-toggler" type="button" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="{{ __('Toggle navigation') }}">

                    <span class="material-symbols-rounded">
                        menu
                    </span>
                </button>

            </section>
            <main class=" py-4 w-100 main">
                @yield('content')
            </main>
        </section>

        
    </div>
</body>
</html>
