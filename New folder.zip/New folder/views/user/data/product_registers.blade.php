<hr>
<h2 class="h5">خرید های {{$user->name}}</h2>
<table class="table table-bordered">
    <tr>
        <th>تاریخ ثبت نام</th>
        <th>محصول</th>
        <th>هزینه</th>
        <th>هزینه پرداخت شده</th>
        <th>وضعیت انصرافی</th>
        <th>توضیحات</th>
    </tr>
    @foreach($product_registers as $register)
        <tr>
            <th>{{$register->created_at}}</th>
            <th>{{$register->supplier->name}}</th>
            <th>{{$register->price}}</th>
            <th>{{calcPyamentPrices($register->approvedPayments)}}</th>
            <th>{{$register->leaveReason ? $register->leaveReason->option_value : ''}}</th>
            <th>{{$register->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>