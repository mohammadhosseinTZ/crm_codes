<hr>
<h2 class="h5">تماس های {{$user->name}}</h2>
<table class="table table-bordered">
    <tr>
        <th>تاریخ</th>
        <th>دوره</th>
        <th>دسته</th>
        <th>توضیحات</th>
    </tr>
    @foreach($calls as $call)
        <tr>
            <th>{{$call->created_at}}</th>
            <th>{{$call->callable->name}}</th>
            <th>{{$call->subject->name}} {{$call->pursuit_date ? 'پیگیری' : null}}</th>
            <th>{{$call->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>