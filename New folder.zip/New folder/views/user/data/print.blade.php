@extends('layouts.user')
@section('content')
<div class="container">
<table class="table table-bordered">
        <tr>
            <td>
                <strong>نام: </strong>
                <span>{{$user->name}}</span>
            </td>
            <td>
                <strong>تلفن: </strong>
                <span>{{$user->phone}}</span>
            </td>
            <td>
                <strong>تاریخ: </strong>
                <span>{{Verta::now()}}</span>
            </td>
        </tr>
    </table>

    @isset($datatoprint['data'])
        @include('user.data.data', ['user' => $user, 'data' => $datatoprint['data']])
    @endisset

    @isset($datatoprint['registers'])
        @include('user.data.registers', ['user' => $user, 'registers' => $datatoprint['registers']])
    @endisset

    @isset($datatoprint['product_registers'])
        @include('user.data.product_registers', ['user' => $user, 'product_registers' => $datatoprint['product_registers']])
    @endisset

    @isset($datatoprint['service_registers'])
        @include('user.data.service_registers', ['user' => $user, 'service_registers' => $datatoprint['service_registers']])
    @endisset

    @isset($datatoprint['payments'])
        @include('user.data.payments', ['user' => $user, 'payments' => $datatoprint['payments']])
    @endisset

    @isset($datatoprint['calls'])
        @include('user.data.calls', ['user' => $user, 'calls' => $datatoprint['calls']])
    @endisset

</div>
<script>
    window.addEventListener('load', () => {
       window.print()
    })
</script>
@endsection