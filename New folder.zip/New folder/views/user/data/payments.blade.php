<hr>
<h2 class="h5">فیش های {{$user->name}}</h2>
<table class="table table-bordered">
    <tr>
        <th>تاریخ</th>
        <th>کد فیش</th>
        <th>روش پرداخت</th>
        <th>هزینه</th>
        <th>برای</th>
        <th>وضعیت</th>
        <th>توضیحات</th>
    </tr>
    @foreach($payments as $payment)
        <tr>
            <td>{{$payment->created_at}}</td>
            <td>{{$payment->code}}</td>
            <td>{{implode(' و ', getPaymentCashways($payment->gates))}}</td>
            <td>{{$payment->gates->pluck('price')->sum()}}</td>
            <td>{{$payment->paymentable->supplier->name}}</td>
            <td>{{$payment->status ? 'تایید' : 'عدم تایید'}}</td>
            <th>{{$payment->getMeta('comment', true)}}</th>
        </tr>
    @endforeach
</table>