@extends('layouts.user')
@section('content')
<div>
<style>
    
        .main p {
            line-height: 1.8;
            font-size: 11px;
        }
        
        table,
        th,
        td {
            border-collapse: collapse;
            border: 1px solid black;
            text-align: right;
            
        }
  		
     
        .main th,
        .main td {
            padding: 5px;
        }
        
        @page: footer {
            display: none;
        }
        
        @page: header {
            display: none;
        }
        .full-height{
            margin: 15px auto;
           min-height: calc(100vh - 30px);
           width: calc(100vw - 30px);
        }
        .p-4.border {
            page-break-before: always;
        }

        p, strong, table tr, table td, table th, table *, table{
            font-size: 18px !important;
            padding: 1px;
            line-height: 1.4;
          font-family: bnazanin !important;
        }
      h3{
       font-family: btitrbold !important;
            font-weight: bold;
            font-size: 2rem;
      }

         main.py-4 {
              padding: 0 !important;
          }

        .border {
            border: double 6px !important;
        }
        p:not(.nft){
            text-align: justify;
        }
  
  		th,
        td {
          padding-right: 5px !important;
          padding-left: 5px !important;
        }
  
      .nft{
        font-family: btitrbold !important;
                font-weight: bold;
      }

      table td, table th {
        padding-top: 5px;
        padding-bottom: 5px;
    }
  
  strong.madeh {
    font-size: 22px !important;
    font-family: btitrbold !important;
}

          @font-face{
            font-family: bnazanin;
            src: url(/font/BNazanin.ttf) format('truetype');
          }

          @font-face{
            font-family: btitrbold;
            src: url(/font/btitrb.ttf) format('truetype');
          }

  			.nobold , .nobold *:not(strong){
   			font-weight: 100;           
 			 }
  			.nobold strong{font-weight: bold !important}
  
  .back p, .back strong{
  		font-size: 18px !important;
  }
  .back strong.madeh {
    font-size: 18px !important;
}

table.nft hr {
    margin: 3px 0px;
}
    </style>

@php

        if(isset($registers)){
            $regs = $registers;
        }else{
            $regs = $user->registers;
        }
@endphp

@foreach($regs as $register)

@php
  		$jdatey = Verta::now()->format('Y');
        $start =  '.......';
        $end =  '........';
        $day =   '........';
        $begin = '..........';
        $code = '..........';
        $regCount = '..........';
        $count = 3;
        $count -= $register->payments->count();
@endphp
<div class="full-height p-4 border border-dark">
                <div class="row align-items-center mb-2">
                    <div class="col text-right logo">
                        <img class="w-75" src="{{asset('images/download.jpg')}}" alt="">
                        <br>
                        <strong>گروه: {{$register->item->supplier->courses[0]->groups->pluck('name')->join(' و ')}}</strong>
                    </div>
        
                    <h3 class="col text-center ">قرارداد کارآموزی</h3>
        
                    <div class="col text-left">
                      <p class="nft text-left">تاریخ : {{date('Y/m/d', strtotime($register->created_at))}}</p>
                    </div>
                </div>
                    <p>دررعایت آئین نامه نحوه تشكیل و اداره مجتمع ها و آموزشگاه های فنی وحرفه ای آزاد وموسسات كارآموزی مصوب 1385 هیئت محترم وزیران قرارداد كارآموزی که به منظور تعیین میزان تعهدات كارآموز و آموزشگاه نسبت به یكدیگر منعقد می‌گردد.</p>
  					<strong class="madeh">ماده 1- مشخصات طرفین قرارداد:</strong>
                    <br>
                    <strong style="font-size: 22px !important;">
                      بشرح ذیل فیمابین آموزشگاه فنی و حرفه ای آریا تهران 2، به نشانی: خیابان توحید- نبش کوچه حاج رضایی – پلاک 75 – طبقه 1 – واحد 2 ☎️  66919636 - 66919635 - 66919634 كارآموز با مشخصات زیر منعقد می‌گردد.
  </strong>
                      <br>
                    <table class="nft mt-3 nobold" style="width:100%">
                        <tr>
                          <td colspan="2"><strong>نام و نام خانوادگی:</strong> {{$user->name}}</td>
                          <td><strong>نام پدر:</strong> {{$user->getMeta('father_name', true)}}</td>
                          <td><strong>{{is_iranian($user) ? 'کد ملی' : 'شماره پاسپورت' }}:</strong> {{$user->getMeta('national_code', true)}}</td>
                          <td><strong>سال تولد:</strong> {{date('Y/m/d', strtotime($user->getMeta('birth_date', true)))}}</td>
                          <td><strong>وضعیت تاهل:</strong> {{$user->getMeta('marital_status', true) == 1 ? "مجرد" : "متاهل"}}</td>
                        </tr>
                      	<tr>
                          <td><strong>شماره همراه:</strong> {{$user->phone}}</td>
                          <td colspan="2"><strong>تحصیلات:</strong> {{$user->getMeta('evidence', true) && $user->get_meta('evidence', true)->option ? $user->get_meta('evidence', true)->option->option_value : null}}</td>
                          <td><strong>رشته تحصیلی:</strong> {{$user->getMeta('colage_course', true) && $user->get_meta('colage_course', true)->option ? $user->get_meta('colage_course', true)->option->option_value : null}}</td>
                          <td><strong>شغل:</strong> {{$user->getMeta('job', true) && $user->get_meta('job', true)->option ? $user->get_meta('job', true)->option->option_value : null}}</td>  
                          <td><strong>شیوه آشنایی:</strong> {{$user->acquaintance ? $user->acquaintance->option_value : null}}</td>
                        </tr>
                        <tr>
                          <td colspan="1"><strong>شماره ثابت:</strong> {{$user->getMeta('fixed_phone', true)}}</td>
                          <td colspan="2"><strong>محل تولد:</strong> {{$user->getMeta('birth_place', true) && $user->get_meta('birth_place', true)->option ? $user->get_meta('birth_place', true)->option->option_value : null}}</td>
                          <td colspan="3"><strong>آدرس منزل:</strong> {{$user->getMeta('address', true)}}
                                <br>
                            <strong>منطقه:</strong> {{$user->getMeta('region', true)}}
                            </td>
                        </tr>
                        <tr>

                          <td colspan="6"> <strong>آدرس محل کار:</strong> {{$user->getMeta('job_address', true)}}</td>
                        </tr>
                        <tr>
                            <td colspan="6">
                              <strong>هدف از شرکت در دوره:</strong> 
                                 <br>
                              <strong>هدف از انتخاب آموزشگاه:</strong>
                            </td>
                        </tr>
                        <tr>
                          <td colspan="3"><strong>ایمیل:</strong> {{$user->email}}</td>
                          <td colspan="3"><strong>نام کاربری توسط آموزشگاه آریا تهران:</strong> {{$user->username}}</td>
                        </tr>
                    </table>
                    <br>
                    <br>
                    <strong  class="madeh">
                        ماده 2- موضوع و مدت قرارداد:</strong>
                    <p>
                      آموزش دوره: <strong>{{$register->item->supplier->courses[0]->name}}</strong> طبق استاندارد با کد: <strong>...........................</strong> و بخشنامه های سازمان آموزش فنی و حرفه ای تعیین می گردد.
        
                        <br>
                        كلاس حضوری عمومی <input type="checkbox" > &nbsp;&nbsp;&nbsp;&nbsp;
                        الکترونیکی <input type="checkbox"> &nbsp;&nbsp;&nbsp;&nbsp;
                        آنلاین <input type="checkbox" {{$register->is_online_course ? 'checked' : null}} > &nbsp;&nbsp;&nbsp;&nbsp;
                        خصوصی <input type="checkbox" > &nbsp;&nbsp;&nbsp;&nbsp;
                        نیمه خصوصی <input type="checkbox"> &nbsp;&nbsp;&nbsp;&nbsp;
                      به میزان ساعت <strong>{{'..........'}}</strong> و به تعداد ........ نفر كارآموز براساس طرح درس‌های معین شده و برنامه آموزشی اعلام شده توسط آموزشگاه از تاریخ ............................ به بعد اجرا خواهد شد و كارآموز از طریق درج امضا در برگ گزارش عملكرد اجرایی آموزشی و آمار
                        حضور و غیاب كارآموزان، حضور خود در جلسات مربوطه از كلاس (و اجرای موضوع قرارداد) را تائید خواهد كرد. برگزاری كلاس فعلاً از ساعت: <strong>{{$start}}</strong> تا ساعت: <strong>{{$end}}</strong> (روزهای <strong>{{$day}}</strong> ) و با کد <strong>{{$code}}</strong>  می‌باشد كه بنابر مقتضیات آموزشگاه قابل تغییر
                        است.
                    </p>
                    <p>
        
                        <strong> تبصره 1:</strong> در صورت ثبت نام در دوره های حضوری، در مواقعی که بنابر شرایط فورس ماژور امکان برگزاری کلاس حضوری وجود نداشته باشد،ادامه دوره تا زمان بازگشت وضعیت به حالت عادی به صورت آنلاین برگزار می شود.<br>
                        <strong>تبصره 2: </strong> میزان زمان اجرای دوره برای كلاس‌های عمومی، زمان مندرج در استاندارد مهارتی مربوط، خصوصی حداقل 50% و نیمه خصوصی حداقل 75% زمان كل استاندارد آموزشی مربوط و میزان زمان و محتوای اجرای دوره برای آموزش خاص برحسب درخواست
                        كتبی كارآموز خواهد بود.<br>
                        <strong  class="madeh"> ماده 3:</strong> <br> كلیه كلاس‌‌های خصوصی، نیمه خصوصی و آموزش های خاص در محل آموزشگاه برگزار می‌گردد. <br>
                        <strong  class="madeh">ماده 4- مبلغ قرارداد (هزینه كارآموزی):</strong><br> كارآموز موظف است مبلغ <strong>({{number_format($register->price)}})</strong> تومان شهریه مصوب سازمان را به عنوان شهریه بپردازد.
                    </p>
    
                    <table  class="nft" style="width:70%; margin:10px auto;">
                        <tr>
                            <th class="text-center">تاریخ قسط</th>
                            <th class="text-center">شماره فیش</th>
                            <th class="text-center">مبلغ شهریه</th>
                            <th class="text-center">میزان تخفیف (توضیحات)</th>
                        </tr>
                        @foreach($register->payments as $key => $payment)
                        <tr>
                            <th class="text-center">{{date('Y/m/d', strtotime($payment->created_at))}}</th>
                            <th class="text-center">{{$payment->code}}</th>
                            <th class="text-center">{{$payment->gates->pluck('price')->sum()}}</th>
                           @if($key == 0) <th class="text-center" rowspan="4">{{$payment->getMeta('comment', true)}}
                          @php
                            $discountFors = $register->meta()->with(['option' => function($q){ $q->with('meta'); }])->where('meta_key', 'discount_for')->get();
                            $siteDiscout = $register->getMeta('site_discount_compact', true);
                          @endphp
                           @foreach($discountFors as $key => $discount)
                                 درصد کسری/اضافه:  {{$discount->option->getMeta('discount_percent', true)}}%  <br>
                                 دلیل:  {{$discount->option->option_value}} <br>
                                 @if(count($discountFors) - 1 == $key)
                                 <hr>
                                 مبلغ:  {{number_format($register->discount_price)}} تومان <br>
                                 @endif
                                 @endforeach
                               
                                 @if($siteDiscout)
                                 <hr>
                                  @foreach(json_decode($siteDiscout) as $sd)
                                  {{ (int)$sd->amount }} {{ $sd->type == 'percent' ? 'درصد' : 'تومان' }} تخفیف با کد {{ $sd->source != 'site' ? 'معرف  ' : null}}: {{ $sd->name }} <br>                                  @endforeach
                                @endif
                                </th> @endif
                        </tr>
                        @endforeach


                        @for($i = 1; $i <= $count; $i++)
                        <tr>
                            <th>&nbsp;&nbsp;&nbsp;</th>
                            <th>&nbsp;&nbsp;&nbsp;</th>
                            <th>&nbsp;&nbsp;&nbsp;</th>
                        </tr>
                        @endfor


                    </table>
					<br>
                    <p>
                <strong  class="madeh">ماده 5:</strong> <br> از تاریخ تنظیم این قرارداد به بعد در صورتی كه كارآموز به هر دلیل یا علت از تحصیل در آموزشگاه و شركت در كلاس‌های آن منصرف و توانایی و امكان شركت در كلاس‌ها را قبل یا بعد از شروع دوره نداشته باشد،
                <strong style=" border-bottom: 1px solid; "> هیچ وجهی از شهریه دریافتی توسط آموزشگاه به كارآموز مسترد نخواهد شد</strong> و آموزشگاه به موجب این قرارداد اختیار خواهد داشت
                <strong style=" border-bottom: 1px solid; ">كه به هر گونه درخواست استرداد شهریه، ترتیب اثر ندهند.</strong>
            </p>
    </div>

    <div class="full-height  p-4 border border-dark back">
            
            <p>
                <strong  class="madeh">ماده 6- تعهدات كارآموز: </strong><br>
      			الف) کار آموزانی که قصد شرکت در آزمون سازمان فنی و حرفه ای را داشته و میخواهند مدرک دریافت کنند موظف هستند منابع درسی دوره آموزشی که در یک سی دی یا کتاب ارائه میگردد را خریداری و مورد مطالعه و استفاده قرار دهد. <br>
ب) در صورتی كه كارآموز عمداً یا در اثر سهل انگاری و یا به علت عدم توجه به دستورات مربی و مقررات كارگاهی و غیره خساراتی به سخت افزارها، تجهیزات، لوازم اندازه گیری، تابلوهای آموزش، ابزار، ساختمان و سایر وسایل یا اموال آموزشگاه وارد كند موظف است خسارات را (مطابق تشخیص و برآورد آموزشگاه) ظرف حداكثر یك هفته جبران نماید. <br>
ت) كارآموز موظف است از بحث یا عنوان كردن هر گونه مباحث غیر فنی و یا مطالبی كه با برنامه درسی، اهداف و شئونات آموزشگاه مغایرت داشته باشد جداً خودداری نماید. <br>
ث) كارآموز موظف است كلیه ضوابط اجتماعی، اخلاق و شئون اسلامی را در محیط آموزشگاه دقیقا رعایت نماید. <br>
ج) ایام یا جلسات غیبت موجه و یا غیر ضرور كارآموز (كه در برگه‌های آمار حضور و غیاب كلاس مربوطه منعكس و درج می‌گردد.) جزء زمان آموزش اجرا شده از موضوع این قرارداد منظور می‌شود و آموزشگاه تعهدی مبنی بر جبران آن‌ها نخواهد داشت. درصورتی كه میزان غیبت از 3 جلسه متوالی و یا متجاوز از 15/1كل تعداد جلسات دوره (بطور متناوب)گردد آموزشگاه مختار است كه از حضور كارآموز جلوگیری نموده و این قرارداد را (بدون التزام به استرداد هیچ مبلغی) ملغی نماید.<br>
د) كارآموز می‌باید رأس ساعت شروع به محوطه آموزشگاه وارد و بلافاصله پس از پایان جلسات درسی روزانه، محوطه آموزش را ترك نموده و از هرگونه رفتار بی انظباطی و اختلال در كلاس‌ها یا كارگاه‌ها خودداری نماید. <br>
ه) كارآموز بایستی هرگونه نظرات پیشنهادات، انتقادات اصولی خود را به طور فردی و در خارج از كلاس یا كارگاه‌های آموزشی با مدیر آموزشگاه مطرح نماید و از القا خواسته خود به كارآموزان دیگر جداً پرهیز نماید. <br>
و) كارآموز موظف است تكالیف درسی كه از طرف مربیان آموزشگاه به او داده می‌شود را انجام داده و مطالب آموزشی تدریس شده را مطالعه و فراگیری نماید و از طرح سوالات بی محتوی و متوقف كننده برنامه اصلی كلاس پرهیز نماید. <br>
ز) سایر مقررات پذیرش و ثبت نام، شرایط و نحوه اجرای برنامه آموزشی، مقررات كار در كارگاه و آزمون جداً از مطالب مندرج در قرارداد به اطلاع و تائید كارآموز رسیده یا می‌رسد و جزو لاینفك تعهدات مشمول این قرارداد محسوب و بر ذمه كارآموز است.<br>
ح) در صورتی كه كارآموز به تشخیص آموزشگاه به هر یك از تعهدات فوق عمل ننماید، آموزشگاه می‌تواند بدون استرداد شهریه پرداخت شده توسط كارآموز، از ادامه تحصیل و حضور وی در آموزشگاه ممانعت كرده و این قرارداد را فسخ نماید و هر كارآموز موجب تضییع وقت آموزشگاه و یا وارد شدن خساراتی بیش از مبلغ این قرارداد (یا باقیمانده آن) شود موظف به جبران آن است.<br>
چ)در صورتی که کارآموز بعد از پایان دوره تا 6 ماه جهت ثبت نام آزمون مراجعه ننماید؛ برای شرکت در آزمون دوباره باید در دوره آموزشی مربوطه ثبت نام کند .<br>
و چنانچه کارآموز مدعی است ؛ نیاز به آموزش مجدد ندارد ؛ باید 20 درصد شهریه دوره مربوطه را جهت انجام هزینه های ثبت نام مجدد و رد نمودن آمار حضور به آموزشگاه پرداخت نماید.
خ) کارآموز باوجود دوره آنلاین مشابه و اطلاع از شرایط وجود بیماری کرونا  و  یا شرایط نامساعد اجتماعی، شرکت حضوری در کلاس فوق را با رعایت موارد ایمنی و بهداشتی مثل استفاده از ماسک و دستکش و رعایت تمام پروتکل‌های بهداشتی می‌پذیرد.<br>
همچنین موافقت می‌نماید با توجه به شرایط و قوانین مرتبط با کرونا و پروتکل‌های بهداشتی و البته شرایط نامساعد اجتماعی هرگاه آموزشگاه آریا تهران صلاح بداند دوره فعلی و فوق ذکر را به‌صورت آنلاین شرکت کرده و تا اطلاع ثانوی از طرف آموزشگاه به‌صورت آنلاین از مفاد آموزشی دوره استفاده نماید.

      		</p>
            <p>
                <strong  class="madeh">ماده 7- تعهدات آموزشگاه:</strong><br>
              الف) آموزشگاه موظف است كارآموزان متقاضی برگزاری كلاس‌های عمومی، خصوصی و آموزش خاص را پیش از ثبت نام به طور كامل از شرایط آموزش ، شهریه و ..... (این شرایط می‌باید كتبا یا به صورت دفترچه راهنمای ثبت نام آموزشگاه‌ها به طور واضح و شفاف درج گردد و در معرض دید كارآموز قرار گرفته و یا به وی ارائه شود) مطلع نماید و درخواست ثبت نام در كلاس‌های خصوصی و نیمه و خصوصی و آموزش خاص را كتبا از كارآموز اخذ نماید.<br>
ب) آموزشگاه موظف است كد استاندارد و ساعت كل آموزش (تئوری و عملی) را براساس استاندارد و مطابق تبصره 1 این قرارداد (در كلاس‌های عمومی براساس ساعت استاندارد، خصوصی حداقل 50% زمان تئوری و 50% زمان عملی با پوشش كلیه سرفصل‌های آموزشی و در كلاس‌های نیمه خصوصی حداقل 75% زمان تئوری و 75% زمان عملی با پوشش كلیه سرفصل‌های آموزشی ذكر شده در استاندارد و آموزش خاص بر حسب درخواست كتبی كارآموز) را به اطلاع كارآموز برساند و در قرارداد نیز ذكر نماید. <br>
ج) آموزشگاه موظف به معرفی و ثبت آمار كارآموزان كلاس‌های عمومی، خصوصی و نیمه خصوصی و آموزش‌های خاص حسب ضوابط مربوط و از طریق پرتال سازمان می‌باشد.<br>
د) آموزشگاه موظف به معرفی كلیه متقاضیان كلاس‌های عمومی، خصوصی و نیمه خصوصی جهت شركت در آزمون‌های مربوط برحسب جدول زمانبدی اعلام شده توسط سازمان می‌باشد و همچنین موظف است برای كارآموزان دوره‌های آموزش خاص، گواهی حضور در دوره آموزشی مطابق با فرمت تعیین شده توسط اداره كل ارزشیابی مهارت و تایید مركز معین دولتی مربوط صادر نماید. <br>
ه) آموزشگاه تا پایان مدت این قرارداد موظف به اجرای موضوع قرارداد (آموزش) می‌باشد.<br>
              <strong>تبصره:</strong> در صورتیكه به هر علت آموزشگاه ناچار شود قبل از خاتمه مدت قرارداد و پیش از اجرای كامل موضوع قرارداد بدون توافق كارآموز دوره آموزشی مربوطه را به مدتی بیشتر از یك ماه متوالی تعطیل نماید در صورت درخواست كارآموز، آموزشگاه موظف است ایامی كه كارآموز در كلاس حضور یافته است را (به نسبت كل جلسات و مبلغ موضوع قرارداد) محاسبه نموده و مبلغ 400000ریال (بالاسری و ثبت نام) را به آن افزوده و این مبلغ را از كل شهریه دریافت شده از كارآموز كسر نموده و باقیمانده را به كارآموز تسویه حساب به عمل آورد. در این صورت كلیه تعهدات طرفین نسبت به یكدیگر از هر لحاظ منتفی شده و این قرارداد ملغی خواهد شد. <br> 
و) در صورتی كه موضع این قرارداد جزو استانداردهای سازمان آموزش فنی و حرفه ای بوده و كارآموز واجد شرایط در آزمون نهایی اخذ گواهینامه رسمی باشد، آموزشگاه موظف است در صورت تقبل هزینه‌های قانونی متعلقه توسط كارآموز، جهت شركت در آزمون كارآموز را به سازمان (اداره كل) معرفی نماید.<br>
            </p>
      <p><strong  class="madeh">ماده 8:</strong><br> این قرارداد مشتمل بر 8 ماده و 3 تبصره می‌باشد و در 2 نسخه بدون قلم خوردگی در تاریخ  &nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;/{{$jdatey}}    توسط طرفین تائید، امضا و مبادله گردید و هر نسخه حكم واحد را دارند و طرفین شرعاً و عرفاً متعهد به اجرای مفاد آن هستند. </p>
		
      <div class="d-flex">
        <div class="flex-fill">
          <strong>
          محل امضا كارآموز (یا ولی و سرپرست قانونی او) <br>
            نام  نام خانوادگی: <br>
            تاریخ: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/{{$jdatey}}
          </strong>
        </div>
        <div class="flex-fill">
        <strong>
          	محل امضا و مهر آموزشگاه (مدیر آموزشگاه)<br>
            نام و نام خانوادگی:<br>
          	تاریخ: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/{{$jdatey}}         
          </strong>
        </div>
      </div>
</div>
    @endforeach
</div>



<script>
    document.addEventListener('contextmenu', event => event.preventDefault());
  
  document.addEventListener("keydown", function (e) {
      //document.onkeydown = function(e) {
      // "I" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
          disabledEvent(e);
      }
      // "J" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
          disabledEvent(e);
      }
      // "S" key + macOS
      if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
          disabledEvent(e);
      }
      // "U" key
      if (e.ctrlKey && e.keyCode == 85) {
          disabledEvent(e);
      }
      // "F12" key
      if (event.keyCode == 123) {
          disabledEvent(e);
      }
  }, false);
  function disabledEvent(e) {
      if (e.stopPropagation) {
          e.stopPropagation();
      } else if (window.event) {
          window.event.cancelBubble = true;
      }
      e.preventDefault();
      return false;
  }

window.addEventListener('load', () => {
  window.print()
})
</script>
@endsection