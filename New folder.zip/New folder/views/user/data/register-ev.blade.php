<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<style>
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        direction: rtl;
    }
    .fn{
        font-family: nastaligh;
        line-height: 1.5;
    }
    .fbt{
        font-family: btitrbold;
    }
    .fbm{
        font-family: bnazanin;
    }
    .fbm{
        font-family: bmitra;
    }
        @page: footer {
            display: none;
        }
        
        @page: header {
            display: none;
        }
        @page {
        size: A4;
        margin: 0;
        }

        .main-container{
            width: 210mm;
            height: 297mm;
            margin: auto;
            padding: 70px 75px;
            background: url("{{asset('images/ev2.png')}}");
            background-size: 100% 100%;
            background-repeat: no-repeat;
            background-position: center center;

            display: flex;
            flex-direction: column;
        }

        .main-container .head{
            display: flex;
            justify-content: space-between;
            font-family: bnazanin;
        }

        .main-container .head > span{
            flex: 1;
            text-align: center;
        }

        .main-container .head .s{
            text-align: right;
            color: rgb(142, 169, 73);
            font-size: 18px;
        }
        .main-container .head .c{
            padding-left: 50px;
            font-size: 18px;
        }
        .main-container .head .e{
            text-align: right;
            font-size: 18px;
            margin-left: -50px;
        }

        .main-container .tm{
            text-align: center;
            font-size: 18px;
        }
        .main-container .tm h1{
            color: rgb(142, 169, 73);
            font-size: 36px;
        }
        .main-container .tm h2{
            margin-top: 20px;
            font-size: 28px;
        }

        .main-container .main{
            margin-top: 50px;
            font-size: 22px;
        }

        .main-container .main .content {
            position: relative;
        }

        .main-container .main img.personal-image {
            width: 130px;
            position: absolute;
            left: 20px;
            top: 0;
            border: 2px solid #333;
        }

        .main-container .content.mt{
            margin-top: 50px;
        }

        .main-container .footer {
            align-self: flex-end;
            justify-self: flex-end;
            margin-top: auto;

            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
        }

        .main-container .footer .em{
            padding-bottom: 35px;
        }
        
        h1 small {
        font-size: 13px;
    }
        @font-face{
            font-family: bnazanin;
            src: url(/font/BNazanin.ttf) format('truetype');
        }

        @font-face{
            font-family: btitrbold;
            src: url(/font/btitrb.ttf) format('truetype');
        }

        @font-face{
            font-family: nastaligh;
            src: url(/font/IranNastaliq.ttf) format('truetype');
        }

        @font-face{
            font-family: bmitra;
            src: url(/font/B-Mitra_0.ttf) format('truetype');
        }
</style>
<div class="main-container">
        <div class="head">
            <span class="s">
                <div><span class="fn">شماره مجوز: </span> 29721</div>
                <div><span class="fn">کد استعلام: </span> {{$register->id}}</div>
        </span>
            <span class="c fbm"><strong>جمهوری اسلامی ایران</strong></span>
            <span class="e">
                <div class="count"><span class="fn">شماره: </span> <span dir="rtl">1401/2-{{time()}}</span></div>
                <div class="date"><span class="fn">تاریخ: </span> {{date('Y/m/d', strtotime(toJalali($register->getMeta('rescieve_date', true), '-', '/')))}}</div>
            </span>
        </div>
        <div class="tm">
        <h1 class="fbt">آموزشگاه آریا تهران <small>شعبه {{$register->item->supplier->branches->pluck('id')->contains(2) ? 2 : 1}}</small></h1>
            <strong class="fbm">فناوری اطلاعات، امور مالی و بازرگانی، خدمات تغذیه، صنایع غذایی، صنایع خودرو، خدمات آموزشی، گردشگری، الکترونیک، مراقبت زیبایی<br> با امتیاز رسمی از سازمان فنی و حرفه ای و وزارت کار و امور اجتماعی</strong>
            <h2 class="fbt">گواهی شرکت در دوره</h2>
        </div>
        <div class="main fbm">
           <div class="content">
            گواهی می شود 
            {{$register->user->gender == 1 ? 'سرکار خانم' : 'جناب آقای'}}: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <strong>{{$register->user->name}}</strong> <br><br>
            فرزند: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <strong>{{$register->user->getMeta('father_name', true)}}</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            متولد: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <strong>{{str_replace('-', '/', $register->user->getMeta('birth_date', true))}}</strong>  <br><br> 
            با {{is_iranian($register->user) ? 'کد ملی' : 'شماره پاسپورت' }}: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  
            <strong>{{$register->user->getMeta('national_code', true)}}</strong>

            <img src="{{get_image($register->user->getMeta('personal_image', true))}}" class="personal-image" alt="">
           </div>

           <div class="content mt">
                مطابق استاندارد سازمان فنی و حرفه ای &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                <strong>{{$register->course->standard_code}}</strong> <br><br>
                به مدت: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                <strong>{{$register->course->standard_hours}} ساعت آموزشی</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                دوره مهارت: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <strong>{{$register->course->standard_name}}</strong>   <br><br>
                شامل: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <strong>{{$register->course->standard_headlines}}</strong>  <br><br>
                را تئوری و عملی با کسب مجموع نمره: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <strong>{{$register->score}}</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                به حروف: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <strong>{{numbertoword($register->score)}}</strong> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                از &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <strong>100</strong> <br><br>
                در این آموزشگاه، واقع درشهرستان تهران با موفقیت به پایان رسانده <br><br>

                <strong>تذکر مهم: </strong>
                گواهی شرکت در این دوره آموزشی معادل آموزش های طی شده به منظور دریافت گواهینامه ارزشیابی مهارت سازمان آموزش فنی و حرفه ای نخواهد بود.
           </div>
        </div>

        <div class="footer">
            <div class="code fbm">
                 برای استعلام به سایت aryatehran.com مراجعه نمایید
            </div>
            <strong class="em fn">مهر و امضا مسئول آموزشگاه</strong>
        </div>
        
</div>

</body>
</html>