@extends('layouts.user')
@section('content')
<style>
        @page: footer {
            display: none;
        }
        
        @page: header {
            display: none;
        }

        table.table tr:not(:first-child):nth-child(odd) {
            background: unset;
        }
    
        .green {
            background-color: #8cff8f47 !important;
        }

        .red {
            background-color: #ff470061 !important;
        }
        table tr td, table tr th{
            font-size: 14px;
        }
        table { page-break-inside:auto }
        tr    { page-break-inside:avoid; page-break-after:auto }
</style>

<div class="container">
        <h2 class="title text-center">کارنامه آزمون</h2>
        <table class="table-bordered w-100">
            <tr>
                <td class="p-2"><strong>نام: </strong><span>{{$user->name}}</span></td>
                <td class="p-2"><strong>آزمون: </strong><span>{{$data->exam->name}}</span></td>
                <td class="p-2"><strong>تاریخ: </strong><span>{{$data->created_at}}</span></td>
            </tr>
            <tr>
                <td class="p-2"><strong>تعداد سوالات: </strong><span>{{$data->exam->questions}}</span></td>
                <td class="p-2"><strong>نمره از 100: </strong><span>{{$data->score}}</span></td>
                <td class="p-2"><strong>وضعیت: </strong><span>{{$data->score >= 50? 'قبول' : 'مردود'}}</span></td>
            </tr>
        </table>
        <table class="table table-borderd mt-4 w-100">
            <tr>
                <th>سوال</th>
                <th>پاسخ</th>
                <th>پاسخ درست</th>
            </tr>
            @foreach(json_decode($data->report,true) as $key => $answer)
                    @php
                        $question = \App\Models\ExamQuestion::find($key);
                        $answer_formatted = 'choose_' . $answer;
                    @endphp
                    @if($question && $question = $question->toArray())
                        <tr class="@if($answer == $question['answer']) green @else red @endif">
                            <td width="70%">{{$question['question']}}</td>
                            <td>{{$question[$answer_formatted]}}</td>             
                            <td>{{$question['choose_' . $question['answer']]}}</td>             
                        </tr>
                    @endif
            @endforeach
        </table>
</div>
@endsection