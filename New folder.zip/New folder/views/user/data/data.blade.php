<hr>
<h2 class="h5">اطلاعات {{$user->name}}</h2>

<table class="table table-bordered">
    <tr>
        <td><strong>کد ملی:</strong><span>{{$user->getMeta('national_code', true)}}</span></td>
        <td><strong>نام پدر:</strong><span>{{$user->getMeta('father_name', true)}}</span></td>
        <td><strong>شیوه آشنایی:</strong><span>{{$user->acquaintance ? $user->acquaintance->option_value : ''}}</span></td>
        <td><strong>تلفن:</strong><span>{{$user->getMeta('fixed_phone', true)}}</span></td>
    </tr>
    <tr>
        <td><strong>آدرس:</strong><span>{{$user->getMeta('address', true)}}</span></td>
        <td><strong>تاریخ تولد:</strong><span>{{$user->getMeta('birth_date', true)}}</span></td>
        <td><strong>محل تولد:</strong><span>{{$user->getMeta('birth_place', true) ? $user->get_meta('birth_place', true)->option->option_value : ""}}</span></td>
        <td><strong>شهر:</strong><span></span>{{$user->get_meta('city', true) ? $user->get_meta('city', true)->option->option_value : ''}}</td>
    </tr>
    <tr>
        <td><strong>رشته تحصیلی:</strong><span>{{$user->get_meta('colage_course', true) ? $user->get_meta('colage_course', true)->option->option_value : ''}}</span></td>
        <td><strong>مدرک:</strong><span>{{$user->get_meta('evidence', true) ? $user->get_meta('evidence', true)->option->option_value : ''}}</span></td>
        <td><strong>شغل:</strong><span>{{$user->getMeta('job', true) ? $user->get_meta('job', true)->option->option_value : ''}}</span></td>
        <td><strong>آدرس محل کار:</strong><span>{{$user->getMeta('job_address', true)}}</span></td>
    </tr>
    <tr>
        <td><strong>وضعیت تاهل:</strong><span>{{$user->getMeta('marital_status', true) ? 'متاهل' : 'مجرد' }}</span></td>
        <td><strong>منطقه:</strong><span>{{$user->getMeta('region', true)}}</span></td>
    </tr>
</table>