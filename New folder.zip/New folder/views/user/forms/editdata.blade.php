@extends('layouts.user')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
            <form id="user-info-form" enctype="multipart/form-data">
            <input type="hidden" id="token" name="_token" value="<?php  echo $user->api_token; ?>">
                        <table class="table mt-1">
                                <tr>
                                    <th>کد ملی</th>
                                    <td><input class="form-control" type="text" name="national_code" value="{{$user->getMeta('national_code',true)}}"></td>
                                </tr>
                                <tr>
                                    <th>نام پدر</th>
                                    <td><input class="form-control" type="text" name="father_name" value="{{$user->getMeta('father_name',true)}}"></td>
                                </tr>
                                <tr>
                                    <th>نحوه آشنایی</th>
                                    <td>
                                    <select class="select2 window_acquaintances form-control" name="acquaintance" value="{{$user->acquaintance_id}}"></select>                                    </td>
                                    
                                </tr>
                                <tr>
                                    <th>تلفن ثابت</th>
                                    <td><input class="form-control" type="text" name="fixed_phone" value="{{$user->getMeta('fixed_phone',true)}}"></td>
                                </tr>
                                <tr>
                                    <th>آدرس محل سکونت</th>
                                    <td><input class="form-control" type="text" name="address" value="{{$user->getMeta('address',true)}}"></td>
                                </tr>
                                <tr>
                                    <th>تاریخ تولد</th>
                                    <td>
                                    <input data-jdp name="birth_date" placeholder="تاریخ تولد" name="birth_date" value="{{$user->getMeta('birth_date',true)}}" class="form-control">
                                    </td>
                                </tr>
                                <tr>
                                    <th>استان محل تولد</th>
                                    <td>
                                    <select class="select2 window_places form-control" name="birth_place" value="{{$user->getMeta('birth_place',true)}}"></select>                                    </td>
                                    </td>
                                </tr>
                                <tr>
                                    <th>استان محل سکونت</th>
                                    <td>
                                    <select class="select2 window_places form-control" name="city" value="{{$user->getMeta('city',true)}}"></select>                                    </td>
                                    </td>
                                </tr>
                                <tr>
                                    <th>رشته تحصیلی</th>
                                    <td>
                                    <select class="select2 window_disciplines form-control" name="colage_course" value="{{$user->getMeta('colage_course',true)}}"></select>                                    </td>
                                    </td>
                                </tr>
                                <tr>
                                    <th>مدرک تحصیلی</th>
                                    <td>
                                    <select class="select2 window_evidences form-control" name="evidence" value="{{$user->getMeta('evidence',true)}}"></select>                                    </td>
                                    </td>
                                </tr>

                                <tr>
                                    <th>شغل</th>
                                    <td>
                                    <select class="select2 window_jobs form-control" name="job" value="{{$user->getMeta('job',true)}}"></select>                                    </td>
                                    </td>
                                </tr>
                                <tr>
                                    <th>آدرس محل کار</th>
                                    <td><input class="form-control" type="text" name="job_address" value="{{$user->getMeta('job_address',true)}}"></td>
                                </tr>
                                <tr>
                                    <th>وضعیت تاهل</th>
                                    <td>
                                        <select class="form-control" id="acquaintances" name="marital_status" value="{{$user->getMeta('marital_status',true)}}">
                                            <option value="0">مجرد</option>
                                            <option value="1">متاهل</option>
                                        </select>    
                                    </td>
                                </tr>
                                <tr>
                                    <th>منطقه شهر محل زندگی</th>
                                    <td>
                                        <input type="text"  class="form-control" name="region" value="{{$user->getMeta('region',true)}}">
                                    </td>
                                </tr>
                                <tr>
                                    <th>عکس پرسنلی(برای دریافت مدرک الزامی است)</th>
                                    <td>
                                        <a class="btn-link" href="/images/approve-image.webp" target="_blank">مشاهده عکس قابل قبول</a>
                                        <input type="file" accept="image/*"  class="form-control select-image" name="personal_image">
                                        @if($user->getMeta('personal_image',true))
                                            <img src="{{get_image($user->getMeta('personal_image',true))}}" class="preview mt-2">
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <th>تصویر کارت ملی (برای دریافت مدرک الزامی است)</th>
                                    <td>
                                        <input type="file" accept="image/*" class="form-control select-image" name="national_cart_image">
                                        @if($user->getMeta('national_cart_image',true))
                                            <img src="{{get_image($user->getMeta('national_cart_image',true))}}" class="preview mt-2">
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <th>تصویر صفحه اول شناسنامه(برای دریافت مدرک الزامی است)</th>
                                    <td>
                                        <input type="file" accept="image/*" class="form-control select-image" name="certificate_image">
                                        @if($user->getMeta('certificate_image',true))
                                            <img src="{{get_image($user->getMeta('certificate_image',true))}}" class="preview mt-2">
                                        @endif
                                    </td>
                                </tr>

                        </table>
                        <input type="submit" class="btn btn-primary" value="ثبت اطلاعات"> 
                    </form>
            </div>
        </div>
    </div>
</div>
@endsection
