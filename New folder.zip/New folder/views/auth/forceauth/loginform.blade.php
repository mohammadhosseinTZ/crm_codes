<div class="force-login-body">
    <h3>ورود به حساب کاربری</h3>
    <div class="wrapper">

        <form id="register" class="my_captcha_form" data-redirect="{{url('/')}}" tabindex="502"
            action="{{ route('login-code') }}" method="POST">
            @csrf
            <div class="phone">
                <label>تلفن</label>
                <input id="phone" type="tel" class="form-control" name="phone" placeholder="09120000000" required>
                <span class="feedback" role="alert">
                    <strong></strong>
                </span>
            </div>


            <div class="name" id="namefield">
                <label>نام و نام خانوادگی</label>
                <input id="name" type="text" class="form-control" name="name" value="">
                <span class="feedback" role="alert">
                    <strong></strong>
                </span>
            </div>

            <div class="code">
                <label>کد تایید</label>
                <input id="code" type="number" onkeyup="setStateCode(this)" class="form-control" name="code" required>
                <span class="feedback" role="alert">
                    <strong></strong>
                </span>
            </div>

            <div class="submit">
                <button type="button" class="dark" id="sendCode">ارسال کد تایید</button>
                <button id="submit" class="unactive">ورود</button>
            </div>
        </form>


    </div>
</div>