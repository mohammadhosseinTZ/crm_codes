## Arya tehran crm front end.
### Version 1.1

this repo managing  front of laravel based crm

[Vue 2.5], [Vuex], [Vue router], [Vue select], [Vue jalali date], [Fullcalendar], [apexchart] [bootstrap 4.0], [jquery 3.0], [axios], [cropperjs], [vue-debounce], [vue-notification], [vuejs-smart-table] little [blade 7.0] used in this project and bundling on laravel mix

[Vue 2.5]: <https://v2.vuejs.org/>
[Vuex]: <https://vuex.vuejs.org/>
[Vue router]: <https://router.vuejs.org/>
[Vue select]: <https://vue-select.org/>
[Vue jalali date]: <https://talkhabi.github.io/vue-persian-datetime-picker/>
[Fullcalendar]: <https://fullcalendar.io/>
[apexchart]: <https://apexcharts.com/docs/vue-charts/>
[bootstrap 4.0]: <https://getbootstrap.com/docs/4.6/getting-started/introduction/>
[axios]: <https://axios-http.com/docs/intro>
[jquery 3.0]: <https://jquery.com/>
[blade 7.0]: <https://laravel.com/docs/7.x/blade>
[cropperjs]: <https://fengyuanchen.github.io/cropperjs/>
[vue-debounce]: <https://www.npmjs.com/package/vue-debounce>
[vue-notification]: <https://github.com/euvl/vue-notification>
[vuejs-smart-table]: <https://tochoromero.github.io/vuejs-smart-table/#installation>