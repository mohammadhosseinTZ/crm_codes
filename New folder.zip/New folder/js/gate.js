const Gate = {
    install(Vue, options) {
        Vue.mixin({
            data() {
                return {
                    permissions: window.permissions || []
                }
            },
            methods: {
                can(string, item = null) {
                    string = string.toLowerCase()
                    if (item === null) {
                        return this.permissions.find(x => x == string) ? true : false
                    }
                    
                    return this.permissions.find(x => x == string) && this.personalItem(item) ? true : false;

                    return false;
                },
                personalItem(item) {
                    return item == window.user.id && item != 4260 ? true : false
                }
            }
        });

    }
};

export default Gate;