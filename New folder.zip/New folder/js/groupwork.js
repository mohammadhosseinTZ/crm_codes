import GroupWorkSms from './components/Actions/GroupWorkSms.vue'
const groupWork = {

    template: `
    <div class="d-flex align-items-center justify-content-between">
       <div class="d-flex">
            <div class="d-flex align-items-center">
                <label for="all-page" class="mb-0 ml-1">همه صفحه</label>
                <input id="all-page" type="checkbox" name="select-type" @change="$emit('allpage', $event.target.checked )">
            </div>
            &nbsp;&nbsp;
            <div class="d-flex align-items-center">
                <label for="all-result" class="mb-0 ml-1">همه نتایج</label>
                <input id="all-result" type="checkbox" name="select-type" @change="$emit('allresult', $event.target.checked )">
            </div>
       </div>
       
        <select @change="$emit('oselect', $event.target.value)" class="mot-group-work mot-mr-auto">
                <option value="null">کار گروهی</option>
                <option v-if="allow.some(x => x == 'sms')" value="group-send-message">ارسال پیام</option>
                <option v-if="allow.some(x => x == 'delete') && can('admin')" value="group-delete">حذف</option>
                <option v-if="allow.some(x => x == 'approve') && can('admin')" value="group-approve">تایید</option>
                <option v-if="allow.some(x => x == 'disapprove') && can('admin')" value="group-disapprove">عدم تایید</option>
        </select>
        <GroupWorkSms v-if="allow.some(x => x == 'sms')" :uri="url" :type="type" :incs="incs" :filts="filts" />
    </div>
    `,
    props: ['url', 'type', 'incs', 'filts', 'allow'],
    components:{
        GroupWorkSms
    }
}
export default groupWork;