<template>
    <div class="user-exams">
        
        <div class="modal fade user-exams-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header d-flex alert alert-warning h6 align-items-center">
                        <div>
                              آزمون های کاربران برای: {{exam.name}}
                        </div>
                        <div>تعداد نتایح: {{counts}}</div>
                    </div>
                    <div class="modal-body mt-3">
                        <paginate :paginate="pg" @changePage="changePage"/>
                        <table class="table table-bordered">
                            <tr>
                                <th>ردیف</th>
                                <th>نام</th>
                                <th>تلفن</th>
                                <th>امتیاز</th>
                                <th>تاریخ</th>
                                <th>اطلاعات</th>
                                <th>کارنامه</th>
                                <th>اکشن</th>
                            </tr>
                            <tr v-for="(data, name) in userExams" :key="data.id">
                                <td>{{name + 1}}</td>
                                <td>{{data.user.name}}</td>
                                <td>{{data.user.phone}}</td>
                                <td>{{data.score}} از 100</td>
                                <td>{{data.created_at}}</td>
                                <td><PersonButtons :id="data.user.id" :userdata="data.user" /></td>
                                <td><a target="_blank" :href="`/export/user_exam/${data.id}`" class="btn btn-primary btn-sm">مشاهده کارنامه</a></td>
                                <td><button v-if="can('delete_user_exams')" type="button" @click="deleteItem(`/user-exam/${data.id}`, data.id, onDeleteQuestion)" class="btn btn-danger btn-sm d-block w-100" data-toggle="modal" data-target="">حذف</button></td>
                            </tr>
                        </table>
                        <paginate :paginate="pg" @changePage="changePage"/>
                    </div>
                </div>
            </div>
        </div> 
           <AllPersonDepended />
    </div>
</template>
<script>
import AllPersonDepended from './../Person/AllPersonDepended';
import { mapGetters,mapActions } from 'vuex';
export default {
   name:"ExamQuestion",
   computed: {
        ...mapGetters({
            exam: 'Exam/data',
            userExams: 'UserExam/datas',
            counts: 'UserExam/count',
            pg: 'UserExam/pagination',
        })
   },
   components: {
    AllPersonDepended
   },
   data(){
    return{
        url: '/api/v1/exam/{id}/user-exam',
    }
   },
   methods: {
    ...mapActions({
        deleteUserExams: 'UserExam/delete',
        decrementUserExamCount: 'Exam/decrementUserExamCount',
        getDatas: 'UserExam/get'
    }),
    onDeleteQuestion(id){
        let examQues = this.userExams.find(x => x.id == id)
        this.decrementUserExamCount(examQues.exam_id)
        this.deleteUserExams(id)
    },
    getData(url = false) {
        var exam_id = this.exam.id || this.exam.insideId
        if(!exam_id) return;
        this.getDatas({data: url.replace('{id}', exam_id) || this.url.replace('{id}', exam_id)})
    },
   }
}
</script>
