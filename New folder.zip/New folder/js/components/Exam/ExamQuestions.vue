<template>
    <div class="exam-question">
        
        <div class="modal fade exam-question-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <ExamQuestionData />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import ExamQuestionData from './ExamQuestionData.vue'
export default {
   name:"ExamQuestion",
   components:{
    ExamQuestionData
   }
}
</script>
