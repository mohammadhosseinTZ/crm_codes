<template>
    <div class="exam-question-simple">
                    <div class="modal-header d-flex alert alert-warning h6 align-items-center">
                        <div>
                             سوال های: {{exam.name}}
                        </div>
                        <div class="mr-3">
                            <button v-if="can('add_exam_questions')" type="button" class="btn btn-primary" data-toggle="modal" data-target=".add-exam-question-modal" @click="add()">افزودن</button>
                        </div>
                    </div>
                     <table class="table mt-1">
                         <tr>
                             <th>سوال</th>
                             <th>گزینه 1</th>
                             <th>گزینه 2</th>
                             <th>گزینه 3</th>
                             <th>گزینه 4</th>
                             <th>پاسخ</th>
                             <th>اکشن</th>
                         </tr>
                            <tr v-for="data in examQuestions" :key="data.id">
                                <td width="200px">{{data.question}}</td>
                                <td>{{data.choose_1}}</td>
                                <td>{{data.choose_2}}</td>
                                <td>{{data.choose_3}}</td>
                                <td>{{data.choose_4}}</td>
                                <td>گزینه: {{data.answer}}</td>
                                <td class="dropdown">
                                    <button class="btn mot-info-icon-btn dropdown-toggle" type="button" id="exam-questions-action" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <span class="material-symbols-rounded mot-info-icon"> info </span>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="exam-questions-action">
                                         <button v-if="can('edit_exam_questions')" type="button" class="btn btn-primary" data-toggle="modal" data-target=".add-exam-question-modal" @click="edit({id: data.id, data: data })">ویرایش</button>
                                        <button v-if="can('delete_exam_questions')" type="button" @click="deleteItem(`/exam-question/${data.id}`, data.id, onDeleteQuestion)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                    </div>
                                </td>
                        </tr>
                     </table>

                     <AddExamQuestion />
                </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex';
import AddExamQuestion from './../Actions/AddExamQuestion.vue'
export default {
   name:"ExamQuestionData",
   components: {
        AddExamQuestion
   },
   computed: {
        ...mapGetters({
            exam: 'Exam/data',
            examQuestions: 'ExamQuestion/datas',
            exams: 'Exam/datas',
        })
   },
   methods:{
    ...mapActions({
        add: 'ExamQuestion/add',
        edit: 'ExamQuestion/edit',
        deleteExamQuestion: 'ExamQuestion/delete',
        updateExamQuestionCount: 'Exam/updateExamQuestionCount',
    }),

    onDeleteQuestion(id){
        let examQues = this.examQuestions.find(x => x.id == id).exam
        let exam = this.exams.find(x => x.id == examQues.id)
        this.updateExamQuestionCount({id: exam.id, count: parseInt(exam.exam_questions_count) - 1})
        this.deleteExamQuestion(id)
    }
   }
}
</script>
