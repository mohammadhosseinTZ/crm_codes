<template>
    <!-- Modal -->
<div class="pursuit">
    <div class="modal fade pursuirs-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content mot-nav-modal">
              <div class="modal-header">
                    <h5 class="modal-title">پیگیری های امروز</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <table class="table mot-nav-table-modal">
                <thead>
                    <tr class="position-relative">
                        <th scope="col">نام</th>
                        <th scope="col">جنسیت</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">دوره</th>
                        <th scope="col">تلفن</th>
                        <th scope="col">ثبت کننده</th>
                        <th scope="col">توضیحات</th>
                        <th scope="col">تغییر وضعیت</th>
                        <th scope="col">دلیل انصراف</th>
                        <th scope="col">تغییر</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="position-relative" v-for="prs in datas" :key="prs.id" v-if="prs.is_followed == false">
                        <td>{{prs.user.name}}</td>
                        <td>{{prs.user.gender == 0 ? 'آقا' : 'خانم'}}</td>
                        <td>{{prs.created_at}}</td>
                        <td>{{prs.subject.name}} {{prs.callable.name}}</td>
                        <td>{{prs.user.phone}}</td>
                        <td>{{prs.user_insert.name}}</td>
                        <td><textarea class="form-control" v-model="prs.ncomment">{{prs.comment}}</textarea></td>
                        <td>
                            <date-picker format="jYYYY-jMM-jDD" v-model="prs.npursuit_date"  display-format="jYYYY-jMM-jDD" auto-submit></date-picker>
                        </td>
                        <td>
                            <v-select id="lreasons" v-if="leave_reasons.length" v-model="prs.leave_reason" :options="leave_reasons" />
                        </td>
                        <td class="f">
                            <button class="btn btn-success btn-sm" @click="addData(prs.id, 'register')">ثبت نام</button>&nbsp;
                            <button class="btn btn-warning btn-sm" @click="addData(prs.id, 'leave')">انصراف</button>&nbsp;
                            <button class="btn btn-primary btn-sm" @click="addData(prs.id)">موکول</button>
                        </td>
                    </tr>
                </tbody>
                </table>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
    name:"TodayPursuit",
    computed: mapGetters(['selectedPerson']),
    data(){
        return{
            url: '/api/v1/person/today-pursuits',
            leave_reasons:window.leaveReasons,
            leave_reason:null,
        }
    },
    computed: {
       ...mapGetters(['selectedPerson']),
   },
    mounted(){
        this.getData();
    },
    methods: {
        ...mapActions({
            addRegister: 'Register/addRegister'
        }),

        addData(id, rel){
            var call = this.datas.find(x => x.id == id);
            var person = call.user;

            // // insert new call record
            axios.post('/api/v1/call', {
                callable: call.callable,
                callableType: call.callable_type,
                comments: call.ncomment ? call.ncomment : null,
                pursuit_date: call.npursuit_date ? call.npursuit_date : null,
                leave_reason: call.leave_reason,
                created_at: null,
                insideId: person.id,
                insideType: 'insert',
            });


            // // update clicked call record as readed

            axios.post('/api/v1/call', {
                callable: call.callable,
                callableType: call.callable_type,
                comments: call.comment,
                pursuit_date: call.pursuit_date,
                created_at: call.created_at,
                insideId: call.id,
                insideType: 'update',
                is_followed: true
            }).then(res => this.getData());

            if(rel == 'register'){
                
                Promise.all([
                    this.setSelectedPerson({id: person.id, data: person}),
                    this.addRegister(this.selectedPerson.id)
                ]).then(res => {
                    $('.add-register-modal').modal('show')
                })

            }
        }
    }
}
</script>
