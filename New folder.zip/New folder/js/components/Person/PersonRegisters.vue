<template>
    <div class="person-calls">
        <div class="modal fade person-registers-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <person-registers />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>

import PersonRegisters from './Datas/PersonRegisters.vue';
export default {
   name:"PersonRegisters",
   components:{
       'person-registers': PersonRegisters
   }
}
</script>
