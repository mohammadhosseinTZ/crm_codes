<template>
    <div class="person-regisrer-simple">
        <div class="modal-header d-flex alert alert-warning h6 align-items-center">
            <div>
                خرید ها : {{ selectedPerson.data.name }}
            </div>
            <button v-if="can('add_register')" type="button" class="btn mot-user-info-des" data-toggle="modal"
                data-target=".add-person-product-modal" @click="addRegister(selectedPerson.id)"><span class="material-symbols-rounded"> add </span></button>
        </div>
        <table class="table">
            <tr>
                <th class="mot-w-200">نام محصول</th>
                <th class="mot-w-200">هزینه</th>
                <th class="mot-w-200">پرداختی</th>
                <th class="mot-w-200">باقی مانده</th>
                <th class="mot-w-200">تاریخ</th>
                <th class="mot-w-200">فیش ها</th>
                <th class="mot-w-200">توضیحات</th>
                <th>ثبت کننده</th>
                <th>اکشن</th>
            </tr>
            <tr v-for="data in products" :key="data.id"
                :class="[data.leave_reason_id != null ? 'leave' : '', getGlose(data) <= 0 ? 'clear' : null]">
                <td>{{data.supplier.name}}</td>

                <td>{{data.price | format}} 
                    <span v-for="dc in data.discount_fors" :key="dc.id" class="disconted"><span v-if="dc.option">{{searchMeta(dc.option.meta, 'discount_percent').meta_value}} درصد کسری اضافه برای {{dc.option.option_value}}</span></span>
                    <span v-if="parseInt(data.pay_discount_price)" class="disconted">{{data.pay_discount_price | format}} تخفیف روی فاکتور</span>
                    <span v-if="data.bonus" class="disconted">معرفی توسط: {{data.bonus.user_reference.name}}</span>
                    <span v-if="data.site_discount">
                        <span class="disconted" v-for="sd in data.site_discount" :key="sd.name">
                                {{ Number(sd.amount) }} {{ sd.type == 'percent' ? 'درصد' : 'تومان' }} تخفیف با کد {{ sd.source != 'site' ? 'معرف  ' : null}}: {{ sd.name }}
                                <span v-if="sd.type != 'site' && sd.user" data-toggle="modal" data-target=".person-profile-modal" @click="getPersonData({id: sd.user.id});getPersonPayments(sd.user.id);getPersonRegisters({id: sd.user.id});getPersonCalls(sd.user.id);setSelectedPerson({id: sd.user.id, data: sd.user});" >(مشاهده)</span>
                        </span>
                    </span>

                </td>


                <td>{{ data.payments | getPrice | format }} <span v-if="data.return_price"
                        style="color: gray" class="disconted">عودت ({{ data.return_price | format }})</span></td>

                <td>{{getGlose(data) | format}}</td>


                <td>{{ data.created_at }}</td>
                <td>
                    <button type="button" @click="getPyamentsRegister({id:data.id, type: 'product-register'});"
                        class="btn btn-primary d-block mt-1 w-100" data-toggle="modal"
                        data-target=".person-payments-modal">{{ data.payments.length }} فیش ها</button>
                </td>
                <td>
                    <button class="btn btn-link" type="button" data-toggle="modal" data-target=".add-register-cost" @click="getCostByRegisterId(data.id)" ><i class="fas fa-dollar-sign"></i></button>
                    {{ data.comment }}
                </td>
                <td>
                    <span v-if="data.user_insert"
                        :class="[data.user_insert.phone == '0000000000' ? 'site_insert' : null]">
                        {{ data.user_insert.name }}
                    </span>
                </td>
                <td class="dropdown">
                    <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="calls-action" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="calls-action">
                        <button v-if="(can('edit_register') || can('edit_only_register', data.user_insert_id)) && parseInt(data.can_edit)"
                            type="button" class="btn btn-success" data-toggle="modal" data-target=".add-person-product-modal"
                            @click="editRegister({ id: data.id, data: data })">ویرایش</button>
            
                        <button v-if="can('delete_register')" type="button"
                            @click="customDelete(data)"
                            class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex';

export default {
    name: "PersonRegisters",
    computed: {
        ...mapGetters(['selectedPerson', 'products']),
    },
    filters: {
        getPrice: function (value) {
            var tmpPrice = 0;
            value.forEach(element => {
                if (element.status == 1) {
                    var prices = element.gates.map(value => value.price);
                    tmpPrice += parseInt(prices.reduce((total, num) => {
                        return parseInt(total) + parseInt(num);
                    }));
                }
            });
            return tmpPrice;
        },
        sum: function(val){
            let tmpval = 0
            for(var n of val) tmpval += n
            return tmpval
        }, 
    },

    methods: {
        ...mapActions({
            editRegister: 'ProductRegister/editRegister',
            addRegister: 'ProductRegister/addRegister',
            deletePersonRegisters: 'deletePersonRegisters',
            deleteRegister: 'ProductRegister/delete',
            getCostByRegisterId: 'Cost/getCostByRegisterId',

        }),
        getPrices(values) {
            return this.$options.filters.getPrice(values);
        },
        getGlose(data){
            var payedPrice = this.$options.filters.getPrice(data.payments)
            var price = data.price
            return parseInt(price) - parseInt(payedPrice)

        },
        customDelete(data){
            this.deleteItem(`/product-register/${data.id}`, data.id)
            this.deletePersonRegisters({id: data.id, type: "products"})
            this.deleteRegister(data.id)
        }
    }
}
</script>
<style>span.disconted {
    font-size: 11px;
    display: block;
    color: red;
    font-weight: bold;
}</style>