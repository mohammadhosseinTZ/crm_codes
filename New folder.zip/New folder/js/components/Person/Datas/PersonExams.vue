<template>
    <div class="person-exams-data">
        <div class="modal-header d-flex alert alert-warning h6 align-items-center">
            <div>
                آزمون های: {{selectedPerson.data.name}}
            </div>
        </div>
        <div class="modal-body">
            <table class="table">
                <tr>
                    <th class="mot-w-200">ردیف</th>
                    <th class="mot-w-200">نام آزمون</th>
                    <th class="mot-w-200">تاریخ</th>
                    <th class="mot-w-200">امتیاز</th>
                    <th class="mot-w-200">اطلاعات</th>
                    <th class="mot-w-200">اکشن</th>
                </tr>
                <tr v-for="(data, name) in exams" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.exam.name}}</td>
                    <td>{{data.created_at}}</td>
                    <td>{{data.score}} از 100</td>
                    <td><a target="_blank" :href="`/export/user_exam/${data.id}`" class="btn btn-primary btn-sm">مشاهده کارنامه</a></td>
                    <td><button v-if="can('delete_user_exams')" type="button" @click="deleteItem(`/user-exam/${data.id}`, data.id, deletePersonExams)" class="btn btn-danger btn-sm d-block w-100" data-toggle="modal" data-target="">حذف</button></td>
                </tr>
            </table>
        </div>
    </div>
</template>

<script>

import { mapGetters, mapActions } from 'vuex';
export default {
    name:"PersonExams",
    computed: {
       ...mapGetters(['selectedPerson', 'exams']),
   },
   methods:{
    ...mapActions(['deletePersonExams'])
   }
}
</script>
