<template>
    <div class="person-content">
                    <div class="modal-header d-flex justify-content-between alert alert-warning h6 align-items-center">   
                        اطلاعات: {{selectedPerson.data.name}}
                        <div class="d-flex">
                            <button class="btn btn-primary" @click="sendWelcomeMessage">فرستادن لینک خوش آمد گویی</button>   
                            <button v-if="can('add_data')" type="button" class="btn mot-user-info-des" data-toggle="modal" data-target=".add-data-modal" ><span class="material-symbols-rounded "> add </span></button>
                        </div> 
                    </div>
                     <table class="table mot-modal-table mt-1">
                            <tr>
                                <th>ایمیل</th>
                                <td>{{ selectedPerson.data.email  }}</td>
                            </tr>
                            <tr>
                                <th>دیگر شماره ها</th>
                                <td><span v-if="d.phone">{{d.phone.join(' و ')}}</span></td>
                            </tr>
                            <tr>
                                <th>کد ملی</th>
                                <td><span v-if="d.national_code">{{d.national_code.value}}</span></td>
                            </tr>
                            <tr>
                                <th>نام پدر</th>
                                <td><span v-if="d.father_name">{{d.father_name.value}}</span></td>
                            </tr>
                            <tr>
                                <th>تلفن ثابت</th>
                                <td><span v-if="d.fixed_phone">{{d.fixed_phone.value}}</span></td>
                            </tr>
                            <tr>
                                <th>آدرس</th>
                                <td><span v-if="d.address">{{d.address.value}}</span></td>
                            </tr>
                            <tr>
                                <th>تاریخ تولد</th>
                                <td><span v-if="d.birth_date">{{d.birth_date.value}}</span></td>
                            </tr>
                            <tr>
                                <th>محل تولد</th>
                                <td><span v-if="d.birth_place && d.birth_place.option">{{d.birth_place.option.option_value}}</span></td>
                            </tr>
                            <tr>
                                <th>محل زندگی</th>
                                <td><span v-if="d.city && d.city.option">{{d.city.option.option_value}}</span></td>
                            </tr>
                            <tr>
                                <th>رشته تحصیلی</th>
                                <td><span v-if="d.colage_course && d.colage_course.option">{{d.colage_course.option.option_value}}</span></td>
                            </tr>
                            <tr>
                                <th>مدرک</th>
                                <td><span v-if="d.evidence && d.evidence.option">{{d.evidence.option.option_value}}</span></td>
                            </tr>

                            <tr>
                                <th>نوع شخص</th>
                                <td><span v-if="d.person_type">{{d.person_type.value}}</span></td>
                            </tr>
                            <tr>
                                <th>ملیت</th>
                                <td><span v-if="d.nationality">{{d.nationality.value}}</span></td>
                            </tr>
                            <tr>
                                <th>نام شرکت</th>
                                <td><span v-if="d.company_name">{{d.company_name.value}}</span></td>
                            </tr>

                            <tr>
                                <th>شماره کارت</th>
                                <td><span v-if="d.card_number">{{d.card_number.value}}</span></td>
                            </tr>

                            <tr>
                                <th>شماره حساب</th>
                                <td><span v-if="d.account_number">{{d.account_number.value}}</span></td>
                            </tr>
                            <tr>
                                <th>بانک</th>
                                <td><span v-if="d.bank_name">{{d.bank_name.value}}</span></td>
                            </tr>
                            <tr>
                                <th>کار</th>
                                <td><span v-if="d.job && d.job.option">{{d.job.option.option_value}}</span></td>
                            </tr>
                            <tr>
                                <th>آدرس محل کار</th>
                                <td><span v-if="d.job_address">{{d.job_address.value}}</span></td>
                            </tr>
                            <tr>
                                <th>وضعیت تاهل</th>
                                <td>
                                    <span v-if="d.marital_status && d.marital_status.value == 1">متاهل</span>
                                    <span v-else>مجرد</span>
                                </td>
                            </tr>
                            <tr>
                                <th>منطقه</th>
                                <td><span v-if="d.region">{{d.region.value}}</span></td>
                            </tr>
                            <tr>
                                <th>عکس پرسنلی</th>
                                <td><span v-if="d.personal_image"><img class="preview" :src="d.personal_image.value"></span></td>
                            </tr>
                            <tr>
                                <th>عکس کارت ملی</th>
                                <td><span v-if="d.national_cart_image"><img class="preview"  :src="d.national_cart_image.value"></span></td>
                            </tr>
                            <tr>
                                <th>تصویر صفحه اول شناسنامه</th>
                                <td><span v-if="d.certificate_image"><img class="preview" :src="d.certificate_image.value"></span></td>
                            </tr>
                            <tr>
                                <th>پورسانت معرفی فرد جدید</th>
                                <td><span v-if="d.new_register_commission">{{d.new_register_commission.value}} درصد</span></td>
                            </tr>
                            <tr>
                                <th>پورسانت معرفی کاراموز</th>
                                <td><span v-if="d.register_commission">{{d.register_commission.value}} درصد</span></td>
                            </tr>
                            <tr>
                                <th>تخفیف ثبت با کد به عنوان فرد جدید</th>
                                <td><span v-if="d.new_regcode_discount">{{d.new_regcode_discount.value}} درصد</span></td>
                            </tr>
                            <tr>
                                <th>تخفیف ثبت با کد به عنوان کاراموز</th>
                                <td><span v-if="d.regcode_discount">{{d.regcode_discount.value}} درصد</span></td>
                            </tr>
                     </table>
                        <form @submit.stop.prevent="getExport">
                        <table class="table table-bordered mot-modal-table">
                            <tr class="mot-output">
                                <th>اطلاعات</th>
                                <td class="mot-w-300">
                                    <label for="export-data">اطلاعات</label>
                                     <v-select id="export-data" multiple  v-model="exp.data" :options="exportTypes" />            
                                </td>
                                <td class="mot-w-300">
                                    <label for="export-type">نوع</label>
                                    <v-select id="export-type"  v-model="exp.type" :options="[{label: 'پی دی اف', value: 'pdf'},{label: 'اکسل', value: 'excel'},{label: 'فرم ثبت نام', value: 'regform'},]" />            
                                </td>
                                <td class="mot-w-300"><button class="btn btn-primary">خروجی گرفتن</button></td>
                            </tr>
                        </table>
                    </form>
                </div>
</template>
<script>
import { mapGetters } from 'vuex';

export default {
   name:"PersonData",
   data(){
       return{
           d: {
               national_code: {},
               phone: []
           },
           exp: {
               data:[],
               type:null,
               params: {},
           },
           exportTypes: [
            {label: 'اطلاعات', value: 'data'},
            {label: 'تماس ها', value: 'calls'},
            {label: 'ثبت نامی ها', value: 'registers'},
            {label: 'خرید ها', value: 'product_registers'},
            {label: 'استفاده از خدمات', value: 'service_registers'},
            {label: 'فیش ها', value: 'payments'},
        ]
       }
   },
   computed: {
       ...mapGetters({selectedPerson: 'selectedPerson', tdata: 'sdata'}),

   },
   watch:    {
        tdata: {
            handler:function (newItem) {
                this.d = {
                    national_code: null,
                    father_name: null,
                    address: null,
                    birth_date: null,
                    birth_place: null,
                    job: null,
                    job_address: null,
                    city: null,
                    evidence: null,
                    colage_course: null,
                    region: null,
                    fixed_phone: null,
                    marital_status: null,
                    personal_image: null,
                    national_cart_image: null,
                    certificate_image: null,
                    phone: []
                }

                if(!newItem.length){
                    return;
                } 
                newItem.forEach(elm => {
                        if(elm.option){
                            this.d[elm.meta_key] = {value: elm.meta_value, option: elm.option}
                        }else{
                            if(Array.isArray(this.d[elm.meta_key])){
                                    this.d[elm.meta_key].push(elm.meta_value)
                            }else{
                                this.d[elm.meta_key] = {value: elm.meta_value}
                            }
                        }
                            
                }) 
            },
            deep:true
        }
    },
   methods: {

       sendEditDataLink(){
           axios.get(`/api/v1/person/${this.selectedPerson.id}/sms/complete-link`)
       },
       sendWelcomeMessage(){
           axios.get(`/api/v1/person/${this.selectedPerson.id}/sms/welcome-message`)
       },
       getExport(){
           let exportparam = []
           this.exp.data.map(x => exportparam.push(x.value))

            let url = `/user/export?id=${this.selectedPerson.id}&type=${this.exp.type ? this.exp.type.value : 'pdf'}&export=${exportparam.join(',')}`
            window.open(url);

            
       },

   }
}
</script>
