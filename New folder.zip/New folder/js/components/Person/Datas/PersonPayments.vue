<template>
    <div class="person-paymerns-simple">
                    <div class="modal-header d-flex alert alert-warning h6 align-items-center">
                        <div>
                            فیش های: {{selectedPerson.data.name}}
                        </div>
                      <button v-if="can('add_payment')" type="button" class="btn mot-user-info-des" data-toggle="modal" id="addpaymentbutton" data-target=".add-payment-modal" @click="addPayment({user_id: selectedPerson.id})"><span class="material-symbols-rounded"> add </span></button>
                    </div>
                     <table class="table mt-1">
                         <tr>
                             <th class="mot-w-200">تاریخ</th>
                             <th class="mot-w-200">کد</th>
                             <th class="mot-w-200">مبلغ</th>
                             <th class="mot-w-200">روش های پرداخت</th>
                             <th class="mot-w-200">برای</th>
                             <th class="mot-w-200">وضعیت</th>
                             <th>توضیحات</th>
                             <th>اکشن</th>
                         </tr>
                            <tr v-for="payment in payments" :key="payment.id">
                                <td>{{payment.created_at}}</td>
                                <td><i class="fa fa-print" @click="print(payment);"></i> {{payment.code}}</td>
                                <td>{{payment.gates | getPrice | format}}</td>
                                <td>{{payment.gates | getWays}}</td>
                                <td>{{payment.paymentable.supplier.name}}</td>
                                <td v-if="payment.status == 0">عدم تایید</td>
                                <td v-else>تایید</td>
                                <td>{{payment.comment}}</td>
                                <td class="dropdown">
                                    <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="calls-action" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="calls-action">
                                        <button v-if="payment.status == 0 && (can('edit_payment') || can('edit_only_payment', payment.user_insert_id ))" type="button" class="btn btn-success" data-toggle="modal" data-target=".add-payment-modal" @click="editPayment({id: payment.id, data: payment, user_id: payment.paymentable.user_id})" >ویرایش</button>
                                        <button v-if="parseInt(payment.status) == 0 && can('delete_payment')" type="button" @click="deleteItem(`/payment/${payment.id}`, payment.id, deletePersonPayments)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                    </div>
                                </td>
                        </tr>
                     </table>
                     <table class="table">
                         <tr>
                             <td>جمع تایید: {{totalAcceptedPrice}}</td>
                             <td>جمع عدم تایید: {{totalNotAcceptedPrice}}</td>
                             <td>جمع همه: {{totalPrice}}</td>
                         </tr>
                     </table>
                     <PaymentReceipt v-if="selectedPayment" style="display: none" :payment="selectedPayment" />
                </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex';
import PaymentReceipt from './../../global/PaymentReceipt';

export default {
   name:"PersonPayments",
   components: {
    PaymentReceipt
   },
   data(){
       return{
            totalPrice: 0,
            totalAcceptedPrice: 0,
            totalNotAcceptedPrice : 0,
            selectedPayment: null
       }
   },
   computed: {
       ...mapGetters(['selectedPerson', 'payments']),
   },
    watch:    {
        payments: {
            handler:function (newItem) {
               this.getTotalPrices()
            },
            deep:true
        }
    },
   methods: {
    ...mapActions({
       deletePersonPayments: 'deletePersonPayments' 
    }),
       getTotalPrices(){
            this.totalPrice = 0
            this.totalAcceptedPrice = 0
            this.totalNotAcceptedPrice = 0
            for(var payment in this.payments){
                this.totalPrice += parseInt(this.$options.filters.getPrice(this.payments[payment].gates));
                if(this.payments[payment].status == 1){
                    this.totalAcceptedPrice += parseInt(this.$options.filters.getPrice(this.payments[payment].gates));
                }else{
                    this.totalNotAcceptedPrice += parseInt(this.$options.filters.getPrice(this.payments[payment].gates));
                }
            }
        },

        print(data){
            var obj = this
            var dataToPrint = new Promise((resolve, reject) => {
                if(obj.selectedPayment = data){
                    resolve(obj.selectedPayment)
                }
            });

            dataToPrint.then(res => {
                var myPrintContent = document.getElementById('print-payment');
                var myPrintWindow = window.open('https://portal.aryatehran.com/payments/print', 'print');
                myPrintWindow.document.write(myPrintContent.innerHTML + `<style>@page: footer { display: none; } @page: header { display: none; } @page {margin: none; }@font-face { font-family: \"Iransans\"; src: url(\"/font/IRANSansWeb.woff2\") format(\"woff\"), url(\"/font/IRANSansWeb.woff\") format(\"woff\"), url(\"/font/IRANSansWeb.ttf\") format(\"truetype\"); } img{ width: 30%; } .content{ text-align: center; } h1, table{ margin-top: 50px; } h1, table, tfoot{ text-align: right; direction: rtl; width: 100%; } h1, table *{ color: black; font-family: \"Iransans\"; } h1{ font-size: 20px; margin-top: 10px; } th{ width: 40%; } th,td{ font-size: 14px !important; } .date{ direction: ltr; display: block; } main.py-4{ padding: 0 !important; } table { margin: 9; } </style>`);
                setTimeout(function(){
                    myPrintWindow.document.close();
                myPrintWindow.focus();
                myPrintWindow.print();
                myPrintWindow.close();  
                }, 1000)  
                return false;
            })
            
        }
   }
}
</script>
