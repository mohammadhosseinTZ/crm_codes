<template>
    <div class="person-regisrer-simple">
        <div class="modal-header d-flex alert alert-warning h6 align-items-center">
            <div>
                ثبت نامی های: {{ selectedPerson.data.name }}
            </div>
            <button v-if="can('add_register')" type="button" class="btn mot-user-info-des" data-toggle="modal"
                data-target=".add-register-modal" @click="addRegister(selectedPerson.id)"><span
                    class="material-symbols-rounded"> add </span></button>
        </div>
        <table class="table">
            <tr>
                <th class="mot-w-200">دوره</th>
                <th class="mot-w-200">هزینه</th>
                <th class="mot-w-200">پرداختی</th>
                <th class="mot-w-200">باقی مانده</th>
                <th class="mot-w-200">تاریخ</th>
                <th class="mot-w-200">فیش ها</th>
                <th class="mot-w-200">توضیحات</th>
                <th>ثبت کننده</th>
                <th>اکشن</th>
            </tr>
            <tr v-for="register in registers" :key="register.id"
                :class="[register.leave_reason_id != null ? 'leave' : '', getGlose(register) <= 0 ? 'clear' : null]">
                <td>{{ register.class_course.course_code + '-' + register.course.name }} <span class="text-success"
                        title="وضعیت شرکت در نظر سنجی">{{ parseInt(register.survey_count) ? '✔' : null }}</span></td>

                <td>{{ register.price | format }}
                    <span v-for="dc in register.discount_fors" :key="dc.id" class="disconted"><span v-if="dc.option">{{
                        searchMeta(dc.option.meta, 'discount_percent').meta_value }} درصد کسری اضافه
                            برای {{ dc.option.option_value }}</span></span>
                    <span v-if="parseInt(register.is_online_course)" class="disconted">(آنلاین)</span>
                    <span v-if="register.bonus" class="disconted">معرفی توسط:
                        {{ register.bonus.user_reference.name }}</span>
                    <span v-if="register.site_discount">
                        <span class="disconted" v-for="sd in register.site_discount" :key="sd.name">
                            {{ Number(sd.amount) }} {{ sd.type == 'percent' ? 'درصد' : 'تومان' }} تخفیف با کد {{
                                sd.source != 'site' ? 'معرف ' : null}}: {{ sd.name }}
                            <span v-if="sd.type != 'site' && sd.user" data-toggle="modal"
                                data-target=".person-profile-modal"
                                @click="getPersonData({ id: sd.user.id }); getPersonPayments(sd.user.id); getPersonRegisters({ id: sd.user.id }); getPersonCalls(sd.user.id); setSelectedPerson({ id: sd.user.id, data: sd.user });">(مشاهده)</span>
                        </span>
                    </span>

                </td>


                <td>{{ register.payments | getPrice | format }} <span v-if="register.return_price" style="color: gray"
                        class="disconted">عودت ({{ register.return_price | format }})</span></td>

                <td v-if="register.leave_reason_id == null">{{ getGlose(register) | format }}</td>
                <td v-else>{{ 0 }}</td>

                <td>{{ register.created_at }}</td>
                <td>
                    <button type="button" @click="getPyamentsRegister({ id: register.id });"
                        class="btn d-block mt-1 mot-w-100 btn-warning" data-toggle="modal"
                        data-target=".person-payments-modal">{{ register.payments.length }} فیش ها</button>
                </td>
                <td class="mot-table-des-icons">
                    <a :href="`/export/register_regform/${register.id}`" target="_blank"><i class="fa fa-print"></i></a>
                    <button class="btn btn-link" type="button" data-toggle="modal" data-target=".add-register-cost"
                        @click="getCostByRegisterId(register.id)"><i class="fas fa-dollar-sign"></i></button>
                    <button class="btn btn-link" type="button" data-toggle="modal"
                        data-target=".register-rollcall-modal"
                        @click="getRollCallByRegisterId({ register: register.id })"><i class="fas fa-eye"></i></button>

                    {{ register.comment }}

                </td>
                <td>
                    <span v-if="register.user_insert"
                        :class="[register.user_insert.phone == '0000000000' ? 'site_insert' : null]">
                        {{ register.user_insert.name }}
                    </span>
                </td>
                <td class="dropdown">
                    <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="calls-action"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="calls-action">
                        <button v-if="can('edit_register') || can('edit_only_register', register.user_insert_id)"
                            type="button" class="btn btn-success" data-toggle="modal" data-target=".add-register-modal"
                            @click="editRegister({ id: register.id, data: register })">ویرایش</button>
                        <button v-if="register.class_course.course_code == 999" type="button" class="btn btn-primary"
                            data-toggle="modal" data-target=".manage-course-class-modal"
                            @click="addSession({ id: register.id, type: 'register' }); getEvents({ date: `/api/v1/register/${register.id}/session` })">مدیریت</button>
                        <button v-if="can('delete_register')" type="button" @click="customDelete(register)"
                            class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>


                    </div>
                </td>
            </tr>
        </table>
    </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex';

export default {
    name: "PersonRegisters",
    computed: {
        ...mapGetters(['selectedPerson', 'registers']),
    },
    filters: {
        getPrice: function (value) {
            var tmpPrice = 0;
            value.forEach(element => {
                if (element.status == 1) {
                    var prices = element.gates.map(value => value.price);
                    tmpPrice += parseInt(prices.reduce((total, num) => {
                        return parseInt(total) + parseInt(num);
                    }));
                }
            });
            return tmpPrice;
        },
    },

    methods: {
        ...mapActions({
            editRegister: 'Register/editRegister',
            addRegister: 'Register/addRegister',
            addSession: 'Calendar/addSession',
            getEvents: 'Calendar/getEvetns',
            deletePersonRegisters: 'deletePersonRegisters',
            deleteRegister: 'Register/delete',
            getCostByRegisterId: 'Cost/getCostByRegisterId',
            getRollCallByRegisterId: 'RollCall/getByRegister'
        }),
        getPrices(values) {
            return this.$options.filters.getPrice(values);
        },
        getGlose(data) {
            var price = this.$options.filters.getPrice(data.payments)
            return parseInt(data.price) - parseInt(price)
        },

        setEvidenceStatus(regid) {
            axios.get(`/api/v1/register/${regid}/change-evidence-status`).then(res => {
                this.registers.find(x => x.id == regid).is_apply_evidence = !this.registers.find(x => x.id == regid).is_apply_evidence
            })
        },

        setScore(register) {
            axios.post(`/api/v1/register/${register.id}/set-score/${register.score}`)
        },

        customDelete(data) {
            this.deleteItem(`/register/${data.id}`, data.id)
            this.deletePersonRegisters({ id: data.id })
            this.deleteRegister(data.id)
        }
    }
}
</script>
<style>
span.disconted {
    font-size: 11px;
    display: block;
    color: red;
    font-weight: bold;
}
</style>