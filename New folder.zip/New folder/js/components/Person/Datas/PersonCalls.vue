<template>
    <div class="person-calls-simple">
                    <div class="modal-header d-flex alert alert-warning h6 align-items-center">
                        <div>
                            تماس های: {{selectedPerson.data.name}}
                        </div>
                        <div class="mr-3">
                            <button v-if="can('add_call')" type="button" class="btn mot-user-info-des" data-toggle="modal" data-target=".add-call-modal" @click="addCall(selectedPerson.id)">
                                <span class="material-symbols-rounded"> add </span>
                            </button>
                        </div>
                    </div>
                     <table class="table mt-1">
                         <tr>
                             <th class="mot-w-200">تاریخ</th>
                             <th class="mot-w-200">موضوع</th>
                             <th class="mot-w-200">دسته بندی</th>
                             <th class="mot-w-200">تاریخ پیگیری</th>
                             <th class="mot-w-200">ثبت کننده</th>
                             <th>توضیحات</th>
                             <th>اکشن</th>
                         </tr>
                            <tr v-for="call in calls" :key="call.id">
                                <td>{{call.created_at}}</td>
                                <td>{{call.callable.name}}</td>
                                <td>{{call.subject.name}} {{call.pursuit_date ? '(پیگیری)' : null}}</td>
                                <td>{{call.pursuit_date}}</td>
                                <td>{{call.user_insert.name}}</td>
                                <td>{{call.comment}}</td>
                                <td class="dropdown">
                                    <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="calls-action" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="calls-action">
                                         <button v-if="can('edit_call') || can('edit_only_call', call.user_insert_id )" type="button" class="btn btn-success" data-toggle="modal" data-target=".add-call-modal" @click="editCall({id: call.id, data: call })">ویرایش</button>
                                        <button v-if="can('delete_call')" type="button" @click="deleteItem(`/call/${call.id}`, call.id, deletePersonCalls)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                    </div>
                                </td>
                        </tr>
                     </table>
                </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex';
export default {
   name:"PersonCalls",
   computed: {
       ...mapGetters(['selectedPerson', 'calls']),
   },
   methods:{
    ...mapActions({
        addCall: 'Call/addCall',
        editCall: 'Call/editCall',
        deletePersonCalls: 'deletePersonCalls'
    })
   }
}
</script>
