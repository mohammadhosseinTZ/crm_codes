<template>

    <div>
        <PersonProfile />
        <PersonCalls/>
        <PersonRegisters/>
        <PersonProductRegisters/>
        <PersonServiceRegisters/>
        <PersonPayments />
        <PersonExams />
        <PersonData />
        <PersonRegisterCosts />
        <RollcallRegister />
    </div>

</template>

<script>

import PersonCalls from './PersonCalls';
import PersonRegisters from './PersonRegisters';
import PersonProductRegisters from './PersonProductRegisters';
import PersonServiceRegisters from './PersonServiceRegisters';
import PersonPayments from './PersonPayments';
import PersonData from './PersonData';
import PersonExams from './PersonExams';
import PersonRegisterCosts from './PersonRegisterCosts';
import PersonProfile from './PersonProfile';
import RollcallRegister from './../Class/RollcallRegister';

import { mapGetters } from 'vuex';

export default {
    name: "AllAction",
    components: {
     PersonCalls,
     PersonRegisters,
     PersonPayments,
     PersonExams,
     PersonData,
     PersonProfile,
     PersonRegisterCosts,
     RollcallRegister,
     PersonProductRegisters,
     PersonServiceRegisters
    },
    computed: {
        ...mapGetters(['selectedPerson']),
    }
}
</script>
