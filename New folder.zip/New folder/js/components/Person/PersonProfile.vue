<template>
    <div class="person-profile">
        
        <div class="modal fade person-profile-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg person-lg">
                <div class="modal-content person-content">
                    <div class="modal-header d-flex">
                        <div>
                        پروفایل: {{selectedPerson.data.name}}
                        </div>
                    </div>
                    
                    <person-data></person-data>
                    <!-- <div class="line hr"></div> -->
                    <person-registers></person-registers>
                    <!-- <div class="line hr"></div> -->
                    <person-products></person-products>
                    <!-- <div class="line hr"></div> -->
                    <person-services></person-services>
                    <!-- <div class="line hr"></div> -->
                    <person-payments></person-payments>
                    <!-- <div class="line hr"></div> -->
                    <person-calls></person-calls>
                    <!-- <div class="line hr"></div> -->
                    <person-exams></person-exams>

        
                </div>
            </div>
        </div>    
    </div>
</template>
<script>

import PersonData from './Datas/PersonData.vue'
import PersonCalls from './Datas/PersonCalls.vue'
import PersonPayments from './Datas/PersonPayments.vue'
import PersonRegisters from './Datas/PersonRegisters.vue';
import PersonProductRegisters from './Datas/PersonProductRegisters.vue';
import PersonServiceRegisters from './Datas/PersonServiceRegisters.vue';
import PersonExams from './Datas/PersonExams.vue';

export default {
   name:"PersonProfile",
    components:{
        'person-registers': PersonRegisters,
        'person-products': PersonProductRegisters,
        'person-services': PersonServiceRegisters,
        'person-calls': PersonCalls,
        'person-data': PersonData,
        'person-payments': PersonPayments,
        'person-exams': PersonExams
    }
}
</script>
