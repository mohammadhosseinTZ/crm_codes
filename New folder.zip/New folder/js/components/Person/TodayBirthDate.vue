<template>
    <!-- Modal -->
<div class="pursuit">
    <div class="modal fade birth-date-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content mot-nav-modal">
              <div class="modal-header">
                    <h5 class="modal-title">تولد های امروز</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span class="material-symbols-rounded" aria-hidden="true"> close </span>
                    </button>
                    <div v-if="can('group_work')" class="from-group mr-2 d-flex bg-white round rounded p-1">
                        <label for="is-group m-0">کار گروهی</label>
                        <input type="checkbox" id="is-group" @change="() => {is_group = !is_group; includes=[]}">
                    </div>
                </div>
                <table class="table mot-nav-table-modal">
                <thead>
                    <tr class="position-relative relative">
                        <th v-if="is_group" class="mot-sm-blue col-12">
                                <groupwork :allow="['sms']" :url="url" :type="'person'" :incs="includes" :filts="params" @allpage="(ev) => manageIncludes(datas, ev)" @oselect="(ev) => groupWork(ev)" @allresult="(ev) => manageIncludes(datas, ev, 'allresult')" />
                        </th>
                        <th scope="col">نام</th>
                        <th scope="col">جنسیت</th>
                        <th scope="col">تلفن</th>
                        <th scope="col" class="text-center">اکشن</th>
                    </tr>
                </thead>
                <tbody>
                  <tr v-for="data in datas" :key="data.id" class="text-start ">
                        <td v-if="is_group"><input type="checkbox" v-model="includes" :value="data.id"  class="text-start"></td>
                      <td class="text-start">{{data.name}}</td>
                      <td class="text-start">{{parseInt(data.gender) == 1 ? "خانم" : "آقا"}}</td>
                      <td class="text-start">{{data.phone}}</td>
                      <td  class="text-start relative-important">
                        <PersonButtons class="" :id="data.id" :userdata="data" />
                    </td>
                  </tr>
                </tbody>
                </table>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>
export default {
    name:"TodayBirthDate",
    data(){
        return{
            url: '/api/v1/person/today-birth-date'
        }
    },
    mounted(){
        this.getData();
    },
 
}
</script>
