<template>
    <div>
            <AllList />
            <AllAction />
    </div>
</template>

<script>

import AllList from './AllList';
import AllAction from './../Actions/AllAction';
export default {
    name: "AllPersonDepended",
    components:{
        AllList,
        AllAction
    },
}
</script>
