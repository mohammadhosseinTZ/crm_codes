<template>
    <div class="person-payments">
        <div class="modal fade person-payments-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <person-payments />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import PersonPayments from './Datas/PersonPayments.vue'
export default {
   name:"PersonPayments",
   components:{
       'person-payments': PersonPayments
   }
}
</script>
