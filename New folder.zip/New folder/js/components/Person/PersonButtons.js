const PersonButtons = {

    template: `
    <div class="dropdown">
        <button class="btn mot-profile-icon-btn  dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <span class="material-symbols-rounded mot-profile-icon">
        menu_open
        </span>
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <button type="button" class="btn btn-primary d-block mt-1 w-100" data-toggle="modal" data-target=".person-calls-modal" @click="getPersonCalls(id);setSelectedPerson({id: id, data: userdata});">تماس ها</button>
            <button type="button" class="btn btn-primary d-block mt-1 w-100" data-toggle="modal" data-target=".person-registers-modal" @click="getPersonRegisters({id: id});setSelectedPerson({id: id, data: userdata});">ثبت نامهی ها</button>
            <button type="button" class="btn btn-primary d-block mt-1 w-100" data-toggle="modal" data-target=".person-product-registers-modal" @click="getPersonRegisters({id: id, type: 'products'});setSelectedPerson({id: id, data: userdata});">خرید ها</button>
            <button type="button" class="btn btn-primary d-block mt-1 w-100" data-toggle="modal" data-target=".person-service-registers-modal" @click="getPersonRegisters({id: id, type: 'services'});setSelectedPerson({id: id, data: userdata});">خدمات</button>
            <button type="button" class="btn btn-primary d-block mt-1 w-100" data-toggle="modal" data-target=".person-payments-modal" @click="getPersonPayments(id);setSelectedPerson({id: id, data: userdata});">فیش ها</button>
            <button type="button" class="btn btn-primary d-block mt-1 w-100" data-toggle="modal" data-target=".person-exams-modal" @click="getPersonExams(id);setSelectedPerson({id: id, data: userdata});">آزمون ها</button>
            <button type="button" class="btn btn-primary d-block mt-1 w-100" data-toggle="modal" data-target=".person-data-modal" @click="getPersonData({id: id});setSelectedPerson({id: id, data: userdata});">اطلاعات</button>
            <button type="button" class="btn btn-success d-block mt-1 w-100" data-toggle="modal" data-target=".person-profile-modal" @click="getPersonData({id: id});getPersonPayments(id);getPersonRegisters({id: id});getPersonRegisters({id: id, type: 'products'});getPersonRegisters({id: id, type: 'services'});getPersonCalls(id);setSelectedPerson({id: id, data: userdata});">پروفایل</button>
        </div>
    </div>  
    `,
    props: ['id', 'userdata'],
}
export default PersonButtons;