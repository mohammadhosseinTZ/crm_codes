<template>
    <div class="person-calls">
        <div class="modal fade person-service-registers-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <person-services />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>

import PersonServiceRegisters from './Datas/PersonServiceRegisters.vue';
export default {
   name:"PersonServiceRegisters",
   components:{
       'person-services': PersonServiceRegisters
   }
}
</script>
