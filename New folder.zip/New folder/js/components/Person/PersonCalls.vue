<template>
    <div class="person-calls">
        
        <div class="modal fade person-calls-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <person-calls />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import PersonCalls from './Datas/PersonCalls.vue'
export default {
   name:"PersonCalls",
   components:{
       'person-calls': PersonCalls
   }
}
</script>
