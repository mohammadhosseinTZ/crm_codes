<template>
    <div class="person-register-costs">
        <div class="modal fade add-register-cost" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg mot-modal-cost-item">
                <div class="modal-content">
                    <CostItem :costs="costs" />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import CostItem from './../global/CostItem.vue'
import { mapGetters, mapActions  } from 'vuex';
export default {
   name:"PersonRegisterCosts",
   components: {
    CostItem
   },
   computed: {
        ...mapGetters({
            costs: 'Cost/datas',
        }),
    },
    filters: {
        getPrice: function(value){
            var prices =  value.map(function(value,index) { return value.price; });
            return prices.reduce(function(total, num){
                return parseInt(total) + parseInt(num);
            });
        },
        getWays: function(value){
           var ways =  value.map(function(value,index) {
                if(value.chash_way){
                    return value.chash_way.option_value;
                }
            }); 
           return ways.join(' و ');
        },
    }
}
</script>
