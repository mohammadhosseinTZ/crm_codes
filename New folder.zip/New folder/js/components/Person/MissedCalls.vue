<template>
    <!-- Modal -->
<div class="miss-calls">
    <div class="modal fade miss-calls-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                    <h5 class="modal-title">تماس های از دست رفته</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <table class="table">
                <thead>
                    <tr>
                        <th scope="col">وضعیت</th>
                        <th scope="col">اکشن</th>
                        <th scope="col">تاریخ</th>
                        <th scope="col">تلفن</th>
                        <th scope="col">نام</th>
                    </tr>
                </thead>
                <tbody>
                  <tr v-for="data in datas" :key="data.id">
                      <td v-if="data.status == 0" @click="changeStatus(data.id)">
                          <button v-if="data.person" class="btn btn-sm btn-primary" type="button" data-toggle="modal" data-target=".person-calls-modal" @click="getPersonCalls(id);setSelectedPerson({id: data.person.id, data: data.person});" >✖</button>
                          <button v-else type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".add-person-modal" @click="openAddPerson(data)">✖</button>
                          </td>
                      <td role="button" v-else style="color:green" @click="changeStatus(data.id)">✔</td>
                      <td>{{data.phone}}</td>
                      <td>{{data.created_at}}</td>
                      <td>
                          <div class="d-flex">
                                <input class="form-control" width="70" v-model="data.comment" placeholder="ثبت توضیحات و انصراف">
                                <button @click="exceptWithComment(data)" class="btn btn-primary btn-sm"><i class="fal fa-fist-raised"></i></button>
                          </div>
                          <div class="d-flex mt-2">
                              <v-select style="width:100%" v-model="data.userphone" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                                <button @click="exceptWithPhone(data)" class="btn btn-primary btn-sm"><i class="fal fa-fist-raised"></i></button>
                          </div>
                      </td>
                      <td :class="[data.metaphone.length || data.person ? null : 'text-danger']">{{data | detectPerson}}</td>
                  </tr>
                </tbody>
                </table>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>
export default {
    name:"MissedCalls",
    data(){
        return{
            url: '/api/v1/caller/missed/list?status=0',
            users: []
        }
    },
    mounted(){
        this.getData();
    },
    filters:{
        detectPerson(data){
            if(data.person) return data.person.name
            if(data.metaphone.length) return data.metaphone[0].obj.name
            return 'ثبت نشده'
        }
    },
    methods: {
        changeStatus(id){
            axios.get(`/api/v1/caller/changestatus/${id}`)
            .then(res => {
                this.getData();
            })
        },
        openAddPerson(data){
            
    var url = new URL(window.location.href);
    var search_params = url.searchParams;
    search_params.set("phone", data.phone);
    url.search = search_params.toString();
    var new_url = url.toString();
    let stateObj = { id: "100" }; 
        window.history.replaceState(stateObj, 
                "https://portal.aryatehran.com", decodeURIComponent(new_url)); 

            this.addPerson();
        },
        
        exceptWithComment(data){
            axios.post(`/api/v1/caller/except-with-comment`, data)
            .then(res => {
                this.getData();
            })
        },
        exceptWithPhone(data){
            axios.post(`/api/v1/caller/except-with-phone`, data)
            .then(res => {
                this.getData();
            })
        }
    }
 
}
</script>
