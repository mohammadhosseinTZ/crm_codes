<template>
    <div class="person-data">
        <div class="modal fade person-data-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <person-data />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import PersonData from './Datas/PersonData.vue'
export default {
   name:"PersonData",
   components: {
       'person-data': PersonData
   }
}
</script>
