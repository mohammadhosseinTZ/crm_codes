<template>
    <div class="person-exams">
        
        <div class="modal fade person-exams-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <person-exams />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import PersonExams from './Datas/PersonExams.vue'
export default {
   name:"PersonExams",
   components:{
       'person-exams': PersonExams
   }
}
</script>
