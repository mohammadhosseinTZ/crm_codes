<template>
    <div>Hello</div>
</template>
<script>

export default {
    name: "Person",
    mounted: function(){
    }
}
</script>