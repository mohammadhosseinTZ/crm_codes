<template>
    <!-- Modal -->
<div class="pursuit">
    <div class="modal fade check-date-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                    <h5 class="modal-title">چک های امروز</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <table class="table table-bordered">
            <tr>
                <th>وضعیت</th>
                <th>تاریخ</th>
                <th>سریال</th>
                <th>صیاد</th>
                <th>مبلغ</th>
                <th>تاریخ صدور</th>
                <th>بانک</th>
                <th>ثبت کننده</th>
                <th>برای</th>
                <th>اکشن</th>
            </tr>
            <tr v-for="check in datas" :key="check.id">
                <td v-if="check.status == 0" style="color:red">✖</td>
                <td v-else style="color:green">✔</td>
                <td>{{check.created_at}}</td>
                <td>{{check.serial}}</td>
                <td>{{check.saiyad}}</td>
                <td>{{check.price}}</td>
                <td>{{check.receipt}}</td>
                <td>{{check.bank.option_value}}</td>
                <td>{{check.user_insert.name}}</td>
                <td>{{check.payment.code}}</td>
            </tr>
        </table>
          
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>
import moment from 'moment'
export default {
    name:"TodayCheck",
    data(){
        return{
            url: '/api/v1/check?search-check='+ moment(new Date()).format('YYYY-MM-DD')
        }
    },
    mounted(){
        this.getData();
    },
 
}
</script>
