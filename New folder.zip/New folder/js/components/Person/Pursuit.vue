<template>
    <div class="row">
        <button class="btn btn-sm btn-primary ml-1" v-if="can('can_pursuit_persons')" @click="todaypursuit++"
            data-toggle="modal" data-target=".pursuirs-modal">
            <span class="material-symbols-rounded">
                notifications
            </span>
        </button>
        <div v-if="todaypursuit">
            <TodayPursuit :key="todaypursuit" />
        </div>

        <button class="btn btn-sm btn-primary ml-1" v-if="can('can_pursuit_birthdates')" @click="todaybirthdate++"
            data-toggle="modal" data-target=".birth-date-modal">
            <span class="material-symbols-rounded">
                groups
            </span>
        </button>
        <div v-if="todaybirthdate">
            <TodayBirthDate :key="todaybirthdate" />
        </div>

        <button class="btn btn-sm btn-primary ml-1" v-if="can('can_pursuit_checks')" @click="todatecheck++"
            data-toggle="modal" data-target=".check-date-modal">
            <span class="material-symbols-rounded">
                checkbook
            </span>
        </button>
        <div v-if="todatecheck">
            <TodayCheck :key="todatecheck" />
        </div>

        <button class="btn btn-sm btn-primary ml-1" v-if="can('can_pursuit_misscalls')" @click="missedcalls++"
            data-toggle="modal" data-target=".miss-calls-modal">
            <span class="material-symbols-rounded">
                phone_enabled
            </span>
        </button>
        <div v-if="missedcalls">
            <MissedCalls :key="missedcalls" />
        </div>
    </div>
</template>

<script>
import TodayPursuit from './TodayPursuit'
import TodayBirthDate from './TodayBirthDate'
import TodayCheck from './TodayCheck'
import MissedCalls from './MissedCalls'


export default {
    name: "Pursuit",
    components: {
        TodayPursuit,
        TodayBirthDate,
        TodayCheck,
        MissedCalls
    },
    data() {
        return {
            todaypursuit: 0,
            todaybirthdate: 0,
            todatecheck: 0,
            missedcalls: 0
        }
    }
}
</script>
