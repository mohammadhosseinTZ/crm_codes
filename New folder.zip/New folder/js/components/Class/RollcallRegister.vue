<template>
<div class="session-rollcall">
        <div class="modal fade register-rollcall-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">حضورغیاب این ثبت نامی</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-bordered rollcals">
                            <tr>
                                <th>وضعیت</th>
                                <th>کد</th>
                                <th>نام کلاس</th>
                                <th>دوره</th>
                                <th>مدرس</th>
                                <th>ساعت برگذاری</th>
                                <th>ساعت پایان</th>
                                <th>ساعت حضور</th>
                                <th>تاخیر به دقیقه</th>
                                <th v-if="can('manage_rollcall_comment')" class="mot-w-300">توضیحات</th>
                                <th>اکشن</th>
                            </tr>
                            <tr v-for="item in rollcalls" :key="item.id" :class="[parseInt(item.rollcall_session_status) == 0 && item.rollcall_session_status != 'none' ? 'leave' : null, parseInt(item.rollcall_session_status) == 1 && item.rollcall_session_status != 'none' ? 'clear' : null ]">
                                <td role="button" v-if="parseInt(item.rollcall_session_status) == 0" style="color:red">✖</td>
                                <td role="button" v-else-if="item.rollcall_session_status == 'none'" style="color:orange">نامشخص</td>
                                <td role="button" v-else style="color:green">✔</td>
                                <td>{{item.session.id}}</td>
                                <td>{{item.session.class.name}}</td>
                                <td>{{item.session.class_course.course.name}} - {{item.session.class_course.course_code}}</td>
                                <td>{{item.session.teacher.name}}</td>
                                <td>{{item.session.from}}</td>
                                <td>{{item.session.to}}</td>
                                <td>{{item.rollcall_created_at}}</td>
                                <td>{{item.rollcall_presence_time}}</td>
                                <td v-if="can('manage_rollcall_comment')">
                                    <form v-if="parseInt(item.rollcall_session_status) == 0" @submit.stop.prevent="addRollCallComment(item)" class="d-flex">
                                        <input v-model="item.comment" class="form-control form-control-sm" placeholder="دلیل غیبت">
                                        <button class="btn btn-primary btn-sm">تایید</button>
                                    </form>
                                </td>
                                <td>
                                    <button v-if="can('can_manage_rollcall')" class="btn btn-danger btn-sm" @click="changeStatus({item: item, status: 0})">غایب</button>
                                    <button v-if="can('can_manage_rollcall')" class="btn btn-success btn-sm" @click="changeStatus({item: item, status: 1})">حاضر</button>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>
</template>

<script>

import { mapGetters,mapActions } from 'vuex';
export default {
    name:"RollcallRegister",
    computed:{
        ...mapGetters({
            rollcalls: 'RollCall/get',
        }),
    },
    methods: {
        ...mapActions({
            changeStatus: 'RollCall/changeStatus',
            addRollCallComment: 'RollCall/addRollCallComment'
        })
    }
}
</script>
