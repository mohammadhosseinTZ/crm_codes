<template>
    <div class="add-call">
        <div class="modal fade manage-course-class-modal" tabindex="-1" role="dialog"
            aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">مدیریت دوره کلاس</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                        <div id="accordion">
                            <div class="card">
                                <div class="card-header p-0" id="headingOne">
                                    <h5 class="mb-0">
                                        <button class="btn mt-1 mb-1 collapsed"
                                            @click="addSession({ id: classcoursesession.class_course_id || classcoursesession.insideId, type: classcoursesession.type })"
                                            data-toggle="collapse" data-target="#collapseOne" aria-expanded="false"
                                            aria-controls="collapseOne">
                                            <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                                        </button>
                                    </h5>
                                </div>

                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                                    data-parent="#accordion">
                                    <div class="card-body">
                                        <form action="" @submit.stop.prevent="addData">
                                            <ul class="err-box">
                                                <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}
                                                </li>
                                            </ul>
                                            <div class="row mot-modal-inputs-5 m-0">

                                                <div class="form-group">
                                                    <label for="class">کلاس</label>
                                                    <v-select id="class" v-if="classes.length"
                                                        v-model="classcoursesession.class" :options="classes" />
                                                </div>
                                                <div class="form-group">
                                                    <label for="start_at">ساعت شروع</label>
                                                    <date-picker id="start_at" format="YYYY-MM-DD HH:mm" display-format="HH:mm" v-model="classcoursesession.from" type="time" />
                                                </div>
                                                <div class="form-group">
                                                    <label for="end_at">ساعت پایان</label>
                                                    <date-picker id="end_at" format="YYYY-MM-DD HH:mm" display-format="HH:mm" v-model="classcoursesession.to" type="time" />
                                                </div>
                                                <div class="form-group">
                                                    <label for="">تاریخ ها</label>
                                                    <date-picker format="YYYY-MM-DD"
                                                        @change="show_time_change_sms_input = true"
                                                        display-format="jYYYY-jMM-jDD"
                                                        :min="can('session_past') ? null : fdate"
                                                         v-model="classcoursesession.mainLoops" :multiple="classcoursesession.insideType != 'update'" />
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="session-type">نوع جلسه</label>
                                                    <v-select id="session-type"
                                                        v-model="classcoursesession.session_type"
                                                        :options="session_types" />
                                                </div>
                                    
                                                <div class="form-group">
                                                    <label for="teacher">مدرس</label>
                                                    <v-select id="teacher" v-model="classcoursesession.teacher"
                                                        :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                                                </div>
                                                <div class="form-group">
                                                    <label for="status">وضعیت</label>
                                                    <select class="form-control" v-model="classcoursesession.status"
                                                        id="status">
                                                        <option v-for="d in statuses" :key="d.id" :value="d.id">
                                                            {{ locate(d.option_value) }}</option>
                                                    </select>
                                                </div>
                                                <div class="form-group" v-if="showCancleInput()">
                                                    <label for="cancle-sms">ارسال پیام کنسل شدن جلسه به شاگردان؟</label>
                                                    <input type="checkbox" v-model="classcoursesession.sendCancelSms"
                                                        id="cancle-sms">
                                                </div>

                                                <div class="form-group">
                                                    <label for="online-link">لینک کلاس آنلاین</label>
                                                    <input type="text" class="form-control"
                                                        v-model="classcoursesession.online_link" for="online-link">
                                                </div>

                                                <div class="form-group"
                                                    v-if="show_time_change_sms_input && classcoursesession.insideType == 'update'">
                                                    <label for="time-sms">ارسال پیام تغییر زمان جلسه به شاگردان؟</label>
                                                    <input type="checkbox"
                                                        v-model="classcoursesession.sendChangeTimeSms" id="time-sms">
                                                </div>

                                                

                                            </div>
                                            <div class="rowmot-modal-inputs mt-3">
                                                <div class="form-group">
                                                    <input type="submit" class="form-control"
                                                        :value="[classcoursesession.insideType == 'update' ? 'ویرایش' : 'افزودن']">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="row course-session">
                            <div class="col">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>نام کلاس</th>
                                        <th>دوره</th>
                                        <th>مدرس</th>
                                        <th>وضعیت</th>
                                        <th>ساعت برگذاری</th>
                                        <th>ساعت پایان</th>
                                        <th>اکشن</th>
                                    </tr>
                                    <tr v-for="data in events" :key="data.id">
                                        <td>{{ data.class.name }}</td>
                                        <td>{{ data.course_code }}</td>
                                        <td>{{ data.teacher_name }}</td>
                                        <td>{{ locate(data.statusopt.option_value) }}</td>
                                        <td>{{ data.from }}</td>
                                        <td>{{ data.to }}</td>
                                        <td class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false">
                                                اطلاعات
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <button type="button" v-if="can('edit_session')"
                                                    @click="editSession({ data: data })"
                                                    class="btn btn-primary">ویرایش</button>
                                                <button type="button" v-if="can('delete_session')"
                                                    @click="deleteItem(`/session/${data.id}`, data.id, deleteSession)"
                                                    class="btn btn-danger d-block mt-1 w-100">حذف</button>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
export default {
    name: "ManageClassSessions",
    props: ['type', 'id'],
    data() {
        return {
            classes: window.classRooms,
            users: [],
            statuses: window.statuses,
            url: null,
            fdate: null,
            session_types: window.defined_enums.session_type,
            show_time_change_sms_input: false
        }
    },
    computed: {
        ...mapGetters({
            events: 'Calendar/events',
            classcoursesession: 'Calendar/classcoursesession'
        })
    },
    mounted() {
        this.fdate = window.fdate
    },
    methods: {
        ...mapActions({
            editSession: 'Calendar/editSession',
            addSession: 'Calendar/addSession',
            updateSession: 'Calendar/updateSession',
            deleteSession: 'Calendar/delete',
        }),

        addData() {
            this.vr(this.classcoursesession.class, 'نام کلاس');
            this.vr(this.classcoursesession.teacher, 'نام مدرس');
            this.vr(this.classcoursesession.status, 'وضعیت');
            this.vr(this.classcoursesession.from, 'تاریخ شروع');
            this.vr(this.classcoursesession.to, 'تاریخ پایان');

            if (!this.v_error_check()) return;
            axios.post(`/api/v1/class-course/${this.classcoursesession.class_course_id}/session`, this.classcoursesession)
                .then(res => {
                    if (res.data.alert && res.data.alert.type == 'error') return;

                    this.updateSession(res.data.data);
                });

        },
        showCancleInput() {
            if ((this.classcoursesession.status == window.CANCELED_STATUS || this.classcoursesession.status == window.DECLINED_STATUS) && this.classcoursesession.insideType == 'update') return true
            this.classcoursesession.sendCancelSms = null
            return false
        }
    }
}
</script>