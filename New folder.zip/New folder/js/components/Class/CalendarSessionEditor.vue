<template>
    <div class="edit-session">
        <div class="modal fade manage-session-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">مدیریت جلسه با کد: {{classcoursesession.insideId}}</h5>
                        <button v-if="can('delete_session')" type="button" data-dismiss="modal" aria-label="Close" @click="deleteItem(`/session/${classcoursesession.insideId}`, classcoursesession.insideId, deleteSession)" class="btn btn-danger btn-sm" >حذف</button>    
                        <button type="button" class="close m-0" ref="close-session-button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                       <div class="d-flex">
                        <button  type="button" v-if="can('can_see_rollcall')" class="btn btn-link btn-primary text-white my-2 mot-w-100 ml-1" data-toggle="modal" @click="getRollCallDatas({session: classcoursesession})" data-target=".session-rollcall-modal" >حضورغیاب</button>

                            <button @click="getClassCourse" class="btn btn-link btn-primary text-white my-2 mot-w-100 ml-1">
                            اطلاعات
                            </button>
                       </div>
                            <div v-if="classCourse">
                                <table class="table">
                                    <tr>
                                        <th>کد</th>
                                        <th>نام کلاس</th>
                                        <th>نام دوره</th>
                                        <th>روز</th>
                                        <th>ساعت</th>
                                        <th>تاریخ برگذاری</th>
                                        <th>مدرس</th>
                                        <th>تعداد ساعت کلاس</th>
                                        <th>زمان سپری شده</th>
                                        <th class="mot-w-100">تعداد افراد</th>
                                    </tr>
                                    <tr>
                                        <td>{{classCourse.course_code}}</td>
                                        <td>{{classCourse.class.name}}</td>
                                        <td>{{classCourse.course.name}}</td>
                                        <td>{{classCourse.day}}</td>
                                        <td v-if="classCourse.start_time && classCourse.end_time">{{classCourse.start_time + " الی " + classCourse.end_time}}</td>
                                        <td v-else> </td>
                                        <td>{{classCourse.begin_date}}</td>
                                        <td>{{classCourse.teacher.name}}</td>
                                        <td>{{classCourse.time}}</td>
                                        <td>{{classCourse.elapsed_time}}</td>
                                        <td><button v-if="can('see_registers')" type="button" class="btn btn-primary px-2 py-1" data-toggle="modal" data-target=".class-course-registers-modal" @click="getRegisters({data: `/api/v1/class-course/${classCourse.id}/registers`})">{{classCourse.registers_count}}</button></td>
                                    </tr>
                                </table>
                            </div>

                            <div v-if="user">
                                    <table class="table">
                                        <tr>
                                            <th>نام</th>
                                            <th>شماره</th>
                                            <th>اکشن</th>
                                        </tr>
                                        <tr>
                                            <td>{{user.name}}</td>
                                            <td>{{user.phone}}</td>
                                            <td>
                                                <PersonButtons :id="user.id" :userdata="user" />
                                            </td>
                                        </tr>
                                    </table>
                            </div>
                        
                        <form action="" @submit.stop.prevent="addData">
                            <ul class="err-box">
                                    <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                            </ul>
                            <div class="row mot-modal-inputs-5 m-0">
                      
                                    <div class="form-group">
                                            <label for="class">کلاس</label>
                                            <v-select id="class" v-if="classes.length" v-model="classcoursesession.class" :options="classes" />
                                        </div>
                                        <div class="form-group">
                                            <label for="">از</label>
                                            <date-picker format="YYYY-MM-DD HH:mm" @change="show_time_change_sms_input = true"  display-format="jYYYY-jMM-jDD HH:mm" :min="can('session_past') ? null : fdate" type="datetime"  auto-submit v-model="classcoursesession.from" compact-time />
                                        </div>
                                        <div class="form-group">
                                            <label for="">تا</label>
                                            <date-picker format="YYYY-MM-DD HH:mm" @change="show_time_change_sms_input = true"   display-format="jYYYY-jMM-jDD HH:mm" :min="can('session_past') ? null : fdate" type="datetime"  auto-submit v-model="classcoursesession.to" compact-time />
                                        </div>

                                        <div class="form-group">
                                            <label for="session-type">نوع جلسه</label>
                                            <v-select id="session-type" v-model="classcoursesession.session_type" :options="session_types" />
                                        </div>

                                        
                                        <div class="form-group">
                                            <label for="teacher">مدرس</label>
                                            <v-select id="teacher" v-model="classcoursesession.teacher" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                                        </div>

                                        <div class="form-group">
                                            <label for="status">وضعیت</label>
                                            <select class="form-control" v-model="classcoursesession.status" id="status">
                                               <option v-for="d in statuses" :key="d.id" :value="d.id">{{locate(d.option_value)}}</option>  
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="online-link">لینک کلاس آنلاین</label>
                                            <input type="text" class="form-control" v-model="classcoursesession.online_link" for="online-link">
                                        </div>


                                        <div class="form-group" v-if="showCancleInput()">
                                            <label for="cancle-sms">ارسال پیام کنسل شدن جلسه به شاگردان؟</label>
                                            <input type="checkbox" v-model="classcoursesession.sendCancelSms" id="cancle-sms">
                                        </div>
                                       
                                        <div class="form-group" v-if="show_time_change_sms_input">
                                            <label for="time-sms">ارسال پیام تغییر زمان جلسه به شاگردان؟</label>
                                            <input type="checkbox" v-model="classcoursesession.sendChangeTimeSms" id="time-sms">
                                        </div>
                
                                   
                            </div>
                            <div class="row mot-modal-inputs mt-3">
                                <div class="form-group" v-if="can('edit_session')">
                                        <input type="submit" class="form-control" :value="[classcoursesession.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
            <ClassCourseRegisters />
            <Rollcallsessions />
    </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex';
import ClassCourseRegisters from '../Class/ClassCourseRegisters.vue'
import Rollcallsessions from './Rollcallsessions.vue'
export default{
    components: {
        ClassCourseRegisters,
        Rollcallsessions
    },
    data(){
        return {
            classes: window.classRooms,
            users: [],
            statuses: window.statuses,
            classCourse: null,
            user: null,
            fdate: null,
            show_time_change_sms_input: false,
            session_types: window.defined_enums.session_type
        }
    },
    computed: {
        ...mapGetters({
            classcoursesession: 'Calendar/classcoursesession',
        }),
    },
    mounted(){
        this.fdate = window.fdate

        var obj = this
        $('.manage-session-modal').on('hidden.bs.modal', function (e) {
            obj.user = null
            obj.classCourse = null
        })
    },
    methods: {
        ...mapActions({
            updateEvent: 'Calendar/updateEvent',
            deleteSession: 'Calendar/delete',
            getRegisters: 'Register/getDatas',
            getRollCallDatas: 'RollCall/getDatas'
        }),
        
        addData() {
            if(!this.can('edit_session')) return;
            this.vr(this.classcoursesession.to, 'پایان');
            this.vr(this.classcoursesession.from, 'شروع');
            this.vr(this.classcoursesession.class, 'نام کلاس');
            this.vr(this.classcoursesession.teacher, 'نام مدرس');
            this.vr(this.classcoursesession.status, 'وضعیت');
            if(!this.v_error_check()) return;
            axios.post(`/api/v1/class-course/${this.classcoursesession.class_course_id}/session`, this.classcoursesession)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                $('.manage-session-modal').modal('hide')
                this.updateEvent({data: res.data.data})
            });
          
        },

        getClassCourse(){
            axios.get(`/api/v1/session/${this.classcoursesession.insideId}/data`).then(res =>{
                if(res.data.data.type == 'register'){
                    this.user = res.data.data
                }else{
                    this.classCourse = res.data.data
                }
            })
        },
        showCancleInput(){
            if(this.classcoursesession.status == window.CANCELED_STATUS || this.classcoursesession.status == window.DECLINED_STATUS) return true
            this.classcoursesession.sendCancelSms = null
            return false
        }
    }
}
</script>
