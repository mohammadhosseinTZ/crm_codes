<template>
    <div class="edit-session">
        {{ config }}
        <div class="modal fade manage-free-session-modal" tabindex="-1" role="dialog"
            aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">مدیریت جلسه</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                        <form action="" @submit.stop.prevent="addData">
                            <ul class="err-box">
                                <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                            </ul>
                            <div class="row mot-modal-inputs-4 m-0">

                                <div class="form-group">
                                    <label for="class">کلاس</label>
                                    <v-select id="class" v-if="classes.length" v-model="classcoursesession.class"
                                        :options="classes" />
                                </div>
                                <div class="form-group">
                                    <label for="">از</label>
                                    <date-picker format="YYYY-MM-DD HH:mm" display-format="jYYYY-jMM-jDD HH:mm"
                                        :min="can('session_past') ? null : fdate" type="datetime" auto-submit
                                        v-model="classcoursesession.from" compact-time />
                                </div>
                                <div class="form-group">
                                    <label for="">تا</label>
                                    <date-picker format="YYYY-MM-DD HH:mm" display-format="jYYYY-jMM-jDD HH:mm"
                                        :min="can('session_past') ? null : fdate" type="datetime" auto-submit
                                        v-model="classcoursesession.to" compact-time />
                                </div>
                                <div class="form-group">
                                    <label for="session-type">نوع جلسه</label>
                                    <v-select id="session-type" v-model="classcoursesession.session_type"
                                        :options="session_types" />
                                </div>
                               
                                <div class="form-group">
                                    <label for="teacher">مدرس</label>
                                    <v-select id="teacher" v-model="classcoursesession.teacher" :options="users"
                                    @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                                </div>
                                <div class="form-group">
                                    <label for="status">وضعیت</label>
                                    <select class="form-control" v-model="classcoursesession.status" id="status">
                                        <option v-for="d in statuses" :key="d.id" :value="d.id">
                                            {{ locate(d.option_value) }}</option>
                                    </select>
                                </div>

                                <!-- switcher -->
                                <div class="form-group">
                                    <label for="type">نوع برگزاری</label>
                                    <select class="form-control" v-model="classcoursesession.type" id="type">
                                        <option value="register">خصوصی</option>
                                        <option value="public">عمومی</option>
                                    </select>
                                </div>


                                <!-- public -->
                                <div class="public" v-if="classcoursesession.type == 'public'">
                                    <div class="form-group">
                                        <label for="classcourse">نام دوره</label>
                                        <v-select id="classcourse" @input="getTeacher"
                                            v-model="classcoursesession.class_course" :options="classCourses"
                                            @search="searchClassCourse" />
                                    </div>
                                </div>

                                <!-- private -->
                              

                                    <div class="form-group" v-if="classcoursesession.type == 'register'">
                                        <label for="name">نام</label>
                                        <v-select @input="getUserCourses" id="name" v-model="classcoursesession.name"
                                            :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                                    </div>
                                    <div class="form-group" v-if="classcoursesession.type == 'register'">
                                        <label for="userCourses">انتخاب جلسه برای دوره</label>
                                        <v-select id="userCourses" v-model="classcoursesession.class_course"
                                            :options="userCourses" />
                                    </div>

                                    <div class="form-group">
                                        <label for="online-link">لینک کلاس آنلاین</label>
                                        <input type="text" class="form-control" v-model="classcoursesession.online_link"
                                            for="online-link">
                                    </div>

                            </div>
                            <div class="row mot-modal-inputs-4 mt-3">
                                <div class="form-group">
                                    <input type="submit" class="form-control"
                                        :value="[classcoursesession.insideType == 'update' ? 'ویرایش' : 'افزودن']">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import { mapGetters, mapActions } from 'vuex';
import moment from 'moment'
export default {
    data() {
        return {
            classcoursesession: {
                class: null,
                teacher: null,
                comment: null,
                status: null,
                from: null,
                to: null,
                insideId: null,
                insideType: null,
                type: null,
                class_course: null,
                session_type: null,
                name: null,
            },
            classes: window.classRooms,
            users: [],
            statuses: window.statuses,
            classCourses: window.classCourses,
            session_types: window.defined_enums.session_type,
            userCourses: [],
            class_course_id: null,
            fdate: null
        }
    },
    computed: {
        ...mapGetters({
            grabData: 'Calendar/grabData',
        }),
        config() {
            if (!this.grabData) return;
            this.classcoursesession.class = this.classes.find(x => x.id == this.grabData.resourceId)

            this.classcoursesession.from = this.grabData.start // gregorian 
            this.classcoursesession.to = this.grabData.end // gregorian 
            this.classcoursesession.mainLoops = this.grabData.start // gregorian 
            this.classcoursesession.insideType = 'insert' // gregorian 
        }
    },
    mounted() {
        this.fdate = window.fdate
    },
    methods: {
        ...mapActions({
            addEvent: 'Calendar/addEvent'
        }),

        getTeacher() {
            axios.get('/api/v1/class-course/' + this.classcoursesession.class_course.id)
                .then(res => {
                    res.data.data.teacher.label = res.data.data.teacher.name
                    this.classcoursesession.teacher = res.data.data.teacher
                })
        },
        getUserCourses() {
            this.classcoursesession.class_course = null
            axios.get(`/api/v1/person/${this.classcoursesession.name.id}/register`)
                .then(res => {
                    let courses = []
                    res.data.data.map(x => {
                        x.label = x.course.name
                        courses.push(x)
                    })
                    this.userCourses = courses
                })
        },
        addData() {
            this.vr(this.classcoursesession.to, 'پایان');
            this.vr(this.classcoursesession.from, 'شروع');
            this.vr(this.classcoursesession.class, 'نام کلاس');
            this.vr(this.classcoursesession.teacher, 'نام مدرس');
            this.vr(this.classcoursesession.status, 'وضعیت');
            this.vr(this.classcoursesession.class_course, 'نام دوره');

            if (!this.v_error_check()) return;


                axios.post(`/api/v1/class-course/${this.classcoursesession.class_course.id}/session`, this.classcoursesession)
                .then(res => {
                    if (res.data.alert && res.data.alert.type == 'error') return;
                    $('.manage-free-session-modal').modal('hide')
                    this.classcoursesession.class_course = null
                    this.classcoursesession.name = null
                    this.classcoursesession.teacher = null
                    this.classcoursesession.type = null

                    this.addEvent({ data: res.data.data })
                });

        },

        searchClassCourse(search, loading) {
            if (!search.length) return;
            loading = true;
            axios.get(`/api/v1/class-course?search=${search}`)
                .then(res => {
                    this.classCourses = res.data.data.filter(res => parseInt(res.course_code) != 999)
                    loading = false;
                });
        },
    }
}
</script>
