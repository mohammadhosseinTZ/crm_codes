<template>
<div class="session-rollcall">
        <div class="modal fade session-rollcall-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">حضورغیاب جلسه با کد: {{session.insideId || session.id}}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form @submit.stop.prevent="addComment(session)">
                            <div class="form-group">
                                <label>توضیحات جلسه</label>
                                <textarea :disabled="!can('is_teacher') && !can('manage_session_comment')" v-model="session.comment" class="form-control mot-label-constant" placeholder="توضیحات جلسه را وارد کنید. مثالا چه چیزی تدریس کرده اید"></textarea>
                            </div>
                            <div class="form-group my-3">
                                <button :disabled="!can('is_teacher') && !can('manage_session_comment')" class="btn btn-primary btn-sm">ثبت</button>
                            </div>
                        </form>
                        <div class="d-flex mb-2">
                           <div class="set-start ml-2">
                                <button class="btn btn-sm btn-success mb-1" @click="setStart(session)">
                                    <span v-if="session.teacher_start">شروع کلاس در: <span dir="ltr">{{session.teacher_start | minut}}</span></span>
                                    <span v-else>ثبت شروع کلاس</span>
                                </button>
                                <date-picker v-if="can('rollcall_any_time')" class="mt-2" format="YYYY-MM-DD HH:mm" display-format="jYYYY-jMM-jDD HH:mm" type="datetime"  auto-submit v-model="session.teacher_start"  compact-time />
                           </div>
                           <div class="set-end">
                                <button class="btn btn-sm btn-success mb-1" @click="setEnd(session, status_to)">
                                    <span v-if="session.teacher_end" dir="ltr">پایان کلاس در: <span dir="ltr">{{session.teacher_end | minut}}</span></span>
                                    <span v-else>ثبت پایان کلاس</span>
                                </button>
                                <date-picker v-if="can('rollcall_any_time')" class="mt-2" format="YYYY-MM-DD HH:mm" display-format="jYYYY-jMM-jDD HH:mm" type="datetime"  auto-submit v-model="session.teacher_end" compact-time />

                           </div>
    
                        </div>
                        <table class="table table-bordered rollcals">
                            <tr>
                                <th class="mot-w-45">وضعیت</th>
                                <th>نام</th>
                                <th>ساعت حضور</th>
                                <th>تاخیر به دقیقه</th>
                                <th class="mot-w-200" v-if="can('manage_rollcall_comment')">توضیحات</th>
                                <th>اکشن</th>
                            </tr>
                            <tr v-for="item in rollcalls" :key="item.id" :class="[parseInt(item.rollcall_session_status) == 0 && item.rollcall_session_status != 'none' ? 'leave' : null, parseInt(item.rollcall_session_status) == 1 && item.rollcall_session_status != 'none' ? 'clear' : null ]">
                                <td class="mot-w-45" role="button" v-if="parseInt(item.rollcall_session_status) == 0" style="color:red">✖</td>
                                <td role="button" v-else-if="item.rollcall_session_status == 'none'" style="color:orange">نامشخص</td>
                                <td role="button" v-else style="color:green">✔</td>
                                <td>{{item.user.name}}</td>
                                <td>{{item.rollcall_created_at}}</td>
                                <td>{{item.rollcall_presence_time}}</td>
                                <td class="mot-w-200" v-if="can('manage_rollcall_comment')">
                                    <form v-if="parseInt(item.rollcall_session_status) == 0" @submit.stop.prevent="addRollCallComment(item)" class="d-flex">
                                        <input v-model="item.comment" class="form-control form-control-sm" placeholder="دلیل غیبت">
                                        <button class="btn btn-primary btn-sm">تایید</button>
                                    </form>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <button v-if="can('can_manage_rollcall')" class="btn btn-danger btn-sm" @click="changeStatus({item: item, status: 0})">غایب</button>
                                        <button v-if="can('can_manage_rollcall')" class="btn btn-success btn-sm mr-2" @click="changeStatus({item: item, status: 1})">حاضر</button>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
</div>
</template>

<script>

import { mapGetters,mapActions } from 'vuex';
import moment from 'moment'

export default {
    name:"RollCallSessions",
    computed:{
        ...mapGetters({
            rollcalls: 'RollCall/get',
            session: 'RollCall/session',
        })
    },
    filters: {
        minut(val){
            if(val){
            return moment(val).format('HH:mm')  
            }
            return val
        }
    },
    methods: {
        ...mapActions({
            changeStatus: 'RollCall/changeStatus',
            setStart: 'RollCall/setStart',
            setEnd: 'RollCall/setEnd',
            addComment: 'RollCall/addComment',
            addRollCallComment: 'RollCall/addRollCallComment'
        })
    }
}
</script>
