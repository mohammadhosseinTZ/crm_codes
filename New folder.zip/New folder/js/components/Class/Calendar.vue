<template>
  <div class="mot-padding">
     <CalendarSessionEditor />
     <FreeSessionManage />
     <div class="row mot-modal-inputs mb-2">
            <div class="form-group">
                  <label for="teacher">مدرس</label>
                  <v-select id="teacher" multiple @input="searchUserFilter" v-model="filters.userInsert" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
            </div>
            <div class="form-group">
               <label for="">انتخاب تاریخ</label>
               <date-picker auto-submit format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" v-model="selecteddate" @change="setDateCalendar" />
            </div>
     </div>
   
     <CalendarEvent :date="eventsDate.toISOString()" :key="eventsDate.toISOString()" />

     <FullCalendar id="fullCalendar"  ref="fullCalendar" :options="config" />


      <div class="mt-3" v-if="can('session_statistics')">
            <table class="table table-bordered">
               <tr v-if="statistics">
                  <th v-for="(sp, indexkey) in statistics" :key="indexkey">{{locate(sp.statusopt.option_value)}}</th>
               </tr>
               <tr v-if="statistics">
                  <td v-for="(sp, indexkey) in statistics" :key="indexkey">{{sp.time}}</td>
               </tr>
            </table>
      </div>

  </div>
  
</template>
<script>
import CalendarSessionEditor from './CalendarSessionEditor.vue'
import FreeSessionManage from './FreeSessionManage.vue'
import CalendarEvent from './CalendarEvent.vue'
import '@fullcalendar/core/vdom' // solves problem with Vite
import FullCalendar from '@fullcalendar/vue'
import faLocale from '@fullcalendar/core/locales/fa'
import interactionPlugin, { Draggable } from '@fullcalendar/interaction'
import resourceTimelinePlugin  from '@fullcalendar/resource-timeline';
import adaptivePlugin from '@fullcalendar/adaptive'
import { mapActions, mapGetters } from 'vuex';
import moment from 'moment'
export default {
   computed: {
        ...mapGetters({
            events: 'Calendar/events',
            statistics: 'Calendar/statistics',
        }),
        config(){
           this.calendarOptions.events = this.events
           return this.calendarOptions
        }
    },
	components: {
		FullCalendar, // make the <FullCalendar> tag available
      CalendarSessionEditor,
      FreeSessionManage,
      CalendarEvent
	},
	data() {
		return {
            classes: [],
            selecteddate: null,
            users: [],
            url: '/api/v1/session',
            date: null,
            eventsDate: new Date(),
			   calendarOptions: {
				   plugins: [resourceTimelinePlugin, interactionPlugin, adaptivePlugin],
				   timeZone: 'Asia/Tehran',
				   initialView: 'resourceTimelineDay',
				   aspectRatio: 1.5,
				   headerToolbar: {
					   left: 'prev,today,next',
					   center: 'title',
					   right: ''
				},
				resourceAreaHeaderContent: 'اتاق ها',
				resources: window.classRooms,
            resourceOrder: 'order',
				events: [],
            
            slotDuration: '00:15:00',
            slotLabelInterval: 15,
            resourceAreaWidth: '150px',
            contentHeight: 'auto',

            //  slotWidth: "2%",
            //   eventOverlap: false,
            //   selectOverlap: false,

            businessHours: {
               // days of week. an array of zero-based day of week integers (0=Sunday)
               daysOfWeek: [ 1, 2, 3, 4,5,6,7 ], // Monday - Thursday
               startTime: '08:00', // a start time (10am in this example)
               endTime: '21:00', // an end time (6pm in this example)
               },

            slotMinTime: '08:00',
            slotMaxTime: '21:00',

				droppable: false,
				editable: true,
            selectable: true,
            eventResourceEditable: true,

            locale: faLocale,

				eventDrop: info => {
               if(!this.can('edit_session')) return false;
               this.drop({resource: info.newResource ? info.newResource.id : null , id: info.event.id, start: info.event.startStr, end: info.event.endStr })
            },

            eventClick: info => {
               var data = this.events.find(res => res.id == info.event.id)
               this.edit({id:data.id, data:data})
               $('.manage-session-modal').modal('show')
            },

            eventResize: info => {
               if(!this.can('edit_session')) return false;
               this.resize({id: info.event.id, start: info.event.startStr, end: info.event.endStr})
            },

            select : args => {
               if(!this.can('add_session')) return false;
               
               let start = moment(args.startStr).format('YYYY-MM-DD HH:mm')
               let end = moment(args.endStr).format('YYYY-MM-DD HH:mm')
               let fastart = this.p2e(new Date(moment(args.startStr).format('YYYY-MM-DD')).toLocaleDateString('fa-IR') +" "+ moment(args.startStr).format('HH:mm'))
               let faend = this.p2e(new Date(moment(args.endStr).format('YYYY-MM-DD')).toLocaleDateString('fa-IR') +" "+ moment(args.endStr).format('HH:mm'))
               
               this.grap({resourceId: args.resource.id, start: start, end: end, fastart:fastart, faend:faend})
               $('.manage-free-session-modal').modal('show')
            },
      
			}
		}
	},
    mounted(){

       //set today events
       this.setUrlParam(`date`, this.eventsDate.toISOString())
       this.applyUrl()

       let self = this
       $('button.fc-next-button.fc-button').click(() => {
          self.next()

          self.setUrlParam(`date`, self.eventsDate.toISOString())
          self.applyUrl()
       })
       $('button.fc-prev-button.fc-button').click(() => {
          self.prev()
          self.setUrlParam(`date`, self.eventsDate.toISOString())
          self.applyUrl()
       })
       $('button.fc-today-button.fc-button').click(() => {
          self.today()
          self.setUrlParam(`date`, self.eventsDate.toISOString())
          self.applyUrl()
       })
    },

	methods: {
      ...mapActions({
            getEvetns: 'Calendar/getEvetns',
            edit: 'Calendar/editSession',
            drop: 'Calendar/drop',
            resize: 'Calendar/resize',
            click: 'Calendar/click',
            grap: 'Calendar/grap'
        }),

        next(){
           this.eventsDate.setDate(this.eventsDate.getDate() + 1)
        },
        prev(){
           this.eventsDate.setDate(this.eventsDate.getDate() - 1)
        },
        today(){
           this.eventsDate = new Date()   
        },

        searchUserFilter(){
            let ids = [];
            this.filters.userInsert.map(x => ids.push(x.id))
            this.setUrlParam(`teachers-highlight`, ids)
            this.applyUrl()
        },


        getData(url = false) {
            this.getEvetns({date: url || this.url});
        },

        setDateCalendar(){
         this.eventsDate = new Date(this.selecteddate)
         this.setUrlParam(`date`, this.selecteddate)
         this.applyUrl()
         let today = new Date()
         this.$refs.fullCalendar.getApi().gotoDate(this.selecteddate)   
        },
      
         p2e: (s) => s.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))


	}
}
</script>
