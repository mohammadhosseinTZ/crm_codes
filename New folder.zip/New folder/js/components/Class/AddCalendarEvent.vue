<template>
    <div class="add-calendar-event">
        <div class="modal fade add-calendar-event-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">افزودن/ ویرایش اطلاعات روز</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                          <form action="" @submit.stop.prevent="addData">
                           <ul class="err-box">
                                <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                            </ul>
                           <div class="row mot-modal-inputs m-0">
                               <div class="form-group">
                                       <label for="event_date">تاریخ</label>
                                       <date-picker id="event_date" label="تاریخ" format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="event.date"></date-picker> 
                               </div>
                               <div class="form-group">
                                    <label for="event">توضیحات</label>
                                    <input type="text" class="form-control" id="event" v-model="event.event" >
                               </div>
                               <div class="form-group">
                                    <label for="color">نوع روز</label>
                                    <v-select id="course" v-model="event.day_type" :options="date_type" />
                               </div>

                               <div class="form-group">
                                    <input type="submit" class="form-control" :value="[event.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                               </div>
                           </div>
                           
                       </form>
                    </div>
                </div>
            </div>
        </div>    
    </div>
    </template>
    
    <script>
    import moment from 'moment'
    import { mapGetters,mapActions } from 'vuex';
    export default{
        name: "AddCalendarEvent",
    
        computed: {
            ...mapGetters({
                event: 'CalendarEvent/data'
            })
        },
        data(){
            return{
                date_type: window.defined_enums.date_type
            }
        },
        methods: {
            ...mapActions({
                update: 'CalendarEvent/update'
            }),
            addData() {
                this.vr(this.event.date, 'نام');
                this.vr(this.event.day_type, 'نوع روز');

    
                 this.event.date = moment(this.event.date).format('YYYY-MM-DD')

                if(!this.v_error_check()) return;
                axios.post('/api/v1/calendar', this.event)
                .then(res => {
                    if(res.data.alert && res.data.alert.type == 'error') return;
                    this.update(res.data.data)
                    $('.add-calendar-event-modal').modal('hide')
                });
            },
        }
    }
    </script>