<template>
<div class="class-course-registers">
    <div class="modal fade class-course-registers-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" style="max-width: 98%;">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">مدیریت دوره کلاس</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                        <div class="row course-session">
                            <div class="col">
                            
                                 <div>
                                    <table class="table">
                                    <tr>
                                        <th>ردیف</th>
                                        <th>نام</th>
                                        <th>شماره</th>
                                        <th>دوره</th>
                                        <th>هزینه</th>
                                        <th>پرداختی</th>
                                        <th>باقی مانده</th>
                                        <th>تاریخ</th>
                                        <th>فیش ها</th>
                                        <th>توضیحات</th>
                                        <th>ثبت کننده</th>
                                        <th>اکشن</th>
                                    </tr>
                                    <tr v-for="(data, name) in reisters" :key="data.id" :class="[data.leave_reason_id != null ? 'leave' : '']">
                                        <td>{{name + 1}}</td>
                                        <td>{{(parseInt(data.user.gender)  == 1 ? 'خانم' : 'آقای') + " " + data.user.name}} <span class="text-success" title="وضعیت شرکت در نظر سنجی">{{parseInt(data.survey_count)? '✔' : null}}</span><span class="text-danger" title="وضعیت تکمیل اطلاعات">{{ searchMeta(data.user.meta, 'is_complete_info').meta_value  == 1 ? '✔' : null }}</span><br>
                                            <small>{{ data.user.email }}</small>
                                        </td>
                                        <td>{{data.user.phone}}</td>
                                        <td>{{data.class_course.course_code + '-' + data.course.name}}</td>
                                        
                                        <td>{{data.price | format}} 
                                            <span v-for="dc in data.discount_fors" :key="dc.id" class="disconted"><span v-if="dc.option">{{searchMeta(dc.option.meta, 'discount_percent').meta_value}} درصد کسری اضافه برای {{dc.option.option_value}}</span></span>
                                            <span v-if="parseInt(data.is_online_course)" class="disconted">(آنلاین)</span>
                                            <span v-if="data.bonus" class="disconted">معرفی توسط: {{data.bonus.user_reference.name}}</span>
                                            <span v-if="data.site_discount">
                                                <span class="disconted" v-for="sd in data.site_discount" :key="sd.name">
                                                        {{ Number(sd.amount)  }} {{ sd.type == 'percent' ? 'درصد' : 'تومان' }} تخفیف با کد {{ sd.source != 'site' ? 'معرف  ' : null}}: {{ sd.name }}
                                                        <span v-if="sd.type != 'site' && sd.user" data-toggle="modal" data-target=".person-profile-modal" @click="getPersonData({id: sd.user.id});getPersonPayments(sd.user.id);getPersonRegisters({id: sd.user.id});getPersonCalls(sd.user.id);setSelectedPerson({id: sd.user.id, data: sd.user});" >(مشاهده)</span>
                                                </span>
                                            </span>
                                        </td>

                                        <td>{{data.payments | getPrice | format}} <span v-if="data.return_price" style="color: gray" class="disconted">عودت ({{data.return_price | format}})</span></td>

                                        <td v-if="data.leave_reason_id == null">{{getGlose(data) | format}}</td>
                                        <td v-else>{{0}}</td>
                                        <td>{{data.created_at}}</td>
                                        <td>
                                            <button type="button" @click="getPyamentsRegister({id: data.id});setSelectedPerson({id: data.user.id, data: data.user})" :class="getPrices(data.payments) >= data.price ? 'btn-success' : 'btn-warning'" class="btn d-block mt-1 w-100" data-toggle="modal" data-target=".person-payments-modal">{{data.payments.length}} فیش ها</button>
                                        </td>
                                        <td>
                                            <a :href="`/export/register_regform/${data.id}`" target="_blank"><i class="fa fa-print"></i></a>
                                            <button class="btn btn-link" type="button" data-toggle="modal" data-target=".add-register-cost" @click="getCostByRegisterId(data.id)" ><i class="fas fa-dollar-sign"></i></button>
                                            <button class="btn btn-link" type="button" data-toggle="modal" data-target=".register-rollcall-modal" @click="getRollCallByRegisterId({register: data.id})" ><i class="fas fa-eye"></i></button>
                                            
                                             {{data.comment}}</td>
                                        <td>
                                            <span v-if="data.user_insert" :class="[data.user_insert.phone == '0000000000' ? 'site_insert' : null]">
                                                    {{data.user_insert.name}}
                                            </span>
                                        </td>
                                        <td class="dropdown">
                                            <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <button v-if="can('edit_register') || can('edit_only_register', data.user_insert_id )" type="button" class="btn btn-primary" data-toggle="modal" data-target=".add-register-modal" @click="editRegister({id:  data.id, data: data});">ویرایش</button>
                                                    <button v-if="data.class_course.course_code == 999" type="button" class="btn btn-primary" data-toggle="modal" data-target=".manage-course-class-modal" @click="addSession({id: data.id, type: 'register'}); getEvents({date: `/api/v1/register/${data.id}/session`})">مدیریت</button>
                                                    <button v-if="can('delete_register')" type="button" @click="deleteItem(`/register/${data.id}`, data.id, deleteRegister)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                            </div>
                                        </td>
                                        <td>
                                            <PersonButtons :id="data.user.id" :userdata="data.user" />
                                        </td>
                                    </tr>
                                </table>
                                </div>
                                                
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <AllPersonDepended />
    </div>    
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
import AllPersonDepended from './../Person/AllPersonDepended';
export default{
        name: "ClassCourseRegisters",
        components: {
            AllPersonDepended
        },
        computed: {
            ...mapGetters(['selectedPerson']),
            ...mapGetters({
                reisters: 'Register/datas',
            }),
        },
        filters: {
            getPrice: function(value){
                    var tmpPrice = 0;
                    value.forEach(element => {
                            if(element.status == 1){
                                var prices = element.gates.map(value => value.price);
                                tmpPrice += parseInt(prices.reduce((total, num) =>{
                                    return parseInt(total) + parseInt(num);
                                }));  
                            }   
                    });
                    return tmpPrice;
            },
    },
      methods: {
        ...mapActions({
            editRegister: 'Register/editRegister',
            addSession: 'Calendar/addSession',
            getEvents: 'Calendar/getEvetns',
            deleteRegister: 'Register/delete',
            getCostByRegisterId: 'Cost/getCostByRegisterId',
            getRollCallByRegisterId: 'RollCall/getByRegister'
            
        }),
       getPrices(values){
           return this.$options.filters.getPrice(values);
       },
       getGlose(data){
            var price = this.$options.filters.getPrice(data.payments)
            return parseInt(data.price) - parseInt(price)
        }
   }
}
</script>
<style>
span.disconted {
    font-size: 11px;
    display: block;
    color: red;
    font-weight: bold;
}
</style>