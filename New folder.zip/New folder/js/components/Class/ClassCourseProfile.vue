<template>
<div class="class-course-profile">
        <div class="modal fade class-course-profile-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">پروفایل دوره</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                        <table class="table">
                            <tr>
                                <th>ردیف</th>
                                <th>نام هزینه</th>
                                <th>مقدار تخصیص</th>
                                <th>محاسبه</th>
                                <th>باقی مانده</th>
                                <th>هزینه محاسبه شده</th>
                                <th>ثبت کننده</th>
                                <th>توضیحات</th>
                            </tr>
                            <tr v-for="(data, name) in allocations" :key="data.id" :title="data.id">
                                <td>{{name + 1}}</td>
                                <td>{{data.cost_item ? data.cost_item.label : null}}</td>
                                <td>{{data.type_value}} {{locate(data.cost_item.unit.name)}}</td>
                                <td>{{data.allocation_value | format}} {{locate(data.allocation_type)}}</td>
                                <td>{{parseFloat(data.glose) | format}}</td>
                                <td>{{data.price | format}}</td>
                                <td>{{data.user_insert.name}}</td>
                                <td>{{data.comment}}</td>
                            </tr>
                        </table>
                        <table class="table table-bordered">
                            <tr>
                                <th>جمع همه هزینه ها</th>
                                <td>{{allocations | sumPrices | format}}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name: "ClassCourseProfile",
    computed: {
        ...mapGetters({
            allocations: 'Allocation/datas',
        }),
    },
    filters: {
        sumPrices(value){
            return value.map(x => x.price).reduce((a, b) => {
                return parseInt(a) + parseInt(b)
            }, 0)
        }
    }
}
</script>