<template>
    <div class="calendar-event">
        <button type="button" class="btn btn-primary btn-sm mb-3" data-toggle="modal" data-target=".add-calendar-event-modal" @click="add({data: {date: date}})">افزودن اطلاعات روز</button>
       <table class="table table-bordered">
        <tr>
            <th>نوع روز</th>
            <th>توضیحات</th>
            <th>اکشن</th>
        </tr>
        <tr v-for="(data, name) in events" :key="data.id">
                    <td>{{locate(data.day_type)}}</td>
                    <td>{{data.event}}</td>
                    <td class="d-flex">
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target=".add-calendar-event-modal" @click="edit({id: data.id, data:data})">ویرایش</button>
                        <button type="button" @click="deleteItem(`/calendar/${data.id}`, data.id, deleteEvent);" class="btn btn-danger btn-sm d-block btn-sm mr-2" data-toggle="modal" data-target="">حذف</button>
                    </td>
                </tr>
       </table>

       <AddCalendarEvent />
    </div>
</template>
<script>
import AddCalendarEvent from './AddCalendarEvent.vue'
import {mapActions, mapGetters} from 'vuex'
    export default{
        name: "CalendarEvent",
        props: ["date"],
        components: {
            AddCalendarEvent
        },
        computed: {
            ...mapGetters({
                events: 'CalendarEvent/datas',
            })
        },
        data(){
            return {
                url: "/api/v1/calendar"
            }
        },
        mounted(){
            this.setUrlParam(`date`, this.date)
            this.applyUrl()
        },
        methods:{
            ...mapActions({
            add: 'CalendarEvent/add',
            edit: 'CalendarEvent/edit',
            getEvents: 'CalendarEvent/get',
            deleteEvent: 'CalendarEvent/delete',
        }),
        getData(url = false) {
            this.getEvents({data: url || this.url})
        },
        }
    }
</script>