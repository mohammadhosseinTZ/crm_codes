<template>
    <div class="charge-fund-card">
        
        <div class="modal fade charge-fund-card-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content p-2">
                    <div class="modal-header d-flex alert alert-warning h6 align-items-center">
                        <div>
                            گزارش انتقال وجه
                        </div>
                    </div>
                    <div class="model-body">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" @click="charge({id: selected, type:'fund-cards', calc_from: bank.calc_from, calc_to: bank.calc_to })" id="transform-tab" data-toggle="tab" data-target="#transform" type="button" role="tab" aria-controls="transform" aria-selected="true">انتقال به این حساب</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="transform-out-tab" @click="charge({id: selected, type:'bank', calc_from: bank.calc_from, calc_to: bank.calc_to })" data-toggle="tab" data-target="#transformout" type="button" role="tab" aria-controls="transformout" aria-selected="false">انتقال از این حساب</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="charge-tab" @click="charge({id: selected, type:'charge', calc_from: bank.calc_from, calc_to: bank.calc_to })" data-toggle="tab" data-target="#charge" type="button" role="tab" aria-controls="charge" aria-selected="false">شارژ</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="costs-tab" @click="costs({date: `/api/v1/cost?fund-cards=${selected}&date=${bank.calc_from},${bank.calc_to}`})" data-toggle="tab" data-target="#costs" type="button" role="tab" aria-controls="costs" aria-selected="false">هزینه های این منبع</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="payments-tab" @click="payments(selected)" data-toggle="tab" data-target="#payments" type="button" role="tab" aria-controls="payments" aria-selected="false">فیش های واریزی این منبع</button>
                            </li>
                        </ul>
                        <div class="tab-content" id="report-tab-content">
                            <div class="tab-pane fade show active" id="transform" role="tabpanel" aria-labelledby="transform-tab">
                                    <TransferIn />
                            </div>
                            <div class="tab-pane fade" id="transformout" role="tabpanel" aria-labelledby="transform-out-tab">
                                    <TransferOut/>
                            </div>
                            <div class="tab-pane fade" id="charge" role="tabpanel" aria-labelledby="charge-tab">
                                    <Charge />
                            </div>
                            <div class="tab-pane fade" id="costs" role="tabpanel" aria-labelledby="costs-tab">
                                    <Cost />
                            </div>
                            <div class="tab-pane fade" id="payments" role="tabpanel" aria-labelledby="payments-tab">
                                    <Payment />
                            </div>
                        </div>
                        
                        <ReportDetails />
                    </div>
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex';
import TransferIn from './BankPartials/TransferIn.vue'
import TransferOut from './BankPartials/TransferOut.vue'
import Charge from './BankPartials/Charge.vue'
import Payment from './BankPartials/Payment.vue'
import Cost from './BankPartials/Cost.vue'
import ReportDetails from './BankPartials/ReportDetails.vue'
export default {
   name:"FundCardHistory",
   components:{
    TransferIn,
    TransferOut,
    Charge,
    Payment,
    Cost,
    ReportDetails
   },
   computed: {
        ...mapGetters({
            pg: 'CardCharge/pagination',
            charges: 'CardCharge/datas',
            selected: 'CardCharge/selected',
            bank: 'Bank/data'
        })
    },
    
    methods: {
        ...mapActions({
            deleteCharge: 'CardCharge/delete',
            charge: 'CardCharge/get',
            costs: 'Cost/get',
            payment: 'Payment/getDatas',
        }),
        payments(item){
            var gateways = this.bank.charge_sources.map(x => x.id)
            var branches = this.bank.branches.map(x => x.id)
            this.payment({data: `/api/v1/payment?gateways=${gateways.join(',')}&user_branches=${branches.join(',')}&date=${this.bank.calc_from},${this.bank.calc_to}`})
        }
    }
}
</script>
<style>
div#report-tab-content {
    height: auto;
    min-height: 100px;
    max-height: 500px;
    overflow-y: auto;
}
</style>
