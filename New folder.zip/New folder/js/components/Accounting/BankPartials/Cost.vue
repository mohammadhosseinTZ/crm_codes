<template>
    <div class="cost-report">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <small v-if="can('costs_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date','end-date' , 'branches', 'pay-status', 'gate-way' , 'cost-type' , 'cost-category' , 'user-insert', 'user-search', 'cost-search', 'comment-item-search','export']" :prm="params" :uri="url" @set="setFilter" />      
        <CostItem :costs="costs" />
        <paginate :paginate="pg" @changePage="changePage"/>
        <div v-if="can('costs_statistics')">
            <table class="table table-bordered">
                <tr v-if="statistics">
                    <th v-for="sp in statistics" :key="sp.option_value">{{sp.option_value}}</th>
                </tr>
                <tr v-if="statistics">
                    <td v-for="sp in statistics" :key="sp.option_value">{{sp.price}}</td>
                </tr>
            </table>
        </div>
    </div>
</template>
<script>
import CostItem from './../../global/CostItem.vue'
import Filters from './../../Section/Filters.vue'
import { mapActions, mapGetters } from 'vuex';

export default {
    name: "Cost",
    computed: {
        ...mapGetters({
            costs: 'Cost/datas',
            pg: 'Cost/pagination',
            counts: 'Cost/count',
            statistics: 'Cost/statistics',
            bank: 'Bank/data'
        }),
    },
    components: {
        CostItem,
        Filters
    },
    data(){
        return{
            url: '/api/v1/cost',
        }
    },
    methods:{
        ...mapActions({
            getDatas: 'Cost/get',
        }),

        getData(url = false) {
            var nurl = new URL(window.location.origin + (url || this.url))
            nurl.searchParams.set('fund-cards', this.bank.id || this.bank.insideId);
            nurl.searchParams.set('date',  [this.bank.calc_from,this.bank.calc_to].join(','));
            this.getDatas({date: nurl})
        },
    }
    
}
</script>