<template>
    <div>
        <paginate :paginate="pg" @changePage="changePage"/>
            <table class="table table-bordered">
                    <tr>
                        <th>منبع واریز</th>
                        <th>منبع شارژ شده</th>
                        <th>هزینه</th>
                        <th>کارمزد</th>
                        <th>توضیحات</th>
                        <th>تاریخ</th>
                        <th>اکشن</th>
                    </tr>
                    <tr v-for="data in charges" :key="data.id">
                        <td>{{data.bank ? data.bank.name : null}}</td>
                        <td>{{data.fund_card ? data.fund_card.name : null}}</td>
                        <td>{{data.price | format}}</td>
                        <td>{{data.commission | format}}</td>
                        <td>{{data.comment}}</td>
                        <td>{{data.created_at}}</td>
                        <td>
                            <button type="button" v-if="can('charge_fund_card')" @click="deleteItem(`/accounting/card-charge/${data.id}`, data.id, deleteCahrge)" class="btn btn-sm btn-danger d-block mt-1 w-100" >حذف</button>           
                        </td>
                    </tr>
            </table>
    </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex';
export default {
    name: "TransferOut",
    computed: {
        ...mapGetters({
            pg: 'CardCharge/pagination',
            charges: 'CardCharge/datas',
        })
    },
    
    methods: {
        ...mapActions({
            deleteCahrge: 'CardCharge/delete',
        })
    }
}
</script>