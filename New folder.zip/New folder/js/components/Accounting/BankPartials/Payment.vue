<template>
    <div class="payment-report"> 
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <small v-if="can('payment_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date','end-date','class-course', 'search_price', 'export','subject' ,'subject-cat', 'pay-status','payment-search', 'group','user-insert', 'only-fp']" :prm="params" :uri="url" @set="setFilter" />      
        <div>
            <table class="table">
                <tr>
                    <th>ردیف</th>
                    <th>وضعیت</th>
                    <th>کد</th>
                    <th>تاریخ</th>
                    <th>قیمت</th>
                    <th>روش پرداخت</th>
                    <th>ثبت کننده</th>
                    <th>برای</th>
                    <th>نام</th>
                    <th>تلفن</th>
                    <th>تعداد ثبت نامی</th>
                    <th>توضیحات</th>
                    <th>اکشن</th>
                </tr>
                <tr v-for="(data, name) in payments" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td role="button" v-if="data.status == 0" style="color:red">✖</td>
                    <td role="button" v-else style="color:green">✔</td>
                    <td>{{data.code}}</td>
                    <td>{{data.created_at}}</td>
                    <td>{{data.gates | getPrice | format}}</td>
                    <td>{{data.gates | getWays}}</td>
                    <td>{{data.user_insert ? data.user_insert.name : null}}</td>
                    <td>{{data.paymentable.supplier.name}} <span v-if="data.sr.en_name == 'courses'">{{parseInt(data.paymentable.class_course.course_code) != 999 ? 'کد: ' + data.paymentable.class_course.course_code : ''}}</span></td>
                    <td>{{data.paymentable.user.name}}</td>
                    <td>{{data.paymentable.user.phone}}</td>
                    <td>{{data.reg_count}} <i class="fa fa-print" @click="print(data);"></i></td>
                    <td>{{data.comment}}</td>
                    <td class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="parseInt(data.status) == 0 && (can('edit_payment') || can('edit_only_payment', data.user_insert_id ))" type="button" class="btn btn-primary" data-toggle="modal" data-target=".add-payment-modal" @click="editPayment({id: data.id, data: data, user_id: data.paymentable.user_id});" >ویرایش</button>
                                <button v-if="parseInt(data.status) == 0 && can('delete_payment')" @click="deleteItem(`/payment/${data.id}`, data.id, deletePayment)" type="button" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.paymentable.user.id" :userdata="data.paymentable.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>

        <div v-if="can('payment_statistics')">
            <table class="table table-bordered">
                <tr v-if="statistics">
                    <th v-for="sp in statistics" :key="sp.option_value">{{sp.option_value}}</th>
                </tr>
                <tr v-if="statistics">
                    <td v-for="sp in statistics" :key="sp.option_value">{{sp.price}}</td>
                </tr>
            </table>
        </div>
        <AllPersonDepended />
    </div>
</template>
<script>
import AllPersonDepended from './../../Person/AllPersonDepended';
import { mapGetters, mapActions } from 'vuex';
import Filters from './../../Section/Filters.vue'
export default {
    name: 'Payment',
    props: ['data'],
    components:{
        AllPersonDepended,
        Filters,
        },
    computed: {
       ...mapGetters({
            payments: 'Payment/datas',
            counts: 'Payment/count',
            statistics: 'Payment/statistics',
            pg: 'Payment/pagination',
            bank: 'Bank/data'
        }),
   },
    data(){
        return{
            url: '/api/v1/payment',
        }
    },
    methods:{
         ...mapActions({
            getDatas: 'Payment/getDatas',
            deletePayment: 'Payment/delete',
        }),
        getData(url = false) {
            var gateways = this.bank.charge_sources.map(x => x.id)
            var branches = this.bank.branches.map(x => x.id)

            var nurl = new URL(window.location.origin + (url || this.url))
            nurl.searchParams.set('gateways', gateways.join(','));
            nurl.searchParams.set('user_branches',  branches.join(','));
            nurl.searchParams.set('date',  [this.bank.calc_from,this.bank.calc_to].join(','));
            
            this.getDatas({data: nurl})
        },

    }
}
</script>