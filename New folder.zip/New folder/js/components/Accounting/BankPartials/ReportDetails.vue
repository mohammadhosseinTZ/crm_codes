<template>  
    <div class="bank-reports">
        <table class="table table-bordered">
            <thead>
                <tr class="bg-warning">
                    <th colspan="2">وضعیت حال منبع</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>موجودی اولیه</th>
                    <td>{{bank.primitive_amount | format}}</td>
                </tr>
                <tr>
                    <th>موجودی حال حاضر</th>
                    <td>{{bank.current_amount | format}}</td>
                </tr>
            </tbody>
        </table>
        <table v-if="report.charge" class="table table-bordered">
            <thead>
                <tr class="bg-warning">
                    <th colspan="2">گزارشات شارژ و انتقال</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(charge, index) in report.charge" :key="index">
                    <th>{{charge.option_value}}</th>
                    <td>{{charge.price | format}}</td>
                </tr>
            </tbody>
        </table>
        <table v-if="report.cost" class="table table-bordered">
            <thead>
                <tr class="bg-warning">
                    <th colspan="2">گزارشات برداشت</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(cost, index) in report.cost" :key="index">
                    <th>{{cost.option_value}}</th>
                    <td>{{cost.price | format}}</td>
                </tr>
            </tbody>
        </table>
        <table v-if="report.payment" class="table table-bordered">
            <thead>
                <tr class="bg-warning">
                    <th colspan="2">گزارشات واریز</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(payment, index) in report.payment" :key="index">
                    <th>{{payment.option_value}}</th>
                    <td>{{payment.price | format}}</td>
                </tr>
            </tbody>
        </table>

        <table v-if="report.payment && report.cost && report.charge " class="table table-bordered">
            <thead>
                <tr class="bg-success">
                    <th colspan="2">گزارش کلی</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th dir="rtl">
                        <small>(موجودی اولیه + شارژ + جمع ورودی ها + واریزی جابه جایی)</small> 
                        -
                         <small>(جمع هزینه ها + جمع انتقالی ها + موجودی حال حاضر)</small>
                         = {{report | calcReport | format}}
                    </th>
                </tr>
            </tbody>
        </table>
    </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name: "ReportDetails",
    computed: {
        ...mapGetters({
            bank: 'Bank/data',
            report: 'Bank/report'
        }),
    },
    filters: {
        calcReport(report){
            var paymentsAll = report.payment.find(x => x.report_all == true).price
            var charge = report.charge.find(x => x.type == 'charge').price
            var transferIn = report.charge.find(x => x.type == 'transfer_in').price
            var bank = report.bank

            var transferOut = report.charge.find(x => x.type == 'transfer_out').price
            var costAll = report.cost.find(x => x.report_all == true).price
            console.log((parseInt(paymentsAll) + parseInt(charge) + parseInt(transferIn) + parseInt(bank.primitive_amount)) , (parseInt(costAll) + parseInt(transferOut) + parseInt(bank.current_amount)))
            return (parseInt(paymentsAll) + parseInt(charge) + parseInt(transferIn) + parseInt(bank.primitive_amount)) - (parseInt(costAll) + parseInt(transferOut) + parseInt(bank.current_amount))
        }
    }
}
</script>