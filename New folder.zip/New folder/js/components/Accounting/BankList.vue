<template>
    <div class="bank-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation d-flex">
                <button v-if="can('add_bank')" type="button" class="btn btn-sm mt-1 mb-1" data-toggle="modal" data-target=".add-bank-modal" @click="add()"><span class="material-symbols-rounded mot-add-newItem"> add_box </span></button>
                <button type="button" class="mr-2 btn btn-sm btn-primary mt-1 mb-1" data-toggle="modal" data-target=".charge-card-modal" @click="addCharge()">انتقال وجه</button>
            </div>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>
        <table class="table table-bordered">
                <tr>
                    <th>ردیف</th>
                    <th>نام بانک</th>
                    <th>منبع تامین</th>
                    <th>تعلق</th>
                    <th>شماره کارت</th>
                    <th>شماره حساب</th>
                    <th>موجودی اولیه</th>
                    <th>موجودی</th>
                    <th>شعبه</th>
                    <th>توضیحات</th>
                    <th>اکشن</th>
                </tr>
                <tr v-for="(data, index) in banks" :key="data.id">
                    <td>{{index + 1}}</td>
                    <td>{{data.type ? locate(data.type) : data.type}} {{data.name}}</td>
                    <td>{{data.charge_sources.map(x => x.option_value).join(' و ')}}</td>
                    <td>{{data.user ? data.user.name : null}}</td>
                    <td>{{data.card_number}}</td>
                    <td>{{data.account_number}}</td>
                    <td>{{data.primitive_amount | format}}</td>
                    <td>{{data.current_amount | format}}</td>
                    <td>{{data.branches | name}}</td>
                    <td>{{data.comment}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_bank')" type="button" class="btn btn-primary" data-toggle="modal" data-target=".add-bank-modal" @click="edit({id:  data.id, data: data})">ویرایش</button>
                                <div class="delete-form mt-2" v-if="can('delete_bank')">
                                    <v-select placeholder="انتقال موارد به..."  v-model="replace" :options="rbanks" @search:focus="search_params = 'bank|name|rbanks'" v-debounce="dynamicSearch" />
                                    <button  type="button" @click="deleteItem(`/accounting/bank/${data.id}?bank_id=${replace ? replace.id : null}`, data.id, deleteBank);replace = null" class="btn btn-sm btn-danger d-block mt-1 w-100 btn-sm mx-0" >و حذف این آیتم</button>
                                </div> 
                        </div>
                            <button v-if="can('charge_fund_card')" type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".charge-fund-card-modal" @click="charge({id: data.id, calc_from: data.calc_from, calc_to: data.calc_to }); edit({id:  data.id, data: data}); report({data: data})">گزارش</button>
                    </td>
                </tr>
        </table>
        <paginate :paginate="pg" @changePage="changePage"/>


        
        <AddBank />
        <AddChargeCard />
        <FundCardHistory />
    </div>
</template>
<script>
import AddBank from './Actions/AddBank.vue'
import { mapActions, mapGetters } from 'vuex';
import FundCardHistory from './FundCardHistory.vue'
import AddChargeCard from './Actions/AddChargeCard.vue'


export default {
    name: 'BankList',
    props: ['data'],
    components:{
        AddBank,
        AddChargeCard,
        FundCardHistory,
    },
    computed: {
        ...mapGetters({
            banks: 'Bank/datas',
            pg: 'Bank/pagination',
            counts: 'Bank/count',
            statistics: 'Bank/statistics',
        }),
    },
    filters: {
        name(data){
            let items = []
            for(var n of data){
                items.push(n.name)
            }
            return items.join(' و ')
        }
    },
    data(){
        return{
            url: '/api/v1/accounting/bank',
            replace: null,
            rbanks: []
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        ...mapActions({
            getDatas: 'Bank/get',
            edit: 'Bank/edit',
            add: 'Bank/add',
            addCharge: 'CardCharge/add',
            deleteBank: 'Bank/delete',
            charge: 'CardCharge/get',
            report: 'Bank/report',
        }),

        getData(url = false) {
            this.getDatas({date: url || this.url})
        },
    }
}
</script>

