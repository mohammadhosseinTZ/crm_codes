<template>
    <!-- Modal -->
<div class="add-bank">
    <div class="modal fade add-bank-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش بانک</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                        <div class="row mot-modal-inputs m-0">
                            <div class="form-group mot-input-md">
                                <label for="type">نوع حساب</label>
                                <v-select v-model="bank.type" :options="bank_types" />
                            </div>
                            <div class="form-group">
                                <label for="name">نام</label>
                                <input type="text" id="name" class="form-control" v-model="bank.name"> 
                            </div>
                            <div class="form-group mot-input-md">
                                <label for="name">این منبع متعلق است به چه شخصی</label>
                                <v-select v-model="bank.user" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                            </div>
                            <div class="form-group mot-input-md">
                                <label for="name">منابع تامین</label>
                                <v-select multiple v-model="bank.charge_sources" :options="charge_sources" />
                            </div>
                            <div class="form-group mot-input-md">
                                <label for="category">شعبه تامین <small>فیش شعبه های انتخاب شده به این حساب اضافه می شوند</small></label>
                                <v-select id="branches" placeholder="" multiple v-model="bank.branches" :options="branches" />
                            </div>
                            <div class="form-group">
                                <label for="card_number">شماره کارت</label>
                                <input type="text" id="card_number" class="form-control" v-model="bank.card_number"> 
                            </div>
                            <div class="form-group">
                                <label for="account_number">شماره حساب</label>
                                <input type="text" id="account_number" class="form-control" v-model="bank.account_number"> 
                            </div>
                            <div class="form-group">
                                <label for="shaba">شماره شبا</label>
                                <input type="text" id="shaba" class="form-control" v-model="bank.shaba"> 
                            </div>
                            <div class="form-group">
                                <label for="current_amount">موجودی حال حاضر</label>
                                <input type="text" id="current_amount" class="form-control" v-model="bank.current_amount"> 
                            </div>
                            <div class="form-group">
                                <label for="current_amount">موجودی اولیه</label>
                                <input type="text" :disabled="bank.insideType == 'update' && !can('primitive_amount')" id="current_amount" class="form-control" v-model="bank.primitive_amount"> 
                            </div>

                            <div class="form-group">
                                <label for="">تاریخ شروع گزارش</label>
                                <date-picker format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="bank.calc_from"></date-picker>
                            </div>
                            <div class="form-group">
                                <label for="">تاریخ پایان گزارش</label>
                                <date-picker format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="bank.calc_to"></date-picker>
                            </div>

                            <div class="form-group col-md-12">
                                <label for="comment">توضیحات</label>
                                <textarea  id="comment" class="form-control" v-model="bank.comment"></textarea>
                            </div>

                           
                            <div class="form-group col-md-12">
                                <input type="submit" class="form-control" :value="[bank.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                            </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddBank",
    computed: {
        ...mapGetters({
            bank: 'Bank/data'
        })
    },
    data(){
        return{
            users: [],
            charge_sources: window.gateWays,
            branches : window.branches,
            bank_types: window.defined_enums.bank_types
        }
    },
 
    methods: {
        ...mapActions({
            update: 'Bank/update',
        }),
     
        addData() {
            this.vr(this.bank.name, 'نام');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/accounting/bank', this.bank)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                $('.add-bank-modal').modal('hide')
            });
        },

    }

}
</script>

