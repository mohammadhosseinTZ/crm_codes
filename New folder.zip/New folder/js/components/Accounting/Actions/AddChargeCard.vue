<template>
    <!-- Modal -->
<div class="charge-card">
    <div class="modal fade charge-card-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">شارژ تنخواه</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                    <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                        <div class="row m-0">
                            <div class="form-group col-md-6">
                                <label for="name">منبع برداشت</label>
                                <v-select v-model="card.bank" :options="banks" @search:focus="search_params = 'bank|name|banks'" v-debounce="dynamicSearch" />
                            </div>
                            <div class="form-group col-md-6">
                                <label for="name">منبع واریز</label>
                                <v-select v-model="card.fundCard" :options="fundCards" @search:focus="search_params = 'bank|name|fundCards'" v-debounce="dynamicSearch" />
                            </div>
                            <div class="form-group col-md-6">
                                <label for="price">مبلغ شارژ</label>
                                <input type="number" id="price" class="form-control" v-model="card.price"> 
                            </div>
                            <div class="col-md-6 form-group">
                                <label for="commission">کارمزد</label>
                                <input type="number" class="form-control" id="commission" v-model="card.commission" placeholder="اگر نیاز به ثبت کارمزدی هست وارد کنید" />  
                          </div>
                          <div class="col-md-12 form-group">
                                <label for="">تاریخ</label>
                                <date-picker format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="card.created_at"></date-picker>
                            </div>
                            <div class="col-md-12 form-group">
                                <label for="comment">توضیحات</label>
                                <input type="text" class="form-control" id="comment" v-model="card.comment" placeholder="توضیحات" />  
                          </div>

                            <div class="form-group col-md-12">
                                <input type="submit" class="form-control" :value="[card.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                            </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddChargeCard",
    computed: {
        ...mapGetters({
            card: 'CardCharge/data'
        })
    },
    data(){
        return{
            banks: [],
            fundCards: []
        }
    },
 
    methods: {
        ...mapActions({
            update: 'CardCharge/update',
        }),
     
        addData() {
            this.vr(this.card.fundCard, 'تنخواه');
            this.vr(this.card.price, 'مبلغ شارژ');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/accounting/card-charge', this.card)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                $('.charge-card-modal').modal('hide')
            });
        },
    }

}
</script>
<style>
.charge-card .modal {
    z-index: 1157 !important;
}
</style>
