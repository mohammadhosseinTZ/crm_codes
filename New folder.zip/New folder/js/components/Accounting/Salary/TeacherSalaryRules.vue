<template>
    <div class="teacher-salary-rules">
        
        <div class="modal fade teacher-salary-rules-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content p-2">
                    <TeacherSalaryRulesData />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import TeacherSalaryRulesData from './Datas/TeacherSalaryRulesData.vue'
export default {
   name:"TeacherSalaryRules",
   components:{
    TeacherSalaryRulesData
   }
}
</script>
