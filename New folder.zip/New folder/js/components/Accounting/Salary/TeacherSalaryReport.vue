<template>
    <div class="teacher-salary-report">
        
        <div class="modal fade teacher-salary-reports-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content p-2">
                    <TeacherSalaryReportData />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import TeacherSalaryReportData from './Datas/TeacherSalaryReportData.vue'
export default {
   name:"TeacherSalaryReport",
   components:{
    TeacherSalaryReportData
   }
}
</script>
