<template>
    <div class="add-teacher-salary-rule">
        
        <div class="modal fade add-teacher-salary-rule-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content p-2">
                    <form action="" @submit.stop.prevent="addData">
                           <ul class="err-box">
                                <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                            </ul>
                           <div class="row m-0">

                                <div class="col-md-6 form-group">
                                    <label for="course">دوره</label>
                                   <v-select id="course" v-model="rule.course" :options="courses" />
                               </div>

                               <div class="col-md-6 form-group">
                                    <label for="course">نوع دوره</label>
                                   <v-select id="course" v-model="rule.course_type" :options="course_type" />
                               </div>

                               <div class="col-md-6 form-group">
                                    <label for="course">نوع جلسه</label>
                                   <v-select id="course" v-model="rule.session_type" :options="session_type" />
                               </div>

                               <div class="col-md-6 form-group">
                                    <label for="course">واحد محاسبه</label>
                                   <v-select id="course" v-model="rule.unit" :options="units" />
                               </div>

                               <div class="col-md-6 form-group">
                                   <label for="price">قیمت</label>
                                   <input class="form-control" type="number" v-model="rule.price" id="price">
                               </div>

                               <div class="col-md-6 form-group">
                                   <label for="holiday_price">قیمت ایام تعطیل</label>
                                   <input class="form-control" type="number" v-model="rule.holiday_price" id="holiday_price">
                               </div>

                               <div class="col-md-6 form-group">
                                   <label for="overtime_price">قیمت اضافه کاری مدرس </label>
                                   <input class="form-control" type="number" v-model="rule.overtime_price" id="overtime_price">
                               </div>


                               <div class="col-md-12 form-group">
                                    <date-picker id="start_date" label="تاریخ شروع محاسبه این قانون" format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="rule.start_date"></date-picker> 
                               </div>
                               <div class="col-md-12 form-group">
                                    
                                    <date-picker id="expiry_date" label="تاریخ پایان محاسبه این قانون" format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="rule.expiry_date"></date-picker> 
                               </div>
                               
                              
                           </div>
                           <div class="row">
                               <div class="col form-group">
                                    <input type="submit" class="form-control" :value="[rule.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                               </div>
                           </div>
                       </form>
                </div>
            </div>
        </div>    
    </div>
</template>
<script>

import { mapActions, mapGetters } from 'vuex';

export default {
   name:"AddTeacherSalaryRule",
   components:{
    
   },
   data(){
    return {
        courses: window.courses,
        course_type: window.defined_enums.course_type,
        session_type: window.defined_enums.session_type,
        units: window.defined_enums.teacher_salary_calc_units,
    }
   },
   computed: {
            ...mapGetters({
                rule: 'TeachersSalary/data'
            })
        },
        methods: {
            ...mapActions({
                update: 'TeachersSalary/update'
            }),
            addData() {
                this.vr(this.rule.course, 'نام دوره');
                this.vr(this.rule.course_type, 'نوع دوره');
                this.vr(this.rule.session_type, 'نوع جلسه');
                this.vr(this.rule.unit, 'نوع روز');
                this.vr(this.rule.price, 'هزینه');
                this.vr(this.rule.holiday_price, 'هزینه روز های تعطیل');
                this.vr(this.rule.teacher, 'مدرس');
                this.vr(this.rule.start_date, 'تاریخ شروع محاسبه');
                this.vr(this.rule.expiry_date, 'تاریخ اتمام محاسبه');
                if(!this.v_error_check()) return;
                axios.post('/api/v1/accounting/salary/teachers-salary-schema/' + this.rule.teacher.id , this.rule)
                .then(res => {
                    if(res.data.alert && res.data.alert.type == 'error') return;
                    this.update(res.data.data)
                    $('.add-teacher-salary-rule-modal').modal('hide')
                });
            },
        }
}
</script>
