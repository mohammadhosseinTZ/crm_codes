<template>
        <div class="teachers-salary-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <h4>حقوق مدرسین</h4>
        </div>
        <table class="table table-bordered">
                <tr>
                    <th>ردیف</th>
                    <th>نام مدرس</th>
                    <th>گزارش کلی</th>
                    <th>قوانین حقوقی</th>
                    <th>مشاهده گزارشات</th>
                </tr>
                <tr v-for="(data, name) in teachers" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.name}}</td>
                    <td>{{data.name}}</td>
                    <td>
                        <button class="btn btn-sm btn-primary salary-rules"
                        data-toggle="modal" data-target=".teacher-salary-rules-modal" @click="getRules({data: data})"
                        >
                        <span class="material-symbols-rounded"> table_eye </span>
                        </button>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-primary salary-reports mot-w-100"
                        data-toggle="modal" data-target=".teacher-salary-reports-modal" @click="getSalaryReport({data: data})"
                        >
                        گزارشات
                        </button>
                    </td>
                    
                </tr>
        </table>
        <TeacherSalaryRules />
        <AddTeacherSalaryRule />
        <TeacherSalaryReport />
    </div>
</template>
<script>
import AllPersonDepended from './../../Person/AllPersonDepended'
import Filters from './../../Section/Filters.vue'
import TeacherSalaryRules from './TeacherSalaryRules.vue'
import TeacherSalaryReport from './TeacherSalaryReport.vue'
import AddTeacherSalaryRule from './SalaryActions/AddTeacherSalaryRule.vue'
import { mapGetters,mapActions } from 'vuex'
export default{
    name: "TeachersSalarySchema",
    props: ['data'],
    components: {
        AllPersonDepended,
        Filters,
        TeacherSalaryRules,
        TeacherSalaryReport,
        AddTeacherSalaryRule
    },
    computed: {
        ...mapGetters({
            teachers: 'TeachersSalary/teachers',
            pg: 'TeachersSalary/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/accounting/salary/teachers-salary-schema',
        }
    },

    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },

    methods:{
        ...mapActions({
            getDatas: 'TeachersSalary/teachers',
            getRules: 'TeachersSalary/get',
            getSalaryReport: "TeachersSalary/salaryReport"
        }),

        getData(url = false) {
            this.getDatas({date: url || this.url})
        },

    }
}
</script>