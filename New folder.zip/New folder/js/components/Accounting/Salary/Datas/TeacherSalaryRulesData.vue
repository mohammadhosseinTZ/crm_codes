<template>
    <div class="teachers-salary-list">
    <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
        <h6 v-if="teacher.teacher">قوانین حقوقی: {{teacher.teacher.name}}</h6>
        <div class="mr-3">
            <button v-if="can('accounting_salary')" type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".add-teacher-salary-rule-modal" @click="add({teacher: teacher.teacher})">افزودن</button>
        </div>
    </div>
    <h3>دوره هایی که این استاد تدریس کرده است</h3>
    <div class="teacher-courses-salary">
        <table class="table table-bordered">
            <tr>
                <th>دوره</th>
                <th>وضعیت ثبت حقوقی</th>
            </tr>
            <tr v-for="(data, name) in teacher_courses" :key="data.id">
                <td>{{data.name}}</td>
                <td>
                    <div class="d-flex justify-content-between gap-3">
                        <button class="btn btn-sm" type="button"  data-toggle="modal" data-target=".add-teacher-salary-rule-modal" @click="add({teacher: teacher.teacher, datas: {course: data, course_type: 'public', session_type: 'normal'}})" :class="[get_salary_calc_status(data.id, 'public', 'normal') ? 'btn-success' : 'btn-danger']" >عمومی -عادی</button>
                        <button class="btn btn-sm" type="button"  data-toggle="modal" data-target=".add-teacher-salary-rule-modal" @click="add({teacher: teacher.teacher, datas: {course: data, course_type: 'public', session_type: 'project'}})"  :class="[get_salary_calc_status(data.id, 'public', 'project') ? 'btn-success' : 'btn-danger']" >عمومی - پروژه محور</button>
                        <button class="btn btn-sm" type="button"  data-toggle="modal" data-target=".add-teacher-salary-rule-modal" @click="add({teacher: teacher.teacher, datas: {course: data, course_type: 'private', session_type: 'normal'}})"  :class="[get_salary_calc_status(data.id, 'private', 'normal') ? 'btn-success' : 'btn-danger']" >خصوصی - عادی</button>
                        <button class="btn btn-sm" type="button"  data-toggle="modal" data-target=".add-teacher-salary-rule-modal" @click="add({teacher: teacher.teacher, datas: {course: data, course_type: 'private', session_type: 'project'}})"  :class="[get_salary_calc_status(data.id, 'private', 'project') ? 'btn-success' : 'btn-danger']" >خصوصی - پروژه محور</button>    
                    </div>
                </td>
            </tr>
        </table>
    </div>
    <hr>
    <table class="table table-bordered">
            <tr>
                <th>ردیف</th>
                <th>دوره</th>
                <th>نوع دوره</th>
                <th>نوع جلسه</th>
                <th>واحد</th>
                <th>هزینه</th>
                <th>روزهای تعطیل</th>
                <th>اضافه کاری</th>
                <th>تاریخ شروع</th>
                <th>تاریخ انقضا</th>
                <th>اکشن</th>
            </tr>
            <tr v-for="(data, name) in rules" :key="data.id">
                <td>{{name + 1}}</td>
                <td>{{data.course.name}}</td>
                <td>{{locate(data.course_type)}}</td>
                <td>{{locate(data.session_type)}}</td>
                <td>{{locate(data.unit)}}</td>
                <td>{{data.price | format}}</td>
                <td>{{data.holiday_price | format}}</td>
                <td>{{data.overtime_price | format}}</td>
                <td>{{data.start_date}}</td>
                <td>{{data.expiry_date}}</td>
                <td>
                <button v-if="can('accounting_salary')" type="button" class="btn btn-primary btn-sm w-100" data-toggle="modal" data-target=".add-teacher-salary-rule-modal" @click="editRule({id: data.id, data: data })">ویرایش</button>
                    <button v-if="can('accounting_salary')" type="button" @click="deleteItem(`/accounting/salary/teachers-salary-schema/${data.id}`, data.id, deleteRule)" class="btn btn-sm btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                </td>
            </tr>
    </table>
</div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex'
export default{
name: "TeacherSalaryRulesData",
props: ['data'],
components: {
   
},
computed: {
    ...mapGetters({
        rules: 'TeachersSalary/datas',
        teacher_courses: 'TeachersSalary/courses',
        pg: 'TeachersSalary/pagination',
        teacher: "TeachersSalary/data"
    }),
},
data(){
    return{
    }
},

mounted(){
},

methods:{
    ...mapActions({
        editRule: 'TeachersSalary/edit',
        deleteRule: 'TeachersSalary/delete',
        add: 'TeachersSalary/add',
    }),

    get_salary_calc_status(course_id, course_type, session_type){
        if(!this.rules.find(
            x => x.course.id == course_id &&
            x.course_type == course_type &&
            x.session_type == session_type)) return false;
        return true
    }   
}
}
</script>