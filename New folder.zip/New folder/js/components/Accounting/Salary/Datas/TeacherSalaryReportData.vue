<template>
    <div class="salary-report">
        <h6 v-if="teacher.teacher">حقوق استاد: {{teacher.teacher.name}}</h6>
        <div class="col-md-4 px-0 py-2">
            <label>فیلتر تاریخ</label>
            <date-picker v-if="salary_reports.queries" @change="changeDate" v-model="date" range clearable format="YYYY-MM-DD" display-format="jMMMM jD" placeholder="انتخاب تاریخ" />   
        </div>
    <h6>گزارش جزئی</h6>
    <table  v-if="salary_reports.segments"  class="table table-bordered">
            <tr>
                <th>ردیف</th>
                <th>دوره</th>
                <th>واحد</th>
                <th>مبلغ روز عادی</th>
                <th>مبلغ روز تعطیل</th>
                <th>مبلغ اضافه کاری</th>
                <th>تاریخ شروع</th>
                <th>تاریخ انقضا</th>
                <th>تعداد ساعت</th>
                <th>تعداد جلسات</th>
                <th>حضورغیاب نشده</th>
                <th>تاخیر ها</th>
                <th>حقوق محاسبه شده در سی روز گذشته با این قانون</th>
            </tr>
            <tr v-for="(data, name) in salary_reports.segments" :key="data.id">
                <td>{{name + 1}}</td>
                <td>{{data.rule.course.name}} {{locate(data.rule.course_type)}} {{locate(data.rule.session_type)}}</td>
                <td>{{locate(data.rule.unit)}}</td>
                <td>{{data.rule.price | format}}</td>
                <td>{{data.rule.holiday_price | format}}</td>
                <td>{{data.rule.overtime_price | format}}</td>
                <td>{{data.rule.start_date}}</td>
                <td>{{data.rule.expiry_date}}</td>
                <td>{{data.times_formatted}}</td>
                <td>{{data.sessions_count}}</td>
                <td>{{data.unrollcalled_count}}</td>
                <td>{{data.delay_count}}</td>

                <td>
                    <span class="d-block">عادی <strong>{{data.price | format}}</strong> تومان</span>
                    <span class="d-block">تعطیل <strong>{{data.holiday_price | format}}</strong> تومان</span>
                    <span class="d-block">اضافه کاری <strong>{{data.overtime_price | format}}</strong> تومان</span>
                </td>
            </tr>
    </table>

    
    <hr>
    <h6>گزارش کلی</h6>
    <table v-if="salary_reports.all" class="table table-bordered">
        <tr>
            <th>مجموع ساعت های تدریس در این بازه</th>
            <td>{{salary_reports.all.times}}</td>
        </tr>
        <tr>
            <th>ساعت های باقی مانده برگزار نشده در این بازه</th>
            <td>{{salary_reports.all.running_times}}</td>
        </tr>
        <tr>
            <th>مجموع جلسات برگزار شده در این بازه</th>
            <td>{{salary_reports.all.sessions_count}}</td>
        </tr>
        <tr>
            <th>مجموع جلسات خصوصی</th>
            <td>{{salary_reports.all.private_sessions_count}}</td>
        </tr>
        <tr>
            <th>مجموع ساعت خصوصی</th>
            <td>{{salary_reports.all.private_sessions_times}}</td>
        </tr>
        <tr>
            <th>مجموع جلسات عمومی</th>
            <td>{{salary_reports.all.normal_sessions_count}}</td>
        </tr>
        <tr>
            <th>مجموع ساعت عمومی</th>
            <td>{{salary_reports.all.normal_sessions_times}}</td>
        </tr>
        <tr>
            <th>مجموع تعداد حضور غیاب نشده</th>
            <td>{{salary_reports.all.unrollcalled_count}}</td>
        </tr>

        <tr>
            <th>مجموع تاخیر ها</th>
            <td>{{salary_reports.all.delay_count}}</td>
        </tr>

        <tr>
            <th>تعداد معرفی</th>
            <td>{{salary_reports.all.bonus_count}}</td>
        </tr>

        <tr>
            <th>مجموع پورسانت</th>
            <td>{{salary_reports.all.bonus_price | format}}</td>
        </tr>

        <tr>
            <th>تعداد فروش</th>
            <td>{{salary_reports.all.sale_count}}</td>
        </tr>

        <tr>
            <th>مجموع درآمد فروش</th>
            <td>{{salary_reports.all.sale_price | format}}</td>
        </tr>
        
        <tr>
            <th>مجموع حقوق محاسبه شده در این بازه</th>
            <td>{{salary_reports.all.price | format}}</td>
        </tr>
    </table>
    </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex'
import moment from 'moment'
export default {
    name : "TeacherSalaryReportData",
    components:{
        
    },
        computed: {
        ...mapGetters({
            salary_reports: 'TeachersSalary/salary_report',
            rules: 'TeachersSalary/datas',
            pg: 'TeachersSalary/pagination',
            teacher: "TeachersSalary/data"
        }),
        },
        data(){
            return{
                url: '',
                date: [],
            }
        },

        mounted(){
            this.date = [
                moment(new Date()).subtract(30, 'd').format('YYYY-MM-DD 00:00:00'), 
                moment(new Date()).add(1, 'days').format('YYYY-MM-DD 23:59:59'),
            ]
        },

        methods:{
            ...mapActions({
                getSalaryReport: "TeachersSalary/salaryReport"
            }),

        
            changeDate(){
                this.getSalaryReport({data: this.teacher.teacher, queries: {
                    calc_date: this.date.join(',')
                }})
            }
        }
}
</script>