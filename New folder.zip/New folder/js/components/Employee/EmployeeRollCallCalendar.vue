<template v-s>

  <div class="mot-padding">
    <div class="filter row mb-3">
      <div class="col-md-4">
        <label for="employee-filter">جستجو پرسنل</label>
        <v-select id="employee-filter" v-model="employee" :options="employees" v-debounce="searchEmployee" />
      </div>
      <div class="col-md-4">
        <label for="branch-filter">شعبه </label>
        <v-select id="branch-filter" multiple @input="searchBranch" v-model="filters.branches" :options="branches" />
      </div>
      <div class="col-md-4">
        <label for="branch-filter">برو به تاریخ</label>
        <date-picker format="YYYY-MM-DD" display-format="jYYYY-jMM-01" v-model="selecteddate"
          @change="setDateCalendar"  simple />
      </div>

    </div>
    <button type="button" data-target=".add-employee-leave-modal" data-toggle="modal"
      class="btn btn-primary btn btn-sm d-block">ثبت مرخصی</button>
    <FullCalendar :options="config" ref="employee_rollcall_calendar"  goToDate="2024-8-22"/>
    <AddEmployeeLeave />
  </div>
</template>

<script>

import FullCalendar from '@fullcalendar/vue'
import interactionPlugin from '@fullcalendar/interaction';
import resourceTimelinePlugin from '@fullcalendar/resource-timeline';
import faLocale from '@fullcalendar/core/locales/fa'
import AddEmployeeLeave from './Actions/AddEmployeeLeave.vue';
import axios from 'axios';
import { isNavigationFailure, NavigationFailureType } from 'vue-router';
import {mapGetters, mapActions} from 'vuex'
import moment from 'moment-jalaali'
// import listPlugin from '@fullcalendar/list';
export default {
  name: "EmplyeeRollCallCalendar",
  components: {
    FullCalendar,
    AddEmployeeLeave
  },
  computed: {
        ...mapGetters({
            webdatas: 'EmployeeRollCall/datas',
            meta_data: 'EmployeeRollCall/meta_data',
        }),
        config(){
           this.calendarOptions.events = this.webdatas
          if( this.meta_data.month_start && this.$refs.employee_rollcall_calendar){
            this.$refs.employee_rollcall_calendar.getApi().gotoDate(this.meta_data.month_start)
            this.$refs.employee_rollcall_calendar.getApi().changeView('resourceTimelineMonth' + this.meta_data.month_date )
          }
         
          window.calendarEvents.forEach(el =>{
            let new_holidays = {
              date :  el.date_orginal ,
              title : el.event,
              overlap: false,
              display: 'background',
              color: '#ff00004d',
              allDay:true,
              classNames:['holiday']
            }
            this.calendarOptions.events.push(new_holidays)
          })
        
           return this.calendarOptions
        }
    },

  data() {
    return {
      url: '/api/v1/employee/rollcall/get',
      props: ['data'],
      employee: null,
      employees: [],
      branches: window.branches,
      selecteddate: null,
      eventsDate: new Date(),
      calendarOptions: {
        resourceLabelContent:  (resourceObj)=> {
          return {
            html : `<span class="router-link mot-success employee-calendar-link" ref="employee" data-id="${resourceObj.resource.id}"   > ${resourceObj.resource.title}</span>`
          }
        },
        eventContent: function(event){
          return {
            html: event.event.title ? event.event.title : "تعطیل رسمی"
          }
        },
        plugins: [interactionPlugin, resourceTimelinePlugin],
        locale: faLocale,
        resourceOrder: 'order',
        timeZone: 'Asia/Tehran',
        initialView: 'resourceTimelineMonth31',
        // initialDate: '2024-10-22',
        views: {
          resourceTimelineMonth31: {
            type: 'resourceTimelineMonth',
            duration: { days: 31 },
            buttonText: 'ماه'
          },
          resourceTimelineMonth30: {
            type: 'resourceTimelineMonth',
            duration: { days: 30 },
            buttonText: 'ماه'
          },
          resourceTimelineMonth29: {
            type: 'resourceTimelineMonth',
            duration: { days: 29 },
            buttonText: 'ماه'
          },
        },
        selectable: true,
        slotDuration: '00:30:00',
        slotLabelInterval: 15,
        resourceAreaWidth: '250px',
        contentHeight: 'auto',
        businessHours: {
          daysOfWeek: [1, 2, 3, 4, 5, 6, 7],
          startTime: '08:00', 
          endTime: '21:00', 
        },
        slotMinTime: '08:00',
        slotMaxTime: '21:00',
        headerToolbar: {
          left: '',
          center: 'title',
          right: ''
        },
        resourceGroupField: 'branch_name',
        resourceAreaHeaderContent: 'فهرست پرسنل',
        resources: [],
        events: [],
      },
    }
  },
  mounted(){ 
    let obj = this
    $(document).on('click', function(e){
      if(!$(e.target).hasClass('employee-calendar-link')) return;
      obj.$router.push({name: `EmployeeProfile` , params: { id: e.target.getAttribute('data-id') }}).catch(error => {
          if (!isNavigationFailure(error, NavigationFailureType.duplicated)) {
            throw Error(error)
          }
        });

    })
    this.getCalendarResources();
    // SET TODAY EVENTS
    this.applyUrl();
    let self = this
    $('button.fc-next-button.fc-button').click(() => {
      self.next();
      self.setUrlParam(`date`, self.eventsDate.toISOString());
      self.applyUrl();
    })
    $('button.fc-prev-button.fc-button').click(() => {
      self.prev();
      self.setUrlParam(`date`, self.eventsDate.toISOString());
      self.applyUrl();
    })
    $('button.fc-today-button.fc-button').click(() => {
      self.today()
      self.setUrlParam(`date`, self.eventsDate.toISOString())
      self.applyUrl()
    })
  },
  methods: {
    ...mapActions({
            getDatas: 'EmployeeRollCall/get',
      }),
    next() {
    this.eventsDate.setDate(this.eventsDate.getDate() + 1)
    },
    prev() {
      this.eventsDate.setDate(this.eventsDate.getDate() - 1)
    },
    today() {
      this.eventsDate = new Date()
    },
    getData(url = false) {
        this.getDatas({data: url || this.url});
    },

    getCalendarResources() {
      var url = '/api/v1/employee/rollcall/get-calendar-resource';
      axios.get(url + this.compileParamsToUrl()).then(res => {
        this.calendarOptions.resources = res.data.data
      })
    },
    searchEmployee(search, loading) {
      this.setUrlParam('search', search)
      this.getCalendarResources()
    },

    searchBranch() {
      if (!this.filters.branches) return;
      this.setUrlParam('branches', this.filters.branches.map(x => x.id).join(','))
      this.getCalendarResources()
    },
  

    setDateCalendar() {
      this.eventsDate = new Date(this.selecteddate)
      this.setUrlParam(`date`, this.selecteddate)
      // get resources
      this.applyUrl()

    },
  }

}




</script>
<style>
.fc-bg-event.fc-event.fc-event-start {
    height: 100%;
}
</style>




