<template>

    <div class="employee-profile mot-padding">
        <div class="d-flex justify-content-between align-items-center pb-3">
            <h3 v-if="employee">
                پروفایل <span v-if="employee.user">{{ employee.user.name }}</span>
            </h3>
            <div class="d-flex align-items-start">
                <button type="button" data-target=".add-employee-leave-modal" data-toggle="modal"
                    class="btn btn-primary btn  d-block ml-3 p-1 ">ثبت مرخصی</button>
                <div class="d-flex flex-column">
                    <date-picker format="YYYY-MM-DD" placeholder="انتخاب ماه" display-format="jYYYY-jMM-01" v-model="selecteddate"
                    @change="setDateCalendar"  simple />
                </div>
            </div>
        </div>
        <p class="mot-calendar-today">
            اطلاعات سایر ستون ها در ای پی آی موجوده. فیلد مرخصی هم بیاد
        </p>
        <p class="mot-calender-today">روی هرکدام از ورود و خروج ها کلیک کرد بتونه ویرایشش کنه اون تایم رو همچنین بخشی برای توضیحات باشه</p>
        <p class="mot-calender-today">اگر ورود ثبت شده بود خروج ثبت نشده بود بایستی بشه که خروج هم با دو بار کلیک کردن روی اون سل بتونه خروج اضافه کنه و توضیحات وارد کنه</p>
        <p class="mot-calender-today">یک فید تاریخ و زمان هم باشه که با کلیک کردن روش بتونیم اضافه کنیم همراه با توضیحات. و بعد از ثبت استیت دوباره اجرا بشه</p>
        <table class="table">
            <tr>
                <th>تاریخ</th>
                <th>روز</th>
                <th v-for="times in meta.come_out_lines">{{ times }}</th>
          
                <th class="btn-success-sm">
                    توضیحات
                </th>
                <th class="btn-success-sm">
                    عادی
                </th>
                <th class="btn-success-sm">
                    تعطیل
                </th>
                <th class="btn-success-sm">
                    اضافه
                </th>
                <th class="btn-success-sm">
                    غیبت
                </th>
                <th class="btn-success-sm">
                    تاخیر
                </th>
                <th class="btn-success-sm">
                   مرخصی
                </th>
                <th class="btn-success">
                    جمع
                </th>
            </tr>
            <tr v-for="data in employee_data" :key="data.id" :class="data.is_holiday ? 'leave' : null ||  data.vacations.length>0 && data.vacations[0].time_type == 'daily'? 'leave' : null">
                <td>{{ data.jalali_date | formatDays }}</td>
                <td>{{data.week_day}}</td>
                <td v-for="rolcall in Object.values(data.rollcalls)" v-on:dblclick="changeTime(rolcall) " >{{ rolcall.date_time | formatTime }} </td>
                <td v-for="rol2 in meta.max_count -  Object.values(data.rollcalls).length" :key="rol2"></td>
                <td class="btn-success-sm">
                    توضیحات
                </td>
                <td class="btn-success-sm">
                {{data.is_holiday?"-":data.work_hour }}
                </td>
                <td class="btn-success-sm">
                    {{data.is_holiday?data.work_hour: "-" }}
                </td>
          
                <td class="btn-success-sm">{{ data.overtime }}</td>
                <td class="btn-success-sm">{{ data.absence }}</td>
                <td class="btn-success-sm">{{ data.delay }}</td>
                <td class="btn-success-sm">{{ data.vacations.length>0  ? data.vacations[0].time_type =="daily" && `مرخصی روزانه ${data.vacations[0].from  } تا ${data.vacations[0].to  }` ||  data.vacations[0].time_type =="hourly" && `مرخصی ساعتی ${data.vacations.from}`  : "-" }}</td>
                <td class="btn-success ">{{data.day_report  }}</td>
            
            </tr>
        </table>

        <AddEmployeeLeave />
    </div>

</template>



<script>
import FullCalendar from '@fullcalendar/vue'
import AddEmployeeLeave from './Actions/AddEmployeeLeave.vue';
import { mapGetters, mapActions } from 'vuex'
import moment from 'moment'
export default {

    name: 'EmployeeProfile',
    components: {
        FullCalendar // make the <FullCalendar> tag available
        ,
        AddEmployeeLeave
    },
    computed: {
        ...mapGetters({
            employee_data: 'EmployeeRollCall/datas',
            employee: 'EmployeeRollCall/employee',
            meta: 'EmployeeRollCall/meta_data',
        }),
    },
    mounted() {
        this.getData();
    },
    data() {
        return {
            url: '/api/v1/employee/{id}/rollcall/get-table',
            id: this.$route.params.id,
            selecteddate: null

        };
    },
    filters: {
        formatTime(val){
            return moment(val).format('HH:mm')
        },
        formatDays(val){
           return moment(val).format('DD')
        }
    },
    methods: {
        ...mapActions({
            get: 'EmployeeRollCall/get',
        }),
        getData(url = false) {
            this.get({ data: (url || this.url).replace('{id}', this.id) });
        },
        changeTime(e){
            console.log(e);
        },
        handleComments(e){
            console.log(e , "c");
        },
        
    setDateCalendar() {
      this.eventsDate = new Date(this.selecteddate)
      this.setUrlParam(`date`, this.selecteddate)
      // get resources
      this.applyUrl()

    },  
    },

}
</script>
