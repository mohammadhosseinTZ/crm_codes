<template>
    <div class="employee-salary mot-padding">
        <h3>حقوق و دستمزد</h3>
   
        <table class="table">
            <tr>
                <th>ردیف</th>
                <th>تاریخ</th>
                <th>مبلغ پرداختی</th>
                <th class="mot-w-150">
                صدور فیش حقوقی                  </th>
            </tr>
            <tr>
                <td>1</td>
                <td>1403 مهر</td>
                <td>15,000,00 تومان</td>
                <td class="mot-w-50 d-flex justify-content-center m-auto">
                    <ExportSection  />
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>1403 آبان</td>
                <td>15,200,00 تومان</td>
                <td class="mot-w-50 d-flex justify-content-center m-auto">
                    <ExportSection  />
                </td>
            </tr>
        </table>


    </div>
</template>
<script>
import ExportSection from '../Section/ExportSection.vue';
import Filters from '../Section/Filters.vue'
export default{
    name:'EmployeeSalary',
    components:{
    Filters,
    ExportSection
},
    data(){
        return{

        }
    }
}
    
</script>