<template>
    <popup name="employee-phone">
        <template v-slot:header>
            <h3>تلفن های پرسنل</h3>
        </template>
        <template v-slot:content>
            <div class="mot-personnel-info-container mt-4">
                <!-- FOURTH ROW -->

                <div class="w-100 ">
                    
                    <div class="row d-flex flex-row flex-md-nowrap gap-1 mb-3" v-for="(item, index) in employee.phones"
                        :key="index">
                        
                        <!-- FIRST COL -->
                        <i @click="minusItem(index)" class="fa fa-times text-danger"></i>
                        <div class="mot-personel-box mot-personel-label  col-11 mr-3">
                            <div class="col-3 ">
                                <div class="d-flex">
                
                                    <label :for="'phone_' + index">شماره تلفن</label>
                                </div>
                                <input v-model="item.phone_number" :id="'phone_' + index"  type="text">
                            </div>
                            <div class="col-9 ">
                                <label class="d-block" :for="'comments_' + index">توضیحات</label>
                                <input  v-model="item.comments" :id="'comments_' + index" type="text">
                            </div>
                        </div>
                    </div>
           
                            <button type="button" class="btn btn-sm btn-primary mt-2 align-self-end mb-3"
                    @click="addItem">+</button>
                </div>

        

            </div>
        </template>

    </popup>

</template>
<script>
import { mapGetters, mapActions } from 'vuex';
export default {
    name: "AddEmployeePhone",
    computed: {
        ...mapGetters({
            employee: 'Employee/data'
        })
    },    
    methods: {
        addItem() {
            this.employee.phones.push({
                phone: null,
                comments: null,
            })
        },

        minusItem(item) {
            if (this.employee.phones.length > 1) {
                this.employee.phones = this.employee.phones.filter(x => x != this.employee.phones[item])
            }
        }
    }

}
</script>