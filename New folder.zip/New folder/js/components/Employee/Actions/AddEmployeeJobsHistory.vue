<template>
    <popup name="job-history">
        <template v-slot:header>
            <h3>سابقه کار</h3>
        </template>
        <template v-slot:content>



            <div class=" w-100 mt-4"  v-for="(employee, index) in employee.work_histories " :key="index">
                <i @click="minus_employee_history(index)" class="fa fa-times text-danger"></i>
                <div class="mot-personnel-personal-info-col2 w-100 mr-3 mot-personel-border">
                    <div class="d-flex justify-content-between mot-personel-label flex-wrap">
                   
                   <div class="col-3">
                      
                       <label for="" :for="`name` + index">نام محل کار</label>
                       <input type="text" v-model="employee.name" :id="`name` + index">
                   </div>
                   <div class="col-3">
                           <label :for="`status` + index">سمت</label>
                           <input type="text" v-model="employee.status" :id="`status` + index">
                       </div>
                       <div class="col-3">
                           <label :for="`salary` + index">حقوق</label>
                           <input type="text" v-model="employee.salary" :id="`salary` + index">
                       </div>
                   <div class="col-3">
                       <label :for="`phone` + index">شماره تماس</label>
                       <input type="text" v-model="employee.phone" :id="`phone` + index">
                   </div>
               </div>
               <div class="first-row flex-row-reverse">
                   <!-- FIRST COL -->
                   <div class="first-col ">
                     
                       <div class="col-6 mot-personel-calender ">
                           <label :for="`from-date` + index ">شروع</label>
                           <date-picker :id="`from-date ` + index" format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="employee.from_date" ></date-picker>
           
                       </div>
                       <div class="col-6 mot-personel-calender">
                           <label :for="`to-date` + index">پایان</label>
                           <date-picker :id="`to-date` + index" format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="employee.to_date" ></date-picker>
                          
                       </div>

                       <div class="col-12  ">
                                         
                           <label :for="`leave-status` + index">علت ترک</label>
                           <input type="text" v-model="employee.leave_status" :id="`leave-status` + index">
                       </div>

                   </div>
                   <!-- SECOND COL -->
                   <div class="sec-col mot-personel-label">
                       <label :for="`address` + index">آدرس</label>
                       <input type="text" name="" :id="`address` + index" class="h-100" v-model="employee.address">
                   </div>
               </div>
                </div>

   
            </div>
            <button type="button" class="btn btn-sm btn-primary mt-2 align-self-end mb-3"
                    @click="add_employee_history">+</button>

        </template>

    </popup>
</template>
<script>
import { mapGetters, mapActions } from 'vuex';
export default {
    name: "AddEmployeeJobsHistory",
    data() {
        return {
            
        }
    },
    methods: {
        ...mapActions({
            update: 'Employee/update'
        }),
        add_employee_history() {
            this.employee.work_histories.push({
                name: null,
                phone: null,
                address: null,
                salary: null,
                leave_status: null,
                from_date:null,
                to_date:null,
                status:null

            })
        },
        minus_employee_history(index) {
            if (this.employee.work_histories.length > 1) {
                this.employee.work_histories = this.employee.work_histories.filter(x => x != this.employee.work_histories[index])
            }
        },
    },
    computed: {
        ...mapGetters({
            employee: 'Employee/data',
        })
    },



}
</script>