<template>
    <popup name="employee-relations">
        <template v-slot:header>
            <h3>خویشاوندان</h3>
        </template>
        <template v-slot:content>
            <div class="mot-personnel-info-container mt-4">
                <!-- FOURTH ROW -->

                <div class="w-100 ">
                    
                    <div class="row d-flex flex-row flex-md-nowrap gap-1 mb-3" v-for="(item, index) in employee.relations"
                        :key="index">
                        
                        <!-- FIRST COL -->
                        <i @click="minusItem(index)" class="fa fa-times text-danger"></i>
                        <div class="mot-personel-box mot-personel-label mr-3">
                            <div class="col-2 ">
                                <div class="d-flex">
                                    <!-- <span class="material-symbols-rounded"  @click="minusItem(index)"> close </span> -->
                                    <label :for="'name_' + index">نام و نام خانوادگی</label>
                                </div>
                                <input v-model="item.name" :id="'name_' + index" type="text">
                            </div>
                            <div class="col-2 ">
                                <label class="d-block" :for="'relation_' + index">نسبت</label>
                                <input  v-model="item.relation" :id="'relation_' + index" type="text">
                            </div>
                            <div class="col-2  mot-personel-calender">
                                <label  class="d-block" :for="'birth_date_' + index">تولد</label>
                                <date-picker  format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="item.birth_date" :id="'birth_date_' + index"></date-picker>

                            </div>
                            <div class="col-2 ">
                                <label  class="d-block" :for="'phone_' + index">تلفن</label>
                                <input  v-model="item.phone" :id="'phone_' + index" type="text">
                            </div>
                            <div class="col-2 ">
                                <label :for="'fixed_phone_' + index"   class="d-block" for="">تلفن ثابت</label>
                                <input  v-model="item.fixed_phone" type="text" :id="'fixed_phone_' + index">
                            </div>
                            <div class="col-2 ">
                                <label  class="d-block" :for="'address_' + index">آدرس</label>
                            
                                <textarea  :id="'address_' + index" v-model="item.address" cols="30" rows="1"></textarea>
                            </div>
                        </div>
                    </div>
                    <!-- <button type="button" class="btn btn-sm" @click="addItem"><span
                            class="material-symbols-rounded">add</span></button> -->
                            <button type="button" class="btn btn-sm btn-primary mt-2 align-self-end mb-3"
                    @click="addItem">+</button>
                </div>

        

            </div>
        </template>

    </popup>

</template>
<script>
import { mapGetters } from 'vuex';
export default {
    name: "AddEmployeeRelations",
    computed: {
        ...mapGetters({
            employee: 'Employee/data'
        })
    },
    methods: {
        addItem() {
            this.employee.relations.push({
                relation: null,
                name: null,
                phone: null,
                address: null,
                birth_date: null,
                fixed_phone: null,
            })
        },

        minusItem(item) {
            if (this.employee.relations.length > 1) {
                this.employee.relations = this.employee.relations.filter(x => x != this.employee.relations[item])
            }
        }
    }

}
</script>