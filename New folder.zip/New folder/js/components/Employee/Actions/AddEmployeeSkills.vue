<template>
    <popup name="job-skill">
        <template v-slot:header>
            <h3>
                مهارت ها 
            </h3>
        </template>
        <template v-slot:content>
            <div class="mot-personnel-info-container mt-4" v-for="(employee , index) in employee.skills">
                <i @click="minus_employee_skill(index)" class="fa fa-times text-danger"></i>
                    
                <div class="first-col w-100 mot-personel-box mot-personel-label mr-3">
                    <div class="col-3">
                        <label :for="`name` + index">نام مهارت</label>
                        <input type="text" :id="`name` + index" v-model="employee.name">
                    </div>
                    <div class="col-2" >
                        <label :for="`time` + index">مدت آموزش</label>
                        <input type="text" v-model="employee.time" :id="`time` + index">
                    </div>
                    <div class="col-3">
                        <label :for="`institute_name` + index">نام موسسه</label>
                        <input type="text" v-model="employee.institute_name" :id="`institute_name` + index">
                    </div>
                    <div class="col-2 mot-personel-calender">
                        <label :for="`date` + index">تاریخ دریافت</label>
                        <date-picker  format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="employee.achieve_date" :id="`institute_name` + index" ></date-picker>
                    </div>
                    
                    <div class="col-2 ">
                      
                        
                        
                        <label :for="`mastery_level` + index"  class="ml-3"> میزان تسلط:</label>
                        <select  id="`mastery_level` + index" v-model="employee.mastery_level">
                            <option value="good">خوب</option>
                            <option value="midlevel">متوسط</option>
                            <option value="weak">ضعیف</option>
                        </select>
                    </div>
                                       
                </div>
                         
                
                    
            </div>
            <button type="button" class="btn btn-sm btn-primary mt-2 align-self-end mb-3"
            @click="add_employee_skill">+</button>
        </template>
    </popup>

</template>
<script>
    import { mapGetters, mapActions } from 'vuex';
    export default{
        name:"AddEmployeeSkills",
        methods: {
        add_employee_skill() {
            this.employee.skills.push({
                name: null,
                institute_name:null,
                achieve_date:null,
                time:null
              

            })
        },
        minus_employee_skill(index) {
            if (this.employee.skills.length > 1) {
                this.employee.skills = this.employee.skills.filter(x => x != this.employee.skills[index])
            }
        },
    },
    computed: {
        ...mapGetters({
            employee: 'Employee/data',
        })
    },

    }
</script>