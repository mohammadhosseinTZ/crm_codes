<template>
    <popup name="employee-dependents">
        <template v-slot:header>
            <h3>افراد تحت تکفل (فرزند، همسر و..)</h3>
        </template>
        <template v-slot:content>
            <div class="mot-personnel-info-container mt-4">
                <!-- FOURTH ROW -->

                <div class="w-100 ">
                    
                    <div class="row d-flex flex-row flex-md-nowrap gap-1 mb-3" v-for="(item, index) in employee.dependents"
                        :key="index">
                        
                        <!-- FIRST COL -->
                        <i @click="minusItem(index)" class="fa fa-times text-danger"></i>
                        <div class="mot-personel-box mot-personel-label  col-11 mr-3">
                            <div class="col-4 ">
                                <div class="d-flex">
                                    <!-- <span class="material-symbols-rounded"  @click="minusItem(index)"> close </span> -->
                                    <label :for="'name_' + index">نام</label>
                                </div>
                                <input v-model="item.name" :id="'name_' + index"  type="text">
                            </div>
                            <div class="col-4 ">
                                <label class="d-block" :for="'national_code_' + index">کد ملی</label>
                                <input  v-model="item.national_code" :id="'national_code_' + index" type="text">
                            </div>
                            <div class="col-4 ">
                                <label class="d-block" :for="'relation_' + index">نسبت</label>
                                <input  v-model="item.relation" :id="'relation_' + index" type="text">
                            </div>
                        </div>
                    </div>
                    <!-- <button type="button" class="btn btn-sm" @click="addItem"><span
                            class="material-symbols-rounded">add</span></button> -->
                            <button type="button" class="btn btn-sm btn-primary mt-2 align-self-end mb-3"
                    @click="addItem">+</button>
                </div>

        

            </div>
        </template>

    </popup>

</template>
<script>
import { mapGetters, mapActions } from 'vuex';
export default {
    name: "AddEmployeeDependent",
    computed: {
        ...mapGetters({
            employee: 'Employee/data'
        })
    },    
    methods: {
        addItem() {
            this.employee.dependents.push({
                phone: null,
                comments: null,
            })
        },

        minusItem(item) {
            if (this.employee.dependents.length > 1) {
                this.employee.dependents = this.employee.dependents.filter(x => x != this.employee.dependents[item])
            }
        }
    }

}
</script>