<template>
    <popup name="employee-uploads">
        <template v-slot:header>
            <h3>مدارک و پیوست های پرسنل</h3>
        </template>
        <template v-slot:content>
            <div class="add-upload">
                <ul class="err-box">
                    <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                </ul>
                <div class="row mot-modal-inputs-4 p-3 align-items-end">
                    <div class="form-group mb-3" >
                        <label for="select-file">انتخاب فایل</label>
                        <input type="file" ref="files" class="form-control" multiple @change="setImage" id="select-file" accept="image/*">
                    </div>
                    <div class="form-group mb-3">
                        <label for="upload-type">نوع سند</label>
                        <v-select id="upload-type" v-model="upload.upload_type" :options="upload_types" @search:focus="search_params = 'uploadType|name|upload_types'" v-debounce="dynamicSearch" />
                    </div>
                    <div class="form-group mb-2">
                        <label for="comment-item">توضیحات</label>
                        <input type="text" class="form-control" id="comment-item" v-model="upload.comments" />
                    </div>
                    <div class="form-group mb-2">
                        <button @click="addUpload" class="btn btn-sm btn-primary">بارگزاری مدارک</button>
                    </div>
                </div>
                <div class="d-flex gap-1 flex-wrap mb-3" ref="previews">
                </div>
            </div>
            <div class="upload-list">
                <table class="table max-500-scroll">
                    <tr>
                        <th class="mot-w-45">ردیف</th>

                        <th class="mot-w-200">تصویر پیوست</th>
                        <th>نوع تصویر و مشخصات</th>
                        <th>توضیحات</th>
                        <th>اکشن</th>
                    </tr>
                    <tr v-for="(data, name) in employee.uploads" :key="data.id">
                        <td>{{ name + 1 }}</td>
                        <td>
                            <vue-picture-swipe v-if="data.attachment" :items="[
                                { src: data.attachment.url, thumbnail: data.attachment.url, w: 1200, h: 600, title: data.comments }
                            ]"></vue-picture-swipe>

                        </td>
                        <td>
                            <p><strong>نام سند</strong> {{ locate(data.upload_type.name) }}</p>
                        </td>
                        <td>{{ data.comments }}</td>
                        <td class="dropdown">
                            <button class="btn dropdown-toggle mot-edit-icon-btn" type="button" id="dropdownMenuButton"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="material-symbols-rounded mot-edit-icon">
                                    edit
                                </span>
                            </button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('delete_uploads')" type="button"
                                    @click="deleteItem(`/upload/${data.id}`, data.id, deleteuploads)"
                                    class="btn btn btn-sm btn-danger d-block mt-1 w-100">حذف</button>
                            </div>
                        </td>
                    </tr>
                </table>

            </div>
        </template>

    </popup>

</template>
<script>
import { mapGetters, mapActions } from 'vuex';
export default {
    name: "AddEmployeeUpload",
    computed: {
        ...mapGetters({
            employee: 'Employee/data'
        })
    },
    data(){
        return{
            upload: {
                upload_type: null,
                comments: null,
            },
            upload_types: []
        }
    },      
    methods: {
        deleteuploads(id) {
            this.employee.uploads = this.employee.uploads.filter(x => x.id !== id)
        },
        setImage(){
            var input = this.$refs['files'];
            if (input.files) {
            var filesAmount = input.files.length;
                var obj = this
                $(obj.$refs['previews']).html('')
            for (var i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();
                    reader.onload = function(event) {
                        $($.parseHTML('<img class="mot-w-300 rounded">')).attr('src', event.target.result).appendTo(obj.$refs['previews']);
                    }
                    reader.readAsDataURL(input.files[i]);
                }
            }

    
        },
        addUpload(){
            var files = this.$refs['files'];
            this.vr( this.upload.upload_type, 'نوع سند')
            this.vr(files.files.length, 'انتخاب حداقل یک تصویر')
            this.vr(this.employee.id || this.employee.insideId, 'پرسنل جهت آپلود تصویر')

      
            if(!this.v_error_check()) return;

            var formdata = new FormData()
            
            formdata.append('upload_type_id', this.upload.upload_type.id)
            formdata.append('comments', this.upload.comments)
            formdata.append('employee_id', this.employee.id || this.employee.insideId)
            for(var n of files.files){
                formdata.append('files[]', n)
            }
            axios.post(`/api/v1/employee/upload`,  formdata,{ "Content-Type": "multipart/form-data" })
                .then(res => {
                   this.employee.uploads = res.data.data
            });
        }
    }

}
</script>