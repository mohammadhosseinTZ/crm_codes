<template >
    <popup name="employee-leave">
        <template v-slot:header>
            <h3>مرخصی کارمندان</h3>    
        </template>
        <template v-slot:content> 
            <div class="d-flex justify-content-between mot-personel-label flex-wrap">
            <div class="col-6">
                <label for=" type-leave">نوع مرخصی</label>
                <select  id="type-leave" class="mot-personel" v-model="v_type_leave">
                    <option value="leave-hourly">مرخصی ساعتی</option>
                    <option value="leave-daily">مرخصی روزانه</option>
                </select>
            </div>  
            <div class="form-group col-6">
                <label for=" employee-leave">انتخاب شخص</label>
                <v-select id="employee-leave" @search:focus="search_params='user|name,phone|users'" class="mot-personel" :options="users"  v-debounce="dynamicSearch"/>                       
            </div>
            <div  class="d-flex flex-row justify-content-between mot-personel-label col-6">
                <div class="mot-personel-calender" >
                    <label for="date" >{{ v_type_leave == 'leave-daily' ? 'از تاریخ': 'تاریخ'  }}</label>
                    <date-picker id="date" format="YYYY-MM-DD" display-format="jYYYY-jMM-jDD" auto-submit  class=""></date-picker>
                </div>
                <div class="mot-personel-calender" v-if="v_type_leave == 'leave-daily'">
                    <label for="to-date" >تا تاریخ</label>
                    <date-picker id="to-date" format="YYYY-MM-DD" display-format="jYYYY-jMM-jDD" auto-submit  class=""></date-picker>
                </div>
                <div  v-if="v_type_leave == 'leave-hourly'" class="col-6 mot-personel-label d-flex flex-row justify-content-between ">
                    <div class="col-6">
                    <label for="from-hour">از ساعت</label>
                    <input type="text" id="from-hour">
                    </div>
                    <div class="col-6">
                        <label for="to-hour">تا ساعت</label>
                        <input type="text" id="to-hour">
                    </div>
                </div>
                                          
                                
            </div>
            
            <div v-if="users.length>1" class="d-flex flex-row justify-content-between mot-personel-label  col-6">
                <label for="status">وضعیت</label>
                <div class="col-4 col-4 d-flex flex-row align-items-end">
                    <label for="status_one">مسئول یک</label>
                    <input type="checkbox" class="mb-2 mr-1"   id="status_one">
                </div>
                <div class="col-4 col-4 d-flex flex-row align-items-end">
                    <label for="status_two">مسئول یک</label>
                    <input type="checkbox" class="mb-2 mr-1"   id="status_two">
                </div>
                <div class="col-4 col-4 d-flex flex-row align-items-end">
                    <label for="status_three">مسئول یک</label>
                    <input type="checkbox"   class="mb-2 mr-1" id="status_three">
                </div>
            </div>
                <div class="row w-100 mt-1" >
                    <div class=" ">
                      <input type="submit" class="btn btn-success mt-3 mb-3" placeholder="افزودن">
                         
                    </div>
              </div>
            </div>
            
        
        </template>
    </popup>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default{
        name:'AddEmployeeLeave',
     
        data() {
        return {
            users: [],
            v_type_leave:false,
            status_checked:false
        
        };
        },
        computed:{
            ...mapGetters({
                employee: 'Employee/data'  
            })
        }
        
    }

</script>