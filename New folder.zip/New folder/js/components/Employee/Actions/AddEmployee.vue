<template>
    <!-- Modal -->
    <div class="add-employee">
        <div class="modal fade add-employee-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">افزودن/ ویرایش</h5>
                        <div class="d-flex gap-1 align-items-center">
                            <span>کد پرسنلی</span>
                            <input type="text" dir="ltr" v-model="employee.code" disabled>
                        </div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                        <form action="" @submit.stop.prevent="addData">
                            <ul class="err-box">
                                <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                            </ul>
                            <div class="row mot-modal-inputs-6 m-0">


                                <div class="form-group">
                                    <label for=" user_id">جستجو افراد</label>
                                    <v-select id=" user_id" @search:focus="search_params = 'user|name,phone|users'"
                                        v-model="employee.user" :options="users" v-debounce="dynamicSearch" />
                                </div>

                                <div class="form-group">
                                    <label for="work_type_id">فعالیت</label>
                                    <v-select @input="setpersonal_code(employee.work_type)"
                                        @search:focus="search_params = 'workType|name|workType'" id="work_type_id"
                                        v-model="employee.work_type" :options="workType" v-debounce="dynamicSearch" />
                                </div>

                                <div class="form-group">
                                    <label for="branch_id">شعبه</label>
                                    <v-select @input="setpersonal_code(employee.branch)"
                                        @search:focus="search_params = 'branch|name|branch'" id="branch_id"
                                        v-model="employee.branch" :options="branch" v-debounce="dynamicSearch" />
                                </div>

                                <div class="form-group">
                                    <label for="work_section_id">بخش</label>
                                    <v-select @input="setpersonal_code(employee.work_section)"
                                        @search:focus="search_params = 'workSection|name|workSection'"
                                        id="work_section_id" v-model="employee.work_section" :options="workSection"
                                        v-debounce="dynamicSearch" />
                                </div>


                                <div class="form-group">
                                    <label for="work_job_id">شغل</label>
                                    <v-select @input="setpersonal_code(employee.work_job)"
                                        @search:focus="search_params = 'workJob|name|workJob'" id="work_job_id"
                                        v-model="employee.work_job" :options="workJob" v-debounce="dynamicSearch" />
                                </div>




                                <div class="form-group">
                                    <label for="director_id">مسئول مستقیم</label>
                                    <v-select id="director_id" @search:focus="search_params = 'employee|name,phone,code|users'"
                                        v-model="employee.director" :options="users" v-debounce="dynamicSearch" />
                                </div>

                            </div>
                            <hr>
                            <!-- FIRST ROW -->
                            <div class="mot-personnel-info-container ">
                                <!-- FIRST COL -->
                                <div class="mot-personnel-personal-info-col1">
                                    <!-- RIGHT COL -->
                                    <div class="right-col">
                                        <div class="col-3">
                                            <label for="nationality">ملیت</label>
                                            <input type="text" id="nationality"
                                                v-model="employee.extra_data.nationality">
                                        </div>
                                        <div class="col-3">
                                            <label for="religion">دین</label>
                                            <input type="text" id="religion" v-model="employee.extra_data.religion">
                                        </div>
                                        <div class="col-3">
                                            <label for="religion_sect">مذهب</label>
                                            <input type="text" id="religion_sect"
                                                v-model="employee.extra_data.religion_sect">
                                        </div>
                                        <div class="col-3">
                                            <label for="marital_status">وضعیت تاهل</label>
                                            <v-select id="marital_status" v-model="employee.extra_data.marital_status"
                                                :reduce="item => item.name" :options="attached.marital_statuses" class="mot-personel"/>
                                        </div>
                                        <div class="" v-if="typeof employee.extra_data.marital_status == 'string' && employee.extra_data.marital_status != 'single'">
                                            <label for="childs">تعداد فرزندان</label>
                                            <input id="childs" v-model="employee.extra_data.childs">
                                        </div>
                                        <div class="col-3">
                                            <label for="insurance_history">سابقه بیمه</label>
                                            <input type="text" id="insurance_history"
                                                v-model="employee.extra_data.insurance_history">
                                        </div>
                                        <div class="col-4">
                                            <label for="insurance_number">شماره بیمه</label>
                                            <input type="text" id="insurance_number"
                                                v-model="employee.extra_data.insurance_number">
                                        </div>
                                        <div class="col-5 mot-personel-calender">
                                            <label for="birth_date">تاریخ تولد</label>
                                            <date-picker id="birth_date" format="YYYY-MM-DD"
                                                display-format="jYYYY-jMM-jDD" auto-submit
                                                v-model="employee.extra_data.birth_date"></date-picker>
                                        </div>
                                    </div>
                                    <!-- LEFT COL -->
                                    <div class="left-col">
                                        <div class="col-6">
                                            <label for="birth_place">محل تولد</label>
                                            <v-select id="birth_place" v-model="employee.extra_data.birth_place"
                                                :reduce="item => `${item.id}`" :options="attached.birth_place" class="mot-personel"/>
                                        </div>
                                        <div class="col-6">
                                            <label for="birth_place">محل سکونت</label>
                                            <v-select class="mot-personel" id="birth_place" v-model="employee.extra_data.city"
                                                :reduce="item => `${item.id}`" :options="attached.city" />
                                        </div>
                                        <div class="col-6">
                                            <label for="evidence">مدرک تحصیلی</label>
                                            <v-select class="mot-personel" id="evidence" v-model="employee.extra_data.evidence"
                                                :reduce="item => `${item.id}`" :options="attached.evidence" />
                                        </div>
                                        <div class="col-6">
                                            <label for="evidence">رشته تحصیلی</label>
                                            <v-select class="mot-personel" id="evidence" v-model="employee.extra_data.colage_course"
                                                :reduce="item => `${item.id}`" :options="attached.colage_course" />
                                        </div>
                                    </div>


                                </div>
                                <!-- SECOND COL -->
                                <div class="mot-personnel-personal-info-col2">
                                    <div class="first-row">
                                        <!-- FIRST COL -->
                                        <div class="first-col">
                                            <div class="col-6">
                                                <label for="father_name">نام پدر</label>
                                                <input type="text" id="father_name"
                                                    v-model="employee.extra_data.father_name">
                                            </div>
                                            <div class="col-6">
                                                <label for="national_code">کدملی/پاسپورت</label>
                                                <input type="text" id="national_code"
                                                    v-model="employee.extra_data.national_code">
                                            </div>
                                            <div class="col-6">
                                                <label for="duty_status">وضعیت نظام وظیفه</label>

                                                <v-select class="mot-personel" id="duty_status" v-model="employee.extra_data.duty_status"
                                                    :reduce="item => item.name" :options="attached.duty_status" />
                                            </div>
                                            <div>
                                                <label for="card_number">شماره شبا</label>
                                                <input type="text" id="card_number"
                                                    v-model="employee.extra_data.card_number">
                                            </div>
                                            <div class="col-8 justify-content-center "
                                                v-if="employee.extra_data.duty_status && employee.extra_data.duty_status == 'excused'">
                                                <label for="duty_status_des">دلیل معافیت</label>
                                                <input type="text" id="duty_status_des">
                                            </div>

                                        </div>
                                        <!-- SECOND COL -->
                                        <div class="sec-col ">
                                            <label for="address">آدرس</label>
                                            <input type="text" id="address" v-model="employee.extra_data.address"
                                                class="h-100">
                                        </div>
                                    </div>

                                </div>
                            </div>


                            <!-- THIRD ROW -->
                            <div class="d-flex justify-content-start gap-1">
                                <button class="btn btn-primary btn-sm  mt-4" type="button" data-toggle="modal"
                                    data-target=".add-job-history-modal"> افزودن / ویرایش سابقه کار </button>
                                <button class="btn btn-primary btn-sm  mt-4" type="button" data-toggle="modal"
                                    data-target=".add-job-skill-modal">افزودن / ویرایش مهارت ها</button>
                                <button class="btn btn-primary btn-sm mt-4" type="button" data-toggle="modal"
                                    data-target=".add-employee-relations-modal">افزودن / ویرایش مشخصات آشنایان</button>
                                <button v-if="employee.insideType == 'update'" class="btn btn-primary btn-sm mt-4"
                                    type="button" data-toggle="modal" data-target=".add-employee-uploads-modal">مدارک و
                                    مشخصات</button>
                                <button class="btn btn-primary btn-sm mt-4"
                                    type="button" data-toggle="modal" data-target=".add-employee-dependents-modal">افراد تحت تکفل</button>
                                <button class="btn btn-primary btn-sm mt-4"
                                    type="button" data-toggle="modal" data-target=".add-employee-phone-modal">تلفن ها</button>
                            </div>



                            <hr>

                            <!-- FIFTH ROW -->
                            <div class="mot-personnel-info-container mt-4">

                                <div class="mot-personnel-personal-info-col1 col-12 px-0">
                                    <!-- RIGHT COL -->
                                    <div class="right-col w-100 ">
                                        <!-- Relations -->


                                        <div class="col-2">
                                            <label for="contract">نحوه همکاری و قرداد </label>

                                            <v-select  class="mot-personel" id="contract" v-model="employee.extra_data.contract"
                                                :reduce="item => `${item.id}`" :options="contracts" />
                                        </div>


                                        <div class="col-2 ">
                                            <label for="insurance"> بیمه تامین اجتماعی</label>
                                            <v-select class="mot-personel"  id="insurance" v-model="employee.extra_data.insurance"
                                                :reduce="item => item.name" :options="attached.insurance" />
                                        </div>

                                        <div class="col-2 ">

                                            <label for="rights_requested"> حقوق درخواستی</label>
                                            <input type="text" id="rights_requested"
                                                v-model="employee.extra_data.rights_requested">

                                        </div>
                                        <div class="col-2 mot-personel-calender">
                                            <label for="from_date"> شروع کار</label>

                                            <date-picker format="YYYY-MM-DD" display-format="jYYYY-jMM-jDD" auto-submit
                                                v-model="employee.extra_data.from_date" id="from_date"></date-picker>

                                        </div>
                                        <div class="col-2 mot-personel-calender">
                                            <label for="to_date"> ترک کار</label>
                                            <date-picker format="YYYY-MM-DD" display-format="jYYYY-jMM-jDD" auto-submit
                                                v-model="employee.extra_data.to_date" id="to_date"></date-picker>

                                        </div>
                                        <div class="col-2 px-0">
                                            <label for="leave_reason"> علت ترک کار </label>
                                            <textarea id="leave_reason" cols="30" rows="1"
                                                v-model="employee.extra_data.leave_reason"></textarea>
                                        </div>
                                    </div>



                                </div>
                                <!-- SECOND COL -->



                            </div>

                            <!-- SIXTH ROW -->

                            <div class="mot-personnel-info-container mt-4">
                                <!-- FIRST COL -->
                                <div class="mot-personnel-personal-info-col1 w-100">
                                    <!-- RIGHT COL -->
                                    <div class="right-col w-100 flex-column">
                                        <label for="job-duties">شرح وظایف</label>
                                        <v-select  class="w-100 mot-personel" id="job-duties"
                                            @search:focus="search_params = 'jobDuty|name|job_duties'" multiple
                                            v-model="employee.job_duties" :options="job_duties"
                                            v-debounce="dynamicSearch" />
                                    </div>
                                </div>
                                <!-- SECOND COL -->

                            </div>

                            <!-- SEVENTH ROW -->
                            <div class="mot-personnel-info-container ">
                                <!-- FIRST COL -->
                                <div class="mot-personnel-personal-info-col1 w-100">
                                    <!-- RIGHT COL -->
                                    <div class="right-col  align-items-start col-6">

                                            <label for="">ایام کاری</label>
                                            <div class="class-section col-12">
                                                <div class="row m-0  class-wrapper"
                                                    v-for="(work_hour, index) in employee.work_hours">
                                                    <div class=" d-flex mb-2">
                                                        <label for="saturday"
                                                            class="mot-w-100 mb-0 d-flex align-items-center ml-2">{{
                                                            locate(work_hour.week_day) }}:</label>
                                                        <div class="d-flex flex-row ml-3">
                                                            <label for="from"
                                                                class="mb-0 d-flex align-items-center ml-2">از
                                                                ساعت</label>
                                                            <input type="text" :id="`from` + index"
                                                                class="col-4 mot-w-100" required
                                                                v-model="work_hour.from">
                                                        </div>
                                                        <div class="d-flex flex-row ml-3">
                                                            <label for="to"
                                                                class="mb-0 d-flex align-items-center ml-2">تا
                                                                ساعت</label>
                                                            <input type="text" :id="`to` + index"
                                                                class="col-4  mot-w-100" required
                                                                v-model="work_hour.to">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                     

                                    </div>
                                </div>
                                <!-- SECOND COL -->
                                <div class="mot-personnel-personal-info-col1 w-100">
                                <div class="form-group">
                                        <label for="comments">توضیحات</label>
                                        <textarea type="text" rows="10" class="form-control" id="comments"
                                            v-model="employee.comments"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group">
                                    <input type="submit" class="form-control"
                                        :value="[employee.insideType == 'update' ? 'ویرایش' : 'افزودن']">
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex';

export default {
    name: "AddEmployee",

    computed: {
        ...mapGetters({
            employee: 'Employee/data'
        })
    },
    data() {
        return {
            users: [],
            workJob: [],
            workType: [],
            workSection: [],
            branch: [],
            director: [],
            contracts: window.contracts,
            job_duties: [],
            attached: {
                birth_place: window.places,
                city: window.places,
                evidence: window.evidences,
                colage_course: window.disciplines,
                duty_status: window.defined_enums.duty_statuses,
                insurance: window.defined_enums.insurance,
                marital_statuses:  window.defined_enums.marital_statuses

            },
        };
    },
    methods: {
        ...mapActions({
            update: 'Employee/update',

        }),
        addData() {
            // this.vr(data,  alert);
            if (!this.v_error_check())
                return;
            axios.post('/api/v1/employee', this.employee)
                .then(res => {
                    if (res.data.alert && res.data.alert.type == 'error')
                        return;
                    this.employee.insideId = res.data.data.id;
                    this.employee.insideType = 'update';
                    this.update(res.data.data);
                    $('.add-employee-modal').modal('hide');
                });
        },

        setpersonal_code(obj_param) {
            if (this.employee.work_job &&
                this.employee.work_section &&
                this.employee.branch &&
                this.employee.work_type) {
                axios.post('api/v1/employee/get-employee-id', {
                    work_job_id: this.employee.work_job.id,
                    work_section_id: this.employee.work_section.id,
                    branch_id: this.employee.branch.id,
                    work_type_id: this.employee.work_type.id,
                }).then(res => {
                    this.employee.code = ''.concat(this.employee.work_type.id, `${this.employee.branch.id}`.padStart(2, '0'), `${this.employee.work_section.id}`.padStart(2, '0'), `${this.employee.work_job.id}`.padStart(2, '0'), res.data.id);
                });
            }

            if (this.employee.work_job) {
                axios.get(`api/v1/search/jobDuty/job_id/${this.employee.work_job.id}?filter_job_id=${this.employee.work_job.id}`).then(res => {
                    this.employee.job_duties = res.data;
                    this.job_duties = res.data
                });
            }
        }
    },

}
</script>