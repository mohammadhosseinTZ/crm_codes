<template>
    <div class="employee-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex align-items-center">
                <button v-if="can('add_employee')" type="button" class="btn " data-toggle="modal" data-target=".add-employee-modal" @click="add()"><span class="material-symbols-rounded mot-add-newItem">
                add_box
                </span> </button>
               <div class="mot-actions-col2">
                    <small class="text-muted pr-2">نتایج: {{counts}}</small>
               </div>
            </div>
        </div>
   
            <div class="mot-pagination-header">
                <Filters v-if="can('use_filters')" :allows="['user_branches', 'search']" :prm="params" :uri="url" @set="setFilter" />   
                <paginate :paginate="pg" @changePage="changePage"/>
            </div>
            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th>کد پرسنلی</th>
                    <th>فرد</th>
                    <th>حوزه کاری</th>
                    <th>شعبه</th>
                    <th>بخش</th>
                    <th>شفل</th>
                    <th>مسئول مستقیم</th>
                    <th>صدور فیش های حقوقی</th>
                    <th></th>
                </tr>
                <tr v-for="(data, name) in webdatas" :key="data.id">
                    <td >{{name + 1}}</td>
                    <td @click="profile_page(data.id)" class="mot-success">{{data.code}}</td>
                    <td @click="profile_page(data.id)" class="mot-success">{{data.user.name}} - {{data.user.phone}}</td>
                    <td>{{data.work_type.name}}</td>
                    <td>{{data.branch.name}}</td>
                    <td>{{data.work_section.name}}</td>
                    <td>{{data.work_job.name}}</td>
                    <td>{{data.director.label}}</td>
                    <td class="d-block mot-w-150 p-0  ">
                        <button type="button"  class="mot-font-14 btn btn-warning btn px-0 py-1 my-1 d-block w-75 text-white" data-toggle="modal" data-target=".add-employee-salary-modal">فیش های حقوقی</button>
                    </td>
                    <td class="dropdown">
                        <button class="btn dropdown-toggle mot-edit-icon-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon">
                            edit
                            </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_employee')" type="button" class="btn btn-primary btn btn-sm d-block" data-toggle="modal" data-target=".add-employee-modal" @click="edit({id: data.id, data: data })">ویرایش</button>
                                <button v-if="can('delete_employee')" type="button" @click="deleteItem(`/employee/${data.id}`, data.id, deleteemployee)" class="btn btn btn-sm btn-danger d-block mt-1 w-100">حذف</button>       
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>

            <AddEmployee />
            <AddEmployeeJobsHistory/>
            <AddEmployeeRelations />
            <AddEmployeeSkills/>
            <AddEmployeeUpload />
            <AddEmployeePhone />
            <AddEmployeeDependent />
            <AddEmployeeSalary/>
    </div>
</template>
<script>
import Filters from '../Section/Filters.vue'
import AddEmployee from './Actions/AddEmployee.vue'
import { mapGetters,mapActions } from 'vuex'
import AddEmployeeJobsHistory from './Actions/AddEmployeeJobsHistory.vue'
import AddEmployeeRelations from './Actions/AddEmployeeRelations.vue'
import AddEmployeeSkills from './Actions/AddEmployeeSkills.vue'
import AddEmployeeUpload from './Actions/AddEmployeeUpload.vue'
import AddEmployeePhone from './Actions/AddEmployeePhone.vue'
import AddEmployeeDependent from './Actions/AddEmployeeDependent.vue'
import AddEmployeeSalary from './Actions/AddEmployeeSalary.vue'
export default {
    name: 'EmployeeList',
    props: ['data'],
    components:{
    Filters,
    AddEmployee,
    AddEmployeeJobsHistory,
    AddEmployeeRelations,
    AddEmployeeSkills,
    AddEmployeeUpload,
    AddEmployeePhone,
    AddEmployeeDependent,
    AddEmployeeSalary
},
    computed: {
        ...mapGetters({
            webdatas: 'Employee/datas',
            counts: 'Employee/count',
            pg: 'Employee/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/employee',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data};
    },
    methods: {
        ...mapActions({
            add: 'Employee/add',
            edit: 'Employee/edit',
            getDatas: 'Employee/get',
            deleteemployee: 'Employee/delete',
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
  
        },

        profile_page(el){
            this.$router.push({name: `EmployeeProfile` , params: { id: el }}).catch(error => {
                if (!isNavigationFailure(error, NavigationFailureType.duplicated)) {
                  throw Error(error)
                }
            });
                 
        }
    }
}
</script>