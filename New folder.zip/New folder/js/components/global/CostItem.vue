<template>
    <table class="table table-bordered">
        <tr>
            <th>ردیف</th>
            <th>وضعیت</th>
            <th>تاریخ</th>
            <th>الصاق به</th>
            <th>نوع هزینه</th>
            <th>تنخواه</th>
            <th>کسب و کار</th>
            <th>کد رهگیری</th>
            <th>کد پیگیری</th>
            <th>هزینه جز</th>
            <th>هزینه کل</th>
            <th>تعداد</th>
            <th>هزینه پراخت شده</th>
            <th>روش پرداخت</th>
            <th>ثبت کننده</th>
            <th>فروشنده</th>
            <th>توضیحات</th>
            <th>اکشن</th>
        </tr>
        <tr v-for="(data, index) in costs" :class="!checkPrice(data) ? 'leave' : null" :key="data.id">
            <td>{{index + 1}}</td>
            <td role="button" v-if="data.status == 0" style="color:red" @click="checkCan(data.id)">✖ {{data.id}}</td>
            <td role="button" v-else style="color:green" @click="checkCan(data.id)">✔ {{data.id}}</td>
            <td>{{data.created_at}}</td>
            <td>
                {{data.items.map(x => x.costableName).join(' و ')}}
            </td>
            <td>{{data.items.map(x => x.key.name).join(' و ')}}</td>
            <td v-if="data.fund_card">{{data.fund_card.label}}</td>
            <td v-else>نامشخص</td>
            <td>{{data.branch.name}}</td>
            <td>{{data.transaction_id}}</td>
            <td>{{data.order_id}}</td>
            <td>{{data | price | format}}</td>
            <td>{{data | allPrice | format}}</td>
            <td>{{data.items | quantity}} {{data.items | unit}}</td>
            <td>{{data.gates | getPrice | format}} <small v-if="parseInt(data.pay_discount_price)" class="text-danger bold"><br><strong> {{data.pay_discount_price | format}} تخفیف روی فاکتور </strong></small></td>
            <td>{{data.gates | getWays}}</td>
            <td>{{data.user_insert.name}}</td>
            <td>{{data.seller ? data.seller.name : null}}</td>
            <td>{{data.comment}} {{data.items.map(x => x.comment).join(' - ')}}</td>
            <td class="dropdown">
                <button class="btn mot-info-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <button v-if="parseInt(data.status) == 0 && (can('edit_costs') || can('see_only_costs', data.user_insert_id ))" type="button" class="btn btn-sm w-100 btn-primary" data-toggle="modal" data-target=".add-cost-modal" data-backdrop="static" data-keyboard="false" @click="edit({id:  data.id, data: data})">ویرایش</button>
                        <button v-if="parseInt(data.status) == 0 &&  can('delete_costs')" type="button" @click="deleteItem(`/cost/${data.id}`, data.id, deleteCost)" class="btn btn-sm btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                        <button v-if="parseInt(data.status) == 0 &&  can('delete_costs') && data.deleted_at" type="button" @click="deleteItem(`/cost/${data.id}?type=restore`, data.id, deleteCost)" class="btn btn-sm btn-success d-block mt-1 w-100" data-toggle="modal" data-target="">بازیابی</button>           
                        <div v-if="can('change_stock_status')">
                            <button v-if="parseInt(data.delivered)" type="button" @click="changeStockStatus(data)" class="btn btn-sm btn-success d-block mt-1 w-100">تحویل انبار داده شده</button>           
                            <button v-else  type="button" @click="changeStockStatus(data)" class="btn btn-sm btn-warning d-block mt-1 w-100">تحویل انبار داده نشده</button>           
                        </div>
                </div>
            </td>
        </tr>
    </table>
</template>
<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name: "CostItem",
    props: ['costs'],
    filters: {
        price: function(costItem){
            var price = 0
            costItem.items.forEach(item => {
                price += parseInt(item.price)
            });
            return price;
        },
        allPrice: function(costItem){
            var price = 0
            costItem.items.forEach(item => {
                price += parseInt((item.price * item.quantity) - item.discount_price) 
            });
            return parseInt(price - costItem.pay_discount_price);
        },
        quantity: function(items){
            var quantity = 0
            items.forEach(item => {
                quantity +=  parseInt(item.quantity)
            });
            return quantity
        },
        unit: function(items){
            var unit = null
            items.forEach(item => {
                if(item.unit){
                    unit =  item.unit.label
                }
            });
            return unit
        }
    },
    methods:{
        ...mapActions({
            edit: 'Cost/edit',
            deleteCost: 'Cost/delete',
            changeCostStatus: 'Cost/changeStatus'
        }),
        checkPrice(data){
            return parseInt(data.is_payid);
        },
        checkCan(id){
          if(this.can('change_costs_status')){
                this.changeCostStatus(id)
           }
        },
        changeStockStatus(data){
            axios.get(`/api/v1/cost/${data.id}/change-delivered-status`).then(res => {
                data.delivered = res.data.data.delivered
            })
        }
    }
}
</script>