<template>
    <div id="print-product-factor">
        <div class="content">
            <div class="head">
                <img src="https://portal.aryatehran.com/images/logo.png" class="logo" alt="">
                <div class="head-content">
                    <h3>{{register.user_insert.branch_id | branchname}}</h3> 
                    <span>فاکتور فروش شماره: {{register.id}}</span>  
                    <span><strong>تاریخ: </strong> <span class="date">{{register.created_at}}</span></span>                
                </div>
            </div>
            </div>
            
            <div class="product-items">
            <div class="pthead">
                <strong>تعداد</strong>
                <strong>قیمت مصرف کننده</strong>
                <strong>مبلغ تخفیف</strong>
                <strong>قابل پرداخت</strong>
            </div>
            <div class="pt-item" v-for="item in register.items" :key="item.id">
                <span class="pname">{{item.supplier.name}}</span>
                <span><strong>تعداد محصول:</strong> {{item.quantity}}</span> 
                <span>{{item.unit_price | format}} تومان</span> 
                <span>{{item.discount_price | format}} تومان</span>   
                <span>{{item.price | format}} تومان </span>    
            </div>
            </div>
        <table class="pay-info">
            <tr>
                <th>مجموع اقلام:</th>
                <td>{{register.quantity}}</td>
            </tr>
            <tr>
                <th>مبلغ فاکتور قبل از تخفیف:</th>
                <td>{{register.undiscounted_price | format}} تومان</td>
            </tr>
            <tr>
                <th>مبلغ فاکتور:</th>
                <td>{{register.price | format}} تومان</td>
            </tr>
            <tr>
                <th>سود شما از خرید:</th>
                <td>{{register.your_profit | format}} تومان</td>
            </tr>
          
            <tr class="pay-methods" v-for="payment in register.payments" :key="payment.id">
                <th>روش پرداخت: {{payment.gates | getWays}}</th>
                <td>مبلغ: {{payment.gates | getPrice | format}} تومان</td>
            </tr>
            </table>
            <hr>
            <table class="complete-info">
                <tr>
                    <th>
                        نام فروشگاه:
                    </th>
                    <td>
                        {{register.user_insert.branch_id | branchname}}
                    </td>
                </tr>
                <tr>
                    <th>
                        آدرس:
                    </th>
                    <td>
                        {{register.user_insert.branch_id | branchaddress}}
                    </td>
                </tr>
                <tr>
                    <th>
                        کد پستی:
                    </th>
                    <td>
                        {{register.user_insert.branch_id | branchpostalcode}}
                    </td>
                </tr>
                <tr>
                    <th>
                        آدرس سایت:
                    </th>
                    <td>
                        {{register.user_insert.branch_id | branchsite}}
                    </td>
                </tr>
                <tr>
                    <th >
                        اینستاگرام:
                    </th>
                    <td dir="ltr">
                        {{register.user_insert.branch_id | branchinsta}}
                    </td>
                </tr>
                <tr>
                    <th>
                        شماره تماس شعبه:
                    </th>
                    <td>
                        <span class="date">{{register.user_insert.branch_id | branchphone}}</span>
                    </td>
                </tr>
                <tr>
                    <th>
                        نام مشتری:
                    </th>
                    <td>
                        <span class="date">{{register.user.name}}</span>
                    </td>
                </tr>
                <tr>
                    <th>
                        شماره تماس مشتری:
                    </th>
                    <td>
                        <span class="date">{{register.user.phone}}</span>
                    </td>
                </tr>
            </table>
        </div>
</template>
<script>
export default{
    name: "ProductRegisterReceipt",
    props: ['register'],
    filters: {
        getPrice: function(value){
            var prices =  value.map(function(value,index) { return value.price; });
            return prices.reduce(function(total, num){
                return parseInt(total) + parseInt(num);
            });
        },
        getWays: function(value){
           var ways =  value.map(function(value,index) {
                if(value.chash_way){
                    return value.chash_way.option_value;
                }
            }); 
           return ways.join(' و ');
        },

        getType: function(value){
            var registerPrice = parseInt(value.paymentable.price)
            var tmpPrice = 0;
                value.related.forEach(element => {
                    if(value.paymentable_type == element.paymentable_type){
                        var prices = element.gates.map(value => value.price);
                        tmpPrice += parseInt(prices.reduce((total, num) =>{
                            return parseInt(total) + parseInt(num);
                        }));  
                    }
                    
                });
            var glose = registerPrice - tmpPrice
            if(parseInt(glose) == 0) return 'تسویه';
            return glose + ' تومان';
        },
        branchname: function(val){
            return window.branches.find(x => x.id == val).name
        },
        branchpostalcode: function(val){
            return window.branches.find(x => x.id == val).postal_code
        },
        branchaddress: function(val){
            return window.branches.find(x => x.id == val).address
        },
        branchphone: function(val){
            return window.branches.find(x => x.id == val).phone
        },
        branchsite: function(val){
            return window.branches.find(x => x.id == val).market_url
        },
        branchinsta: function(val){
            return window.branches.find(x => x.id == val).insta
        },
        branchtelegram: function(val){
            return window.branches.find(x => x.id == val).branchtelegram
        },

    }
}
</script>


