<template>
    <div class="loading" :class="[getLoadingStatus ? 'active' : null]">
        <div class="row justify-content-center text-center">
            <div class="col-md-12">
                <div class="loader mx-auto"></div>
            </div>
            <h5 class="col-md-12 mt-5">لطفا صبر کنید ...</h5>
        </div>
    
        
    </div>
</template>
<script>


export default {
    name: "Loading",
    
}
</script>
