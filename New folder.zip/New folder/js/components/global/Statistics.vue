<template>
    <div class="statistics">
        <h3>{{title}}</h3>
        <table class="table table-bordered">
            <tr v-if="statistics">
                <th v-for="sp in statistics" :key="sp.option_value">{{sp.option_value}}</th>
            </tr>
            <tr v-if="statistics">
                <td v-for="sp in statistics" :key="sp.option_value">{{sp.price || calc}}</td>
            </tr>
        </table>
    </div>
</template>
<script>

export default {
    name: "Statistics",
    props: ['statistics', 'title']
}
</script>
