<template>
    <div id="print-payment">
        <div class="content">
            <img src="https://portal.aryatehran.com/images/logo.png" alt="">
            </div>
            <h1>قبض رسید آموزشگاه آریا تهران</h1>
            <table>
            <tr>
                <th>شماره فیش:</th>
                <td>{{payment.code}}</td>
            </tr>
            <tr v-if="payment.order_id">
                <th>کد سفارش در سایت:</th>
                <td>{{payment.order_id}}</td>
            </tr>
            <tr>
                <th>تاریخ:</th>
                <td>
                <span class="date">{{payment.created_at}}</span>
                </td>
            </tr>
            <tr>
                <th>مبلغ(به عدد):</th>
                <td>{{payment.gates | getPrice | format}} تومان</td>
            </tr>
            
                <tr>
                <th>مبلغ(به حروف):</th>
                <td>{{payment.wordPrice}}</td>
            </tr>
            
            <tr>
                <th>روش پرداخت:</th>
                <td>{{payment.gates | getWays}}</td>
            </tr>
            
                <tr>
                <th>بابت:</th>
                <td>{{payment.paymentable.supplier.name}} <span v-if="payment.sr.en_name == 'courses'">{{parseInt(payment.paymentable.class_course.course_code) != 999 ? 'کد: ' + payment.paymentable.class_course.course_code : ''}}</span></td>
            </tr>
            
                <tr>
                    <th>پرداخت کننده:</th>
                    <td>{{payment.paymentable.user.name}}</td>
                </tr>
            
                <tr>
                    <th>پذیرنده:</th>
                    <td>{{payment.user_insert.name}}</td>
                </tr>

                <tr>
                    <th>باقی مانده:</th>
                    <td>{{payment | getType}}</td>
                </tr>
            <tfoot>
                <tr>
                <td colspan="9">
                    سایت: www.aryatehran.com
                </td>
                </tr>
                <tr>
                <td colspan="9">
                    تلگرام: https://t.me/aryatehran
                </td>
                </tr>
                <tr>
                <td colspan="9">
                    اینستاگرام: @aryatehran_
                </td>
                </tr>
                <tr>
                <th>
                    شماره تماس:
                </th>
                <td>
                    <span class="date">66919633-7</span>
                </td>
                </tr>
            </tfoot>
            </table>
        </div>
</template>
<script>
export default{
    name: "PaymentReceipt",
    props: ['payment'],
    filters: {
        getPrice: function(value){
            var prices =  value.map(function(value,index) { return value.price; });
            return prices.reduce(function(total, num){
                return parseInt(total) + parseInt(num);
            });
        },
        getWays: function(value){
           var ways =  value.map(function(value,index) {
                if(value.chash_way){
                    return value.chash_way.option_value;
                }
            }); 
           return ways.join(' و ');
        },

        getType: function(value){
            var registerPrice = parseInt(value.paymentable.price)
            var tmpPrice = 0;
                value.related.forEach(element => {
                    if(value.paymentable_type == element.paymentable_type){
                        var prices = element.gates.map(value => value.price);
                        tmpPrice += parseInt(prices.reduce((total, num) =>{
                            return parseInt(total) + parseInt(num);
                        }));  
                    }
                    
                });
            var glose = registerPrice - tmpPrice
            if(parseInt(glose) == 0) return 'تسویه';
            return glose + ' تومان';
        }
    }
}
</script>


