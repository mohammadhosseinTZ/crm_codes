<template>
    <div>
        <table class="table">
                <tr>
                    <th>نام سوال</th>
                    <th>تعداد کل امتیازات</th>
                    <th>تعداد کل نظرات</th>
                    <th>میانگین امتیاز برای این سوال</th>
                </tr>
                <tr v-for="data in this.surveys" :key="data.id">
                    <td>{{data.question.option_value}}</td>
                    <td>{{data.total}}</td>
                    <td>{{data.question_count}}</td>
                    <td>{{data.total_rate}}</td>
                </tr>
                <tr>
                    <td><strong>جمع همه</strong></td>
                    <td><strong>{{calc.total}}</strong></td>
                    <td><strong>{{calc.question_count}}</strong></td>
                    <td><strong>{{calc | allRate}}</strong></td>
                </tr>
            </table>
    </div>
</template>
<script>
export default {
    name: "SurveyData",
    props: ['surveys', 'calc'],
    filters:{
        allRate(val){
            return (val.total / val.question_count).toFixed(2)
        }
    },
}
</script>