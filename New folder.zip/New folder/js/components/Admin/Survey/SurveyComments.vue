<template>
    <div class="person-list">      
        <div class="d-flex justify-content-end align-items-center mt-1 mb-1">
            <paginate :paginate="pagination" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date', 'user-search','end-date','course', 'class-course','teacher','is_seen']" :prm="params" :uri="url" @set="setFilter" />      
            <table class="table">
                <tr>
                    <th>اکشن</th>
                    <th>ردیف</th>
                    <th>نام</th>
                    <th>نظر</th>
                    <th>از دوره</th>
                    <th>نام مربی دوره</th>
                    <th>میانگین امتیاز</th>
                    <th>تاریخ</th>
                    <th>اکشن</th>
                    <th>پروفایل</th>
                </tr>
                <tr v-for="(data, index) in this.datas" :key="data.id">
                    <td role="button" v-if="data.is_seen == 0" style="color:red" @click="changeCommentStatus(data.id)">✖</td>
                    <td role="button" v-else style="color:green" @click="changeCommentStatus(data.id)">✔</td>
                    <td>{{index + 1}}</td>
                    <td>{{data.user.name}}</td>
                    <td>{{data.content}}</td>
                    <td>{{data.class_course.course_code}} - {{ data.class_course.course.name }}</td>
                    <td v-if="data.class_course.teacher">{{data.class_course.teacher.name }}</td>
                    <td v-else></td>
                    <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target=".person-survey-modal" @click="getSingleSurvey(data)">{{data.questions.length ? data.questions[0].avg_rate : null}}</button></td>
                    <td>{{data.created_at}}</td>
                    <td class="dropdown">
                        <button class="btn mot-info-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-info-icon"> info </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('delete_survey')" type="button" @click="deleteItem(`/survey/${data.id}`)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.user.id" :userdata="data.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pagination" @changePage="changePage"/>
            <AllPersonDepended />  

            <div class="person-survey">
                <div class="modal fade person-survey-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <SurveyData :surveys="single_datas" :calc="calc" />
                        </div>
                    </div>
                </div>    
            </div>

    </div>
</template>

<script>
import Filters from '../../Section/Filters.vue'
import AllPersonDepended from '../../Person/AllPersonDepended';
import SurveyData from './SurveyData.vue'
export default {
name: "SurveyComment",
    props: ['data'],
    components:{
        Filters,
        AllPersonDepended,
        SurveyData
    },
    data(){
        return{
            url: '/api/v1/survey/comments',
            single_datas: [],
            calc: {
                total: 0,
                question_count: 0,
                total_rate: 0
            }
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        changeCommentStatus(id){
            axios.get(`/api/v1/survey/${id}/changestatus`)
            .then(res => this.datas.find(x => x.id == id).is_seen = res.data.data.is_seen)
        },
        getSingleSurvey(item) {
            this.calc.total = 0
            this.calc.question_count = 0
            this.calc.total_rate = 0

            axios.get(`/api/v1/survey?class-course=${item.class_course.id}&user-search=${item.user.phone}`)
                .then(res => {
                    this.single_datas = res.data.data;
                   
                    for(var data of res.data.data){
                        this.calc.total += parseInt(data.total)
                        this.calc.question_count += parseInt(data.question_count)
                        this.calc.total_rate += parseFloat(data.total_rate)
                    }

                })
        }
    }
}
</script>
