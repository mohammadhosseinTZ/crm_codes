<template>
    <div class="person-list">
        <div class="d-flex justify-content-end align-items-center mt-1 mb-1">
            {{calcTotal}}
            <paginate :paginate="pagination" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date', 'user-search','end-date','course', 'class-course','teacher']" :prm="params" :uri="url" @set="setFilter" />      
            <SurveyData :surveys="datas" :calc="calc" />
            <paginate :paginate="pagination" @changePage="changePage"/>
    </div>
</template>
<script>
import Filters from '../../Section/Filters.vue'
import SurveyData from './SurveyData.vue'
export default {
    name: "Survey",
    props: ['data'],
    components:{
        Filters,
        SurveyData
    },
    computed:{
        calcTotal(){
            if(!this.datas) return;
            for(var data of this.datas){
                this.calc.total += parseInt(data.total)
                this.calc.question_count += parseInt(data.question_count)
                this.calc.total_rate += parseFloat(data.total_rate)
            }
            return;
        }
    },
    data(){
        return{
            url: '/api/v1/survey',
            calc: {
                total: 0,
                question_count: 0,
                total_rate: 0
            }
        }
    },
    filters:{
        allRate(val){
            return (val.total / val.question_count).toFixed(2)
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
         getData(url = false) {
            axios.get(url || this.url)
                .then(res => {
                    this.datas = res.data.data;
                    this.metadata = res.data.metadata
                    res.data.metadata ? this.count = res.data.metadata.count : null
                    this.paginator(res.data.meta, res.data.links)

                    this.calc.total = 0
                    this.calc.question_count = 0
                    this.calc.total_rate = 0

                })
        }
    }
}
</script>
