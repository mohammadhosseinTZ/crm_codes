<template>
    <div class="person-list">      
        <div class="d-flex justify-content-end align-items-center mt-1 mb-1">
            <paginate :paginate="pagination" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date', 'user-search','end-date','course', 'class-course','teacher']" :prm="params" :uri="url" @set="setFilter" />      
            <table class="table">
                <tr>
                    <th>ردیف</th>
                    <th>نام</th>
                    <th>انتقاد/شکایت</th>
                    <th>از دوره</th>
                    <th>تاریخ</th>
                    <th>اکشن</th>
                    <th>پروفایل</th>
                </tr>
                <tr v-for="(data, name) in this.datas" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.user.name}}</td>
                    <td>{{data.content}}</td>
                    <td>{{data.class_course.course_code}}  - {{ data.class_course.course.name }}</td>
                    <td>{{data.created_at}}</td>
                    <td class="dropdown">
                        <button class="btn mot-info-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-info-icon"> info </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('delete_complaint')" type="button" @click="deleteItem(`/complaint/${data.id}`)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.user.id" :userdata="data.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pagination" @changePage="changePage"/>
            <AllPersonDepended />  
    </div>
</template>

<script>
import Filters from '../Section/Filters.vue'
import AllPersonDepended from '../Person/AllPersonDepended';
export default {
name: "Complaint",
    props: ['data'],
    components:{
        Filters,
        AllPersonDepended
    },
    data(){
        return{
            url: '/api/v1/complaint',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    }
}
</script>
