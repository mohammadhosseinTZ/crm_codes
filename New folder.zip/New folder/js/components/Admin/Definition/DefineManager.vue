<template>
<div class="mot-define-manager">
        <div class="row align-items-center">
        <div id="accordion" class="col-md-12">
            <div class="card">
                <div class="card-header p-0" id="headingOne">
                <h5 class="mb-0 d-flex justify-content-between">
                    <button class="btn collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                        <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                    </button>
                </h5>
                </div>

                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <form @submit.stop.prevent="addData">
                            <div class="row mot-modal-inputs align-items-end">
                                <div class="form-group w-100 mb-1 mot-input-md">
                                    <label for="option-type">نوع مقدار</label>
                                    <v-select id="option-type" @input="isRole" v-model="option.option_key" :options="optionTypes" />
                                </div>
                                <div class="form-group w-100 mb-1">
                                    <label for="option-val">مقدار</label>
                                <input id="option-val" type="text" class="form-control" v-model="option.option_value">
                                </div>

                                <div class="form-group">
                                    <button class="btn btn-primary">ارسال</button>
                                </div>
                            </div>
                            <div class="row" v-if="option.is_role">
                                <div class="form-group col-md-12">
                                     <label for="option-permission">نوع دسترسی</label>
                                    <v-select :getOptionLabel="x => x.label_value" id="option-permission" multiple v-model="option.permissions" :options="permissions" />
                                </div>
                            </div>
                            <div class="row mot-modal-inputs mot-input-md" v-if="option.is_discount_for">
                                <div class="form-group">
                                     <label>درصد تخفیف</label>
                                     <input type="number" max="100" class="form-control" v-model="option.discount_percent">
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-9 form-group mb-1 mt-3 mot-define-manager-filter">
                <label for="option-type-filter">نوع مقدار</label>
                <v-select multiple id="option-type-filter" @input="setFilter" v-model="optionsType" :options="optionTypes" />
        </div> 
        <div class="col-md-3 d-flex justify-content-end my-2 my-md-0">
            <paginate :paginate="pagination" @changePage="changePage"/>
            </div>
        </div>

        
        <table class="table">
            <tr>
                <th>نام</th>
                <th>مقدار</th>
                <th>دسترسی ها</th>
                <th>اکشن</th>
            </tr>
            <tr v-for="data in this.datas" :key="data.id">
                <td>{{locate(data.option_key)}}</td>
                <td>{{data.option_value}}</td>
                <td><span v-if="data.permissions">{{data.permissions | getPermision}}</span></td>
                <td class="dropdown">
                    <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <button type="button" class="btn btn-primary" @click="setUpdate(data.id)">ویرایش</button>       
                    </div>
                </td>
            </tr>
            </table>
            <paginate :paginate="pagination" @changePage="changePage"/>
</div>
   
</template>

<script>
export default {
    name: "DefineManager",
    props: ['data'],
    data(){
        return{
            url: "/api/v1/option",
            optionsType: [],
            optionTypes: window.optionTypes,
            permissions: window.allPermissions,
            option:{
                option_key: null,
                option_value: null,
                permissions: [],
                discount_percent: null,
                insideId: null,
                insideType: 'insert',
                is_role: false,
                is_discount_for: false,
                is_category: false,
            }

        }
    },
    filters:{
        getPermision(data){
            let permissions = []
            data.map(x => permissions.push(x.label_value))
            return permissions.join(' و ')
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
        setFilter(){
            let ids = [];
            this.optionsType.map(x => ids.push(x.option_key))
            this.setUrlParam('option-types', ids)
            this.applyUrl()
        },
        setUpdate(id){
            let data = this.datas.find(x => x.id == id)      
            this.option.insideId = data.id
            this.option.insideType = 'update'
            this.option.option_value = data.option_value
            this.option.permissions = data.permissions.map(x => {
                x.label = x.option_value
                return x
            })
            this.option.option_key = this.optionTypes.find(x => x.option_key == data.option_key)
            this.option.is_role = data.option_key == 'role' ? true : false
            this.option.is_category = data.option_key == 'category' ? true : false
            this.option.is_discount_for = data.option_key == 'discount_for' ? true : false
            this.option.discount_percent = data.discount_percent
        },
        isRole(){
            this.option.is_role = this.option.option_key.option_key == 'role' ? true : false
            this.option.is_category = this.option.option_key.option_key == 'category' ? true : false
            this.option.is_discount_for = this.option.option_key.option_key == 'discount_for' ? true : false
        },
        addData(){
            axios.post(this.url, this.option)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                
                this.option.insideId = null
                this.option.insideType = 'insert'
                this.option.option_value = null
                this.option.permissions = []
                this.option.is_category = null
                this.option.option_key = null
                this.option.is_role = false
                this.option.is_discount_for = null
                this.option.discount_percent = null

                if(this.datas.find(x => x.id == res.data.data.id)) return;
                
                this.datas.push(res.data.data)

                if(res.data.data.option_key == 'acquaintance'){
                    window.acquaintances.push(res.data.data)
                }

                if(res.data.data.option_key == 'bank'){
                    window.banks.push(res.data.data)
                }

                if(res.data.data.option_key == 'category'){
                    window.categories.push(res.data.data)
                }

                if(res.data.data.option_key == 'cost'){
                    window.categories.push(res.data.data)
                }

                if(res.data.data.option_key == 'discipline'){
                    window.disciplines.push(res.data.data)
                }

                if(res.data.data.option_key == 'discount_for'){
                    window.discountFor.push(res.data.data)
                }

                if(res.data.data.option_key == 'evidence'){
                    window.evidences.push(res.data.data)
                }

                if(res.data.data.option_key == 'job'){
                    window.jobs.push(res.data.data)
                }

                if(res.data.data.option_key == 'leave_reason'){
                    window.leaveReasons.push(res.data.data)
                }

                if(res.data.data.option_key == 'payment_gates'){
                    window.gateWays.push(res.data.data)
                }

                if(res.data.data.option_key == 'permission'){
                    window.allPermissions.push(res.data.data)
                }

                if(res.data.data.option_key == 'place'){
                    window.places.push(res.data.data)
                }

                if(res.data.data.option_key == 'reason'){
                    window.reasons.push(res.data.data) 
                }

                if(res.data.data.option_key == 'role'){
                    window.roles.push(res.data.data) 
                }

                if(res.data.data.option_key == 'status'){
                    window.statuses.push(res.data.data) 
                }


                
            })
        }
    }

}
</script>
