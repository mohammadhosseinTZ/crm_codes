<template>
        <div class="branch-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation d-flex align-items-center">
                <button v-if="can('add_branch')" type="button" class="btn" data-toggle="modal" data-target=".add-branch-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
            </div>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>
            <table class="table">
                <tr>
                    <th>ردیف</th>
                    <th>نام</th>
                    <th>کد شعبه</th>
                    <th>آدرس</th>
                    <th>کد پستی</th>
                    <th>تلفن</th>
                    <th>آدرس سایت</th>
                    <th>کاربر اتوماتیک</th>
                    <th>مدیر شعبه</th>
                    <th>اینستاگرام</th>
                    <th>تلگرام</th>
                    <th>اکشن</th>
                </tr>
                <tr v-for="(data, name) in branches" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.name}}</td>
                    <td>{{data.en_sign}}</td>
                    <td>{{data.address}}</td>
                    <td>{{data.postal_code}}</td>
                    <td>{{data.phone}}</td>
                    <td>
                        <a v-if="data.market_url" target="_blank" :href="data.market_url">{{data.market_url}}</a>
                    </td>
                    <td><span v-if="data.market_user">{{ data.market_user.name }}</span></td>
                    <td><span v-if="data.manager">{{ data.manager.name }}</span></td>
                    <td>{{ data.insta }}</td>
                    <td>{{ data.telegram }}</td>
                    <td class="dropdown">
                        <button class="btn mot-info-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_branch')" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-branch-modal" @click="edit({id: data.id, data: data })">ویرایش</button>
                                <div class="delete-form mt-2 text-start" v-if="can('delete_branch')">
                                    <v-select placeholder="انتقال اطلاعات به ..."  v-model="replace" :options="branches" />
                                    <button v-if="can('delete_branch')" type="button" @click="deleteItem(`/branch/${data.id}?branch_id=${replace ? replace.id : null}`, data.id, deleteBranch); replace = null" class="btn btn-danger mt-1 mb-1">حذف</button>
                                </div>         
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            <AddBranch />
    </div>
</template>

<script>
import AddBranch from './../../Actions/AddBranch.vue'
import { mapGetters,mapActions } from 'vuex'
export default {
    name: 'Branch',
    props: ['data'],
    components:{
        AddBranch
    },
    computed: {
        ...mapGetters({
            branches: 'Branch/datas',
            counts: 'Branch/count',
            pg: 'Branch/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/branch',
            replace: null,
        }
    },
    mounted(){
        if(!this.data){ this.getDatas()} else{ this.datas = this.data}
    },
    methods: {
        ...mapActions({
            add: 'Branch/add',
            edit: 'Branch/edit',
            get: 'Branch/get',
            deleteBranch: 'Branch/delete',
        }),
        getDatas(url = false) {
            this.get({data: url || this.url})
        },
    }
}
</script>