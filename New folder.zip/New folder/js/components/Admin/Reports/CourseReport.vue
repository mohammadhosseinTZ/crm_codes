<template>
    <div class="card">
        <div class="card-header">   
            <div class="d-flex align-items-center justify-content-between">
                <div>گزارش بر اساس دوره ها</div>
                <button @click="getreport" class="btn btn-primary">نمایش گزارش این بخش</button>
            </div>
        </div>
        <div class="form-group">
            <input class="form-control" placeholder="جستجوی دوره" v-model="filter.course.value"/>
        </div>
        <v-table v-if="datas" 
        :currentPage.sync="currentPage"
        :pageSize="20"
        @totalPagesChanged="totalPages = $event" class="table table-bordered nav-tabs" id="myTab3" role="tablist" :data="datas.courseReport" :filter="filter">
            <thead slot="head">
                <v-th sortKey="name">نام</v-th>
                <v-th sortKey="calls">تعداد تماس</v-th>
                <v-th sortKey="registers">تعداد ثبت نام</v-th>  
                <v-th sortKey="registerLeaves">تعداد کنسلی ثبت نام</v-th>  
                <v-th sortKey="callLeaves">تعداد انصراف از تماس</v-th> 
                <v-th sortKey="callToRegisterPercent">تماس به ثبت نام</v-th>
                <v-th sortKey="callToLeavePercent">انصراف به تماس</v-th>
                <v-th sortKey="cancelToRegisterPercent">کنسل به ثبت نام</v-th>
                <v-th sortKey="callPriceSet">درامد از تماس</v-th>
                <v-th sortKey="registerPriceSet">درامد از ثبت نام</v-th>
                <v-th sortKey="male">آقا</v-th>
                <v-th sortKey="female">خانم</v-th>
                
            </thead>
            <tbody slot="body" slot-scope="{displayData}">
                <tr v-for="course in displayData" :key="course.id">
                    <td>{{course.name}}</td>
                    <td>{{course.calls}}</td>
                    <td>{{course.registers}}</td>
                    <td>{{course.registerLeaves}}</td>
                    <td>{{course.callLeaves}}</td>
                    <td>{{getPercent(course.registers, course.calls, course, 'callToRegisterPercent')}}</td>
                    <td>{{getPercent(course.callLeaves, course.calls, course, 'callToLeavePercent')}}</td>
                    <td>{{getPercent(course.registerLeaves, course.registers, course, 'cancelToRegisterPercent')}}</td>
                    <td>{{setProp((course.callPrice ? course.callPrice.price : 0), course, 'callPriceSet') | format}}</td>
                    <td>{{setProp((course.registerPrice ? course.registerPrice.price : 0), course, 'registerPriceSet') | format}}</td>
                    <td>{{course.male}}</td>
                    <td>{{course.female}}</td>
                </tr>
            </tbody>
        </v-table>
        <smart-pagination
        :currentPage.sync="currentPage"
        :totalPages="totalPages"
      />
    </div>
</template>

<script>

export default {
    props: ['reportdate', 'report_branches'],
    methods:{
        setProp(data, item, prop){
            item[prop] = data
            return data
        },
        getreport(){
            if(this.reportdate) this.setUrlParam('date', this.reportdate)
            if(this.report_branches) this.setUrlParam('branches', this.report_branches.map(x => x.id).join(','))
            this.setUrlParam('reports', 'courseReport')
            this.applyUrl()
        }
    },
    data(){
        return{
            filter:{
                course: { value: '', keys: ['name'] }
            },
            currentPage: 1,
            totalPages: 0,
            url:"/api/v1/admin/report"
        }
    }
}
</script>
