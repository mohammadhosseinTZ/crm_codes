<template>
    <div class="card">
        <div class="card-header">
           <div class="d-flex align-items-center justify-content-between">
                <div>گزارش پیشخوان</div>
                <button @click="getreport" class="btn btn-primary">نمایش گزارش این بخش</button>
            </div>
        </div>
         <ul v-if="datas" class="nav nav-tabs p-0 mt-3" id="myTab4" role="tablist">
            <li v-for="expert in datas.expertReport" :key="expert.id" class="nav-item" role="presentation">
                <a class="nav-link" :id="`#expert-tab${expert.id}`" data-toggle="tab" :href="`#expert${expert.id}`" role="tab" >{{expert.name}}</a>
            </li>
        </ul>
        <div  v-if="datas" class="tab-content border border-1 border-top-0" id="myTabContent4">
            <div v-for="expert in datas.expertReport" :key="expert.id" class="tab-pane fade" :id="`expert${expert.id}`" role="tabpanel">
                 <table class="table table-bordered">
                            <tr>
                                <th>نام</th>
                                <th>تماس ها</th>
                                <th>ثبت نام ها</th>
                                <th>کنسل ثبت نام</th>
                                <th>انصراف تماس</th>
                                <th>نسبت تماس به ثبت نام</th>
                                <th>هزینه تماس های از دست رفته</th>
                                <th>هزینه کل تماس ها</th>
                                <th>هزینه های کنسلی</th>
                                <th>دارمد از ثبت نام</th>
                                <th>هزینه فیش ها</th>
                            </tr>
                            <tr v-for="opt in expert.byCat" :key="opt.id">
                                <td>{{opt.name}}</td>
                                <td>{{opt.calls}}</td>
                                <td>{{opt.registers}}</td>
                                <td>{{opt.registerLeaves}}</td>
                                <td>{{opt.callLeaves}}</td>
                                <td>{{getPercent(opt.registers,opt.calls, opt, 'callToRegisterPercent' )}}</td>
                                <td>{{(opt.callLeavesPrice ? opt.callLeavesPrice.price : 0) | format}}</td>
                                <td>{{(opt.callsPrice ? opt.callsPrice.price : 0) | format}}</td>
                                <td>{{(opt.registerLeavesPrice ? opt.registerLeavesPrice.price : 0) | format}}</td>
                                <td>{{(opt.registerPrice ? opt.registerPrice.price : 0) | format}}</td>
                                <td>{{(opt.expertPayment ? opt.expertPayment.price : 0) | format}}</td>
                            </tr>
                            <tr>
                                <td>جمع همه</td>
                                <td>{{sumField(expert.byCat, 'calls')}}</td>
                                <td>{{sumField(expert.byCat, 'registers')}}</td>
                                <td>{{sumField(expert.byCat, 'registerLeaves')}}</td>
                                <td>{{sumField(expert.byCat, 'callLeaves')}}</td>
                                <td></td>
                                <td>{{sumField(expert.byCat, 'callLeavesPrice', 'price') | format}}</td>
                                <td>{{sumField(expert.byCat, 'callsPrice', 'price') | format}}</td>
                                <td>{{sumField(expert.byCat, 'registerLeavesPrice', 'price') | format}}</td>
                                <td>{{sumField(expert.byCat, 'registerPrice', 'price') | format}}</td>
                                <td>{{sumField(expert.byCat, 'expertPayment', 'price') | format}}</td>

                            </tr>
                        </table>
                <!-- <ul class="nav nav-tabs p-0 mt-3" id="expertreport" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a :href="`#expert-course-${expert.id}`" class="nav-link" data-toggle="tab" role="tab">بر اساس دوره</a>
                    </li>
                    <li class="nav-item" role="presentation">
                        <a :href="`#expert-cat-${expert.id}`" class="nav-link" data-toggle="tab" role="tab">بر اساس دسته بندی</a>
                    </li>
                </ul>
                <div class="tab-content border border-1 border-top-0" id="catereortpanel">
                    <div class="tab-pane fade p-3" :id="`expert-course-${expert.id}`" role="tabpanel">
                       <table class="table table-bordered">
                           <tr>
                               <th>نام</th>
                               <th>تماس ها</th>
                               <th>ثبت نام ها</th>
                               <th>کنسل ثبت نام</th>
                               <th>انصراف تماس</th>
                           </tr>
                           <tr v-for="course in expert.byCourse" :key="course.id">
                               <td>{{course.name}}</td>
                               <td>{{course.calls}}</td>
                               <td>{{course.registers}}</td>
                               <td>{{course.registerLeaves}}</td>
                               <td>{{course.callLeaves}}</td>
                           </tr>
                       </table>
                    </div>
                    <div class="tab-pane fade p-3" :id="`expert-cat-${expert.id}`" role="tabpanel">
                            <table class="table table-bordered">
                            <tr>
                                <th>نام</th>
                                <th>تماس ها</th>
                                <th>ثبت نام ها</th>
                                <th>کنسل ثبت نام</th>
                                <th>انصراف تماس</th>
                                <th>نسبت تماس به ثبت نام</th>
                                <th>هزینه تماس های از دست رفته</th>
                                <th>هزینه کل تماس ها</th>
                            </tr>
                            <tr v-for="opt in expert.byCat" :key="opt.id">
                                <td>{{opt.option_value}}</td>
                                <td>{{opt.calls}}</td>
                                <td>{{opt.registers}}</td>
                                <td>{{opt.registerLeaves}}</td>
                                <td>{{opt.callLeaves}}</td>
                                <td>{{((opt.registers * 100) / opt.calls) && ((opt.registers * 100) / opt.calls) != Infinity ? (opt.registers * 100) / opt.calls : null}}</td>
                                <td>{{opt.callLeavesPrice ? opt.callLeavesPrice.price : 0}}</td>
                                <td>{{opt.callsPrice ? opt.callsPrice.price : 0}}</td>
                            </tr>
                        </table>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['reportdate', 'report_branches'],
     data(){
        return{
            url:"/api/v1/admin/report"
        }
    },
    methods:{
        getreport(){
            if(this.reportdate) this.setUrlParam('date', this.reportdate)
            if(this.report_branches) this.setUrlParam('branches', this.report_branches.map(x => x.id).join(','))
            this.setUrlParam('reports', 'expertReport')
            this.applyUrl()
        },
        sumField(obj, key1, key2 = null) {
            // sum data in give key (property)
            if(key1 && key2){
                return obj.reduce((a, b) => a + (b[key1] ? +b[key1].price : 0) , 0)
            }
            return obj.reduce((a, b) => a + (b[key1] || 0), 0)
        }
    }
}
</script>
