<template>
    <div class="card">
        <div class="card-header">
            <div class="d-flex align-items-center justify-content-between">
                <div>گزارش بر اساس دسته ها</div>
                <button @click="getreport" class="btn btn-primary">نمایش گزارش این بخش</button>
            </div>
        </div>
         <ul v-if="datas" class="nav nav-tabs p-0 mt-3" id="myTab2" role="tablist">
            <li v-for="cat in datas.categoriesReport" :key="cat.id" class="nav-item" role="presentation">
                <a class="nav-link" :id="`#cat-tab${cat.id}`" data-toggle="tab" :href="`#cat${cat.id}`" role="tab" :aria-controls="`#cat${cat.id}`" aria-selected="true">{{cat.name}}</a>
            </li>
        </ul>
        <div v-if="datas" class="tab-content border border-1 border-top-0" id="myTabContent2">
            <div v-for="cat in datas.categoriesReport" :key="cat.id" class="tab-pane fade" :id="`cat${cat.id}`" role="tabpanel" :aria-labelledby="`#cat${cat.id}`">

              <div class="form-group">
                <input class="form-control" placeholder="جستجوی دوره" v-model="filter.course.value"/>
            </div>
            <v-table class="table table-bordered" :currentPage.sync="currentPage"
        :pageSize="20" :data="cat.reports" 
        @totalPagesChanged="totalPages = $event"
         :filter="filter">
                <thead slot="head">
                    <v-th sortKey="name">نام دوره</v-th>
                    <v-th sortKey="calls">تعداد تماس</v-th>
                    <v-th sortKey="registers">تعداد ثبت نام</v-th>
                    <v-th sortKey="callLeaves">تعداد انصراف تماس</v-th>
                    <v-th sortKey="registerLeaves">تعداد کنسلی ثبت نام</v-th>
                    <v-th sortKey="callToRegisterPercent">درصد ثبت نام</v-th>
                    <v-th sortKey="callToLeavePercent">درسد انصراف</v-th>
                    <v-th sortKey="cancelToRegisterPercent">درصد کنسلی</v-th>
                </thead>
                <tbody slot="body" slot-scope="{displayData}">
                    <tr v-for="course in displayData" :key="course.id">
                        <td>{{course.name}}</td>
                        <td>{{course.calls}}</td>
                        <td>{{course.registers}}</td>
                        <td>{{course.callLeaves}}</td>
                        <td>{{course.registerLeaves}}</td>
                        <td>{{getPercent(course.registers, course.calls, course, 'callToRegisterPercent')}}</td>
                        <td>{{getPercent(course.callLeaves, course.calls, course, 'callToLeavePercent')}}</td>
                        <td>{{getPercent(course.registerLeaves, course.registers, course, 'cancelToRegisterPercent')}}</td>
                    </tr>
                </tbody>
            </v-table>
            <smart-pagination
                    :currentPage.sync="currentPage"
                    :totalPages="totalPages"
                />

            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['reportdate', 'report_branches'],
    data(){
        return{
            filter:{
                course: { value: '', keys: ['name'] }
            },
            currentPage: 1,
            totalPages: 0,
            url:"/api/v1/admin/report"
        }
    },
    methods:{
        getreport(){
            if(this.reportdate) this.setUrlParam('date', this.reportdate)
            if(this.report_branches) this.setUrlParam('branches', this.report_branches.map(x => x.id).join(','))
            this.setUrlParam('reports', 'categoriesReport')
            this.applyUrl()
        }
    }
}
</script>
