<template>
    <div>
        <ul class="nav nav-tabs p-0" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">دسته بندی</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">شیوه آشنایی</a>
            </li>
        </ul>
        <div class="tab-content border border-1 border-top-0" id="myTabContent">
            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                <CategoryChart />
            </div>
            <div class="tab-pane fade border" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                <Acquisition />
            </div>
        </div>
    </div>
</template>

<script>
import CategoryChart from "./CategoryChart.vue";
import Acquisition  from "./Acquisition.vue";
export default {
    components:{
        Acquisition,
        CategoryChart
    }
}
</script>
