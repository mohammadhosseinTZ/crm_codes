<template>
    <div>
      {{config}}
        <div id="catchart">
                <apexchart type="bar" :key="key" height="350" :options="chartOptions" :series="series"></apexchart>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapActions  } from 'vuex';
export default {
    components: {
 
    },
    computed: {
        ...mapGetters({
            reports: 'Report/datas',
        }),
        config(){
          if(!this.reports.categoryChart) return
          // set names
          this.chartOptions.xaxis.categories = []
          this.series = []

          this.reports.categoryChart.map(x => this.chartOptions.xaxis.categories.push(x.name))
          
          let calls = {
            name:"تماس ها",
            data: []
          }, registers = {
            name:"ثبت نام ها",
            data: []
          }, leaveRegisters = {
            name:"کنسل ها",
            data: []
          }, leaveCalls = {
            name:"انصراف ها",
            data: []
          }, pursuitCalls = {
            name:"پیگیری ها",
            data: []
          }
          this.reports.categoryChart.forEach(el => {
              calls.data.push(el.calls)
              registers.data.push(el.registers)
              leaveRegisters.data.push(el.registerLeaves)
              leaveCalls.data.push(el.callLeaves)
              pursuitCalls.data.push(el.pursuitCalls)
          });

          this.series.push(calls)
          this.series.push(registers)
          this.series.push(leaveRegisters)
          this.series.push(leaveCalls)
          this.series.push(pursuitCalls)

          
          this.key++
          return
        }
    },
    data(){
        return{
          key:0,
             series: [],
          chartOptions: {
            chart: {
              type: 'bar',
              height: 350
            },
            plotOptions: {
              bar: {
                horizontal: false,
                columnWidth: '55%',
                borderRadius: 10,
                endingShape: 'rounded'
              },
            },
            dataLabels: {
              enabled: false
            },
            stroke: {
              show: true,
              width: 2,
              colors: ['transparent']
            },
            xaxis: {
              categories: [],
            },
    
          }
        }
    }
    
}
</script>
