<template>
    <div>
      {{config}}
        <div id="coursechart">
                <apexchart type="bar" :key="key" height="350" :options="chartOptions" :series="series"></apexchart>
        </div>
        <div class="limited-hight">
            <table v-if="this.reports.acquisition" class="table table-bordered">
              <tr>
                  <th>عبارت جستجو</th>
                  <th>تعداد</th>
              </tr>
              <tr v-for="param in this.reports.acquisition.search_params">
                  <td>{{param.param}}</td>
                  <td>{{param.total}}</td>
              </tr>

          </table>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapActions  } from 'vuex';
export default {
    computed: {
        ...mapGetters({
            reports: 'Report/datas',
        }),
        config(){
          if(!this.reports.acquisition) return
          // set names
          this.chartOptions.xaxis.categories = this.reports.acquisition.register.map(x => x.label + " - " + x.total)
          this.series = [{
            name: "شیوه آشنایی ثبت نامی ها",
              data: this.reports.acquisition.register.map(x => x.total)
          },{
            name: "شیوه آشنایی  تماس ها",
              data: this.reports.acquisition.calls.map(x => x.total)
          }]
          this.key++
          return
        }
    },
    data(){
        return{
          key:0,
             series: [],
          chartOptions: {
            chart: {
              type: 'bar',
              height: 350
            },
            dataLabels: {
              enabled: false
            },
            xaxis: {
              categories: [],
            },
            plotOptions: {
            bar: {
              borderRadius: 10,
              dataLabels: {
                position: 'top', // top, center, bottom
              },
            }
          },
    
          }
        }
    }
    
}
</script>
<style>
.limited-hight{
  max-height: 300px;
  overflow-y: auto;
}
</style>