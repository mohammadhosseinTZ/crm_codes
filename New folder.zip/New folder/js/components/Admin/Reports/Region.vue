<template>
    <div class="card">
        <div class="card-header">
            <div class="d-flex align-items-center justify-content-between">
                <div>گزارش مناطق</div>
                <button  @click="getreport" class="btn btn-primary">نمایش گزارش این بخش</button>
            </div>
        </div>
         <!-- <ul v-if="reports.coursesRegions" class="minlv nav nav-tabs p-0 mt-3" id="weekdaystab" role="tablist">
            <li v-for="course in reports.coursesRegions.courses" :key="course.id" class="nav-item"  role="presentation">
                <a class="nav-link" data-toggle="tab" :href="`#course-region-tab${course.id}`" role="tab" >{{course.name}}</a>
            </li>
        </ul>
        <div v-if="reports.coursesRegions" class="tab-content border border-1 border-top-0" id="weekdaystabpanel">
            <div v-for="course in reports.coursesRegions.courses" :key="course.id" class="tab-pane fade" :id="`course-region-tab${course.id}`" role="tabpanel">
                <v-table class="table table-bordered" :data="course.regions" >
                    <thead slot="head">
                        <v-th sortKey="meta_value">منطقه</v-th>
                        <v-th sortKey="total">تعداد ثبت نام</v-th>
                    </thead>
                    <tbody slot="body" slot-scope="{displayData}">
                        <tr v-for="(region, name) in displayData" :key="name">
                        <td>{{region.meta_value}}</td>
                        <td>{{region.total}}</td>
                    </tr>
                    </tbody>
                </v-table>
            </div>
        </div> -->


        <ul v-if="datas" class="nav nav-tabs p-0 mt-3" id="weekdaystab" role="tablist">
            <li v-for="course in datas.coursesRegions.options" :key="course.id" class="nav-item"  role="presentation">
                <a class="nav-link" data-toggle="tab" :href="`#cat-region-tab${course.id}`" role="tab" >{{course.name}}</a>
            </li>
        </ul>
        <div v-if="datas" class="tab-content border border-1 border-top-0" id="weekdaystabpanel">
            <div v-for="course in datas.coursesRegions.options" :key="course.id" class="tab-pane fade" :id="`cat-region-tab${course.id}`" role="tabpanel">
                <v-table class="table table-bordered" :data="course.regions" >
                    <thead slot="head">
                        <v-th sortKey="meta_value">منطقه</v-th>
                        <v-th sortKey="total">تعداد ثبت نام</v-th>
                    </thead>
                    <tbody slot="body" slot-scope="{displayData}">
                        <tr v-for="(region, name) in displayData" :key="name">
                        <td>{{region.meta_value}}</td>
                        <td>{{region.total}}</td>
                    </tr>
                    </tbody>
                </v-table>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['reportdate', 'report_branches'],
     data(){
        return{
            url:"/api/v1/admin/report"
        }
    },
    methods:{
        getreport(){
            if(this.reportdate) this.setUrlParam('date', this.reportdate)
            if(this.report_branches) this.setUrlParam('branches', this.report_branches.map(x => x.id).join(','))
            this.setUrlParam('reports', 'coursesRegions')
            this.applyUrl()
        }
    }
}
</script>
