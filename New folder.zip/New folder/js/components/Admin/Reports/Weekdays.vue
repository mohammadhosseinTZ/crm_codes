<template>
    <div class="card">
        <div class="card-header">
           <div class="d-flex align-items-center justify-content-between">
                <div>گزارش روز های هفته</div>
                <button @click="getreport" class="btn btn-primary">نمایش گزارش این بخش</button>
            </div>
        </div>
         <ul v-if="datas" class="nav nav-tabs p-0 mt-3" id="weekdaystab" role="tablist">
            <li v-for="(weekday, name) in datas.weekdays" :key="name" class="nav-item"  role="presentation">
                <a class="nav-link" data-toggle="tab" :href="`#weekday-opt-tab${name}`" v-if="name != 'options'" role="tab" >{{locate(name)}}</a>
            </li>
        </ul>
        <div  v-if="datas" class="tab-content border border-1 border-top-0" id="weekdaystabpanel">
            <div v-for="(weekday, name) in datas.weekdays" :key="name" class="tab-pane fade" :id="`weekday-opt-tab${name}`" role="tabpanel">
               <div v-if="name != 'options'">
                   <v-table class="table table-bordered" :data="weekday" >
                    <thead slot="head">
                        <v-th sortKey="weekday">روز</v-th>
                        <v-th sortKey="total">تعداد</v-th>
                    </thead>
                    <tbody slot="body" slot-scope="{displayData}">
                        <tr v-for="(day, name) in displayData" :key="name">
                        <td>{{locate(day.weekday)}}</td>
                        <td>{{day.total}}</td>
                    </tr>
                    </tbody>
                </v-table>

               </div>
            </div>
        </div>
    </div>
</template>

<script>

export default {
    props: ['reportdate', 'report_branches'],
     data(){
        return{
            url:"/api/v1/admin/report"
        }
    },
    methods:{
        getreport(){
            if(this.reportdate) this.setUrlParam('date', this.reportdate)
            if(this.report_branches) this.setUrlParam('branches', this.report_branches.map(x => x.id).join(','))
            this.setUrlParam('reports', 'weekdays')
            this.applyUrl()
        }
    }
}
</script>
