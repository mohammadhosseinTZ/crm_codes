<template>
    <div class="reports">
        <div class="row  mot-modal-inputs justify-content-start px-3 px-3">
            <div class="form-group my-2">
                    <date-picker @change="changeDate" v-model="date" range clearable format="YYYY-MM-DD" display-format="jMMMM jD" placeholder="انتخاب تاریخ" />   
            </div>
            <div class="form-group my-2 mot-input-md">
                    <v-select id="date" placeholder="تاریخ های پیش فرض" @input="getDefultDate" v-model="defaultFormat" :options="[{label: 'هفته', value: 7},{label: 'ماه', value: 30},{label: 'سه ماه', value: 90 },{label: 'شش ماه', value: 180},{label: 'سال', value: 365}]" />
            </div>
            <div class="form-group my-2 mot-input-md">
                    <v-select id="branch-filter" placeholder="شعبه" multiple @input="changeBranch" v-model="report_branches" :options="branches" />
            </div>
            
        </div>
        <Statistics class="mt-2" :reportdate="reportdate" />
        <div class="row mt-2">
            <div class="col">
                <ChartTab />
            </div>
        </div>
        <div :key="changedatekey">
             <div class="row mt-3 mot-report-header">
                <div class="col p-0">
                    <CategoriesReport :reportdate="reportdate" :report_branches="report_branches" />
                </div>
            </div>
            <div class="row mt-3 mot-report-header" id="mot-report-row-two" >
                <div class="col p-0">
                    <CourseReport :reportdate="reportdate" :report_branches="report_branches" />
                </div>
            </div>
            <div class="row mt-3 mot-report-header">
                <div class="col p-0">
                    <ExpertReport :reportdate="reportdate" :report_branches="report_branches" />
                </div>
            </div>
            <div class="row mt-3 mot-report-header">
                <div class="col p-0">
                    <Weekdays :reportdate="reportdate" :report_branches="report_branches" />
                </div>
            </div>
            <div class="row mt-3 mot-report-header">
                <div class="col p-0">
                    <Cities :reportdate="reportdate" :report_branches="report_branches" />
                </div>
            </div>
            <div class="row mt-3 mot-report-header">
                <div class="col p-0">
                    <Region :reportdate="reportdate" :report_branches="report_branches" />
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import ChartTab from "./Charts/ChartTab.vue";
import { mapGetters, mapActions  } from 'vuex';
import CategoriesReport from './CategoriesReport.vue'
import CourseReport from './CourseReport.vue'
import ExpertReport from './ExpertReport.vue'
import Weekdays from './Weekdays.vue'
import Cities from './Cities.vue'
import Region from './Region.vue'
import Statistics from './Statistics.vue'
import moment from 'moment'
export default {
    props: ['data'],
    components: {
        ChartTab,
        CategoriesReport,
        CourseReport,
        ExpertReport,
        Weekdays,
        Cities,
        Region,
        Statistics
    },
    data(){
        return{
            url:"/api/v1/admin/report",
            date: null,
            defaultFormat: null,
            changedatekey: 1,
            reportdate: null,
            report_branches: [],
            branches: window.branches
        }
    },
    mounted(){
        this.setUrlParam('reports', 'allcount,categoryChart,acquisition')
        this.applyUrl()
    },
    methods: {
        ...mapActions({
            get: 'Report/get',
        }),
        getData(url){
            this.get({date: url || this.url})
        },
        changeDate(){
            this.setUrlParam('date', this.date.join(','))
            this.applyUrl()
            this.reportdate = this.date.join(',')
            this.changedatekey++
        },
        changeBranch(){
            this.setUrlParam('branches', this.report_branches.map(x => x.id).join(','))
            this.applyUrl()
            this.changedatekey++
        },
        getDefultDate(){
            if(!this.defaultFormat) return;
            let start = [
                moment(new Date()).subtract(this.defaultFormat.value, 'd').format('YYYY-MM-DD 00:00:00'), 
                moment(new Date()).format('YYYY-MM-DD 23:59:59'),
            ]

            this.reportdate = start.join(',')

            this.setUrlParam('date', start.join(','))
            this.applyUrl()
            this.changedatekey++
        }
    }
}
</script>
