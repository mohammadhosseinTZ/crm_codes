<template>
    <div class="row mot-report-colored" v-if="reports.allcount">
            <div class="col-6 mb-1 col-md">
                <div class="card text-white bg-primary">
                    <div class="card-header text-center">تعداد تماس های ثبت شده</div>
                    <div class="card-body">
                        <p v-if="reportdate">در بازه انتخاب شده: {{reports.allcount.date.calls}}</p>
                        <p v-else>در تمام زمان ها: {{reports.allcount.all.calls}}</p>
                    </div>
                </div>
            </div>
            <div class="col-6 mb-1 col-md">
                <div class="card text-white bg-secondary">
                    <div class="card-header text-center">تعداد پیگیری های انجام شده</div>
                    <div class="card-body">
                        <p v-if="reportdate">در بازه انتخاب شده : {{reports.allcount.date.pursuit}}</p>
                        <p v-else>در تمام زمان ها: {{reports.allcount.all.pursuit}}</p>
                    </div>
                </div>
            </div>
            <div class="col-6 mb-1 col-md">
                <div class="card text-white bg-danger">
                    <div class="card-header text-center">مجموع ثبت نام شدگان</div>
                    <div class="card-body">
                        <p v-if="reportdate">در بازه انتخاب شده : {{reports.allcount.date.registers}}</p>
                        <p v-else>در تمام زمان ها: {{reports.allcount.all.registers}}</p>
                    </div>
                </div>
            </div>
            <div class="col-6 mb-1 col-md">
                <div class="card text-white bg-warning">
                    <div class="card-header text-center">مجموع کنسلی دوره ها</div>
                    <div class="card-body">
                        <p v-if="reportdate">در بازه انتخاب شده : {{reports.allcount.date.callLeaves}}</p>
                        <p v-else>در تمام زمان ها: {{reports.allcount.all.callLeaves}}</p>
                    </div>
                </div>
            </div>
            <div class="col-6 mb-1 col-md">
                <div class="card text-white bg-dark">
                    <div class="card-header text-center">مجموع انصراف از ثبت نام</div>
                    <div class="card-body">
                        <p v-if="reportdate">در بازه انتخاب شده: {{reports.allcount.date.registerLeaves}}</p>
                        <p v-else>در تمام زمان ها: {{reports.allcount.all.registerLeaves}}</p>
                    </div>
                </div>
            </div>
        </div>
</template>

<script>
import { mapGetters, mapActions  } from 'vuex';
export default {
    props: ['reportdate', 'report_branches'],
    computed: {
        ...mapGetters({
            reports: 'Report/datas',
        })
    },
}
</script>
