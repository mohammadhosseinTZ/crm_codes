<template>

    <popup name="work-job-duties">
        <template v-slot:header >
            <h3>شرح وظایف شغل: {{ workjob.name }}</h3>
        </template>
        <template v-slot:content >
                <div>
                    <table class="w-100 table">
                        <tr>
                            <th class="mot-w-200">عنوان شرح وظایف</th>
                            <th >شرح وظایف</th>
                        </tr>

                        <tr  v-for="(workjobDuties , index) in workjob.duties" :key="index">
                            <td>{{ workjobDuties.name }}</td>
                            <td>{{ workjobDuties.description }}</td>
                        </tr>
                    </table>
                    
                </div>
        </template>
    </popup>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddWorkJobDescriptions",
computed: {
        ...mapGetters({
            workjob: 'WorkJob/data'
        })
    },
    data(){
        return{
           
        }
    },
}
</script>