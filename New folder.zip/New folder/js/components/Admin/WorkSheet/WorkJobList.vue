<template>
    <div class="workjob-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex justify-content-between align-items-center mt-1 mb-1">
                <button v-if="can('add_workjob')" type="button" class="btn " data-toggle="modal" data-target=".add-workjob-modal" @click="add()"><span class="material-symbols-rounded mot-add-newItem">
                add_box
                </span> 
            
            
            
            </button>
         
               <div class="mot-actions-col2">
                    <small class="text-muted pr-2">نتایج: {{counts}}</small>
               </div>
            </div>
        </div>
     
            <div class="mot-pagination-header">
                <Filters v-if="can('use_filters')" :allows="[]" :prm="params" :uri="url" @set="setFilter" />   
                <paginate :paginate="pg" @changePage="changePage"/>
            </div>
            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    
                    <th>نام</th>
                    <th>توضیحات</th>
                    <th>وظایف</th>
                </tr>
                <tr v-for="(data, name) in webdatas" :key="data.id">
                    <td>{{name + 1}}</td>
                    
                    <td>{{data.name}}</td>
                    <td>{{data.comments}}</td>
                    <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target=".add-work-job-duties-modal" @click="edit({id: data.id, data: data })">{{data.duties.length}}</button></td>
 
                    <td class="dropdown">
                        <button class="btn dropdown-toggle mot-edit-icon-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon">
                            edit
                            </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_workjob')" type="button" class="btn btn-primary btn btn-sm d-block" data-toggle="modal" data-target=".add-workjob-modal" @click="edit({id: data.id, data: data })">ویرایش</button>
                                <button v-if="can('delete_workjob')" type="button" @click="deleteItem(`/workjob/${data.id}`, data.id, deleteworkjob)" class="btn btn btn-sm btn-danger d-block mt-1 w-100">حذف</button>       
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>

            <AddWorkJob />
            <AddWorkJobDescriptions />

    </div>
</template>
<script>
import Filters from './../../Section/Filters.vue'
import AddWorkJob from './../../Actions/AddWorkJob.vue'
import { mapGetters,mapActions } from 'vuex'
import AddWorkJobDescriptions from './AddWorkJobDescriptions.vue'
export default {
    name: 'WorkJobList',
    props: ['data'],
    components:{
    Filters,
    AddWorkJob,
    AddWorkJobDescriptions
},
    computed: {
        ...mapGetters({
            webdatas: 'WorkJob/datas',
            counts: 'WorkJob/count',
            pg: 'WorkJob/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/workjob',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
        ...mapActions({
            add: 'WorkJob/add',
            edit: 'WorkJob/edit',
            getDatas: 'WorkJob/get',
            deleteworkjob: 'WorkJob/delete',
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
    }
}
</script>