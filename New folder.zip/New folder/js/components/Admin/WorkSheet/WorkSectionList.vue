<template>
    <div class="worksection-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex align-items-center">
                <button v-if="can('add_worksection')" type="button" class="btn " data-toggle="modal" data-target=".add-worksection-modal" @click="add()"><span class="material-symbols-rounded mot-add-newItem">
                add_box
                </span> </button>
               <div class="mot-actions-col2">
                    <small class="text-muted pr-2">نتایج: {{counts}}</small>
               </div>
            </div>
        </div>
   
            <div class="mot-pagination-header-md">
                <Filters v-if="can('use_filters')" :allows="[]" :prm="params" :uri="url" @set="setFilter" />   
            </div>
            <paginate :paginate="pg" @changePage="changePage"/>
            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    
                    <th>name</th>
                    <th>comment</th>
                </tr>
                <tr v-for="(data, name) in webdatas" :key="data.id">
                    <td>{{name + 1}}</td>
                    
                    <td>{{data.name}}</td>
                    <td>{{data.comment}}</td>
                    <td class="dropdown">
                        <button class="btn dropdown-toggle mot-edit-icon-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon">
                            edit
                            </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_worksection')" type="button" class="btn btn-primary btn btn-sm d-block" data-toggle="modal" data-target=".add-worksection-modal" @click="edit({id: data.id, data: data })">ویرایش</button>
                                <button v-if="can('delete_worksection')" type="button" @click="deleteItem(`/worksection/${data.id}`, data.id, deleteworksection)" class="btn btn btn-sm btn-danger d-block mt-1 w-100">حذف</button>       
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>

            <AddWorksection />
    </div>
</template>
<script>
import Filters from './../../Section/Filters.vue'
import AddWorksection from './../../Actions/AddWorksection.vue'
import { mapGetters,mapActions } from 'vuex'
export default {
    name: 'worksectionList',
    props: ['data'],
    components:{
        Filters,
        AddWorksection
    },
    computed: {
        ...mapGetters({
            webdatas: 'WorkSection/datas',
            counts: 'WorkSection/count',
            pg: 'WorkSection/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/worksection',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
        ...mapActions({
            add: 'WorkSection/add',
            edit: 'WorkSection/edit',
            getDatas: 'WorkSection/get',
            deleteworksection: 'WorkSection/delete',
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
    }
}
</script>