<template>
    <div class="course-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation navigation d-flex align-items-center">
                <button v-if="can('add_class_course')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-class-course-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <div v-if="can('group_work')" class="from-group mr-2">
                    <label for="is-group">کار گروهی</label>
                    <input type="checkbox" id="is-group" @change="() => {is_group = !is_group; includes=[]}">
                </div>
            </div>
        </div>

        <div  class="mot-pagination-header">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['course', 'group','course_branches', 'status', 'start-date', 'end-date','register-count-limit', 'class-course-search', 'class-course-time']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th v-if="is_group" class="w-100 mot-sm-blue">
                            <groupwork :allow="['sms']" :url="url" :type="'class-courses'" :incs="includes" :filts="params" @allpage="(ev) => manageIncludes(coursesdata, ev)" @oselect="(ev) => groupWork(ev)" @allresult="(ev) => manageIncludes(coursesdata, ev, 'allresult')" />
                    </th>
                    <th>کد</th>
                    <th class="mot-w-100">نام کلاس</th>
                    <th class="mot-w-100">نام دوره</th>
                    <th class="mot-w-100">روز</th>
                    <th class="mot-w-100">ساعت</th>
                    <th class="mot-w-100">تاریخ برگذاری</th>
                    <th class="mot-w-100">مدرس</th>
                    <th class="mot-w-100">تعداد ساعت کلاس</th>
                    <th class="mot-w-100">زمان سپری شده</th>
                    <th  class="mot-w-100">قیمت</th>
                    <th  class="mot-w-100">قیمت تخفیف</th>
                    <th class="mot-w-200">تعداد افراد</th>
                    <th class="mot-w-45">اکشن</th>
                    <th v-if="can('add_session')" class="mot-w-45">کلاس ها</th>
                </tr>
                <tr v-for="(data, name) in coursesdata" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td v-if="is_group"><input type="checkbox" v-model="includes" :value="data.id"></td>
                    <td>{{data.course_code}}</td>
                    <td>{{data.class.name}}</td>
                    <td>{{data.course.name}}</td>
                    <td>{{data.day}}</td>
                    <td v-if="data.start_time && data.end_time">{{data.start_time + " الی " + data.end_time}}</td>
                    <td v-else> </td>
                    <td>{{data.begin_date_p}}</td>
                    <td>{{data.teacher.name}}</td>
                    <td>{{data.time}}</td>
                    <td>{{data.elapsed_time}}</td>
                    <td>{{data.price}}</td>
                    <td>{{data.sale_price}}</td>
                    <td>
                       <div class="d-flex align-items-center flex-gap-2">
                        <a :href="`/export/presence_absence_form/${data.id}`" target="_blank"><i class="fa fa-print"></i></a>
                        <button v-if="can('see_registers')" type="button" class="btn mx-2 btn-sm btn-success px-2 py-1" data-toggle="modal" data-target=".class-course-registers-modal" @click="getRegisters({data: `/api/v1/class-course/${data.id}/registers`})">{{data.registers.length}}</button>
                        <small type="button" @click="deleteSiteObject(data.id)"><i class="fa fa-trash text-danger"></i> پاکسازی از سایت</small>
                       </div>
                    </td>
                    <td class="dropdown">
                        <button class="btn btn-sm mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_class_course')" type="button" class="btn btn-sm btn-primary d-block" data-toggle="modal" data-target=".add-class-course-modal" @click="edit({id:data.id, data: data})">ویرایش</button>
                                 <div class="delete-form mt-2" v-if="can('delete_class_course')">
                                    <v-select placeholder="انتقال ثبتی ها به دوره ..."  v-model="replace_class_course" :options="class_courses" v-debounce="searchClassCourse" />
                                    <button  type="button" @click="deleteItem(`/class-course/${data.id}?class_course_id=${replace_class_course ? replace_class_course.id : null}`, data.id, deleteClassCourse);replace_class_course = null" class="btn btn-sm btn-danger d-block mt-1 w-100 btn-sm" data-toggle="modal" data-target="">و حذف این دوره</button>
                                </div>
                        </div>
                    </td>
                    <td class="d-md-block w-100">
                        <button v-if="can('add_session') && parseInt(data.course_code) != 999" type="button" class="btn btn-sm btn-success w-100 mb-md-1 ml-1 ml-md-0 px-2 py-1 justify-content-center" data-toggle="modal" data-target=".manage-course-class-modal" @click="addSession({id: data.id, type: 'classcourse'}); getEvents({date: `/api/v1/class-course/${data.id}/session`})">مدیریت</button>
                        <button v-if="can('see_class_course_profile')" type="button" class="btn btn-sm btn-primary w-100 px-2 py-1 justify-content-cente" data-toggle="modal" data-target=".class-course-profile-modal" @click="classCourseCosts({date: '/api/v1/allocation?class-course=' + data.id})">گزارش دوره</button>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            <AddClassCourse />
            <ManageClassSessions />
            <ClassCourseRegisters />
            <ClassCourseProfile />
    </div>
</template>
<script>
import AddClassCourse from '../Actions/AddClassCourse.vue'
import ManageClassSessions from '../Class/ManageClassSessions.vue'
import ClassCourseRegisters from '../Class/ClassCourseRegisters.vue'
import ClassCourseProfile from '../Class/ClassCourseProfile.vue'
import Filters from './Filters.vue'
import { mapActions, mapGetters } from 'vuex';

export default {
    name: 'ClassList',
    props: ['data'],
    components:{
        AddClassCourse,
        ManageClassSessions,
        Filters,
        ClassCourseRegisters,
        ClassCourseProfile
    },
    computed: {
        ...mapGetters({
            coursesdata: 'ClassCourse/datas',
            pg: 'ClassCourse/pagination'
        }),
    },
    data(){
        return{
            url: '/api/v1/class-course',
            class_courses: window.class_courses,
            replace_class_course: null
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        ...mapActions({
            getDatas: 'ClassCourse/get',
            edit: 'ClassCourse/edit',
            add: 'ClassCourse/add',
            getRegisters: 'Register/getDatas',
            addSession: 'Calendar/addSession',
            getEvents: 'Calendar/getEvetns',
            deleteClassCourse: 'ClassCourse/delete',
            classCourseCosts: 'Allocation/get',
        }),
        searchClassCourse(search, loading){
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/class-course?search=${search}`)
                .then(res => {
                    this.class_courses = res.data.data
                    loading = false;
                });
        },
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
        deleteSiteObject(classCourseid){
            axios.delete(`/api/v1/class-course/purge-site/${classCourseid}`)
        }
    }
}
</script>

