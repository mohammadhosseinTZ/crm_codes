<template>
        <div id="accordion">
            <div class="card">
                <div class="card-header p-0" id="headingOne">
                <h5 class="mb-0 d-flex justify-content-between">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                    فیلتر ها 
                    </button>
                    <ExportSection v-if="isallow('export')" :prm="prm" :url="uri" />
                </h5>
                </div>

                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <div class="row align-items-end">
                            <div class="col-md-4" v-if="isallow('start-date')">
                                <label for="">فیلتر تاریخ</label>
                                <date-picker v-if="isallow('start-date') && isallow('end-date')"  @change="changeDate" v-model="date" range clearable format="YYYY-MM-DD" display-format="jMMMM jD" placeholder="انتخاب تاریخ" />   
                            </div>
                            <div class="col-md-4" v-if="isallow('start-date')">
                                <label for="">تاریخ هایی پیشفرض</label>
                                <v-select id="date" placeholder="تاریخ های پیش فرض" @input="getDefultDate" v-model="defaultFormat" :options="[{label: 'دیروز', value: -1},{label: 'روز', value: 1},{label: 'هفته', value: 7},{label: 'ماه', value: 30},{label: 'سه ماه', value: 90 },{label: 'شش ماه', value: 180},{label: 'سال', value: 365}]" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('user_branches')">
                                    <label for="user-branch-filter">شعبه </label>
                                    <v-select id="user-branch-filter" multiple @input="$emit('set', 'user_branches', filters.user_branches , 'vselect')" v-model="filters.user_branches" :options="branches" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('upload_type')">
                                    <label for="branch-filter">نوع پیوست</label>
                                    <v-select id="branch-filter" multiple @input="$emit('set', 'upload_types', filters.upload_types , 'vselect')" v-model="filters.upload_types" :options="upload_types" @search:focus="search_params = 'uploadType|name|upload_types'"  v-debounce="dynamicSearch" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('branches')">
                                    <label for="branch-filter">شعبه </label>
                                    <v-select id="branch-filter" multiple @input="$emit('set', 'branches', filters.branches , 'vselect')" v-model="filters.branches" :options="branches" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('course_branches')">
                                    <label for="course-branch-filter">شعبه دوره ها</label>
                                    <v-select id="course-branch-filter" multiple @input="$emit('set', 'course_branches', filters.course_branches , 'vselect')" v-model="filters.course_branches" :options="branches" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('category')">
                                    <label for="category-filter">دسته</label>
                                    <v-select id="category-filter" multiple @input="$emit('set', 'categories', filters.categories , 'vselect')" v-model="filters.categories" :options="categories" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('service-category')">
                                    <label for="category-filter">دسته</label>
                                    <v-select id="category-filter" multiple @input="$emit('set', 'categories', filters.categories , 'vselect')" v-model="filters.categories" :options="serviceCategories" />
                            </div>
                            <div class="col-md-4 " v-if="isallow('product-category')">
                                    <label for="category-filter">دسته</label>
                                    <v-select id="category-filter" multiple @input="$emit('set', 'categories', filters.categories , 'vselect')" v-model="filters.categories" :options="productCategories" />
                            </div>
                            <div class="col-md-4 " v-if="isallow('cost-category')">
                                    <label for="category-filter">دسته</label>
                                    <v-select id="category-filter" multiple @input="$emit('set', 'categories', filters.categories , 'vselect')" v-model="filters.categories" :options="costCategories" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('product-search')">
                                    <label for="category-filter">انتخاب محصول</label>
                                    <v-select id="category-filter" multiple @input="$emit('set', 'suppliers', filters.products , 'vselect')" v-model="filters.products" :options="products" @search:focus="search_params = 'product|name,code|products'" v-debounce="dynamicSearch" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('service-search')">
                                    <label for="category-filter">انتخاب خدمت</label>
                                    <v-select id="category-filter" multiple @input="$emit('set', 'suppliers', filters.services , 'vselect')" v-model="filters.services" :options="services" @search:focus="search_params = 'service|name|services'"  v-debounce="dynamicSearch" />
                            </div>

                            
                            
                            <div class="col-md-4 " v-if="isallow('costable')">
                                <label for="costable">موضوع</label>
                                <v-select @input="changeType();$emit('set', 'costables', filters.costable, 'vselect')" multiple id="costable" v-model="filters.costable" :options="costables" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('subject') || isallow('subject-only')">
                                <label for="service_type">موضوع</label>
                                <v-select @input="changeType();$emit('set', 'subjects', filters.callableType, 'vselect')" multiple id="service_type" v-model="filters.callableType" :options="serviceList" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('subject-cat') && filters.callableType && filters.callableType.length">
                                <label for="service_type">انتخاب دسته</label>
                                <v-select id="service_type" multiple @input="$emit('set', 'categories', filters.categories, 'vselect')" v-model="filters.categories" :options="categories" />
                            </div>


                            <div class="col-md-4 " v-if="isallow('subject') && filters.callableType && filters.callableType.length">
                                <label for="service_type">انتخاب داده</label>
                                <v-select id="service_type" multiple @input="$emit('set', 'subject_data', filters.courses, 'vselect')" v-model="filters.courses" :options="callables" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('course')">
                                <label for="course-filter">دوره</label>
                                <v-select id="course-filter" multiple @input="$emit('set', 'courses', filters.courses, 'vselect')" v-model="filters.courses" :options="courses" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('group')">
                                <label for="course-group">گروه</label>
                                <v-select id="course-group" multiple @input="$emit('set', 'groups', filters.groups, 'vselect')" v-model="filters.groups" :options="groups" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('city')">
                                <label for="place-filter" >مکان</label>
                                <v-select id="place-filter" multiple @input="$emit('set', 'cities', filters.places, 'vselect')" v-model="filters.places" :options="places" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('user-insert')">
                                <label for="teacher">ثبت کننده</label>
                                <v-select id="teacher" multiple @input="$emit('set', 'user_insert', filters.userInsert , 'vselect')" v-model="filters.userInsert" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                            </div>

                            <div class="col-md-4 " v-if="isallow('class-course')">
                                    <label for="class-course">انتخاب کلاس</label>
                                    <v-select multiple id="class-course" @input="$emit('set', 'class-course', filters.classCourses , 'vselect')" v-model="filters.classCourses" :options="class_courses" v-debounce="searchClassCourse" />
                            </div>


                            <div class="col-md-3 " v-if="isallow('refer')">
                                <label for="teacher">معرف</label>
                                <v-select id="teacher" multiple @input="$emit('set', 'refer-by', filters.refer , 'vselect')" v-model="filters.refer" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                            </div>

                            <div class="col-md-3 " v-if="isallow('teacher')">
                                <label for="teacher">مدرس</label>
                                <v-select id="teacher" multiple @input="$emit('set', 'teachers', filters.userInsert , 'vselect')" v-model="filters.userInsert" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                            </div>

                            <div class="col-md-3 " v-if="isallow('room')">
                                    <label for="class-room-filter">اتاق</label>
                                    <v-select id="class-room-filter" multiple @input="$emit('set', 'class-rooms', filters.classRooms , 'vselect')" v-model="filters.classRooms" :options="classRooms" />
                            </div>

                            <div class="col-md-3 " v-if="isallow('status')">
                                    <label for="status-filter">وضعیت</label>
                                    <v-select multiple id="status-filter" @input="$emit('set', 'statuses', statuses , 'vselect')" v-model="statuses" :options="statusesopt" />
                            </div>

                            <div class="col-md-3 " v-if="isallow('statusi')">
                                    <label for="status-filter">وضعیت</label>
                                    <select class="form-control" @change="$emit('set', 'status', $event.target.value)">
                                        <option :value="null">وضعیت</option>
                                        <option value="1">ok</option>
                                        <option value="0">not ok</option>
                                    </select>
                            </div>
                            
                            <div class=" col-md-3" v-if="isallow('register-count-limit')">
                                <label for="register-count-limit">محدود کردن تعداد ثبت نامی</label>
                                <input type="text" id="register-count-limit" class="form-control" placeholder="تعداد ثبت نامی: 8|12" @keyup="$emit('set', `register-count-limit`, $event.target.value, 'single')">
                            </div>

                            <div class=" col-md-3" v-if="isallow('class-course-time')">
                                <label for="class-course-time">ساعت کلاس</label>
                                <input type="text" id="class-course-time" class="form-control" placeholder="ساعت برگذاری : 8|12" @keyup="$emit('set', `class-course-time`, $event.target.value, 'single')">
                            </div>

                            <div class=" col-md-3" v-if="isallow('teacher-delay-status')">
                                <label for="teacher-delay-status">وضعیت حضور مدرس</label>
                                <v-select multiple id="teacher-delay-status" @input="$emit('set', 'teacher_delay_status', filters.teacher_delay_status , 'vselect')" v-model="filters.teacher_delay_status" :options="teacher_delay_statuses" />
                            </div>
                            
                            <div class=" col-md-3" v-if="isallow('session-teaching-type')">
                                <label for="session-teaching-status">نوع برگذاری جلسه</label>
                                <v-select multiple id="session-teaching-type" @input="$emit('set', 'session_teaching_type', filters.session_teaching_type , 'vselect')" v-model="filters.session_teaching_type" :options="session_teaching_types" />
                            </div>

                            <div class=" col-md-3" v-if="isallow('gate-way')">
                                <label for="gateway-filter">روش پرداخت</label>
                                <v-select multiple id="gateway-filter" @input="$emit('set', 'gateways', filters.gateWays , 'vselect')" v-model="filters.gateWays" :options="gateWays" />
                            </div>

                            <div class=" col-md-3" v-if="isallow('discount_for')">
                                <label for="discount-filter">دلیل تخفیف</label>
                                <v-select multiple id="discount-filter" @input="$emit('set', 'discount-fors', filters.discountFors , 'vselect')" v-model="filters.discountFors" :options="discountFors" />
                            </div>

                            <div class=" col-md-3" v-if="isallow('cost-type')">
                                <label for="cost-type">نوع هزینه</label>
                                <v-select multiple id="cost-type" @input="$emit('set', 'cost-type', filters.cost_type , 'vselect')" v-model="filters.cost_type" :options="cost_types" @search:focus="search_params = 'CostType|name|cost_types'"  v-debounce="dynamicSearch" />
                            </div>
                            

                            <div class=" col-md-3" v-if="isallow('cost-type-not-pay')">
                                <label for="cost-type-not">پرداخت نشده آزمون ها</label>
                                <v-select multiple id="cost-type-not" @input="$emit('set', 'cost-type-not-pay', filters.cost_type_not_pay , 'vselect')" v-model="filters.cost_type_not_pay" :options="cost_types" v-debounce="serachCostTypes" />
                            </div>

                            <div class=" col-md-3" v-if="isallow('gender')">
                                <label for="gender">جنسیت</label>
                                <v-select multiple id="gender" @input="$emit('set', 'gender', filters.gender , 'vselect')" v-model="filters.gender" :options="genders" />
                            </div>

                            <div class=" col-md-3" v-if="isallow('bank')">
                                <label for="bank">بانک</label>
                                <v-select multiple id="bank" @input="$emit('set', 'bank', filters.bank , 'vselect')" v-model="filters.bank" :options="banks" />
                            </div>

                            <div class=" col-md-3" v-if="isallow('fund-card')">
                                <label for="fund-card">تنخواه</label>
                                <v-select multiple id="fund-card" @input="$emit('set', 'fund-cards', filters.fund_cards , 'vselect')" v-model="filters.fund_cards" :options="fund_cards" @search:focus="search_params = 'bank|name|fund_cards'"  v-debounce="dynamicSearch" />
                            </div>

                            
                            <div class="col-md-4 " v-if="isallow('debt')">                                       
                                <label for="teacher">بدهکاران</label>
                                <select class="form-control" @change="$emit('set', 'debts', $event.target.value)">
                                    <option :value="null">وضعیت</option>
                                    <option value="0">بدهکاران</option>
                                    <option value="1">تصویه ها</option>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col" v-if="isallow('leave')">
                                <label for="leave-user">انصرافی</label>
                                <input id="leave-user" type="checkbox" @click="$emit('set','leave', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('no_register')">
                                <label for="not-register">ثبت نام نشده</label>
                                <input id="not-register" type="checkbox" @click="$emit('set','no_register', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('no_leave')">
                                <label for="no-leave">انصراف نداده</label>
                                <input id="no-leave" type="checkbox" @click="$emit('set','no_leave', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('one_person')">
                                <label for="one-person">تک شخص</label>
                                <input id="one-person" type="checkbox" @click="$emit('set','one_person', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('glose')">
                                <label for="glose">باقی مانده</label>
                                <input id="glose" type="checkbox" @click="$emit('set','glose', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('private')">
                                <label for="private-register">خصوصی</label>
                                <input id="private-register" type="checkbox" @click="$emit('set','private', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('only-fp')">
                                <label for="only-fp">فیش ثبت نامی ها</label>
                                <input id="only-fp" type="checkbox" @click="$emit('set','only-fp', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('is_seen')">
                                <label for="private-register">دیده نشده</label>
                                <input id="private-register" type="checkbox" @click="$emit('set','is_seen', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('is_online')">
                                <label for="is-online-register">ثبت نامی آنلاین</label>
                                <input id="is-online-register" type="checkbox" @click="$emit('set','is_online', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('pay-status')">
                                <label for="approve">تایید شده</label>
                                <input id="approve" type="checkbox" @click="$emit('set','approve', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('pay-status')">
                                <label for="disapprove">تایید نشده</label>
                                <input id="disapprove" type="checkbox" @click="$emit('set','disapprove', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('deleted') && can('admin')">
                                <label for="deleted">حذف شده</label>
                                <input id="deleted" type="checkbox" @click="$emit('set','deleted', $event.target.checked, 'single')">
                            </div>


                            <div class="col" v-if="isallow('site-discount')">
                                <label for="site-discount">تخفیف سایت</label>
                                <input id="site-discount" type="checkbox" @click="$emit('set','site-discount', $event.target.checked, 'single')">
                            </div>

                            <div class="col" v-if="isallow('all-discount')">
                                <label for="all-discount">همه تخفیف ها</label>
                                <input id="all-discount" type="checkbox" @click="$emit('set','all_discount', $event.target.checked, 'single')">
                            </div>


                            


                            
                        </div>
                        
                        <div class=" mb-1 mt-3" v-if="isallow('user-search')">
                            <input type="text" class="form-control" placeholder="جستوجو کاربران" v-model="params.search" v-debounce="emitUserSearch">
                        </div>

                        <div class=" mb-1 mt-3" v-if="isallow('payment-search')">
                            <label for="">جستجو</label>
                            <input type="text" class="form-control" placeholder="جستوجو فیش ها" v-model="params.search" v-debounce="emitPaymentSearch">
                        </div>

                        <div class=" mb-1  mt-3" v-if="isallow('check-search')">
                            <input type="text" class="form-control" placeholder="جستوجو چک ها" v-model="params.search" v-debounce="emitCheckSearch">
                        </div>

                        <div class=" mb-1  mt-3" v-if="isallow('class-course-search')">
                            <input type="text" class="form-control" placeholder="جستجوی دوره ها" v-model="params.search" v-debounce="emitCourseSearch">
                        </div>

                        <div class=" mb-1  mt-3" v-if="isallow('cost-search')">
                            <input type="text" class="form-control" placeholder="جستجوی هزینه ها" v-debounce="emitCostSearch">
                        </div>

                        <div class=" mb-1  mt-3" v-if="isallow('comment-item-search')">
                            <input type="text" class="form-control" placeholder="جستجوی توضیحات" v-debounce="emitCommentSearch">
                        </div>

                        <div class=" mb-1  mt-3" v-if="isallow('search')">
                            <input type="text" class="form-control" placeholder="جستجوی" v-model="params.search" v-debounce="emitCourseSearch">
                        </div>

                        <div class=" mb-1  mt-3" v-if="isallow('search_price')">
                            <input type="text" class="form-control" placeholder="min|max search price" v-model="params.search_price" v-debounce="emitPriceSearch">
                        </div>
                    </div>
                </div>
            </div>
        </div>


</template>
<script>
import ExportSection from './ExportSection.vue'
import moment from 'moment'
export default {
    name: 'Filters' ,
    props: ['allows', 'uri', 'prm'],
    components: {
        ExportSection
    },
    data(){
        return{
            users: [],
            products: [],
            services: [],
            fund_cards: [],
            cost_types: [],
            upload_types: [],
            places: window.places,
            class_courses: window.classCourses,
            gateWays: window.gateWays,
            statuses: [],
            statusesopt: window.statuses,
            classRooms: window.classRooms,
            defaultFormat: null,
            groups: window.coursesCategory,
            serviceCategories: window.servicesCategory,
            productCategories: window.productsCategory,
            costCategories: window.costsCategory,
            costables: window.costables,
            categories: [],
            banks: window.banks,
            discountFors: window.discountFor,
            branches: window.branches,
            teacher_delay_statuses: window.defined_enums.teacher_delay_statuses,
            session_teaching_types: window.defined_enums.session_type,
            callables: [],
            serviceList: window.serviceList,
            date: [],
            genders: [
                {label: "آقا" , id: 0},
                {label: "خانم" , id: 1}
            ]
        }
    },
    methods: {
        isallow(filter){
            return this.allows.includes(filter) ? true : false
        },
        changeType(){
            if(!this.filters.callableType || !this.filters.callableType.length){
                this.callables = []
                return
            };
            let callables = this.filters.callableType[0].supplier_table
            this.callables = window[callables]
            this.categories = window[callables + 'Category']
        },

        searchClassCourse(search, loading){
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/class-course?search=${search}`)
                .then(res => {
                    this.class_courses = res.data.data
                    loading = false;
                });
        },
        getDefultDate(){
            if(!this.defaultFormat) return;
            let start = [
                moment(new Date()).subtract(this.defaultFormat.value, 'd').format('YYYY-MM-DD 00:00:00'), 
                moment(new Date()).format('YYYY-MM-DD 23:59:59'),
            ]
            return this.$emit('set', 'date', start)
        },

        emitUserSearch(val, $event){
            this.$emit('set', `user-search`, $event.target.value, 'single')
        },

        emitPaymentSearch(val, $event){
            this.$emit('set', `payment-search`, $event.target.value, 'single')
        },

        emitCheckSearch(val, $event){
            this.$emit('set', `search-check`, $event.target.value, 'single')
        },

        emitCourseSearch(val, $event){
            this.$emit('set', `search`, $event.target.value, 'single')
        },
        emitPriceSearch(val, $event){
            this.$emit('set', `price_search`, $event.target.value, 'single')
        },
        emitCostSearch(val, $event){
            this.$emit('set', `search`, $event.target.value, 'single')
        },
        emitCommentSearch(val, $event){
            this.$emit('set', `comment_search`, $event.target.value, 'single')
        },
        changeDate(){
            this.$emit('set', 'date', this.date.join(','))
        }

    }
}
</script>
