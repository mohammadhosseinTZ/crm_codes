<template>
    <div class="exam-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex align-items-center">
                <button v-if="can('add_exams')" type="button" class="btn " data-toggle="modal" data-target=".add-exam-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
            </div>
        </div>
            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th>تصویر</th>
                    <th>نام</th>
                    <th>دوره</th>
                    <th>توضیحات کوتاه</th>
                    <th>هزینه</th>
                    <th>دفعات رایگان</th>
                    <th>تایمر</th>
                    <th>تعداد سوالات در آزمون</th>
                    <th>درصد برای قبولی</th>
                    <th v-if="can('see_user_exams')">تعداد استفاده</th>
                    <th v-if="can('see_exam_questions')">سوالات</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data, name) in exams" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td><img v-if="data.image" :src="data.image" width="50px"></td>
                    <td>{{data.name}}</td>
                    <td>{{data.course_id | getCourse}}</td>
                    <td>{{data.short_description}}</td>
                    <td>{{data.price}}</td>
                    <td>{{data.free_use}}</td>
                    <td>{{data.timer}}</td>
                    <td>{{data.question_count}}</td>
                    <td>{{data.pass_score_percent}}</td>
                    <td v-if="can('see_user_exams')"><button  type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target=".user-exams-modal" @click="edit({id: data.id, data: data });getUserExams({exam_id: data.id})">{{data.user_exams_count}}</button></td>
                    <td v-if="can('see_exam_questions')"><button  type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target=".exam-question-modal" @click="edit({id: data.id, data: data });getExamQuestions({exam_id: data.id})">{{data.exam_questions_count}}</button></td>
                    <td class="dropdown">
                        <a :href="`/export/exam_word/${data.id}`" target="_blank"><i class="fa fa-print"></i></a>

                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_exams')" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-exam-modal" @click="edit({id: data.id, data: data })">ویرایش</button>
                                <button v-if="can('delete_exams')" type="button" @click="deleteItem(`/exam/${data.id}`, data.id, deleteExam)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                        </div>
                    </td>
                </tr>
            </table>

            <AddExam />
            <ExamQuestions />
            <UserExams v-if="exam" />
    </div>
</template>
<script>

import { mapGetters,mapActions } from 'vuex'
import AddExam from './../Actions/AddExam.vue'
import ExamQuestions from './../Exam/ExamQuestions.vue'
import UserExams from './../Exam/UserExams.vue'
export default {
    name: 'ExamList',
    props: ['data'],
    components: {
        AddExam,
        ExamQuestions,
        UserExams
    },
    computed: {
        ...mapGetters({
            exams: 'Exam/datas',
            exam: 'Exam/data',
        }),
    },
    data(){
        return{
            url: '/api/v1/exam',
        }
    },
    filters: {
        getCourse(val){
            return window.courses.find(x => x.id == val).name
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
        ...mapActions({
            add: 'Exam/add',
            edit: 'Exam/edit',
            getDatas: 'Exam/get',
            deleteExam: 'Exam/delete',
            getUserExams: 'UserExam/getUserExams',
            getExamQuestions: 'ExamQuestion/getExamQuestions',
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
    }
}
</script>
