<template>
    <div class="cost-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_category')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-category-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <small  class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
        </div>

        <div  class="mot-pagination-header">
            <paginate :paginate="pg" @changePage="changePage"/>
            <Filters v-if="can('use_filters')" :allows="['search', 'subject-only']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <table class="table table-bordered">
                <tr>
                    <th>نام</th>
                    <th>قابلیت انتخاب</th>
                    <th>مادر</th>
                    <th>نوع</th>
                    <th>اکشن</th>
                    <th class="mot-w-250">زیرمجموعه ها</th>
                </tr >
                <tr v-for="(data, name) in categories" :key="data.id"  :title="data.id">
                    <td>{{data.name}}</td>
                    <td>{{data.selectable ? 'درست' : 'غلط' }}</td>
                    <td>{{data.parent ? data.parent.name : 'بدون والد'}}</td>
                    <td>{{data.type ? data.type.name : null}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_category')" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-category-modal" @click="edit({id:  data.id, data: data})">ویرایش</button>
                                <button v-if="can('delete_category')" type="button" @click="deleteItem(`/category/${data.id}`, data.id, deleteCategory)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                        </div>
                    </td>
                    <td class="d-flex justify-content-between w-100">
                        <button v-if="parseInt(data.parent_id)" @click="getParent(data)" class="btn btn-sm btn-success mot-w-100 ml-1 ml-md-0 p-1">مادر</button>
                        <button v-if="parseInt(data.childrens_count)"  @click="getChildrens(data)"  class="btn btn-sm btn-success mot-w-100 ml-1 ml-md-0 p-1">زیر مجموعه</button>
                        <button @click="showAll()" class="btn btn-sm btn-primary mot-w-100 p-1">نمایش همه</button>
                    
                    </td>
                </tr>
           
        </table>
      <AddCategory />
    </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex';
import Filters from './Filters.vue'
import AddCategory from '../Actions/AddCategory.vue'

export default {
    name: 'CategoryList',
    props: ['data'],
    components: {
        Filters,
        AddCategory
    },
    computed: {
        ...mapGetters({
            categories: 'Category/datas',
            pg: 'Category/pagination',
            counts: 'Category/count',
        }),
    },
    data(){
        return{
            url: '/api/v1/category',
            replace_obj: null,
            srs: []
        }
    },

    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },

    methods:{
        ...mapActions({
            getDatas: 'Category/get',
            edit: 'Category/edit',
            add: 'Category/add',
            deleteCategory: 'Category/delete',
        }),

        getData(url = false) {
            this.getDatas({date: url || this.url})
        },

        getParent(data){
            delete this.params['childrens'];
            this.setUrlParam('parent', data.parent_id)
            this.applyUrl()
        },

        getChildrens(data){
            delete this.params['parent'];
            this.setUrlParam('childrens', data.id)
            this.applyUrl()
        },

        showAll(){
            delete this.params['parent']
            delete this.params['childrens'] 
            this.applyUrl()
        }
        

    }
}
</script>

