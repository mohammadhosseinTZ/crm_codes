<template>
    <div class="user-exams=list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1 user-exams=list p-2">
            <div class="navigation d-flex align-items-center">
                <small v-if="can('call_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date','end-date','user-search']" :prm="params" :uri="url" @set="setFilter" />      
            <table class="table">
                <tr>
                    <th>ردیف</th>
                    <th>نام</th>
                    <th>شماره</th>
                    <th>نام آزمون</th>
                    <th>تاریخ</th>
                    <th>امتیاز</th>
                    <th>مشاهده کارنامه</th>
                    <th>اطلاعات</th>
                    <th>اکشن</th>
                </tr>
                <tr v-for="(data, name) in userExams" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{(parseInt(data.user.gender)  == 1 ? 'خانم' : 'آقای') + " " + data.user.name}} ({{data.registers_count}})</td>
                    <td>{{data.user.phone}}</td>
                    <td>{{data.exam.name}}</td>
                    <td>{{data.created_at}}</td>
                    <td>{{data.score}} از 100</td>
                    <td><PersonButtons :id="data.user.id" :userdata="data.user" /></td>
                    <td><a target="_blank" :href="`/export/user_exam/${data.id}`" class="btn btn-primary btn-sm">مشاهده کارنامه</a></td>
                    <td><button v-if="can('delete_user_exams')" type="button" @click="deleteItem(`/user-exam/${data.id}`, data.id, deleteUserExams)" class="btn btn-danger btn-sm d-block w-100" data-toggle="modal" data-target="">حذف</button></td>
                    
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            <AllPersonDepended />
    </div>
</template>
<script>
import AllPersonDepended from './../Person/AllPersonDepended';
import Filters from './Filters.vue'
import { mapGetters,mapActions } from 'vuex'
export default {
    name: 'UserExamList',
    props: ['data'],
    components:{
        AllPersonDepended,
        Filters
    },
    computed: {
        ...mapGetters({
            userExams: 'UserExam/datas',
            counts: 'UserExam/count',
            pg: 'UserExam/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/user-exam',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
        ...mapActions({
            deleteUserExams: 'UserExam/delete',
            getDatas: 'UserExam/get'
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
    }
}
</script>
