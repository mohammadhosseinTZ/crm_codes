<template>
    <div class="cost-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_costs')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-cost-modal" data-backdrop="static" data-keyboard="false" @click="add()"><span class="material-symbols-rounded mot-add-newItem"> add_box </span></button>
                <small v-if="can('costs_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
        </div>

        <div  class="mot-pagination-header-md">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date' ,'fund-card','debt', 'deleted',  'branches', 'pay-status', 'gate-way' , 'cost-type' , 'cost-category' , 'user-insert', 'user-search', 'cost-search', 'comment-item-search','export']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <CostItem :costs="costs" />
        <paginate :paginate="pg" @changePage="changePage" class="mb-2" />

        <div v-if="can('costs_statistics')">
            <table class="table table-bordered">
                <tr v-if="statistics">
                    <th v-for="sp in statistics" :key="sp.option_value">{{sp.option_value}}</th>
                </tr>
                <tr v-if="statistics">
                    <td v-for="sp in statistics" :key="sp.option_value">{{sp.price}}</td>
                </tr>
            </table>
        </div>

        
        <AddCost />
        <AddAllocationItem />
    </div>
</template>
<script>
import CostItem from './../global/CostItem.vue'
import Filters from './Filters.vue'
import AddCost from './../Actions/AddCost.vue'
import AddAllocationItem from './../Actions/AddAllocationItem.vue'
import { mapActions, mapGetters } from 'vuex';

export default {
    name: 'CostList',
    props: ['data'],
    components:{
        Filters,
        AddCost,
        CostItem,
        AddAllocationItem
    },
    computed: {
        ...mapGetters({
            costs: 'Cost/datas',
            pg: 'Cost/pagination',
            counts: 'Cost/count',
            statistics: 'Cost/statistics',
        }),
    },
    data(){
        return{
            url: '/api/v1/cost',
        }
    },
    
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        ...mapActions({
            getDatas: 'Cost/get',
            add: 'Cost/add',
        }),

        getData(url = false) {
            this.getDatas({date: url || this.url})
        },
    }
}
</script>

