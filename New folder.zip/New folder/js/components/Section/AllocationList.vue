<template>
        <div class="allocation-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_allocation')" type="button" class="btn" data-toggle="modal" data-target=".add-allocation-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
            </div>
        </div>


        <div  class="mot-pagination-header">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['class-course', 'cost-type']" :prm="params" :uri="url" @set="setFilter" />      
        </div>

        <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th>وضعیت</th>
                    <th>نام هزینه</th>
                    <th>تخصیص به</th>
                    <th>مقدار تخصیص</th>
                    <th>محاسبه</th>
                    <th>باقی مانده</th>
                    <th>هزینه محاسبه شده</th>
                    <th>ثبت کننده</th>
                    <th>توضیحات</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data, name) in allocations" :key="data.id" :title="data.id">
                    <td>{{name + 1}}</td>
                    <td role="button" v-if="data.status == 0" style="color:red" @click="changeStatus(data.id)">✖</td>
                    <td role="button" v-else style="color:green" @click="changeStatus(data.id)">✔</td>
                    <td>{{data.cost_item ? data.cost_item.costableName : null }} ({{data.cost_item ? data.cost_item.costable_id : null}})</td>
                    <td>{{data.allocationable_name}}</td>
                    <td>{{data.type_value}} {{locate(data.cost_item ? data.cost_item.unit.name : null)}}</td>
                    <td>{{data.allocation_value | format}} {{locate(data.allocation_type)}}</td>
                    <td>{{parseFloat(data.glose) | format}}</td>
                    <td>{{data.price | format}}</td>
                    <td>{{data.user_insert.name}}</td>
                    <td>{{data.comment}}</td>
                    <td class="dropdown">
                        <button class="btn mot-info-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-info-icon"> info </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="parseInt(data.status) == 0 && can('edit_allocation')" type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".add-allocation-modal" @click="edit({id: data.id, data:data})">ویرایش</button>
                                <button v-if="parseInt(data.status) == 0 &&  can('delete_allocation')"  type="button" @click="deleteItem(`/allocation/${data.id}`, data.id, deleteAllocation)" class="btn btn-sm btn-danger d-block mt-1 w-100 btn-sm" data-toggle="modal" data-target="">حذف</button>      
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage" class="mb-2"/>

            <AddAllocationItem />
    </div>
</template>
<script>
import Filters from './Filters.vue'
import AddAllocationItem from './../Actions/AddAllocationItem.vue'

import { mapActions, mapGetters } from 'vuex';
export default {
    name: 'AllocationList',
    props: ['data'],
    components:{
        Filters,
        AddAllocationItem,
    },
    computed: {
        ...mapGetters({
            allocations: 'Allocation/datas',
            pg: 'Allocation/pagination',
            counts: 'Allocation/count',
        }),
    },
    data(){
        return {    
            url: '/api/v1/allocation'
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        ...mapActions({
            getDatas: 'Allocation/get',
            add: 'Allocation/add',
            edit: 'Allocation/edit',
            deleteAllocation: 'Allocation/delete',
            changeStatus: 'Allocation/changeStatus'
        }),

        getData(url = false) {
            this.getDatas({date: url || this.url})
        },
    }
}
</script>