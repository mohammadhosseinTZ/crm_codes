<template>
    <div class="check-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_check')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-check-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <small v-if="can('check_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
        </div>
        <div  class="mot-pagination-header-md">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date','export','check-search','user-insert']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <table class="table table-bordered">
            <tr>
                <th class="mot-w-45">ردیف</th>
                <th>وضعیت</th>
                <th>تاریخ</th>
                <th>سریال</th>
                <th>صیاد</th>
                <th>مبلغ</th>
                <th>تاریخ صدور</th>
                <th>بانک</th>
                <th>ثبت کننده</th>
                <th>برای</th>
                <th class="mot-w-45">اکشن</th>
            </tr>
            <tr v-for="(check , name) in checks" :key="check.id">
                <td>{{name + 1}}</td>
                <td role="button" v-if="check.status == 0" style="color:red" @click="changeCheckStatus(check.id)">✖</td>
                <td role="button" v-else style="color:green" @click="changeCheckStatus(check.id)">✔</td>
                <td>{{check.created_at}}</td>
                <td>{{check.serial}}</td>
                <td>{{check.saiyad}}</td>
                <td>{{check.price}}</td>
                <td>{{check.receipt}}</td>
                <td>{{check.bank.option_value}}</td>
                <td>{{check.user_insert.name}}</td>
                <td>{{check.payment.code}}</td>
                <td class="dropdown">
                    <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <button v-if="!check.status && (can('edit_check') || can('edit_only_check', check.user_insert_id ))" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-check-modal" @click="edit({data: check})">ویرایش</button>
                            <button v-if="can('delete_check')" type="button" @click="deleteItem(`/check/${check.id}`, check.id, deleteCheck)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                    </div>
                </td>
            </tr>
        </table>
        <paginate :paginate="pg" @changePage="changePage" class="mb-2"/>
        <AddCheck />
    </div>
</template>
<script>
import AddCheck from '../Actions/AddCheck.vue'
import Filters from './Filters.vue'
import { mapGetters, mapActions  } from 'vuex';
export default {
    name: 'CheckList',
    props: ['data'],
    components:{
        AddCheck,
        Filters
    },
    computed: {
        ...mapGetters({
            checks: 'Check/datas',
            counts: 'Check/count',
            pg: 'Check/pagination'
        }),
    },
    data(){
        return{
            url: '/api/v1/check',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.checks = this.data}
    },
  
   methods: {
       ...mapActions({
            get: 'Check/get',
            add: 'Check/add',
            edit: 'Check/edit',
            deleteCheck: 'Check/delete',
        }),
        getData(url = false) {
            this.get({date: url || this.url})
        },
        changeCheckStatus(id){
            if(!this.can('change_check_status')) return;
            axios.get(`/api/v1/check/${id}/changestatus`)
            .then(res => this.checks.find(x => x.id == id).status = res.data.data.status)
        }
   }
}
</script>