<template>
    <div class="course-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_class')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-class-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
            </div>
        </div>
        <paginate :paginate="pagination" @changePage="changePage"/>
        
        <table class="table">
                <tr>
                    <th>ردیف</th>
                    <th>نام کلاس</th>
                    <th>ظرفیت</th>
                    <th>مساحت</th>
                    <th>شعبه</th>
                    <th class="mot-w-300 text-center">اکشن</th>
                </tr>
                <tr v-for="(data, name) in classes" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.name}}</td>
                    <td>{{data.capacity}} نفر</td>
                    <td>{{data.area}}</td>
                    <td>{{data.branch.name}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_class')" type="button" class="btn btn-primary d-block " data-toggle="modal" data-target=".add-class-modal" @click="edit({id: data.id, data:data})">ویرایش</button>
                                <div class="delete-form mt-2" v-if="can('delete_course')">
                                    <v-select placeholder="انتقال موارد به..."  v-model="replace_class" :options="classes" />
                                    <button type="button" @click="deleteItem(`/class/${data.id}?class_id=${replace_class ? replace_class.id : null}`, data.id, deleteClass);replace_class = null" class="btn btn-danger d-block mt-1 w-100 btn-sm" data-toggle="modal" data-target="">و حذف این دوره</button>
                                </div>
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pagination" @changePage="changePage"/>
            <AddClass />
    </div>
</template>
<script>
import AddClass from '../Actions/AddClass.vue'
import { mapActions, mapGetters } from 'vuex';
export default {
    name: 'ClassList',
    props: ['data'],
    components:{
        AddClass
    },
    computed: {
        ...mapGetters({
            classes: 'ClassIndex/datas'
        }),
    },
    data(){
        return{
            url: '/api/v1/class',
            replace_class: null,
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        ...mapActions({
            add: 'ClassIndex/add',
            edit: 'ClassIndex/edit',
            get: 'ClassIndex/get',
            deleteClass: 'ClassIndex/delete'
        }),
        getData(url = false){
            this.get({data: url || this.url})
        }
    }
}
</script>

