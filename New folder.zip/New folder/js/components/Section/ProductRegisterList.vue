<template>
    <div class="person-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex justify-content-between align-items-center mt-1 mb-1">
                <button v-if="can('add_person')" type="button" class="btn " data-toggle="modal" data-target=".add-person-modal" @click="addPerson();"><span class="material-symbols-rounded mot-add-newItem">
                add_box
                </span> </button>
                <div class="mot-actions-col2">
                <div v-if="can('group_work')" class="from-group mr-2">
                    <label for="is-group">کار گروهی</label>
                    <input type="checkbox" id="is-group" @change="() => {is_group = !is_group; includes=[]}">
                </div>
                <small v-if="can('register_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
            </div>
        </div>
        <div  class="mot-pagination-header-md">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date', 'deleted','user_branches', 'debt','refer', 'gender' ,'course_branches','discount_for','city','leave','product-category','export','product-search','user-insert','user', 'user-search', 'site-discount']" :prm="params" :uri="url" @set="setFilter" />        </div>    
    
            <div>
                <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th v-if="is_group" class="w-100 mot-sm-blue">
                            <groupwork :allow="['sms', 'delete']" :url="url" :type="'product_registers'" :incs="includes" :filts="params" @allpage="(ev) => manageIncludes(registers, ev)" @oselect="(ev) => groupWork(ev)" @allresult="(ev) => manageIncludes(registers, ev, 'allresult')" />
                    </th>
                    <th>نام</th>
                    <th class="mot-w-100">شماره</th>
                    <th>محصول</th>
                    <th class="mot-w-100">قیمت واحد</th>
                    <th class="mot-w-100">هزینه کل</th>
                    <th class="mot-w-100">پرداختی</th>
                    <th class="mot-w-100">باقی مانده</th>
                    <th>تاریخ</th>
                    <th class="mot-w-200">فیش ها</th>
                    <th class="mot-w-100">توضیحات</th>
                    <th>ثبت کننده</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data, name) in registers" :key="data.id" :class="[data.items.some(x => x.leave_reason_id == true) ? 'leave' : '']">
                    <td>{{name + 1}}</td>
                    <td v-if="is_group"><input type="checkbox" v-model="includes" :value="data.id"></td>
                    <td>{{(parseInt(data.user.gender)  == 1 ? 'خانم' : 'آقای') + " " + data.user.name}}</td>
                    <td>{{data.user.phone}}</td>
                    <td>{{data.supplier.name}}</td>
                    <td>{{data.items.map(x => x.unit_price).join(' و ')}}</td>
                    <td>{{data.price | format}} 
                        <span v-for="dc in data.discount_fors" :key="dc.id" class="disconted"><span v-if="dc.option">{{searchMeta(dc.option.meta, 'discount_percent').meta_value}} درصد کسری اضافه برای {{dc.option.option_value}}</span></span>
                        <span v-if="parseInt(data.pay_discount_price)" class="disconted">{{data.pay_discount_price | format}} تخفیف روی فاکتور</span>
                        <span v-if="data.bonus" class="disconted">معرفی توسط: {{data.bonus.user_reference.name}}</span>
                        <span v-if="data.site_discount">
                        <span class="disconted" v-for="sd in data.site_discount" :key="sd.name">
                                {{ Number(sd.amount) }} {{ sd.type == 'percent' ? 'درصد' : 'تومان' }} تخفیف با کد {{ sd.source != 'site' ? 'معرف  ' : null}}: {{ sd.name }}
                                <span v-if="sd.type != 'site' && sd.user" data-toggle="modal" data-target=".person-profile-modal" @click="getPersonData({id: sd.user.id});getPersonPayments(sd.user.id);getPersonRegisters({id: sd.user.id});getPersonCalls(sd.user.id);setSelectedPerson({id: sd.user.id, data: sd.user});" >(مشاهده)</span>
                        </span>
                    </span>
                    </td>

                    <td>{{data.payments | getPrice | format}}</td>

                    <td>{{getGlose(data) | format}}</td>
                

                    <td>{{data.created_at}}</td>
                    <td>
                        <button type="button" @click="setSelectedPerson({id: data.user_id, data: data.user});getPyamentsRegister({id: data.id, type: 'product-register'});" :class="getPrices(data.payments) >= data.price ? 'btn-success' : 'btn-warning'" class="btn d-block mt-1 w-100 mot-w-100" data-toggle="modal" data-target=".person-payments-modal">{{data.payments.length}} فیش ها</button>
                    </td>
                    <td>
                        <div class="d-flex align-items-center">
                            <button class="btn btn-link" type="button" data-toggle="modal" data-target=".add-register-cost" @click="getCostByRegisterId(data.id)" ><i class="fas fa-dollar-sign"></i></button>
                            <i class="fa fa-print" @click="print(data);"></i>
                        </div>
                        {{data.comment}}
                    </td>
                    <td>
                        <span v-if="data.user_insert" :class="[data.user_insert.phone == '0000000000' ? 'site_insert' : null]">
                                {{data.user_insert.name}}
                        </span>
                    </td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="(can('edit_register') || can('edit_only_register', data.user_insert_id )) && parseInt(data.can_edit)" type="button" class="btn btn-primary" data-toggle="modal" data-target=".add-person-product-modal" @click="edit({id:  data.id, data: data})">ویرایش</button>
                                <button v-if="(can('edit_register') || can('edit_only_register', data.user_insert_id )) && !parseInt(data.can_edit)" type="button" @click="getReturns({data: `/api/v1/return-product/?register=${data.id}`});edit({id:  data.id, data: data})" class="btn btn-warning d-block mt-1 w-100" data-toggle="modal" data-target=".return-product-modal">انصراف از خرید</button>     
                                <button v-if="can('delete_register') && parseInt(data.can_edit)" type="button" @click="deleteItem(`/product-register/${data.id}`, data.id, deleteRegister)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>     
                                <button v-if="can('delete_register') && parseInt(data.can_edit) && data.deleted_at" type="button" @click="deleteItem(`/product-register/${data.id}?type=restore`, data.id, deleteRegister)" class="btn btn-success d-block mt-1 w-100" data-toggle="modal" data-target="">بازیابی</button>     
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.user.id" :userdata="data.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            </div>
            <AllPersonDepended />
            <ReturnProduct />
            <AddReturnedProduct />
            <ProductRegisterReceipt v-if="selectedItem" style="display: none" :register="selectedItem" />  
    </div>
</template>
<script>


import AllPersonDepended from './../Person/AllPersonDepended';
import ProductRegisterReceipt from './../global/ProductRegisterReceipt';
import ReturnProduct from './../Product/ReturnProduct.vue';
import AddReturnedProduct from './../Product/AddReturnedProduct.vue'

import { mapGetters, mapActions  } from 'vuex';
import Filters from './Filters.vue'
export default {
    name: 'ProductRegisterList',
    props: ['data'],
    components:{
        AllPersonDepended,
        Filters,
        ProductRegisterReceipt,
        ReturnProduct,
        AddReturnedProduct
    },
    computed: {
        ...mapGetters({
            registers: 'ProductRegister/datas',
            counts: 'ProductRegister/count',
            pg: 'ProductRegister/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/product-register',
            selectedItem: null
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    filters: {
        getPrice: function(value){
                var tmpPrice = 0;
                value.forEach(element => {
                        if(element.status == 1){
                            var prices = element.gates.map(value => value.price);
                            tmpPrice += parseInt(prices.reduce((total, num) =>{
                                return parseInt(total) + parseInt(num);
                            }));  
                        }   
                });
                return tmpPrice;
        },
        sum: function(val){
            let tmpval = 0
            for(var n of val) tmpval += n
            return tmpval
        }, 
   },
   methods: {
       ...mapActions({
            edit: 'ProductRegister/editRegister',
            getDatas: 'ProductRegister/getDatas',
            deleteRegister: 'ProductRegister/delete',
            getCostByRegisterId: 'Cost/getCostByRegisterId',
            getReturns: 'ProductRegisterReturn/get'
        }),
       getPrices(values){
           return this.$options.filters.getPrice(values);
       },

        getGlose(data){
            var payedPrice = this.$options.filters.getPrice(data.payments)
            var price = data.price
            return parseInt(price) - parseInt(payedPrice)

        },
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
        print(data){
            var obj = this
            var dataToPrint = new Promise((resolve, reject) => {
                if(obj.selectedItem = data){
                    resolve(obj.selectedItem)
                }
            });

            dataToPrint.then(res => {
                var myPrintContent = document.getElementById('print-product-factor');
                var myPrintWindow = window.open('https://portal.aryatehran.com/product/factor/print', 'print');
                myPrintWindow.document.write(myPrintContent.innerHTML + `<style>@page: footer {
    display: none;
}

@page: header {
    display: none;
}

@page {
    margin: none;
}

@font-face {
    font-family: \"Iransans\";
    src: url(\"/font/IRANSansWeb.woff2\") format(\"woff\"), url(\"/font/IRANSansWeb.woff\") format(\"woff\"), url(\"/font/IRANSansWeb.ttf\") format(\"truetype\");
}

img {
    width: 10%;
}
.head{
    display: flex;
    align-items: center;
    gap: 10px;
    justify-content: center;
}
.content {
    text-align: center;
}

h1,
table {
    margin-top: 50px;
}

h1,
table,
tfoot {
    text-align: right;
    direction: rtl;
    width: 100%;
}

* {
    font-family: \"Iransans\";
}

h1 {
    font-size: 20px;
    margin-top: 10px;
}

th {
    width: 40%;
}

th,
td {
    font-size: 14px !important;
}

.date {
    direction: ltr;
    display: block;
}

main.py-4 {
    padding: 0 !important;
}

table {
    margin: 9;
}

body {
    direction: rtl;
}

h3 {
    margin: 0;
}

.head-content {
    display: flex;
    flex-direction: column;
}

.head-content span {
    display: flex;
    gap: 10px;
}

.head-content {
    text-align: right;
}

.product-items {
    margin: 15px 0;
    font-size: 12px;
}

.product-items .pthead {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    background: black;
    color: white;
    padding: 5px;
}

.product-items .pthead strong {
    border-right: 1px solid white;
    flex: 1;
    text-align: center;
}

.product-items .pthead strong:first-child {
    border: none;
}

.product-items .pt-item {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-bottom: 10px;
    padding-bottom: 10px;
    border-bottom: 1px solid #ccc;
    
}
.product-items .pt-item:last-child{
    border: none;
}
.product-items .pt-item .pname {
    min-width: 100%;
    margin-bottom: 3px;
}
table.pay-info tr:nth-child(even) {
    background: black;
    color: white;
    padding: 5px !important;
}
table.pay-info tr:nth-child(even) th, table.pay-info tr:nth-child(even) td{
    padding: 2px;
}
table.pay-info{
    margin: 0;
}

</style>


`);
                setTimeout(function(){
                myPrintWindow.document.close();
                myPrintWindow.focus();
                myPrintWindow.print();
                myPrintWindow.close();  
                }, 1000)  
                return false;
            })
            
        }

   }
}
</script>
<style>
span.disconted {
    font-size: 11px;
    display: block;
    color: red;
    font-weight: bold;
}
</style>