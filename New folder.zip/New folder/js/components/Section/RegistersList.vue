<template>
    <div class="person-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex justify-content-between align-items-center mt-1 mb-1">
                <button v-if="can('add_person')" type="button" class="btn" data-toggle="modal" data-target=".add-person-modal" @click="addPerson();">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <div class="d-flex align-items-center">
                    <div v-if="can('group_work')" class="from-group mr-2">
                    <label for="is-group">کار گروهی</label>
                    <input type="checkbox" id="is-group" @change="() => {is_group = !is_group; includes=[]}">
                </div>
                <small v-if="can('register_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
                </div>
            </div>
        </div>
        <div  class="mot-pagination-header-md">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date','debt', 'deleted', 'refer', 'user_branches', 'all-discount', 'gender' ,'course_branches','discount_for','city' ,'group','class-course','leave','is_online','export','course','user-insert','user', 'user-search', 'site-discount']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
            <div>
                <table class="table">
                <tr>
                    <th class="mot-w-45 ">ردیف</th>
                    <th v-if="is_group" class="w-100 mot-sm-blue">
                            <groupwork :allow="['sms', 'delete']" :url="url" :type="'registers'" :incs="includes" :filts="params" @allpage="(ev) => manageIncludes(registers, ev)" @oselect="(ev) => groupWork(ev)" @allresult="(ev) => manageIncludes(registers, ev, 'allresult')" />
                    </th>
                    <th class="mot-w-100">نام</th>
                    <th class="mot-w-100"   >شماره</th>
                    <th class="mot-w-200">دوره</th>
                    <th class="mot-w-100">هزینه</th>
                    <th class="mot-w-100">پرداختی</th>
                    <th class="mot-w-100">باقی مانده</th>
                    <th class="mot-w-100">تاریخ</th>
                    <th class="mot-w-200">فیش ها</th>
                    <th class="mot-w-100">توضیحات</th>
                    <th class=" mot-w-200">ثبت کننده</th>
                    <th class="mot-w-45 ">اکشن</th>
                </tr>
                <tr v-for="(data, name) in registers" :key="data.id" :class="[data.leave_reason_id != null ? 'leave' : '']">
                    <td>{{name + 1}}</td>
                    <td v-if="is_group"><input type="checkbox" v-model="includes" :value="data.id"></td>
                    <td>{{(parseInt(data.user.gender)  == 1 ? 'خانم' : 'آقای') + " " + data.user.name}} 
                        <span class="text-success" title="وضعیت شرکت در نظر سنجی">{{parseInt(data.survey_count)? '✔' : null}}</span><span class="text-danger" title="وضعیت تکمیل اطلاعات">{{ searchMeta(data.user.meta, 'is_complete_info').meta_value  == 1 ? '✔' : null }}</span>
                        <small>{{ data.user.email }}</small>
                    </td>
                    <td>{{data.user.phone}}</td>
                    <td>{{data.class_course.course_code + '-' + data.course.name}}</td>

                    <td>{{data.price | format}} 
                        <span v-for="dc in data.discount_fors" :key="dc.id" class="disconted"><span v-if="dc.option">{{searchMeta(dc.option.meta, 'discount_percent').meta_value}} درصد کسری اضافه برای {{dc.option.option_value}}</span></span>
                        <span v-if="parseInt(data.is_online_course)" class="disconted">(آنلاین)</span>
                        <span v-if="data.bonus" class="disconted">معرفی توسط: {{data.bonus.user_reference.name}}</span>
                        <span v-if="data.site_discount">
                        <span class="disconted" v-for="sd in data.site_discount" :key="sd.name">
                                {{ Number(sd.amount) }} {{ sd.type == 'percent' ? 'درصد' : 'تومان' }} تخفیف با کد {{ sd.source != 'site' ? 'معرف  ' : null}}: {{ sd.name }}
                                <span v-if="sd.type != 'site' && sd.user" data-toggle="modal" data-target=".person-profile-modal" @click="getPersonData({id: sd.user.id});getPersonPayments(sd.user.id);getPersonRegisters({id: sd.user.id});getPersonCalls(sd.user.id);setSelectedPerson({id: sd.user.id, data: sd.user});" >(مشاهده)</span>
                        </span>
                    </span>
                    </td>

                    <td>{{data.payments | getPrice | format}} <span v-if="data.return_price" style="color: gray" class="disconted">عودت ({{data.return_price | format}})</span></td>

                    <td v-if="data.leave_reason_id == null">{{getGlose(data) | format}}</td>
                    <td v-else>{{0}}</td>

                    <td>{{data.created_at}}</td>
                    <td>
                        <button type="button" @click="setSelectedPerson({id: data.user_id, data: data.user});getPyamentsRegister({id: data.id});" :class="getPrices(data.payments) >= data.price ? 'btn-success' : 'btn-warning'" class="btn d-block mt-1 mot-w-100 w-100" data-toggle="modal" data-target=".person-payments-modal">{{data.payments.length}} فیش ها</button>
                    </td>
                    <td class="mot-table-des-icons">
                        <a :href="`/export/register_regform/${data.id}`" target="_blank"><i class="fa fa-print"></i></a>
                        <button class="btn btn-link" type="button" data-toggle="modal" data-target=".add-register-cost" @click="getCostByRegisterId(data.id)" ><i class="fas fa-dollar-sign"></i></button>
                        <button class="btn btn-link" type="button" data-toggle="modal" data-target=".register-rollcall-modal" @click="getRollCallByRegisterId({register: data.id})" ><i class="fas fa-eye"></i></button>
                        <span v-if="data.before_class_course" class="disconted">انتقالی از {{data.before_class_course}}</span>
                        {{data.comment}}</td>
                    
                    <td>
                        <span v-if="data.user_insert" :class="[data.user_insert.phone == '0000000000' ? 'site_insert' : null]">
                                {{data.user_insert.name}}
                        </span>
                    </td>
                    <td class="dropdown">
                        <button class="btn dropdown-toggle mot-edit-icon-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_register') || can('edit_only_register', data.user_insert_id )" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-register-modal" @click="editRegister({id:  data.id, data: data})">ویرایش</button>
                                 <button v-if="data.class_course.course_code == 999" type="button" class="btn btn-primary" data-toggle="modal" data-target=".manage-course-class-modal" @click="addSession({id: data.id, type: 'register'}); getEvents({date: `/api/v1/register/${data.id}/session`})">مدیریت</button>
                                <button v-if="can('delete_register')" type="button" @click="deleteItem(`/register/${data.id}`, data.id, deleteRegister)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>     
                                <button v-if="can('delete_register') && data.deleted_at" type="button" @click="deleteItem(`/register/${data.id}?type=restore`, data.id, deleteRegister)" class="btn btn-success d-block mt-1 w-100" data-toggle="modal" data-target="">بازیابی</button>     
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.user.id" :userdata="data.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            </div>
            <AllPersonDepended />  
    </div>
</template>
<script>


import AllPersonDepended from './../Person/AllPersonDepended';
import { mapGetters, mapActions  } from 'vuex';
import Filters from './Filters.vue'
export default {
    name: 'RegisterList',
    props: ['data'],
    components:{
        AllPersonDepended,
        Filters
    },
    computed: {
        ...mapGetters({
            registers: 'Register/datas',
            counts: 'Register/count',
            pg: 'Register/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/register',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    filters: {
        getPrice: function(value){
                var tmpPrice = 0;
                value.forEach(element => {
                        if(element.status == 1){
                            var prices = element.gates.map(value => value.price);
                            tmpPrice += parseInt(prices.reduce((total, num) =>{
                                return parseInt(total) + parseInt(num);
                            }));  
                        }   
                });
                return tmpPrice;
        },
   },
   methods: {
       ...mapActions({
            editRegister: 'Register/editRegister',
            getDatas: 'Register/getDatas',
            addSession: 'Calendar/addSession',
            getEvents: 'Calendar/getEvetns',
            deleteRegister: 'Register/delete',
            getCostByRegisterId: 'Cost/getCostByRegisterId',
            getRollCallByRegisterId: 'RollCall/getByRegister'
        }),
       getPrices(values){
           return this.$options.filters.getPrice(values);
       },
       getGlose(data){
            var price = this.$options.filters.getPrice(data.payments)
            return parseInt(data.price) - parseInt(price)
        },
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
   }
}
</script>
<style>
span.disconted {
    font-size: 11px;
    display: block;
    color: red;
    font-weight: bold;
}
</style>