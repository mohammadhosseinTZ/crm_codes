<template>
    <div class="course-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_course')" type="button" class="btn" data-toggle="modal" data-target=".add-course-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
            </div>
        </div>
        <div  class="mot-pagination-header">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['group','class-course-search']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th>نام دوره</th>
                    <th>قیمت</th>
                    <th>هزینه مدرک</th>
                    <th>هزینه مدرک ویژه</th>
                    <th>هزینه آزمون</th>
                    <th>هزینه آزمون ویژه</th>
                    <th>هزینه کلاس خصوصی به ساعت</th>
                    <th>گروه ها</th>
                    <th>شعبه</th>
                    <th v-if="can('admin')">تعداد ثبت</th>
                    <th v-if="can('admin')">تعداد تماس</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data, name) in dataCourses" :key="data.id" :title="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.name}}</td>
                    <td>{{data.price | format}}</td>
                    <td>{{data.evidence_price | format}}</td>
                    <td>{{data.sp_evidence_price | format}}</td>
                    <td>{{data.technical_evidence_price | format}}</td>
                    <td>{{data.sp_technical_evidence_price | format}}</td>
                    <td>{{data.private_price | format}}</td>
                    <td>{{data.groups.map(x => {
                        return x.name
                    }).join(' و ')}}</td>
                    <td>{{data.branches.map(x => {
                        return x.name
                    }).join(' و ')}}</td>
                    <td v-if="can('admin')">{{data.registers_count}}</td>
                    <td v-if="can('admin')">{{data.calls_count}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_course')" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-course-modal" @click="edit({id: data.id, data:data})">ویرایش</button>
                                <div class="delete-form mt-2" v-if="can('delete_course')">
                                    <v-select placeholder="انتقال موارد به..."  v-model="replace_course" :options="courses" />
                                    <button  type="button" @click="deleteItem(`/course/${data.id}?course_id=${replace_course ? replace_course.id : null}`, data.id, deleteCourse);replace_course = null" class="btn btn-danger d-block mt-1 w-100 btn-sm" data-toggle="modal" data-target="">و حذف این دوره</button>
                                </div>           
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            <AddCourse />
    </div>
</template>
<script>
import Filters from './Filters.vue'
import AddCourse from '../Actions/AddCourse.vue'
import { mapActions, mapGetters } from 'vuex';
export default {
    name: 'CourseList',
    props: ['data'],
    components:{
        AddCourse,
        Filters
    },
    computed: {
        ...mapGetters({
            dataCourses: 'CourseIndex/datas',
            counts: 'CourseIndex/count',
            pg: 'CourseIndex/pagination'
        }),
    },
    data(){
        return{
            url: '/api/v1/course',
            replace_course: null,
            courses: window.courses
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        ...mapActions({
            add: 'CourseIndex/add',
            edit: 'CourseIndex/edit',
            get: 'CourseIndex/get',
            deleteCourse: 'CourseIndex/delete',
        }),

        getData(url = false){
            this.get({data: url || this.url})
        }
    }
}
</script>

