<template>
    <div class="export">
        <div class="dropdown">
            <span class="material-symbols-rounded  m-0 btn btn-primary dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> output </span>        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" role="button" target="_blank" @click.stop.prevent="exp('pdf')">pdf</a>
            <a class="dropdown-item" role="button" target="_blank" @click.stop.prevent="exp('excel')">اکسل</a>
        </div>
        </div>
    </div>    
</template>
<script>
export default {
    props: ['prm', 'url'],
    methods: {
        exp(type){
            this.prm['export'] = type
            window.open(this.url.replace('/api/v1','') + this.compileParamsToUrl(this.prm))
            delete this.prm['export']            
        }
    }
}
</script>
