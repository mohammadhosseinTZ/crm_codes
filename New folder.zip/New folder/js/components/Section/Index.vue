<template>
    <div class="p-0">
        <div class="card">
            <div class="card-header">پیشخوان</div>

            <div class="card-body" >
                <PersonList v-if="can('expert')" />
                <TeacherIndex class="mt-10" v-if="can('is_teacher')" />
            </div>


            
        </div>
    </div>
</template>

<script>
import PersonList from './PersonList.vue';
import TeacherIndex from '../Teacher/TeacherIndex.vue';
    export default {
        components: {PersonList, TeacherIndex},
    }
</script>
