<template>
    <div class="person-list ">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex align-items-center">
                <button ref="addperson" v-if="can('add_person')" type="button" class="btn  mt-1 mb-1"
                    data-toggle="modal" data-target=".add-person-modal" @click="addPerson()"><span
                        class="material-symbols-rounded mot-add-newItem">
                        add_box
                    </span></button>
                <div class="mot-actions-col2">
                    <div v-if="can('group_work')" class="from-group mr-2">
                        <label for="is-group">کار گروهی</label>
                        <input type="checkbox" id="is-group" @change="() => { is_group = !is_group; includes = [] }">
                    </div>
                    <small v-if="can('person_statistics')" class="text-muted pr-2">نتایج: {{ counts }}</small>
                </div>
            </div>
        </div>
        <div class="form-group mb-1">
            <div class="mot-pagination-header col-12 p-0">
                <div class="mot-pagination-header">

                    <Filters v-if="can('use_filters')" :allows="['user', 'user_branches', 'deleted', 'user-search']"
                        :prm="params" :uri="url" @set="setFilter" />
                    <paginate :paginate="pg" @changePage="changePage" />
                </div>
            </div>
        </div>
        <table class="table">
            <tr>
                <th class="mot-w-45">ردیف</th>
                <th v-if="is_group" class="w-100 mot-sm-blue">
                    <groupwork :allow="['sms']" :url="url" :type="'person'" :incs="includes" :filts="params"
                        @allpage="(ev) => manageIncludes(persons, ev)" @oselect="(ev) => groupWork(ev)"
                        @allresult="(ev) => manageIncludes(persons, ev, 'allresult')" />
                </th>
                <th class="mot-w-200">نام</th>
                <th class="mot-w-200">شماره</th>
                <th>تعداد تماس ها</th>
                <th class="mot-w-200">ثبت کننده</th>
                <th class="mot-w-45 text-center">اکشن</th>
                <th class="mot-w-45">اکشن</th>
            </tr>
            <tr v-for="(person, name) in persons" :key="person.id" :title="'شماره کاربری: ' + person.id">
                <td>{{ name + 1 }}</td>
                <td v-if="is_group"><input type="checkbox" v-model="includes" :value="person.id"></td>
                <td data-toggle="tooltip" data-placement="top" :title="person.registers | showPersonRegister">
                    {{ (person.gender == 1 ? 'خانم' : 'آقای') + " " + person.name }}</td>
                <td>{{ person.phone }}</td>
                <td>{{ person.calls_count }}</td>
                <td>
                    <span v-if="person.user_insert"
                        :class="[person.user_insert.phone == '0000000000' ? 'site_insert' : null]">
                        {{ person.user_insert.name }}
                    </span>
                </td>
                <td>
                    <PersonButtons :id="person.id" :userdata="person" />
                </td>
                <td class="dropdown">
                    <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <button v-if="can('edit_person') || can('edit_only_person', person.user_insert_id)"
                            type="button" class="btn btn-success d-block mb-1 p-1" data-toggle="modal"
                            data-target=".add-person-modal"
                            @click="editPerson({ id: person.id, data: person }); setSelectedPerson({ id: person.id, data: person });">ویرایش</button>
                        <div class="delete-form mt-2 text-start" v-if="can('delete_person')">
                            <v-select placeholder="انتقال به ..." v-model="replace_user" :options="users"
                            @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                            <button v-if="can('delete_person')" type="button"
                                @click="deleteItem(`/person/${person.id}?user_id=${replace_user ? replace_user.id : null}`, person.id, deletePerson); replace_user = null"
                                class="btn btn-danger mb-1 p-1">حذف</button>
                        </div>

                        <button v-if="can('delete_person') && person.deleted_at" type="button"
                            @click="deleteItem(`/person/${person.id}?type=restore`, person.id, deletePerson);"
                            class="btn btn-success mt-1 mb-1">بازیابی</button>
                    </div>

                </td>
            </tr>
        </table>
        <paginate :paginate="pg" @changePage="changePage" />
        <AllPersonDepended />
    </div>
</template>
<script>
import Filters from './Filters.vue'
import AllPersonDepended from './../Person/AllPersonDepended';
import { mapGetters, mapActions } from 'vuex'
export default {
    name: 'PersonList',
    props: ['data'],
    components: {
        AllPersonDepended,
        Filters
    },
    computed: {
        ...mapGetters({
            persons: 'datas',
            counts: 'count',
            pg: 'pagination',
        }),
    },
    data() {
        return {
            url: '/api/v1/person',
            replace_user: null,
            users: [],
        }
    },
    mounted() {

        if (!this.data) { this.getData() } else { this.datas = this.data }

        const url = new URL(window.location.href);
        if (url.searchParams.has('phone')) {
            axios.get(`${this.url}?user-search=${this.fixPhone(url.searchParams.get('phone'))}`)
                .then(res => {
                    if (res.data.data.some(x => x.phone == this.fixPhone(url.searchParams.get('phone')))) {
                        this.params.search = this.fixPhone(url.searchParams.get('phone'))
                        this.setUrlParam(`user-search`, this.params.search)
                        this.applyUrl()
                        return
                    }
                    $('.add-person-modal').modal('show')
                    return
                })
        }
    },
    filters: {
        showPersonRegister(registers) {
            let courses = []
            registers.map(x => courses.push(window.courses.find(n => n.id == x.course_id).name))
            return courses.join(' و ')
        }
    },
    methods: {
        ...mapActions({
            getDatas: 'getDatas',
            deletePerson: 'delete',
        }),
        fixPhone(phone) {
            if (phone.length == 8) {
                phone = "021" + phone
            } else if (phone.length == 11) {
                phone = phone
            } else if (phone.length == 12) {
                phone = phone.substring(1)
            } else if (phone.length == 13) {
                phone = phone.substring(2)
            }
            return phone;
        },

        getData(url = false) {
            this.getDatas({ data: url || this.url })
        },
    }
}
</script>
