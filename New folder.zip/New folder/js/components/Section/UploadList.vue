<template>
    <div class="uploads-list p-3">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex align-items-center">

               <div class="mot-actions-col2">
                    <small class="text-muted pr-2">نتایج: {{counts}}</small>
               </div>
            </div>
        </div>
   
            <div class="mot-pagination-header-md">
                <Filters v-if="can('use_filters')" :allows="['upload_type', 'start-date', 'end-date']" :prm="params" :uri="url" @set="setFilter" />   
            </div>
            <paginate :paginate="pg" @changePage="changePage"/>
            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    
                    <th class="mot-w-200">تصویر پیوست</th>
                    <th>نوع تصویر و مشخصات</th>
                    <th>توضیحات</th>
                    <th>اکشن</th>
                </tr>
                <tr v-for="(data, name) in webdatas" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>
                        <vue-picture-swipe v-if="data.url" :items="[
                        {src: data.url,thumbnail: data.url ,w: 1200,h: 600, title: data.comments}
                    ]"></vue-picture-swipe>
    
                    </td>
                    <td>
                        <p><strong>نام سند</strong> {{ locate(data.upload_type.name) }}</p>
                        <p><strong>پیوست به</strong> {{ locate(data.uploadable.upload_label) }}</p>
                    </td>
                    <td>{{data.comments}}</td>
                    <td class="dropdown">
                        <button class="btn dropdown-toggle mot-edit-icon-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon">
                            edit
                            </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_uploads')" type="button" class="btn btn-primary btn btn-sm d-block" data-toggle="modal" data-target=".add-uploads-modal" @click="edit({id: data.id, data: data })">ویرایش</button>
                                <button v-if="can('delete_uploads')" type="button" @click="deleteItem(`/upload/${data.id}`, data.id, deleteuploads)" class="btn btn btn-sm btn-danger d-block mt-1 w-100">حذف</button>       
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>

            <AddUploads />
    </div>
</template>
<script>
import Filters from './Filters.vue'
import AddUploads from './../Actions/AddUploads.vue'
import { mapGetters,mapActions } from 'vuex'
export default {
    name: 'UploadsList',
    props: ['data'],
    components:{
        Filters,
        AddUploads
    },
    computed: {
        ...mapGetters({
            webdatas: 'Uploads/datas',
            counts: 'Uploads/count',
            pg: 'Uploads/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/upload',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
        ...mapActions({
            add: 'Uploads/add',
            edit: 'Uploads/edit',
            getDatas: 'Uploads/get',
            deleteuploads: 'Uploads/delete',
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
    }
}
</script>