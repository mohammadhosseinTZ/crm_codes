<template>
    <div class="person-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <small v-if="can('session_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
        </div>
        <div  class="mot-pagination-header-md">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date', 'deleted','class-course','teacher-delay-status', 'session-teaching-type', 'course_branches','export','course','teacher','private','status','room']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th>کد</th>
                    <th>نام کلاس</th>
                    <th>دوره</th>
                    <th>مدرس</th>
                    <th>وضعیت</th>
                    <th>ساعت برگذاری</th>
                    <th>ساعت پایان</th>
                    <th>وضعیت استاد</th>
                    <th>توضیحات</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data,name) in this.events" :key="data.id" :class="[data.teacher_delay_status == 'has_delay' ? 'leave' : null]">
                    <td>{{name + 1}}</td>
                    <td>{{data.id}}</td>
                    <td>{{data.class.name}}</td>
                    <td>{{data.course_name}} - {{data.course_code}}</td>
                    <td>{{data.teacher_name}}</td>
                    <td>{{locate(data.statusopt.option_value)}}</td>
                    <td>{{data.from}}</td>
                    <td>{{data.to}}</td>
                    <td>
                        <div><strong>شروع استاد: </strong> {{data.teacher_start | minut}}</div>
                        <div><strong>پایان استاد: </strong> {{data.teacher_end | minut}}</div>
                        <div><strong>وضعیت تاخیر: </strong> {{locate(data.teacher_delay_status)}}</div>
                        <div><strong>تاخیر به دقیقه</strong> {{data.teacher_delay}}</div>
                    </td>
                    <td>{{data.comment}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_session')" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".manage-session-modal" @click="editSession({data: data})">ویرایش</button>
                                <button v-if="can('delete_session')" type="button" @click="deleteItem(`/session/${data.id}`, data.id, deleteSession)" class="btn btn-danger d-block mt-1 w-100" >حذف</button>           
                                <button v-if="can('delete_session') && data.deleted_at" type="button" @click="deleteItem(`/session/${data.id}?type=restore`, data.id, deleteSession)" class="btn btn-success d-block mt-1 w-100" >بازیابی</button>           
                        </div>
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>



            <div class="mt-3" v-if="can('session_statistics')">
                <table class="table table-bordered">
                    <tr v-if="statistics">
                        <th v-for="(sp, indexkey) in statistics" :key="indexkey">{{locate(sp.statusopt.option_value)}}</th>
                    </tr>
                    <tr v-if="statistics">
                        <td v-for="(sp, indexkey) in statistics" :key="indexkey">{{sp.time}}</td>
                    </tr>
                </table>
            </div>

            <CalendarSessionEditor />
    </div>
</template>
<script>



import CalendarSessionEditor from '../Class/CalendarSessionEditor.vue'
import AllPersonDepended from './../Person/AllPersonDepended';
import { mapGetters, mapActions  } from 'vuex';
import moment from 'moment'
import Filters from './Filters.vue'
export default {
    name: 'RegisterList',
    props: ['data'],
    components:{
        AllPersonDepended,
        CalendarSessionEditor,
        Filters
    },
    computed: {
        ...mapGetters({
            events: 'Calendar/events',
            counts: 'Calendar/count',
            statistics: 'Calendar/statistics',
            rooms: 'Calendar/rooms',
            pg: 'Calendar/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/session',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    filters: {
        minut(val){
            if(val){
            return moment(val).format('HH:mm')  
            }
            return val
        }
    },
   methods: {
       ...mapActions({
            getEvetns: 'Calendar/getEvetns',
            editSession: 'Calendar/editSession',
            deleteSession: 'Calendar/delete'
        }),
        getData(url = false) {
            this.getEvetns({date: url || this.url})
        },
   }
}
</script>
