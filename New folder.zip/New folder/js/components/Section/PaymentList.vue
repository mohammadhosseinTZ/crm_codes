<template>
    <div class="person-list"> 
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <small v-if="can('payment_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
        </div>
        <div  class="mot-pagination-header-md">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date', 'deleted','class-course','user_branches', 'search_price', 'export','subject' ,'subject-cat','gate-way', 'pay-status','payment-search', 'group','user-insert', 'only-fp']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <div>
            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th>وضعیت</th>
                    <th>کد</th>
                    <th>تاریخ</th>
                    <th>قیمت</th>
                    <th>روش پرداخت</th>
                    <th>ثبت کننده</th>
                    <th>برای</th>
                    <th>نام</th>
                    <th>تلفن</th>
                    <th>تعداد ثبت نامی</th>
                    <th>توضیحات</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data, name) in payments" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td role="button" v-if="data.status == 0" style="color:red" @click="changePaymentStatus(data.id)">✖</td>
                    <td role="button" v-else style="color:green" @click="changePaymentStatus(data.id)">✔</td>
                    <td>{{data.code}}</td>
                    <td>{{data.created_at}}</td>
                    <td>{{data.gates | getPrice | format}}</td>
                    <td>{{data.gates | getWays}}</td>
                    <td>{{data.user_insert ? data.user_insert.name : null}}</td>
                    <td>{{data.paymentable.supplier.name}} <span v-if="data.sr.en_name == 'courses'">{{parseInt(data.paymentable.class_course.course_code) != 999 ? 'کد: ' + data.paymentable.class_course.course_code : ''}}</span></td>
                    <td>{{data.paymentable.user.name}}</td>
                    <td>{{data.paymentable.user.phone}}</td>
                    <td>{{data.reg_count}} <i class="fa fa-print" @click="print(data);"></i></td>
                    <td>{{data.comment}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon">edit</span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="parseInt(data.status) == 0 && (can('edit_payment') || can('edit_only_payment', data.user_insert_id ))" type="button" class="btn btn-primary" data-toggle="modal" data-target=".add-payment-modal" @click="editPayment({id: data.id, data: data, user_id: data.paymentable.user_id});" >ویرایش</button>
                                <button v-if="parseInt(data.status) == 0 && can('delete_payment')" @click="deleteItem(`/payment/${data.id}`, data.id, deletePayment)" type="button" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                <button v-if="parseInt(data.status) == 0 && can('delete_payment')  && data.deleted_at" @click="deleteItem(`/payment/${data.id}?type=restore`, data.id, deletePayment)" type="button" class="btn btn-success d-block mt-1 w-100" data-toggle="modal" data-target="">بازیابی</button>           
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.paymentable.user.id" :userdata="data.paymentable.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>

        <div v-if="can('payment_statistics')" class="mt-2">
            <table class="table table-bordered">
                <tr v-if="statistics">
                    <th v-for="sp in statistics" :key="sp.option_value">{{sp.option_value}}</th>
                </tr>
                <tr v-if="statistics">
                    <td v-for="sp in statistics" :key="sp.option_value">{{sp.price}}</td>
                </tr>
            </table>
        </div>
    <AllPersonDepended />
    <PaymentReceipt v-if="selectedPayment" style="display: none" :payment="selectedPayment" />
    </div>
</template>
<script>
import AllPersonDepended from './../Person/AllPersonDepended';
import PaymentReceipt from './../global/PaymentReceipt';
import { mapGetters, mapActions } from 'vuex';
import Filters from './Filters.vue'
export default {
    name: 'PaymentList',
    props: ['data'],
    components:{
        AllPersonDepended,
        Filters,
        PaymentReceipt
    },
    computed: {
       ...mapGetters({
            payments: 'Payment/datas',
            counts: 'Payment/count',
            statistics: 'Payment/statistics',
            pg: 'Payment/pagination',
        }),
   },
    data(){
        return{
            url: '/api/v1/payment',
            allPrice: 0,
            selectedPayment: null
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods:{
        changePaymentStatus(id){
            if(!this.can('change_payment_status')) return;
            axios.get(`/api/v1/payment/${id}/changestatus`)
            .then(res => this.payments.find(x => x.id == id).status = res.data.data.status)
        },
         ...mapActions({
            getDatas: 'Payment/getDatas',
            deletePayment: 'Payment/delete',
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },

        print(data){
            var obj = this
            var dataToPrint = new Promise((resolve, reject) => {
                if(obj.selectedPayment = data){
                    resolve(obj.selectedPayment)
                }
            });

            dataToPrint.then(res => {
                var myPrintContent = document.getElementById('print-payment');
                var myPrintWindow = window.open('https://portal.aryatehran.com/payments/print', 'print');
                myPrintWindow.document.write(myPrintContent.innerHTML + `<style>@page: footer { display: none; } @page: header { display: none; } @page {margin: none; }@font-face { font-family: \"Iransans\"; src: url(\"/font/IRANSansWeb.woff2\") format(\"woff\"), url(\"/font/IRANSansWeb.woff\") format(\"woff\"), url(\"/font/IRANSansWeb.ttf\") format(\"truetype\"); } img{ width: 30%; } .content{ text-align: center; } h1, table{ margin-top: 50px; } h1, table, tfoot{ text-align: right; direction: rtl; width: 100%; } h1, table *{ color: black; font-family: \"Iransans\"; } h1{ font-size: 20px; margin-top: 10px; } th{ width: 40%; } th,td{ font-size: 14px !important; } .date{ direction: ltr; display: block; } main.py-4{ padding: 0 !important; } table { margin: 9; } </style>`);
                setTimeout(function(){
                    myPrintWindow.document.close();
                myPrintWindow.focus();
                myPrintWindow.print();
                myPrintWindow.close();  
                }, 1000)  
                return false;
            })
            
        }

    }
}
</script>
