<template>
    <div class="person-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation d-flex justify-content-between align-items-center mt-1 mb-1">
                <button v-if="can('add_person')" type="button" class="btn" data-toggle="modal" data-target=".add-person-modal" @click="addPerson();">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <div v-if="can('group_work')" class="from-group mr-2">
                    <label for="is-group">کار گروهی</label>
                    <input type="checkbox" id="is-group" @change="() => {is_group = !is_group; includes=[]}">
                </div>
                <small v-if="can('register_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
        </div>
        <div  class="mot-pagination-header-md">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date','user_branches','debt', 'deleted' , 'gender' ,'course_branches','discount_for','city','leave','service-category','export','service-search','user-insert','user', 'user-search', 'site-discount']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
            <div>
                <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th v-if="is_group" class="w-100 mot-sm-blue">
                            <groupwork :allow="['sms', 'delete']" :url="url" :type="'service_registers'" :incs="includes" :filts="params" @allpage="(ev) => manageIncludes(registers, ev)" @oselect="(ev) => groupWork(ev)" @allresult="(ev) => manageIncludes(registers, ev, 'allresult')" />
                    </th>
                    <th>نام</th>
                    <th>شماره</th>
                    <th>محصول</th>
                    <th>هزینه</th>
                    <th>پرداختی</th>
                    <th>باقی مانده</th>
                    <th>تاریخ</th>
                    <th>فیش ها</th>
                    <th class="mot-w-200">توضیحات</th>
                    <th>ثبت کننده</th>
                    <th class="mot-w-200">اکشن</th>
                </tr>
                <tr v-for="(data, name) in registers" :key="data.id" :class="[data.leave_reason_id != null ? 'leave' : '']">
                    <td>{{name + 1}}</td>
                    <td v-if="is_group"><input type="checkbox" v-model="includes" :value="data.id"></td>
                    <td>{{(parseInt(data.user.gender)  == 1 ? 'خانم' : 'آقای') + " " + data.user.name}}</td>
                    <td>{{data.user.phone}}</td>
                    <td>{{data.supplier.name}}</td>
                    <td>{{data.price | format}} 
                        <span v-for="dc in data.discount_fors" :key="dc.id" class="disconted"><span v-if="dc.option">{{searchMeta(dc.option.meta, 'discount_percent').meta_value}} درصد کسری اضافه برای {{dc.option.option_value}}</span></span>
                        <span v-if="data.site_discount">
                        <span class="disconted" v-for="sd in data.site_discount" :key="sd.name">
                                {{ Number(sd.amount) }} {{ sd.type == 'percent' ? 'درصد' : 'تومان' }} تخفیف با کد {{ sd.source != 'site' ? 'معرف  ' : null}}: {{ sd.name }}
                                <span v-if="sd.type != 'site' && sd.user" data-toggle="modal" data-target=".person-profile-modal" @click="getPersonData({id: sd.user.id});getPersonPayments(sd.user.id);getPersonRegisters({id: sd.user.id});getPersonCalls(sd.user.id);setSelectedPerson({id: sd.user.id, data: sd.user});" >(مشاهده)</span>
                        </span>
                    </span>
                    </td>

                    <td>{{data.payments | getPrice | format}} <span v-if="data.return_price" style="color: gray" class="disconted">عودت ({{data.return_price | format}})</span></td>

                    <td v-if="data.leave_reason_id == null">{{getGlose(data) | format}}</td>
                    <td v-else>{{0}}</td>

                    <td>{{data.created_at}}</td>
                    <td>
                        <button type="button" @click="setSelectedPerson({id: data.user_id, data: data.user});getPyamentsRegister({id: data.id, type: 'service-register'});" :class="getPrices(data.payments) >= data.price ? 'btn-success' : 'btn-warning'" class="btn btn-sm d-block mt-1 w-100" data-toggle="modal" data-target=".person-payments-modal">{{data.payments.length}} فیش ها</button>
                    </td>
                    <td :title="data.comment">
                        <a :href="`/export/register_regform/${data.id}?type=service-register`" target="_blank"><i class="fa fa-print"></i></a>
                        <button class="btn btn-link" type="button" data-toggle="modal" data-target=".add-register-cost" @click="getCostByRegisterId(data.id)" ><i class="fas fa-dollar-sign"></i></button>
                        {{data.comment | sub}}
                    </td>
                    <td>
                        <span v-if="data.user_insert" :class="[data.user_insert.phone == '0000000000' ? 'site_insert' : null]">
                                {{data.user_insert.name}}
                        </span>
                    </td>
                    <td class="dropdown dropdown d-flex">
                        <span v-if="hasKey('takeable', data.supplier.keys)">
                            <strong @click="setEvidenceStatus(data.id)" class="btn d-block mot-w-100 btn-sm p-1 btn-success"
                                v-if="data.is_apply_evidence">تحویل مدرک: ✔</strong>
                            <strong @click="setEvidenceStatus(data.id)" class="btn d-block mot-w-100 btn-sm p-1 btn-danger" v-else>تحویل مدرک: ✖</strong>
                        </span>
                            
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_register') || can('edit_only_register', data.user_insert_id )" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-person-service-modal" @click="edit({id:  data.id, data: data})">ویرایش</button>
                                <button v-if="can('delete_register')" type="button" @click="deleteItem(`/service-register/${data.id}`, data.id, deleteRegister)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>     
                                <button v-if="can('delete_register') && data.deleted_at" type="button" @click="deleteItem(`/service-register/${data.id}?type=restore`, data.id, deleteRegister)" class="btn btn-success d-block mt-1 w-100" data-toggle="modal" data-target="">بازیابی</button>     
                        
                                <div class="mt-2 w-100">
                                    <input class="form-control"  v-if="hasKey('scoreable', data.supplier.keys)" type="number" placeholder="نمره" v-model="data.score">
                                    <a class="btn btn-primary w-100 mt-2" v-if="hasKey('export_special' , data.supplier.keys)"  :href="`/export/register_spev/${data.id}?score=${data.score}`" target="_blank">پرینت مدرک ویژه</a>      
                                    <a class="btn btn-primary w-100 mt-2" v-if="hasKey('export_evidence' , data.supplier.keys)"  :href="`/export/register_ev/${data.id}?score=${data.score}`" target="_blank">پرینت مدرک داخلی</a>      
                                </div>
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.user.id" :userdata="data.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            </div>
            <AllPersonDepended />  
    </div>
</template>
<script>


import AllPersonDepended from './../Person/AllPersonDepended';
import { mapGetters, mapActions  } from 'vuex';
import Filters from './Filters.vue'
export default {
    name: 'ServiceRegisterList',
    props: ['data'],
    components:{
        AllPersonDepended,
        Filters
    },
    computed: {
        ...mapGetters({
            registers: 'ServiceRegister/datas',
            counts: 'ServiceRegister/count',
            pg: 'ServiceRegister/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/service-register',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    filters: {
        getPrice: function(value){
                var tmpPrice = 0;
                value.forEach(element => {
                        if(element.status == 1){
                            var prices = element.gates.map(value => value.price);
                            tmpPrice += parseInt(prices.reduce((total, num) =>{
                                return parseInt(total) + parseInt(num);
                            }));  
                        }   
                });
                return tmpPrice;
        },
        sub: function(val){
            if(typeof val == 'string'){
                return val.substring(0, 20)
            }
            return val;
        }
   },
   methods: {
       ...mapActions({
            edit: 'ServiceRegister/editRegister',
            getDatas: 'ServiceRegister/getDatas',
            deleteRegister: 'ServiceRegister/delete',
            getCostByRegisterId: 'Cost/getCostByRegisterId',

        }),
       getPrices(values){
           return this.$options.filters.getPrice(values);
       },
       getGlose(data){
            var price = this.$options.filters.getPrice(data.payments)
            return parseInt(data.price) - parseInt(price)
        },
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
        setEvidenceStatus(regid) {
            if(!this.can('apply_evidence')) return;
            axios.get(`/api/v1/service-register/${regid}/change-evidence-status`).then(res => {
                this.registers.find(x => x.id == regid).is_apply_evidence = !this.registers.find(x => x.id == regid).is_apply_evidence
            })
        }
   }
}
</script>
<style>
span.disconted {
    font-size: 11px;
    display: block;
    color: red;
    font-weight: bold;
}
</style>