<template>
    <div class="cost-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_cost_type')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-cost-type-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <small v-if="can('cost_type_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
        </div>
        <div  class="mot-pagination-header">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['start-date','end-date' ,'branches', 'search', 'costable', 'cost-category']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <table class="table table-bordered">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th>نام</th>
                    <th>دسته بندی هزینه</th>
                    <th>موضوع هزینه</th>
                    <th>دفعات هزینه شده (<span dir="ltr">{{date.join(' و ')}}</span>) اخیر</th>
                    <th>مجموع کل پرداختی (<span dir="ltr">{{date.join(' و ')}}</span>) اخیر</th>
                    <th>میانگین کل پرداختی (<span dir="ltr">{{date.join(' و ')}}</span>) اخیر</th>
                    <th>هزینه</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data, name) in costTypes" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.name}}</td>
                    <td>{{data.category.map(x => x.name).join(' و ')}}</td>
                    <td>{{locate(data.costable.name)}}</td>
                    <td>{{data.costs_count}}</td>
                    <td>{{data.costs_amount | format}}</td>
                    <td>{{data.costs_avg | format}}</td>
                    <td>{{data.price | format}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_cost_type')" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-cost-type-modal" @click="edit({id:  data.id, data: data})">ویرایش</button>
                                <button v-if="can('delete_cost_type')" type="button" @click="deleteItem(`/cost-type/${data.id}`, data.id, deleteCostType)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                        </div>
                    </td>
                </tr>
        </table>
        <paginate :paginate="pg" @changePage="changePage"/>
      

        <AddCostType />
    </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex';
import AddCostType from '../Actions/AddCostType.vue'
import Filters from './Filters.vue'
import moment from 'moment'

export default {
    name: 'CostTypeList',
    props: ['data'],
    components: {
        AddCostType,
        Filters
    },
    computed: {
        ...mapGetters({
            costTypes: 'CostType/datas',
            pg: 'CostType/pagination',
            counts: 'CostType/count',
        }),
    },
    data(){
        return{
            url: '/api/v1/cost-type',
            date: [],
        }
    },

    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}


        this.date[0] = '30 روز';
    
    },

    methods:{
        ...mapActions({
            getDatas: 'CostType/get',
            edit: 'CostType/edit',
            add: 'CostType/add',
            deleteCostType: 'CostType/delete',
        }),

        getData(url = false) {
            if(url){
                const urlParams = new URL(window.location.origin + url);
                if(urlParams.searchParams.has('date')){
                    this.date = urlParams.searchParams.get('date')
                }
            }
            
            this.getDatas({date: url || this.url})
        },

    }
}
</script>

