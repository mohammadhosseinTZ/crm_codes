<template>
    <div class="cost-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_products')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-product-modal" @click="add()"><span class="material-symbols-rounded mot-add-newItem"> add_box </span></button>
                <small  class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
        </div>
        <div  class="mot-pagination-header-md ">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['course_branches','product-category','search', 'export']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <table class="table table-bordered">
                <tr>
                    <th>ردیف</th>
                    <th>لینک سایت</th>
                    <th>کد</th>
                    <th>نام</th>
                    <th>تعداد موجودی</th>
                    <th>قیمت خرید</th>
                    <th>قیمت فروش</th>
                    <th>میانگین قیمت خرید</th>
                    <th>دسته بندی</th>
                    <th>شعبه ها</th>
                    
                    <th v-if="can('add_products')">تعداد فروش</th>
                    <th v-if="can('add_products')">تعداد موجودی اولیه</th>
                    <th v-if="can('add_products')">مجموع خریداری</th>
                    
                    <th>توضیحات</th>
                    <th>اکشن</th>
                    <th>سابقه خرید</th>
                </tr>
                <tr v-for="(data, name) in products" :key="data.id"  :title="data.id">
                    <td>{{name + 1}}</td>
                    <td width="80px" height="100px"><a class="d-block mb-2" v-for="pbranch in data.branches" v-if="pbranch.market_url" :href="pbranch.market_url + '?cm_id=' + data.id" target="_blank"> سایت شعبه {{pbranch.name}}</a></td>
                    <td dir="ltr">{{data.code}}</td>
                    <td>{{data.name}}</td>
                    <td>{{parseInt(data.is_infinite) ? 'فروش بی نهایت' : data.quantity}} {{data.unit ? locate(data.unit) : null}}</td>
                    <td>{{data.buy_price | format}} <br> 
                        <small v-if="!parseInt(data.is_infinite)">ارزش موجودی خرید: {{data.buy_price * data.quantity | format}}</small>
                    </td>
                    <td>{{data.sale_price | format}} <br> 
                        <small v-if="!parseInt(data.is_infinite)">ارزش موجودی فروش: {{data.price  * data.quantity | format}}</small>
                    </td>
                    
                    <td>{{data.avg_buy_price | format}} <br> 
                        <small v-if="!parseInt(data.is_infinite)">ارزش موجودی میانگین قیمت خرید: {{data.avg_buy_price * data.quantity | format}}</small>
                    </td>

                    <td>{{data.category | name}}</td>
                    <td>{{data.branches | name}}</td>
                    

                    <td v-if="can('add_products')">{{data.registers_count}}</td>
                    <td v-if="can('add_products')">{{data.primitive_quantity}} {{data.unit ? locate(data.unit) : null}}</td>
                    <td v-if="can('add_products')">{{data.cost_count}}</td>

                    <td>{{data.comment}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_products')" type="button" class="btn btn-success d-block" data-toggle="modal" data-target=".add-product-modal" @click="edit({id:  data.id, data: data})">ویرایش</button>
                                <div class="delete-form mt-2 text-start" v-if="can('delete_products')">
                                    <v-select placeholder="انتقال به ..."  v-model="replace_obj" :options="srs" @search:focus="search_params = 'product|name,code|srs'" v-debounce="dynamicSearch" />
                                    <button type="button" @click="deleteItem(`/product/${data.id}?product_id=${replace_obj ? replace_obj.id : null}`, data.id, deleteProduct)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                </div>
                                <button class="btn btn-success d-block d-flex text-white align-items-center"><i @click="print(data)" class="fa fa-print"></i><input max="16" v-model="repeat" class="form-control mr-1" placeholder="تعداد پرینت" type="number"></button>
                        </div>
                    </td>
                    <td class="dropdown">
                        <button class="btn  dropdown-toggle mot-history-icon-btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-history-icon">
                            timeline
                            </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <button @click="edit({id:  data.id, data: data});getPurchase({id: data.id})" class="btn btn-sm btn-primary mot-w-100" type="button" data-toggle="modal" data-target=".product-purchases-modal">سابقه خرید</button>
                        <button @click="addPP(0);fastShop({id:  data.id, data: data})" class="btn btn-sm btn-primary mot-w-100 mt-2" type="button" data-toggle="modal" data-target=".add-person-product-modal">افزودن فروش</button>
                        <button v-if="parseInt(data.parent_id)" @click="getParent(data)" class="btn btn-sm btn-primary mot-w-100 mt-2">مادر</button>
                        <button v-if="parseInt(data.childrens_count)"  @click="getChildrens(data)"  class="btn btn-sm btn-primary mot-w-100 mt-2">زیر مجموعه</button>
                        <button @click="showAll()" class="btn btn-sm btn-primary mot-w-100 mt-2 d-block">نمایش همه</button>
                    </div>
                    </td>
                </tr>
           
        </table>


        <div v-if="can('product_statistics')">
            <table class="table table-bordered">
                <tr v-if="statistics">
                    <th v-for="sp in statistics" :key="sp.name">{{sp.name}}</th>
                </tr>
                <tr v-if="statistics">
                    <td v-for="sp in statistics" :key="sp.price">{{sp.price}}</td>
                </tr>
            </table>
        </div>
      
        <AddProduct />
        <ProductsBuy />
        <AllPersonDepended />
        <Barcode v-if="selectedProduct" style="display:none"  :repeat="repeat" :product="selectedProduct" />

    </div>
</template>
<script>
import Filters from './Filters.vue'
import { mapActions, mapGetters } from 'vuex';
import AddProduct from '../Actions/AddProduct.vue'
import ProductsBuy from '../Product/ProductsBuy.vue'
import AllPersonDepended from './../Person/AllPersonDepended';
import Barcode from './../Product/Barcode';

export default {
    name: 'ProductList',
    props: ['data'],
    components: {
        AddProduct,
        ProductsBuy,
        AllPersonDepended,
        Barcode,
        Filters
    },
    computed: {
        ...mapGetters({
            products: 'Product/datas',
            pg: 'Product/pagination',
            counts: 'Product/count',
            statistics: 'Product/statistics',
        }),
    },
    filters: {
        name(data){
            let items = []
            for(var n of data){
                items.push(n.name)
            }
            return items.join(' و ')
        }
    },
    data(){
        return{
            url: '/api/v1/product',
            replace_obj: null,
            repeat: 0,
            selectedProduct: null,
            srs: []
        }
    },

    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },

    methods:{
        ...mapActions({
            getDatas: 'Product/get',
            getPurchase: 'Cost/getPurchases',
            edit: 'Product/edit',
            add: 'Product/add',
            deleteProduct: 'Product/delete',
            fastShop: 'ProductRegister/fastShop',
            addPP: 'ProductRegister/addRegister',
        }),

        getData(url = false) {
            this.getDatas({date: url || this.url})
        },
        
        getParent(data){
            delete this.params['childrens'];
            this.setUrlParam('parent', data.parent_id)
            this.applyUrl()
        },

        getChildrens(data){
            delete this.params['parent'];
            this.setUrlParam('childrens', data.id)
            this.applyUrl()
        },

        showAll(){
            delete this.params['parent'];
            delete this.params['childrens'];
            this.applyUrl()
        },

        print(data){
            if(this.repeat > 16){
                this.repeat = 16
            } 
            var obj = this
            var dataToPrint = new Promise((resolve, reject) => {
                if(obj.selectedProduct = data){
                    resolve(obj.selectedProduct)
                }
            });
          

            dataToPrint.then(res => {
                JsBarcode(".barcode").init();
                var myPrintContent = document.getElementById('print-barcode');
                var myPrintWindow = window.open('https://portal.aryatehran.com/product/print', 'print');
                myPrintWindow.document.write(myPrintContent.innerHTML + `<style>@page: footer { display: none; } @page: header { display: none; } @page {margin: none; }@font-face { font-family: \"Iransans\"; src: url(\"/font/IRANSansWeb.woff2\") format(\"woff\"), url(\"/font/IRANSansWeb.woff\") format(\"woff\"), url(\"/font/IRANSansWeb.ttf\") format(\"truetype\"); } img{ width: 30%; } .content{width: 108mm; text-align: center; } h1, table{ margin-top: 50px; } h1, table, tfoot{ text-align: right; direction: rtl; width: 100%; } h1, table *{ color: black; font-family: \"Iransans\"; } h1{ font-size: 20px; margin-top: 10px; } th{ width: 40%; } th,td{ font-size: 14px !important; } .date{ direction: ltr; display: block; } main.py-4{ padding: 0 !important; } table { margin: 9; } .content {
    width: 108mm;
}

tbody td {
    border: 1px solid;
    padding: 0px;
    font-size: 9px !important;
    width: 2.5in;
    height: 0.75in;
    display: flex;
    flex-direction: column;
    border-right: 0;
    border-left: 0;
    border-top: 0;
    /* border-bottom: 0; */
}
table {
    border-collapse: collapse;
}

table tbody tr {
    display: flex;
}
table {
    margin: 0 !important;
}

* {
    margin: 0;
    box-sizing: border-box;

}
tbody td svg {
    margin-bottom: -6px;
    margin-top: -8px;
}

tbody td strong {
    position: relative;
}

table tbody tr td:first-child {
    margin-right: 5mm;
    padding-right: 12mm;
}
table tbody tr td:last-child {
    padding-left: 12mm;
}
</style>`);
                setTimeout(function(){
                    myPrintWindow.document.close();
                myPrintWindow.focus();
                myPrintWindow.print();
                myPrintWindow.close();  
                }, 1000)  
                return false;
            })
            
        }
        

    }
}
</script>

