<template>
    <div class="person-list">
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1 mot-table-actions">
            <div class="navigation d-flex align-items-center">
                <button v-if="can('add_person')" type="button" class="btn" data-toggle="modal" data-target=".add-person-modal" @click="addPerson()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <div class="mot-actions-col2">
                    <div v-if="can('group_work')" class="from-group mr-2">
                        <label for="is-group">کار گروهی</label>
                        <input type="checkbox" id="is-group" @change="() => {is_group = !is_group; includes=[]}">
                    </div>
                    <small v-if="can('call_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
               </div>
            </div>
        </div>

        <div class="mot-pagination-header">
            <Filters v-if="can('use_filters')" :allows="['start-date','end-date', 'user_branches', 'deleted', 'gender', 'course_branches', 'subject','group','export','glose','one_person','no_leave','no_register','user-insert','leave','user', 'user-search']" :prm="params" :uri="url" @set="setFilter" />      
            <paginate :paginate="pg" @changePage="changePage"/>
        
        </div>

            <table class="table">
                <tr>
                    <th class="mot-w-45">ردیف</th>
                    <th  v-if="is_group" class="w-100 mot-sm-blue">
                        <groupwork :allow="['sms', 'delete']" :url="url" :type="'calls'" :incs="includes" :filts="params" @allpage="(ev) => manageIncludes(calls, ev)" @oselect="(ev) => groupWork(ev)" @allresult="(ev) => manageIncludes(calls, ev, 'allresult')" />
                    </th>
                    <th class="mot-w-200">نام</th>
                    <th class="mot-w-200">شماره</th>
                    <th class="mot-w-200">موضوع</th>
                    <th class="mot-w-200">دسته بندی</th>
                    <th class="mot-w-200">تاریخ</th>
                    <th class="mot-w-200">پیگیری</th>
                    <th class="mot-w-300">توضیحات</th>
                    <th class="mot-w-200">ثبت کننده</th>
                    <th class="mot-w-45">اکشن</th>
                </tr>
                <tr v-for="(data, name) in calls" :key="data.id" :class="[data.leave_reason_id != null ? 'leave' : '']">
                    <td>{{name + 1}}</td>
                    <td v-if="is_group"><input type="checkbox" v-model="includes" :value="data.id"></td>
                    <td>{{(parseInt(data.user.gender)  == 1 ? 'خانم' : 'آقای') + " " + data.user.name}} ({{data.registers_count}})</td>
                    <td>{{data.user.phone}}</td>
                    <td>{{data.callable ? data.callable.name : null}} {{data.pursuit_date ? '(پیگیری)' : null}}</td>
                    <td>{{data.subject.name}} </td>
                    <td>{{data.created_at}}</td>
                    <td>{{data.pursuit_date}}</td>
                    <td>{{data.comment}}</td>
                    <td>{{data.user_insert.name}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_call') || can('edit_only_call', data.user_insert_id )" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-call-modal" @click="editCall({id: data.id, data: data })">ویرایش</button>
                                <button v-if="can('delete_call')" type="button" @click="deleteItem(`/call/${data.id}`, data.id, deleteCall)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                <button v-if="can('delete_call')  && data.deleted_at" type="button" @click="deleteItem(`/call/${data.id}?type=restore`, data.id, deleteCall)" class="btn btn-success d-block mt-1 w-100" data-toggle="modal" data-target="">بازیابی</button>           
                        </div>
                    </td>
                    <td>
                        <PersonButtons :id="data.user.id" :userdata="data.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
            <AllPersonDepended />
    </div>
</template>
<script>
import AllPersonDepended from './../Person/AllPersonDepended';
import Filters from './Filters.vue'
import { mapGetters,mapActions } from 'vuex'
export default {
    name: 'CallList',
    props: ['data'],
    components:{
        AllPersonDepended,
        Filters
    },
    computed: {
        ...mapGetters({
            calls: 'Call/datas',
            counts: 'Call/count',
            pg: 'Call/pagination',
        }),
    },
    data(){
        return{
            url: '/api/v1/call',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
        ...mapActions({
            addCall: 'Call/addCall',
            editCall: 'Call/editCall',
            getDatas: 'Call/getDatas',
            deleteCall: 'Call/delete',
        }),
        getData(url = false) {
            this.getDatas({data: url || this.url})
        },
    }
}
</script>
