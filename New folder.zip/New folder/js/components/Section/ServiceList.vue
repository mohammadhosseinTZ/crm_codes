<template>
    <div class="cost-list">
        <div class="d-flex align-items-center justify-content-between mot-table-actions">
            <div class="navigation">
                <button v-if="can('add_service')" type="button" class="btn mt-1 mb-1" data-toggle="modal" data-target=".add-service-modal" @click="add()">
                    <span class="material-symbols-rounded mot-add-newItem"> add_box </span>
                </button>
                <small  class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
        </div>
        <div  class="mot-pagination-header">
            <paginate :paginate="pg" @changePage="changePage"/>

            <Filters v-if="can('use_filters')" :allows="['course_branches','service-category','search']" :prm="params" :uri="url" @set="setFilter" />      
        </div>
        <table class="table table-bordered">
                <tr>
                    <th>نام</th>
                    <th>قیمت</th>
                    <th>دسته</th>
                    <th>شعبه</th>
                    <th>اکشن</th>
                    <th class="mot-w-100">زیرمجموعه ها</th>
                </tr>
                <tr v-for="(data, name) in services" :key="data.id"  :title="data.id">
                    <td>{{data.name}}</td>
                    <td>{{data.price | format}}</td>
                    <td>{{data.category | name}}</td>
                    <td>{{data.branches | name}}</td>
                    <td class="dropdown">
                        <button class="btn mot-edit-icon-btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="material-symbols-rounded mot-edit-icon"> edit </span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                <button v-if="can('edit_service')" type="button" class="btn btn-primary d-block" data-toggle="modal" data-target=".add-service-modal" @click="edit({id:  data.id, data: data})">ویرایش</button>
                                
                                <div class="delete-form mt-2 text-start" v-if="can('delete_service')">
                                    <v-select placeholder="انتقال به ..."  v-model="replace_obj" :options="srs"  @search:focus="search_params = 'service|name|srs'" v-debounce="dynamicSearch" />
                                    <button v-if="can('delete_service')" type="button" @click="deleteItem(`/service/${data.id}?service_id=${replace_obj ? replace_obj.id : null}`, data.id, deleteService)" class="btn btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                </div>
                        </div>
                    </td>
                    <td class="text-center">
                        <button v-if="parseInt(data.parent_id)" @click="getParent(data)" class="btn btn-sm btn-warning">مادر</button>
                        <button v-if="parseInt(data.childrens_count)"  @click="getChildrens(data)"  class="btn btn-sm btn-warning">زیر مجموعه</button>
                        <button @click="showAll()" class="btn btn-sm btn-primary">نمایش همه</button>
                    
                    </td>
                </tr>
           
        </table>
      
        <AddService />
    </div>
</template>
<script>
import { mapActions, mapGetters } from 'vuex';
import Filters from './Filters.vue'
import AddService from '../Actions/AddService.vue'
export default {
    name: 'ProductList',
    props: ['data'],
    components: {
        AddService,
        Filters
    },
    computed: {
        ...mapGetters({
            services: 'Service/datas',
            pg: 'Service/pagination',
            counts: 'Service/count',
        }),
    },
    filters: {
        name(data){
            let items = []
            for(var n of data){
                items.push(n.name)
            }
            return items.join(' و ')
        }
    },
    data(){
        return{
            url: '/api/v1/service',
            replace_obj: null,
            srs: []
        }
    },

    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },

    methods:{
        ...mapActions({
            getDatas: 'Service/get',
            edit: 'Service/edit',
            add: 'Service/add',
            deleteService: 'Service/delete',
        }),

        getData(url = false) {
            this.getDatas({date: url || this.url})
        },

        getParent(data){
            delete this.params['childrens'];
            this.setUrlParam('parent', data.parent_id)
            this.applyUrl()
        },

        getChildrens(data){
            delete this.params['parent'];
            this.setUrlParam('childrens', data.id)
            this.applyUrl()
        },

        showAll(){
            delete this.params['parent']
            delete this.params['childrens'] 
            this.applyUrl()
        }
        

    }
}
</script>

