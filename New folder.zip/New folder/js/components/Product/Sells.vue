<template>
    <div>
        <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <small v-if="can('payment_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date','end-date', 'fund-card','gate-way','payment-search','user-insert']" :prm="params" :uri="url" @set="setFilter" />      
        <div>
            <table class="table">
                <tr>
                    <th>ردیف</th>
                    <th>کد</th>
                    <th>تاریخ</th>
                    <th>قیمت</th>
                    <th>روش پرداخت</th>
                    <th>ثبت کننده</th>
                    <th>نام</th>
                    <th>تلفن</th>
                    <th>توضیحات</th>
                    <th>اکشن</th>
                </tr>
                <tr v-for="(data, name) in sells" :key="data.id">
                    <td>{{name + 1}}</td>
                    <td>{{data.code}}</td>
                    <td>{{data.created_at}}</td>
                    <td>{{data.gates | getPrice | format}}</td>
                    <td>{{data.gates | getWays}}</td>
                    <td>{{data.user_insert.name}}</td>
                    <td>{{data.paymentable.user.name}}</td>
                    <td>{{data.paymentable.user.phone}}</td>
                    <td>{{data.comment}}</td>
                    <td>
                        <PersonButtons :id="data.paymentable.user.id" :userdata="data.paymentable.user" />
                    </td>
                </tr>
            </table>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>

        <Statistics v-if="can('payment_statistics') && statistics" :statistics="statistics" :title="'آمار فروش'" />
        <AllPersonDepended />
    </div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
import AllPersonDepended from './../Person/AllPersonDepended';
import Filters from './../Section/Filters.vue'
import Statistics from './../global/Statistics.vue'
export default {
    name: "Sells",
    components:{
        AllPersonDepended,
        Filters,
        Statistics
    },
    computed: {
        ...mapGetters({
            product: 'Product/data',
            sells: 'Product/sells',
            counts: 'Product/sellCount',
            statistics: 'Product/sellStatistics',
            pg: 'Product/sellPagination',
        })
    },
    data(){
        return{
            url: '/api/v1/product/sell/{pid}',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
       ...mapActions({
            getSells: 'Product/getSells'
        }),
        getData(url = '') {
            this.getSells({data: url.replace('{pid}', this.product.insideId) || this.url.replace('{pid}', this.product.insideId), id: this.product.insideId})
        },
   }
}
</script>