<template>
<div class="product-purchases">
    <div class="modal fade product-purchases-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">خرید های: {{product.name}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                    <Purchases />
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import Purchases from './Purchases.vue'
import { mapGetters,mapActions } from 'vuex';
export default {
    name: "ProductsBuy",
    components: {
        Purchases
    },
    computed: {
        ...mapGetters({
            product: 'Product/data',
        })
    },
}
</script>