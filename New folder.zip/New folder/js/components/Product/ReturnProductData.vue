<template>
    <div class="person-calls-simple">
                    <div class="modal-header d-flex alert alert-warning h6 align-items-center">
                        <div>
                                انصراف های: {{register.insideId}}
                        </div>
                        <div class="mr-3">
                            <button v-if="can('add_return')" type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".add-return-product-modal" @click="add(register)">افزودن</button>
                        </div>
                    </div>
                     <table class="table mt-1">
                         <tr>
                             <th>وضعیت</th>
                             <th>نام آیتم</th>
                             <th>تعداد عودت</th>
                             <th>قیمت عودت</th>
                             <th>علت عودت</th>
                             <th>توضیحات</th>
                             <th>تاریخ عودت</th>
                             <th>اکشن</th>
                         </tr>
                         <tr v-for="data in returns" :key="data.id">
                            <td role="button" v-if="data.status == 0" style="color:red" @click="changeReturnStatus(data.id)">✖</td>
                            <td role="button" v-else style="color:green" @click="changeReturnStatus(data.id)">✔</td>
                            <td>{{data.register_item.supplier.name}}</td>
                            <td>{{data.quantity}} {{locate(data.register_item.unit)}} از {{data.register_item.quantity}} {{locate(data.register_item.unit)}}</td>
                            <td>{{data.price | format}} از {{data.register_item.price | format}}</td>
                            <td>{{data.leave_reason ? data.leave_reason.option_value : null}}</td>
                            <td>{{data.comment}}</td>
                            <td>{{data.created_at}}</td>
                            <td class="dropdown">
                                <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    اطلاعات
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <button v-if="parseInt(data.status) == 0 && can('edit_return')" type="button" class="btn  btn-sm btn-primary" data-toggle="modal" data-target=".add-return-product-modal" @click="edit({id: data.id, data: data});" >ویرایش</button>
                                        <button v-if="parseInt(data.status) == 0 && can('delete_return')" @click="deleteItem(`/return-product/${data.id}`, data.id, deleteReturn)" type="button" class="btn  btn-sm btn-danger d-block mt-1 w-100" data-toggle="modal" data-target="">حذف</button>           
                                </div>
                            </td>
                         </tr>
            
                     </table>
                </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex';
export default {
   name:"ReturnProductData",
   computed: {
       ...mapGetters({
            returns: 'ProductRegisterReturn/datas',
            register: 'ProductRegister/register',
       }),
   },
   methods:{
    ...mapActions({
        deleteReturn: 'ProductRegisterReturn/delete',
        edit: 'ProductRegisterReturn/edit',
        add: 'ProductRegisterReturn/add'
    }),
    changeReturnStatus(id){
            if(!this.can('change_return_status')) return;
            axios.get(`/api/v1/return-product/${id}/changestatus`)
            .then(res => this.returns.find(x => x.id == id).status = res.data.data.status)
        },
   }
}
</script>
