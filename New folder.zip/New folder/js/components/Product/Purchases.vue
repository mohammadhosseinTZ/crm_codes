<template>
<div class="product-purchases-data">
    
    <div class="d-flex justify-content-between align-items-center mt-1 mb-1">
            <div class="navigation">
                <button v-if="can('add_costs')" type="button" class="btn  mt-1 mb-1" data-toggle="modal" data-target=".add-cost-modal" data-backdrop="static" data-keyboard="false" @click="add(product)"><span class="material-symbols-rounded mot-add-newItem"> add_box </span></button>
                <small v-if="can('costs_statistics')" class="text-muted pr-2">نتایج: {{counts}}</small>
            </div>
            <paginate :paginate="pg" @changePage="changePage"/>
        </div>
        <Filters v-if="can('use_filters')" :allows="['start-date','end-date','bank', 'gate-way' , 'cost-type' , 'user-insert']" :prm="params" :uri="url" @set="setFilter" />      
        <CostItem :costs="purchases" />
        <paginate :paginate="pg" @changePage="changePage"/>
    <AddCost />
    <AddAllocationItem />
</div>
</template>

<script>
import CostItem from './../global/CostItem.vue'
import { mapGetters,mapActions } from 'vuex';
import Filters from './../Section/Filters.vue'
import AddCost from './../Actions/AddCost.vue'
import AddAllocationItem from './../Actions/AddAllocationItem.vue'
import Statistics from './../global/Statistics.vue'
export default {
    name: "Purchases",
    components: {
        Filters,
        AddCost,
        Statistics,
        CostItem,
        AddAllocationItem
    },
    computed: {
        ...mapGetters({
            product: 'Product/data',
            purchases: 'Cost/datas',
            counts: 'Cost/count',
            statistics: 'Cost/statistics',
            pg: 'Cost/pagination',
        })
    },
    data(){
        return{
            url: '/api/v1/product/purchase/{pid}',
        }
    },
    mounted(){
        if(!this.data){ this.getData()} else{ this.datas = this.data}
    },
    methods: {
       ...mapActions({
            getPurchase: 'Cost/getPurchases',
            edit: 'Cost/edit',
            add: 'Cost/addProduct',
            deleteCost: 'Cost/delete',
            changeCostStatus: 'Cost/changeStatus'
        }),
        getData(url = '') {
            this.getPurchase({data: url.replace('{pid}', this.product.insideId) || this.url.replace('{pid}', this.product.insideId), id: this.product.insideId})
        },

        checkCan(id){
          if(this.can('change_costs_status')){
                this.changeCostStatus(id)
           }
        },
        changeStockStatus(data){
            axios.get(`/api/v1/cost/${data.id}/change-delivered-status`).then(res => {
                this.purchases.find(x => x.id == data.id).delivered = res.data.data.delivered
            })
        }
   }
}
</script>