<template>
    <div id="print-barcode">
        <div class="content">
            <table>
                <tr v-for="time in Math.ceil(repeat / 2)">
                    <td>
                        <svg class="barcode" :jsbarcode-value="product.code" jsbarcode-displayvalue="false" jsbarcode-width="1.2" jsbarcode-height="15"></svg>
                        <strong style="display:none">{{product.code}}</strong>
                        <strong>{{product.name}}</strong>
                        <strong>{{product.price | format}} تومان</strong>
                    </td>
                    <td>
                        <svg class="barcode"  :jsbarcode-value="product.code" jsbarcode-displayvalue="false" jsbarcode-width="1.2" jsbarcode-height="15"></svg>
                        <strong style="display:none">{{product.code}}</strong>
                        <strong>{{product.name}}</strong>
                        <strong>{{product.sale_price | format}} تومان</strong>
                    </td>
                </tr>
            </table>
        </div>
        </div>
</template>
<script>
export default{
    name: "Barcode",
    props: ['product', 'repeat'],
}
</script>


