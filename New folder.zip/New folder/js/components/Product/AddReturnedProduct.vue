<template>
    <div class="add-return-product">
        
        <div class="modal fade add-return-product-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="d-flex align-items-center justify-content-between w-100">
                            <div class="d-flex">
                                <h5 class="modal-title">افزودن/ ویرایش انصراف از خرید</h5>
                            </div>
                            <button type="button" class="close mx-0" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    </div>
                    <div class="model-body">
                     <form action="" @submit.stop.prevent="">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row m-0">
                            
                        <div class="col-md-6 form-group">
                            <label for="prodcut" class="d-flex">انتخاب آیتم انصرافی</label>
                            <v-select @input="getItem()" id="prodcut" v-model="returnProduct.register_item" :options="register.items.map(x => {x.label = x.supplier.name; return x;})" />
                        </div>
                        <div class="col-md-2 mb-2">
                                <label for="quantity">تعداد</label>
                                <input step="0.001" type="number" class="form-control" id="quantity" v-model="returnProduct.quantity" placeholder="تعداد" />  
                        </div>
                        <div class="col-md-4 form-group">
                            <label for="price">مبلغ انصرافی</label>
                            <input  class="form-control" type="number" v-model="returnProduct.price" id="price">
                        </div>
                        <div class="col-md-6 form-group">
                            <label for="dpricefor">دلیل انصراف از خرید</label>
                            <v-select id="dpricefor" placeholder="دلیل کسری اضافه"  v-model="returnProduct.leave_reason" :options="leave_reasons" />
                        </div>

                             
                        <div class="col-md-6 form-group">
                            <label for="">تاریخ</label>
                            <date-picker format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="returnProduct.created_at"></date-picker>
                        </div>

                        <div class="col-md-12 form-group">
                            <label for="comments">توضیحات</label>
                            <textarea class="form-control" v-model="returnProduct.comment" id="comments"></textarea>
                        </div>

                        <div class="col-md-6 form-group">
                            <input type="button" @click="addData" class="form-control" :value="[returnProduct.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                        </div>
                    </div>
                   </form>
                </div>

                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import { mapGetters,mapActions } from 'vuex';
export default {
   name:"AddReturnedProduct",
   computed: {
       ...mapGetters({
            returnProduct: 'ProductRegisterReturn/data',
            register: 'ProductRegister/register',
       }),
   },
   data(){
    return {
        leave_reasons: window.return_reasons,
    }
   },
   methods: {
       ...mapActions({
            update: 'ProductRegisterReturn/update',
        }),
        getItem(){
            if(!this.returnProduct.register_item) return;
            this.returnProduct.price = this.returnProduct.register_item.price
            this.returnProduct.quantity = this.returnProduct.register_item.quantity
        },
        addData() {
            this.returnProduct.register = this.register
            this.vr(this.returnProduct.register, 'خرید');
            this.vr(this.returnProduct.register_item, 'آیتم خرید');
            this.vr(this.returnProduct.quantity, 'تعداد');
            this.vr(this.returnProduct.leave_reason, 'علت انصراف از خرید');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/return-product', this.returnProduct)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.returnProduct.insideId = res.data.data.id;
                this.returnProduct.insideType = 'update';
                this.update(res.data.data)
                
                $('.add-return-product-modal').modal('hide')
            });
        }

   }
}
</script>
