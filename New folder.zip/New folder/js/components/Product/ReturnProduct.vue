<template>
    <div class="return-product">
        
        <div class="modal fade return-product-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <return-prodcuts />
                </div>
            </div>
        </div>    
    </div>
</template>
<script>
import ReturnProductData from './ReturnProductData.vue'
export default {
   name:"ReturnProduct",
   components:{
       'return-prodcuts': ReturnProductData
   }
}
</script>
