<template>
<div class="product-profile">
    <div class="modal fade product-profile-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">پروفایل: {{product.name}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body p-3">
                    <table  class="table table-bordred">
                        <tr>
                           <td rowspan="4"><img class="preview" :src="product.product_image" v-if="isValidHttpUrl(product.product_image)"></td>
                            <td>
                                <strong>نام محصول: </strong>
                                <span><span dir="ltr">{{product.code}}</span> {{product.name}}</span>
                            </td>
                            <td>
                                <strong>قیمت فروش: </strong>
                                <span>{{product.sale_price}}</span>
                            </td>
                            <td>
                                <strong>قیمت خرید: </strong>
                                <span>{{product.buy_price}}</span>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <strong>موجودی: </strong>
                                <span>{{product.quantity}}</span>
                            </td>
                            <td>
                                <strong>تعداد فروش: </strong>
                                <span v-if="sellCount">{{sellCount}}</span>
                            </td>
                        </tr>


                    </table>
                    <hr>
                    <Statistics v-if="can('payment_statistics') && statisticsCost" :statistics="statisticsCost" :title="'آمار خرید'" />
                    <Statistics v-if="can('payment_statistics') && statisticsSell" :statistics="statisticsSell" :title="'آمار آمار فروش'" />
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import Statistics from './../global/Statistics.vue'
import { mapGetters,mapActions } from 'vuex';
export default {
    name: "ProductsBuy",
    components: {
        Statistics
    },
    computed: {
            ...mapGetters({
            product: 'Product/data',
            statisticsCost: 'Cost/statistics',
            statisticsSell: 'Product/sellStatistics',
            sellCount: 'Product/sellCount',
        })
    },
    methods: {
        isValidHttpUrl(string) {
            let url;
            try {
                url = new URL(string);
            } catch (_) {
                return false;
            }
            return url.protocol === "http:" || url.protocol === "https:";
        },
    }
}
</script>