<template>
    <div class="teacher-index">
        <h6 class="alert alert-success">جلسات باقیمانده از امروز</h6>
        <div>
            <table class="table table-bordered">
                <tr>
                    <th>کد</th>
                    <th>نام کلاس</th>
                    <th>دوره</th>
                    <th>وضعیت</th>
                    <th>ساعت برگذاری</th>
                    <th>کلاس آنلاین</th>
                    <th>توضیحات</th>
                </tr>
                <tr v-for="(data,name) in todaySessions" :key="data.id">
                    <td>{{data.id}}</td>
                    <td>{{data.class.name}}</td>
                    <td>{{data.course_name}} - {{data.course_code}}</td>
                    <td>{{locate(data.statusopt.option_value)}}</td>comment
                    <td>{{data.from | date_structure}} تا {{data.to | date_structure}} <br> <button  type="button" v-if="can('can_see_rollcall')" class=" btn-warning btn-sm border-0" data-toggle="modal" @click="getRollCallDatas({session: data})" data-target=".session-rollcall-modal" >حضورغیاب</button></td>
                    <td><a class="btn btn-success btn-sm" v-if="data.online_link" :href="data.online_link" target="_blank">ورود به کلاس آنلاین</a></td>
                    <td>{{data.comment}}</td>
                </tr>
            </table>
        </div>
        <hr>
        <h6 class="alert alert-warning">جلسات فردا</h6>
        <div>
            <table class="table table-bordered">
                <tr>
                    <th>کد</th>
                    <th>نام کلاس</th>
                    <th>دوره</th>
                    <th>وضعیت</th>
                    <th>ساعت برگذاری</th>
                    <th>توضیحات</th>
                </tr>
                <tr v-for="(data,name) in tomorrowSessions" :key="data.id">
                    <td>{{data.id}}</td>
                    <td>{{data.class.name}}</td>
                    <td>{{data.course_name}} - {{data.course_code}}</td>
                    <td>{{locate(data.statusopt.option_value)}}</td>
                    <td>{{data.from | date_structure}} تا {{data.to | date_structure}}</td>
                    <td>{{data.comment}}</td>
                </tr>
            </table>
        </div>
        <hr>
        <h6 class="alert alert-primary">همه جلسات شما</h6>
        <Filters :allows="['start-date','end-date']" :prm="params" :uri="url" @set="setFilter" />
        <paginate :paginate="pagination" @changePage="changePage"/>
        <div>
            <table class="table table-bordered">
                <tr>
                    <th>کد</th>
                    <th>نام کلاس</th>
                    <th>دوره</th>
                    <th>وضعیت</th>
                    <th>ساعت برگذاری</th>
                    <th>توضیحات</th>
                </tr>
                <tr v-for="(data,name) in datas" :key="data.id">
                    <td>{{data.id}}</td>
                    <td>{{data.class.name}}</td>
                    <td>{{data.course_name}} - {{data.course_code}}</td>
                    <td>{{locate(data.statusopt.option_value)}}</td>
                    <td>{{data.from}} تا {{data.to}}</td>
                    <td>{{data.comment}}</td>
                </tr>
            </table>
        </div>
        <paginate :paginate="pagination" @changePage="changePage"/>

            <button class="btn btn-sm btn-primary salary-reports mt-4 mot-w-100"
                        data-toggle="modal" data-target=".teacher-salary-reports-modal" @click="getSalaryReport({data: teacher})"
                        >گزارشات</button>
        <Rollcallsessions />
        <TeacherSalaryReport />
    </div>
</template>
<script>
import Filters from '../Section/Filters.vue'
import Rollcallsessions from '../Class/Rollcallsessions.vue'
import TeacherSalaryReport from './../Accounting/Salary/TeacherSalaryReport.vue'
import notify from './../../bootstrap.js'
import {mapActions, mapGetters} from 'vuex'
import moment from 'moment'
export default {
    name: "TeacherIndex",
    components: {
        Filters,
        Rollcallsessions,
        TeacherSalaryReport
    },
    data(){
        return{
            url: '/api/v1/teacher',
            todaySessions: [],
            tomorrowSessions: [],
            statistics: [],
            teacher: window.user
        }
    },
    mounted(){
        var today = moment(new Date()).format('YYYY-MM-DD')
        var tomorrow = moment(new Date()).add(1, 'days').format('YYYY-MM-DD')

        this.getData().then(res => {
            this.statistics = res.data.metadata ? res.data.metadata.statistics : null
            for(var item of res.data.data){
                if(moment(item.start).format('YYYY-MM-DD') == today){
                    this.todaySessions.push(item)
                }
                if(moment(item.start).format('YYYY-MM-DD') == tomorrow){
                    this.tomorrowSessions.push(item)
                }
            }
        })

        for(var s of this.todaySessions){
            s.showed_message = false;
        }

        setInterval(() => {
            for(var s of this.todaySessions){
                var olderDate = moment(s.end).subtract(5, 'minutes').format('YYYY-MM-DD HH:mm:ss');
                var now = moment(new Date).format('YYYY-MM-DD HH:mm:ss')
                if(olderDate <= now &&  !s.showed_message){
                    notify({
                        title: "پایان کلاس",
                        body: "زمان کلاس شما به اتمام رسیده است. لطفا خروج خود را ثبت کنید"
                    })
                    s.showed_message = true
                }
                
            }
        }, 1000 * 60);

    },
    filters:{
        date_structure(val){
            return moment(new Date(val)).format('hh:mm');
        }
    },  
    methods: {
        ...mapActions({
            getSalaryReport: "TeachersSalary/salaryReport",
            getRollCallDatas: 'RollCall/getDatas'
        }),
    }
}
</script>
