<template>
    <!-- Modal -->
<div class="add-payment">
    <div class="modal fade add-payment-modal" id="addpayment" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش فیش</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                     <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs m-0">
                            <div class="form-group mt-1">
                                <label for="course">
                                    :کد فیش
                                    <div v-if="can('add_any_payment_code')">
                                        <small class="text-primary pointer" v-for="branch in branches" :key="branch.id" @click="getCodeBranch(branch.id)"><strong>({{ branch.name }})</strong> - </small>
                                    </div>
                                </label>
                                <input :disabled="!can('add_any_payment_code')" class="form-control" type="text" v-model="payment.code">
                                
                            </div>
                            <div class="form-group mt-1">
                                <label for="subject">موضوع</label>
                                <v-select @input="changeSubject"  id="subject" v-model="payment.register_type" :options="servicesList" />
                            </div>
                            <div class="form-group mt-1">
                                <label for="course">برای</label>
                                <select v-model="payment.register_id">
                                                <option v-for="dw in personRegisters" :key="dw.id" :value="dw.id">{{dw.supplier.name}}</option>
                                </select>
                            </div>
                            <div class="form-group mt-1">
                                <label for="category">توضیحات</label>
                                <input type="text" class="form-control" id="desc" v-model="payment.desc">
                            </div>
        
                            <div class="form-group mt-1">
                                <label for="">تاریخ</label>
                                <date-picker format="jYYYY-jMM-jDD HH:mm"  display-format="jYYYY-jMM-jDD HH:mm" type="datetime" auto-submit v-model="payment.created_at"></date-picker>
                            </div>
                            
                            <div class="paymentway">
                                <div class="row mb-1 mot-modal-inputs" v-for="way in payment.ways" :key="way.chash_way_id">
                                    <div class="col form-group mt-1">
                                        <select v-model="way.chash_way_id">
                                            <option v-for="dw in paymentGateWays" :key="dw.id" :disabled="payment.ways.filter(e => e.chash_way_id === dw.id).length > 0" :value="dw.id">{{dw.option_value}}</option>
                                        </select>
                                    </div>
                                    <div class="col form-group mt-1">
                                        <input type="number" v-model="way.price" placeholder="هزینه">
                                    </div>
                                    <div class="col form-group mt-1"><button type="button" class="btn btn-sm btn-warning" @click="minusWay(way)">-</button></div>
                    
                                </div>
                                <button type="button" class="btn btn-sm btn-primary" @click="addPaymentWay" :disabled="this.payment.ways.length >= Object.keys(this.paymentGateWays).length">+</button>
                            </div>
                            
                            <div class="form-group mt-1">
                                <input type="submit" class="form-control" :value="[payment.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                            </div>

                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';

export default {
    name:"AddPayment",
    computed: {
        ...mapGetters({selectedPerson: 'selectedPerson', payment: 'Payment/payment', payments: 'payments'})
    },
    watch:    {
        payment: {
            handler:function (newItem) {
               this.getRegisters(newItem.user_id || newItem.insideId, newItem.register_type.id)
            },
            deep:true
        }
    },
    data(){
         return{
            paymentGateWays: window.gateWays,
            servicesList: window.serviceList,
            personRegisters: {},
            branches: window.branches,
            beforeId: null,
            beforeType: null
        }
    },
    methods: {
        ...mapActions({
            updatePaymentData: 'Payment/updatePaymentData',
            updateRegistersPayment: 'Register/updateRegistersPayment',
            updatePersonPaymentData: 'updatePersonPaymentData'
        }),
  
        addData() {
            var promises = [];
            promises.push(this.vr(this.payment.code, 'کد'))
            promises.push(this.payment.insideType != 'update' ?? this.unique(this.payment.code, 'payments.code', 'کد'));
            promises.push(this.vr(this.payment.ways, 'روش پرداخت'));
            promises.push(this.vr(this.payment.register_id, 'فیش برای'));
            for(var n in this.payment.ways){
                promises.push(this.vr(this.payment.ways[n].price, 'هزینه'));
                promises.push(this.vr(this.payment.ways[n].chash_way_id, 'روش پرداخت'));
            }
            Promise.all(promises)
            .then(values => {
                if(!this.v_error_check()) return;
                axios.post('/api/v1/payment', this.payment)
                .then(res => {
                    if(res.data.alert && res.data.alert.type == 'error') return;
                    this.payment.insideId = res.data.data.id;
                    this.payment.insideType = 'update';

                    this.updatePersonPaymentData(res.data.data);
                    this.updatePaymentData(res.data.data)
                    this.updateRegistersPayment(res.data.data)
                    $('.add-person-modal').modal('hide')
                    $('.add-payment-modal').modal('hide')
                });
            })     
            
        },
        addPaymentWay(){
            if(this.payment.ways.length <= Object.keys(this.paymentGateWays).length)
                this.payment.ways.push({id:null,price:null});
        },
        minusWay(way){
            this.payment.ways = this.payment.ways.filter(x => x.chash_way_id !== way.chash_way_id);
        },

        getRegisters(id, type){
            if(!id) return;
            this.beforeId = id
            this.beforeType = type
            axios.get(`/api/v1/person/reg-by-services/${id}/${type}`)
            .then(res => {
                this.personRegisters = res.data
            });
        },
        changeSubject(){
            this.payment.register_id = null
            axios.get(`/api/v1/person/reg-by-services/${this.payment.user_id || this.payment.insideId}/${this.payment.register_type.id}`)
            .then(res => this.personRegisters = res.data);
        },

        getCodeBranch(branch_id){
            axios.get(`/api/v1/payment/get-code?branch_id=${branch_id}`).then(res => {
                this.payment.code = res.data.code
            })
        }

    }

}
</script>
