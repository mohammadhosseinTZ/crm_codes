<template>
    <!-- Modal -->
<div class="add-contract">
    <div class="modal fade add-contract-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                        </ul>
                       <div class="row mot-modal-inputs-6 m-0">

                            
                        <div class="form-group">
                            <label for="name">name</label>
                            <input type="text" class="form-control" id="name" v-model="contract.name">
                        </div>
            
                        <div class="form-group">
                            <label for="form_name">form_name</label>
                            <input type="text" class="form-control" id="form_name" v-model="contract.form_name">
                        </div>
            
                        <div class="form-group">
                            <label for="model_name">model_name</label>
                            <input type="text" class="form-control" id="model_name" v-model="contract.model_name">
                        </div>
            

                            <div class="row">
                                <div class="form-group">
                                        <input type="submit" class="form-control" :value="[contract.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                                </div>
                            </div>
                          
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

    </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddContract",
    computed: {
        ...mapGetters({
            contract: 'Contract/data'
        })
    },
    data(){
        return{
           
        }
    },
 
    methods: {
        ...mapActions({
            update: 'Contract/update'
        }),

        addData() {
            // this.vr(data,  alert);
            if(!this.v_error_check()) return;

            axios.post('/api/v1/contract', this.contract)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.contract.insideId = res.data.data.id;
                this.contract.insideType = 'update';


                this.update(res.data.data)
               
                $('.add-contract-modal').modal('hide')
            });
        }

    }

}
</script>