<template>
    <popup name="person-product">
        <template v-slot:header>
            <h5 class="modal-title">افزودن/ ویرایش خرید</h5>
        </template>
        <template v-slot:content>
            <form action="" @submit.stop.prevent="">
                <ul class="err-box">
                    <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                </ul>
                <div class="row m-0">

                    <div class="row mot-modal-inputs p-0 col-12">

                        <div v-if="register.fast_shop" class="form-group">
                            <label for="gender" class="label">جنسیت:</label>
                            <select class="form-control" id="gender" v-model="register.user_data.gender">
                                <option :value="'0'">آقا</option>
                                <option :value="'1'">خانم</option>
                            </select>
                        </div>
                        <div v-if="register.fast_shop" class="form-group">
                            <label for="name" class="label">نام:</label>
                            <input class="form-control" type="text" v-model="register.user_data.name" id="name">
                        </div>

                        <div v-if="register.fast_shop" class="form-group">
                            <label for="phone" class="label">تلفن:</label>
                            <input class="form-control" type="text" v-model="register.user_data.phone" id="phone">
                        </div>

                    </div>

                    <div class="col-12 form-group mt-2 mb-2">
                        <label for="barcode" class="label">انتخاب سریع</label>
                        <input class="form-control" v-debounce="detectProduct" type="text" v-model="barcode"
                            id="barcode">
                    </div>


                    <div class="product-items max-500-scroll mb-3 col-12">
                        <div class="product-item mt-3  p-0 row mot-modal-inputs-5"
                            v-for="(item, index) in register.items" :key="index">
                            <div class="form-group">
                                <label for="prodcut" class="d-flex">
                                    <i v-if="index != 0" @click="minusItem(index)"
                                        class="fa fa-times text-danger px-2"></i>
                                    انتخاب محصول
                                </label>
                                <v-select @input="getProduct(item)"
                                    :disabled="item.insideType == 'update' && !can('change_product_register')"
                                    id="prodcut" v-model="item.supplier" :options="products" @search:focus="search_params = 'product|name,code|products'"  v-debounce="dynamicSearch" />
                            </div>
                            <div class="form-group d-flex gap-1">
                                <div >
                                    <label for="quantity">تعداد{{ item.supplier && item.supplier.unit ?
                                        '(' + locate(item.supplier.unit) + ')' : null }}</label>
                                    <input @keyup="setPrice(item)" step="0.001" type="number" class="form-control"
                                        id="quantity" v-model="item.quantity" placeholder="تعداد" />
                                </div>
                                <div >
                                    <label for="price">هزینه واحد</label>
                                    <input @keyup="setPrice(item)" class="form-control" :disabled="disabledIf(item)"
                                        type="number" v-model="item.unit_price" id="price">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="price">هزینه کل</label>
                                <input class="form-control" :disabled="disabledIf(item)" type="number"
                                    v-model="item.price" id="price">
                            </div>

                            <div class="form-group d-flex gap-1">
                                <div class="min-w-200">
                                    <label for="dpricefor">دلیل کسری/اضافه</label>
                                    <v-select id="dpricefor" multiple placeholder="دلیل کسری اضافه"
                                        @input="setDiscountPercent(item)" v-model="item.discount_fors"
                                        :options="discount_fors" />
                                </div>

                                <div class="max-w-60">
                                    <label for="calc-percent">درصد</label>
                                    <input id="calc-percent" type="number" :disabled="!can('edit_price_manual')"
                                        @keyup="calcPercent(item)" v-model="item.calcpercentVal" class="form-control">
                                </div>
                            </div>


                            <div class="form-group">
                                <label for="price">هزینه کل با تخفیف</label>
                                <input class="form-control" :disabled="disabledIf(item)" type="number"
                                    v-model="item.discount_price" id="price">
                            </div>

                        </div>
                        <button type="button" class="btn btn-sm btn-primary mt-2" @click="addItem">+</button>
                    </div>

                    <div class="row col-12 m-0 p-0 mot-modal-inputs-4">
                        <div class="form-group">
                            <label for="payment-discount">تخفیف روی فاکتور</label>
                            <input type="number" @keyup="calcPercent" class="form-control" id="payment-discount"
                                v-model="register.pay_discount_price" />
                        </div>
                        <div class="form-group">
                            <label for="reference">معرفی کننده</label>
                            <v-select id="reference"
                                :disabled="register.insideType == 'update' && !can('change_product_register')"
                                v-model="register.user_reference_id" :options="users" v-debounce="searchUsers" />
                        </div>
                        <div class="form-group mt-3">
                            <label for="dprice">مبلغ پراختی با احتساب کسری/اضافه</label>
                            <input class="form-control" disabled v-model="register.all_price" type="number" id="dprice">
                        </div>


                        <div class="form-group">
                            <label for="">تاریخ</label>
                            <date-picker format="jYYYY-jMM-jDD" display-format="jYYYY-jMM-jDD" auto-submit
                                v-model="register.created_at"></date-picker>
                        </div>

                    </div>
                    <div class="form-group col-12 ">
                        <label for="comments">توضیحات</label>
                        <textarea class="form-control" v-model="register.comments" id="comments"></textarea>
                    </div>

                    <div class="form-group mt-2 ">
                        <input type="button" @click="addData" class="form-control"
                            :value="[register.insideType == 'update' ? 'ویرایش' : 'افزودن']">
                    </div>
                </div>
            </form>
        </template>
    </popup>

</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name: "AddPersonProduct",
    props: ['data', 'type'],
    computed: {
        ...mapGetters({ register: 'ProductRegister/register' })
    },

    data() {
        return {
            categories: window.productsCategory,
            products: [],
            users: [],
            barcode: null,
            leave_reasons: window.leaveReasons,
            discount_fors: window.discountFor,
        }
    },
    methods: {
        ...mapActions({ addPayment: "Payment/addPayment", updatePersonRegisterData: "updatePersonRegisterData", updateRegisterData: 'ProductRegister/updateRegisterData' }),
        getProduct(item) {
            if (!item.supplier) {
                item.price = null
                item.unit_price = 0
                item.discount_fors = []
                item.discount_price = null
            } else {
                item.unit_price = item.supplier.sale_price
                item.discount_fors = []
                item.price = item.unit_price * item.quantity
                item.discount_price = 0
            }
            this.calcPercent(item)
        },
        searchUsers(search, loading) {
            if (!search.length) return;
            loading = true;
            axios.get(`/api/v1/search-refs-users/${search}/${this.register.user_id || this.register.insideId}/${this.register.insideType == 'update' ? '?register_id=' + this.register.insideId : ''}`)
                .then(res => {
                    this.users = res.data
                    loading = false;
                });
        },
        minusItem(index) {
            if (this.register.items.length > 1) {

                this.register.items = this.register.items.filter(x => x != this.register.items[index])
                this.calcPercent();
            }
        },
        addItem() {
            this.register.items.push({
                supplier: null,
                discount_price: null,
                discount_fors: null,
                unit_price: null,
                price: null,
                quantity: 1,
                return_price: null,
                leave_reason: null,
                calcpercentVal: 0
            })
        },

        detectProduct() {
            this.barcode = String(this.barcode).replaceAll('-', '')
            if (String(this.barcode).length < 7) {
                return
            }
            if (this.register.items.some(x => x.supplier.code == this.barcode)) {
                var item = this.register.items.find(x => x.supplier.code == this.barcode)
                item.quantity = parseInt(item.quantity) + 1
                this.setPrice(this.register.items.find(x => x.supplier.code == this.barcode))
            } else {
                axios.get(`/api/v1/product/${this.barcode}`).then(res => {
                    this.register.items.push({
                        supplier: res.data.data,
                        discount_price: parseInt(res.data.data.sale_price),
                        discount_fors: [],
                        unit_price: parseInt(res.data.data.sale_price),
                        price: parseInt(res.data.data.sale_price),
                        quantity: 1,
                        return_price: null,
                        leave_reason: null,
                        calcpercentVal: 0
                    })
                    this.calcPercent()
                })
            }
            this.barcode = null
            return;

        },

        addData() {


            if (this.register.fast_shop) {
                this.vr(this.register.user_data.name, 'نام خریدار');
                this.vr(this.register.user_data.phone, 'تلفن خریدار');

            }

            if (!this.v_error_check()) return;

            axios.post('/api/v1/product-register', this.register)
                .then(res => {
                    if (res.data.alert && res.data.alert.type == 'error') return;
                    this.register.insideId = res.data.data.id;

                    if (this.register.insideType == 'insert') {

                        Promise.all([
                            $('.add-person-modal').modal('hide'),
                            $('.add-person-product-modal').modal('hide'),
                            this.addPayment({
                                user_id: res.data.data.user_id,
                                price: res.data.data.price,
                                register_type: window.serviceList.find(x => x.en_name == 'products'),
                                register_id: res.data.data.id,
                            })
                        ]).then(res => {
                            $('.add-payment-modal').modal('show')
                        })


                    } else {
                        $('.add-person-modal').modal('hide')
                        $('.add-person-product-modal').modal('hide')
                    }

                    this.updatePersonRegisterData({ data: res.data.data, type: "products" });
                    this.updateRegisterData(res.data.data);
                    this.register.insideType = 'update';

                });

        },

        setDiscountPercent(item) {
            item.discount_price = null
            item.calcpercentVal = 0

            for (var n of item.discount_fors) {
                if (n.id == window.defined_enums.employee_discount_shopping_id) {
                    item.unit_price = parseInt(item.supplier.buy_price) + parseInt(Math.round((item.supplier.buy_price / 100) * 5))
                    item.price = item.unit_price * item.quantity
                }

                if (!n.discount_percent) continue;
                item.calcpercentVal += parseInt(n.discount_percent);
            }

            this.calcPercent(item)

        },

        calcPercent(item = false) {
            if (item) {
                let price = item.price
                let percent = item.calcpercentVal
                item.discount_price = (parseInt(price) - (parseInt(percent) / 100) * parseInt(price))
            }
            this.register.all_price = this.register.items.map(x => x.discount_price).reduce(function (a, b) { return parseInt(a) + parseInt(b); }, 0) - parseInt(this.register.pay_discount_price)
        },


        disabledIf(item) {
            if (this.can('edit_price_manual')) {
                return false
            }
            if (item.unit_price == 0) {
                return false;
            }
            return true;
        },

        setPrice(data) {
            data.price = data.unit_price * data.quantity
            this.calcPercent(data)
        }

    }

}
</script>
