<template>
    <!-- Modal -->
    <popup :name="'person'">
        <template v-slot:header>
            <h5 class="modal-title">افزودن/ ویرایش افراد</h5>
        </template>
        <template v-slot:content>
            <form class="step1" autocomplete="off">
                <ul class="err-box">
                    <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                </ul>
                <div class="row mot-modal-inputs-6 mr-0 ml-0 m-0">
                    <div class="form-group mt-1">
                        <label for="name" class="label">نام:</label>
                        <input class="form-control" type="text" v-model="person.name" id="name">
                    </div>
                    <div class="form-group mt-1">
                        <label for="gender" class="label">جنسیت:</label>
                        <select class="form-control" id="gender" v-model="person.gender">
                            <option :value="'0'">آقا</option>
                            <option :value="'1'">خانم</option>
                        </select>
                    </div>
                    <div class="form-group mt-1">
                        <label for="date" class="label">تاریخ:</label>
                        <date-picker format="jYYYY-jMM-jDD" display-format="jYYYY-jMM-jDD" auto-submit
                            v-model="person.date"></date-picker>
                    </div>

                    <div v-if="can('add_branch')" class="form-group mt-1">
                        <label for="branch">مربوط به شعبه</label>
                        <v-select id="branch" placeholder="شعبه ثبت کننده" v-model="person.branch"
                            :options="branches" />
                    </div>

                    <div class="form-group mt-1">
                        <label for="phone" class="label">تلفن:</label>
                        <input class="form-control" type="text" v-model="person.phone" id="phone">
                    </div>

                    <div class="form-group mt-1">
                        <label for="acquaintances" class="label"> آشنایی:</label>
                        <v-select id="acquaintances"
                            :disabled="person.insideType == 'update' && !can('change_person_acq')"
                            v-if="acquaintances.length" v-model="person.acquaintance" :options="acquaintances" />
                    </div>

                    <div class="form-group mt-1"
                        v-if="person.acquaintance && search_params_need.includes(person.acquaintance.id)">
                        <label for="acquaintance_param" class="label">عبارت جستجو:</label>
                        <input class="form-control"
                            :disabled="person.insideType == 'update' && !can('change_person_acq')" type="text"
                            v-model="person.acquaintance_param" id="acquaintance_param">
                    </div>

                    <div class="form-group mt-1">
                        <label for="acquaintances_param" class="label">علت انتخاب آریا تهران:</label>
                        <v-select id="acquaintances"
                            :disabled="person.insideType == 'update' && !can('change_person_acq')"
                            v-model="person.reason" :options="reasons" />
                    </div>

                    <div class="form-group mt-1">
                        <label for="comments" class="label">توضیحات:</label>
                        <input class="form-control" type="text" v-model="person.comments" id="comments">
                    </div>

                    <div v-if="can('admin')" class="form-group mt-1">
                        <label for="password" class="label">انتخاب نقش:</label>
                        <v-select id="job" v-model="person.role" :options="roles" />
                    </div>
                    <div v-else-if="can('add_teacher')" class="form-group mt-1">
                        <label for="is_teacher" class="label">ثبت این فرد به عنوان استاد:</label>
                        <input type="checkbox" autocomplete="off" v-model="person.is_teacher" id="is_teacher">
                    </div>

                </div>
                <hr>
                <div class="row mot-modal-inputs-6  mr-0 ml-0 m-0">
                    <div class="form-group mt-1">
                        <label for="email" class="label">ایمیل:</label>
                        <input class="form-control" type="email" autocomplete="off" v-model="person.email" id="email">
                    </div>
                    <div class="form-group mt-1">
                        <label for="password" class="label">رمز ورود:</label>
                        <input class="form-control" type="password" autocomplete="off" v-model="person.password"
                            id="password">
                    </div>


                    <div class="col-md-12">
                        <button class="btn btn-success mt-3 mb-3" @click.stop.prevent="addPerson()">افزودن</button>
                    </div>
                </div>
            </form>

            <div class="btn-group p-3" v-if="person.insideId">
                <button @click="addCall(selectedPerson.id);" type="button" class="btn btn-primary" data-toggle="modal"
                    data-target=".add-call-modal">تماس جدید</button>
                <button @click="getPersonData({ id: selectedPerson.id });" type="button" class="btn btn-primary"
                    data-toggle="modal" data-target=".add-data-modal">افزودن /
                    ویرایش اطلاعات</button>
                <button @click="addpayment({ user_id: selectedPerson.id })" type="button" class="btn btn-primary"
                    data-toggle="modal" data-target=".add-payment-modal">فیش
                    جدید</button>
                <button @click="addRegister(selectedPerson.id);" type="button" class="btn btn-primary"
                    data-toggle="modal" data-target=".add-register-modal">ثبت نام جدید</button>
                <button @click="addProductRegister(selectedPerson.id);" type="button" class="btn btn-primary"
                    data-toggle="modal" data-target=".add-person-product-modal">خرید
                    جدید</button>
                <button @click="addServiceRegister(selectedPerson.id);" type="button" class="btn btn-primary"
                    data-toggle="modal" data-target=".add-person-service-modal">خدمات جدید</button>
            </div>
        </template>
    </popup>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';

export default {
    name: "AddPerson",
    computed: {
        ...mapGetters({ selectedPerson: 'selectedPerson', person: 'person' })
    },
    data() {
        return {
            acquaintances: window.acquaintances,
            branches: window.branches,
            reasons: reasons,
            search_params_need: window.defined_enums.depend_param_ecqu,
            roles: window.roles
        }
    },
    mounted: function () {
        const url = new URL(window.location.href);
        if (url.searchParams.has('phone')) {
            this.person.phone = this.fixPhone(url.searchParams.get('phone'))
        }
    },
    methods: {
        ...mapActions({
            updatePersonData: 'updatePersonData',
            addRegister: 'Register/addRegister',
            addProductRegister: 'ProductRegister/addRegister',
            addServiceRegister: 'ServiceRegister/addRegister',
            addCall: 'Call/addCall'
        }),
        addPerson() {
            let promises = [
                this.vr(this.person.name, 'نام'),
                this.vr(this.person.phone, 'تلفن'),
                this.vr(this.person.acquaintance, 'شیوه آشنایی'),
                this.vr(this.person.reason, 'علت انتخاب آریا تهران'),
                this.v_min_len(this.person.phone, 'تلفن', 11),
                this.v_max_len(this.person.phone, 'تلفن', 11),
                this.unique(this.person.phone, 'users.phone', 'تلفن', `${this.person.insideType}_${this.person.insideId}`)
            ]
            Promise.all(promises)
                .then(values => {
                    if (!this.v_error_check()) return;
                    axios.post('/api/v1/person', this.person).then(data => {
                        if (data.data.alert && data.data.alert.type == 'error') return;
                        this.person.insideId = data.data.data.id;
                        this.person.insideType = 'update';

                        this.setSelectedPerson({ id: data.data.data.id, data: data.data.data });
                        this.updatePersonData(data.data.data);


                        const url = new URL(window.location.href);
                        if (url.searchParams.has('phone')) {
                            var search_params = url.searchParams;
                            search_params.delete('phone');
                            url.search = search_params.toString();
                            var new_url = url.toString();
                            let stateObj = { id: "100" };
                            window.history.replaceState(stateObj,
                                "https://portal.aryatehran.com", decodeURIComponent(new_url));
                        }

                    });
                })
        },

        fixPhone(phone) {
            if (phone.length == 8) {
                phone = "021" + phone
            } else if (phone.length == 11) {
                phone = phone
            } else if (phone.length == 12) {
                phone = phone.substring(1)
            } else if (phone.length == 13) {
                phone = phone.substring(2)
            }
            return phone;
        }

    }

}
</script>
