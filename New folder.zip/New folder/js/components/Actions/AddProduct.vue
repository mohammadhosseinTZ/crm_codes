<template>
<div class="add-product">
    <div class="modal fade add-product-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش کالاها</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs-4 m-0 p-2">
                        <div class="form-group mt-1 form-group">
                                   <label for="code">بارکد کالا</label>
                                   <input :disabled="!can('barcode_managing')" type="number" class="form-control" id="code" v-model="product.code" >
                           </div>
                           <div class="form-group mt-1">
                                   <label for="name">نام کالا یا محصول</label>
                                   <input type="text" class="form-control" id="name" :disabled="product.insideType == 'update' && !can('change_product_name')" v-model="product.name" >
                           </div>
                           <div class="form-group mt-1">
                                <label for="fund-card">واحد</label>
                                <v-select id="fund-card" :disabled="product.insideType == 'update' && !can('change_product_unit')" v-model="product.unit" :options="units" />
                          </div>

                          <div class="form-group mt-1">
                                <label for="buy-price">قیمت خرید</label>
                                <input type="number" class="form-control" :disabled="product.insideType == 'update' && !can('change_product_price')" id="buy-price" v-model="product.buy_price" >
                           </div>

                           <div v-if="type != 'static' && type != 'commodities'" class="form-group mt-1">
                                <label for="priec">قیمت فروش</label>
                                <input type="number" class="form-control" :disabled="product.insideType == 'update' && !can('change_product_price')" id="priec" v-model="product.price" >
                           </div>

                           <div v-if="type != 'static' && type != 'commodities'" class="form-group mt-1">
                                <label for="sale_price">هزینه فروش ویژه</label>
                                <input type="text"  id="sale_price" v-model="product.sale_price" :disabled="product.insideType == 'update' && !can('change_product_price')"  class="form-control">
                            </div>


                           
                            <div class="form-group mt-1" v-if="product.sale_price && type != 'static' && type != 'commodities'">
                                    <label for="sale-price-from">تاریخ شروع تخفیف</label>
                                    <date-picker :disabled="product.insideType == 'update' && !can('change_product_price')" id="sale-price-from" clearable format="YYYY-MM-DD HH:mm" type="datetime" compact-time display-format="jYYYY-jMM-jDD HH:mm" auto-submit v-model="product.sale_price_date_from"></date-picker>
                                </div>

                            <div class="form-group mt-1" v-if="product.sale_price && type != 'static' && type != 'commodities'">
                                <label for="sale-price-to">تاریخ پایان تخفیف</label>
                                <date-picker :disabled="product.insideType == 'update' && !can('change_product_price')" id="sale-price-to" clearable format="YYYY-MM-DD HH:mm" type="datetime" compact-time display-format="jYYYY-jMM-jDD HH:mm" auto-submit v-model="product.sale_price_date_to"></date-picker>
                            </div>

                            <div class="form-group mt-1">
                                <label for="category">دسته بندی</label>
                                <v-select id="category" :disabled="product.insideType == 'update' && !can('change_product_category')" multiple v-model="product.category" :options="productsCategory"  />
                           </div>
                          
                           
                           
                           <div class="form-group mt-1 d-block">
                                <label for="is_infinite" class="d-block mb-2">
                                    آیا موجودی بی نهایت است؟
                                    <input :disabled="product.insideType == 'update' && !can('change_product_quantity')" type="checkbox" class="" id="is_infinite" value="yes" v-model="product.is_infinite" >
                                </label>
                                <div class="d-block w-100">
                                    <v-select id="branches" :disabled="!can('change_product_branch')" placeholder="شعبه های ارائه دهنده" multiple v-model="product.branches" :options="branches" />
                                </div>
                            </div>
                        </div>
                          <div class="rounded border p-2 " v-if="!product.is_infinite">
                            <div class="row mot-modal-inputs product-quantity"  v-for="(store, index) in product.stores" :key="index">
                                <div class="form-group">
                                    <label for="key">
                                        <i @click="minusItem(index)" class="fa fa-times text-danger"></i>
                                        انبار</label>
                                    <v-select  id="key" v-model="store.store" :disabled="product.insideType == 'update' && !can('change_product_quantity')" :options="stores"/>  
                                </div>
                                <div class="form-group quantity-item">
                                    <label for="priec">موجودی</label>
                                    <input type="number" :disabled="product.insideType == 'update' && !can('change_product_quantity')" class="form-control"  step="0.001" id="priec" v-model="store.quantity" >
                                </div>
                                <div class="form-group">
                                    <label for="priec">موجودی اولیه</label>
                                    <input type="number" :disabled="!can('change_primitive_quantity')" class="form-control"  step="0.001" id="priec" v-model="store.primitive_quantity" >
                                </div>
                            </div>
                            <button type="button" :disabled="product.insideType == 'update' && !can('change_product_quantity')" class="btn btn-sm btn-primary mt-2 align-self-end mb-3" @click="addItem">+</button>
                          </div>
                         
                            <div class="col-md-12 mt-3">
                                    
                                <hr class="">
                                <h5>تنظیمات فروشنده و اختصاص هزینه به آن</h5>

                            </div>
                            <div class="row mot-modal-inputs-5 m-0 p-2">

                            <div v-if="type != 'static' && type != 'commodities'" class="form-group mt-1 form-group">
                                <label for="parent">محصول والد</label>
                                <v-select id="parent" placeholder="محصول والد" :disabled="product.insideType == 'update' && !can('change_product_name')" v-model="product.parent_id" :options="products" @search:focus="search_params = 'product|name,code|products'"  v-debounce="dynamicSearch"  />
                            </div>

                            <div class="form-group" v-if="can('set_commission') && type != 'static' && type != 'commodities'">
                                <label for="commission_user">فروشنده</label>
                                <v-select :disabled="!can('define_product_seller')"  id="commission_user" placeholder="فروشنده" v-model="product.commission_user" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch"  />
                            </div>

                            <div class="form-group" v-if="can('set_commission') && type != 'static' && type != 'commodities'">
                                <label for="commission_unit">واحد سود</label>
                                <v-select :disabled="!can('define_product_seller')"  id="commission_unit" placeholder="واحد سود" v-model="product.commission_unit" :options="commission_units"  />
                            </div>

                            <div class="form-group" v-if="can('set_commission') && type != 'static' && type != 'commodities'">
                                <label for="commission_value">مبلغ سود</label>
                                <input :disabled="!can('define_product_seller')"  type="number" class="form-control"  id="commission_value" v-model="product.commission_value" >
                            </div>

                            <div class="form-group" v-if="can('set_commission') && type != 'static' && type != 'commodities'">
                                <label for="commission_market_value">مبلغ سود فروش از سایت</label>
                                <input :disabled="!can('define_product_seller')"  type="number" class="form-control"  id="commission_market_value" v-model="product.commission_market_value" >
                            </div>
                            <div class="form-group">
                                <label for="comment">توضیحات</label>
                                <input type="text" class="form-control"  id="comment" v-model="product.comment" >
                            </div>


                            <div v-if="type != 'static' && type != 'commodities'" class="form-group">
                                    <label for="sync_with_site">آیا میخواهید این محصول با سایت شعبه مربوطه همگام شود؟</label>
                                    <input type="checkbox" v-model="product.sync_with_site" id="sync_with_site">
                                </div>
                       </div>
                       <div class="row mot-modal-inputs">
                           <div class="form-group">
                                <input type="submit" class="form-control" :value="[product.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
export default{
    name: "AddProduct",
    computed: {
        ...mapGetters({
            product: 'Product/data',
        })
    },
    props: ['type'],
    data(){
        return{
            productsCategory: window.productsCategory,
            branches : window.branches,
            units: window.defined_enums.cost_units,
            commission_units:  window.defined_enums.commission_units,
            products: [],
            users: [],
            stores: window.stores,
        }
    },
    methods: {
        ...mapActions({
            update: 'Product/update'
        }),
        addData() {
            var promises = [];
            promises.push(this.vr(this.product.name, 'نام'))
            if(this.type != 'static' && this.type != 'commodities'){
                promises.push(this.vr(this.product.price, 'قیمت'));
            }
            promises.push(this.vr(this.product.category, 'دسته بندی'));
            promises.push(this.vr(this.product.branches, 'شعبه کالا'));
            promises.push(this.vr(this.product.code, 'کد کالا'));
            promises.push(this.unique(this.product.code, 'products.code','کد کالا', `${this.product.insideType}_${this.product.insideId}`));
     
            Promise.all(promises).then(values => {
                if(!this.v_error_check()) return;
                this.product.product_type = this.type || ''
                axios.post('/api/v1/product', this.product)
                .then(res => {
                    if(res.data.alert && res.data.alert.type == 'error') return;
                    this.update(res.data.data)
                    $('.add-product-modal').modal('hide')
                });
            })      
        },
        addItem(){
                this.product.stores.push({
                store: null,
                quantity: null,
                primitive_quantity: null,
            })
        },
        minusItem(index){
            if(this.product.stores.length > 1){
                this.product.stores = this.product.stores.filter(x => x != this.product.stores[index])
            }
        },


    }
}
</script>