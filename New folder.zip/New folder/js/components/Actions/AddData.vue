<template>
    <!-- Modal -->
<div class="add-data">
    <div class="modal fade add-data-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش اطلاعات</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                    <form @submit.stop.prevent="addData">
                       
                        <table class="table mot-modal-table mt-1">
                            <tr>
                                <th>دیگر تلفنن ها</th>
                                <td>
                                     <v-select
                                        v-model="datas.phone"
                                        taggable
                                        multiple
                                        no-drop
                                        placeholder="دیگر تلفن ها"
                                    />
                                </td>
                            </tr>
                            <tr>
                                <th>کد ملی</th>
                                <td><input class="form-control" type="text" v-model="datas.national_code"></td>
                            </tr>
                            <tr>
                                <th>نام پدر</th>
                                <td><input class="form-control" type="text" v-model="datas.father_name"></td>
                            </tr>
                            <tr>
                                <th>تلفن ثابت</th>
                                <td><input class="form-control" type="text" v-model="datas.fixed_phone"></td>
                            </tr>
                            <tr>
                                <th>آدرس</th>
                                <td><input class="form-control" type="text" v-model="datas.address"></td>
                            </tr>
                            <tr>
                                <th>تاریخ تولد</th>
                                <td>
                                    <date-picker format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" clearable editable auto-submit v-model="datas.birth_date"></date-picker>
                                </td>
                            </tr>
                            <tr>
                                <th>محل تولد</th>
                                <td>
                                     <v-select id="birth_palce" v-if="attached.birth_place.length" v-model="datas.birth_place" :options="attached.birth_place" />            
                                </td>
                            </tr>
                            <tr>
                                <th>محل زندگی</th>
                                <td>
                                     <v-select id="city" v-if="attached.city.length" v-model="datas.city" :options="attached.city" />            
                                </td>
                            </tr>
                            <tr>
                                <th>رشته تحصیلی</th>
                                <td>
                                     <v-select id="colage_course" v-if="attached.colage_course.length" v-model="datas.colage_course" :options="attached.colage_course" />            
                                </td>
                            </tr>
                            <tr>
                                <th>مدرک</th>
                                <td>
                                     <v-select id="evidence" v-if="attached.evidence.length" v-model="datas.evidence" :options="attached.evidence" />            
                                </td>
                            </tr>

                            <tr>
                                <th>نوع شخص</th>
                                <td>
                                     <v-select id="person_type" v-if="attached.person_type.length" v-model="datas.person_type" :options="attached.person_type" />            
                                </td>
                            </tr>
                            <tr>
                                <th>ملیت</th>
                                <td><input class="form-control" type="text" v-model="datas.nationality"></td>
                            </tr>
                            <tr>
                                <th>نام شرکت</th>
                                <td><input class="form-control" type="text" v-model="datas.company_name"></td>
                            </tr>

                            <tr>
                                <th>شماره کارت</th>
                                <td><input class="form-control" type="text" v-model="datas.card_number"></td>
                            </tr>

                            <tr>
                                <th>شماره حساب</th>
                                <td><input class="form-control" type="text" v-model="datas.account_number"></td>
                            </tr>
                            <tr>
                                <th>بانک</th>
                                <td><input class="form-control" type="text" v-model="datas.bank_name"></td>
                            </tr>

                            <tr>
                                <th>کار</th>
                                <td>
                                     <v-select id="job" v-if="attached.job.length" v-model="datas.job" :options="attached.job" />            
                                </td>
                            </tr>
                            <tr>
                                <th>آدرس محل کار</th>
                                <td><input class="form-control" type="text" v-model="datas.job_address"></td>
                            </tr>
                            <tr>
                                <th>وضعیت تاهل</th>
                                <td>
                                    <select class="form-control" v-model="datas.marital_status">
                                        <option value="0">مجرد</option>
                                        <option value="1">متاهل</option>
                                    </select>    
                                </td>
                            </tr>
                            <tr>
                                <th>منطقه</th>
                                <td>
                                     <input type="number" v-model="datas.region" class="form-control">
                                </td>
                            </tr>

                            <tr>
                                <th>پورسانت معرفی فرد جدید</th>
                                <td><input class="form-control" type="number" v-model="datas.new_register_commission"></td>
                            </tr>
                            <tr>
                                <th>پورسانت معرفی کاراموز</th>
                                <td><input class="form-control" type="number" v-model="datas.register_commission"></td>
                            </tr>
                            <tr>
                                <th>تخفیف ثبت با کد به عنوان فرد جدید</th>
                                <td><input class="form-control" type="number" v-model="datas.new_regcode_discount"></td>
                            </tr>
                            <tr>
                                <th>تخفیف ثبت با کد به عنوان کاراموز</th>
                                <td><input class="form-control" type="number" v-model="datas.regcode_discount"></td>
                            </tr>

                            <tr>
                                <th>عکس پرسنلی</th>
                                <td ref="add_personal_image">
                                     <input type="file" name="self_personal_image" ref="self_personal_image" @change="setPreview('add_personal_image', 'self_personal_image')" accept="image/*" class="form-control">
                                    <img v-if="isValidHttpUrl(datas.personal_image)" :src="datas.personal_image" class="preview">

                                </td>
                            </tr>
                            <tr>
                                <th>کارت ملی</th>
                                <td ref="add_national_cart_image">
                                     <input type="file" name="self_national_cart_image" ref="self_national_cart_image" @change="setPreview('add_national_cart_image', 'self_national_cart_image')" accept="image/*" class="form-control">
                                    <img v-if="isValidHttpUrl(datas.national_cart_image)" :src="datas.national_cart_image" class="preview">
                                </td>
                            </tr>
                             <tr>
                                <th>صفحه اول شناس نامه</th>
                                <td ref="add_certificate_image">
                                     <input type="file" name="self_certificate_image" ref="self_certificate_image" @change="setPreview('add_certificate_image', 'self_certificate_image')" accept="image/*" class="form-control">
                                    <img v-if="isValidHttpUrl(datas.certificate_image)" :src="datas.certificate_image" class="preview">
                                </td>
                            </tr>
                     </table>
                    <input type="submit" class="form-control mb-3 col-1"" :value="[datas.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                    </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
import Cropper from 'cropperjs'
export default {
    name:"AddData",
    computed: {
        ...mapGetters({selectedPerson: 'selectedPerson', tdata: 'sdata'})
    },
     watch:    {
        tdata: {
            handler:function (newItem) {
                    this.datas = {
                    national_code: null,
                    father_name: null,
                    address: null,
                    birth_date: null,
                    birth_place: null,
                    person_type: null,
                    nationality: null,
                    company_name: null,
                    card_number: null,
                    account_number: null,
                    bank_name: null,
                    job: null,
                    job_address: null,
                    city: null,
                    evidence: null,
                    colage_course: null,
                    region: null,
                    fixed_phone: null,
                    marital_status: null,
                    personal_image: null,
                    national_cart_image: null,
                    certificate_image: null,
                    phone: [],
                    new_register_commission: null,
                    register_commission: null,
                    new_regcode_discount: null,
                    regcode_discount: null,
                }
                for (const [key, value] of Object.entries(this.cropper)){
                    this.$refs[key].value = null
                    value.getCroppedCanvas({
                        imageSmoothingEnabled: true,
                        imageSmoothingQuality: 'high',
                        maxWidth: 1300,
                        maxHeight: 1300,
                    }).toBlob((blob) => {
                            var imageUrl = URL.createObjectURL(blob);
                            $(this.$refs[key]).parent().children('img').remove()
                            $(this.$refs[key]).parent().append(`<img class="preview" src="${imageUrl}">`)
                            value.destroy()
                    }, "image/jpeg", 0.90)
                }

                this.cropper = {}

                if(!newItem.length){
                    return;
                } 
                let exludes = ['birth_place', 'city', 'job','evidence','person_type', 'colage_course'];
                newItem.forEach(elm => {
                    if(!exludes.includes(elm.meta_key)){
                        if(Array.isArray(this.datas[elm.meta_key]) && elm.meta_value){
                                this.datas[elm.meta_key].push(elm.meta_value)
                        }else{
                            
                            this.datas[elm.meta_key] = elm.meta_value
                        }
                    }else{
                        
                        this.datas[elm.meta_key] = this.attached[elm.meta_key].find(x => x.id == elm.meta_value)
                    }
                }) 
            },
            deep:true
        }
    },
    data(){
        return{
            datas: {
                national_code: null,
                father_name: null,
                address: null,
                birth_date: null,
                birth_place: null,
                person_type: null,
                nationality: null,
                company_name: null,
                card_number: null,
                account_number: null,
                bank_name: null,
                job: null,
                job_address: null,
                city: null,
                evidence: null,
                colage_course: null,
                region: null,
                fixed_phone: null,
                marital_status: null,
                files: [],
                personal_image: null,
                national_cart_image: null,
                certificate_image: null,
                phone: [],
                new_register_commission: null,
                register_commission: null,
                new_regcode_discount: null,
                regcode_discount: null,
            },
            attached: {
                birth_place: window.places,
                city: window.places,
                job: window.jobs,
                evidence: window.evidences,
                colage_course: window.disciplines,
                person_type: window.defined_enums.person_type
            },
            cropper: {},
        }
    },
    mounted: function(){
        var thm = this;
        var $modal = $('.add-data-modal');
        $modal.on('hidden.bs.modal', function(e) { 
           return thm.$emit('close', 'data');
        });
    },
    methods: {
        ...mapActions(['addPersonData', 'getPersonData']),
        addData() {
            var formdata = new FormData()
            var formdataset = [];

            for(var n of Object.entries(this.datas)){
                if(typeof n[1] === 'object' && !Array.isArray(n[1])){
                       formdata.append(n[0], n[1] !== null ? n[1].id : null)
                }else if(Array.isArray(n[1])){
                       formdata.append(n[0], n[1].join(','))
                }else{
                       formdata.append(n[0], n[1])
                }
            }


            // formdata.append('personal_image', this.$refs['self_personal_image'].files.item(0))
            // formdata.append('national_cart_image', this.$refs['self_national_cart_image'].files.item(0))
            // formdata.append('certificate_image', this.$refs['self_certificate_image'].files.item(0))
            
			
			for (const [key, value] of Object.entries(this.cropper)) {
				var imageset = new Promise(resolve => {
                    value.getCroppedCanvas({
                        imageSmoothingEnabled: true,
                        imageSmoothingQuality: 'high',
                        maxWidth: 1300,
                        maxHeight: 1300,
                    }).toBlob((blob) => {
                        return resolve(formdata.append(key.replace('self_', ''), blob))	
                    }, "image/jpeg", 0.90)
						
				})

				formdataset.push(imageset)
			}
    
            
            Promise.all(formdataset).then(res => {
                axios.post(`/api/v1/person/${this.selectedPerson.id}/data`, formdata,{ "Content-Type": "multipart/form-data" })
                .then(res => {
                    if(res.data.alert && res.data.alert.type == 'error') return;
                    this.getPersonData({id: this.selectedPerson.id})
                    $('.add-person-modal').modal('hide')
                    $('.add-data-modal').modal('hide')
                });
            })
        },

        isValidHttpUrl(string) {
            let url;
            try {
                url = new URL(string);
            } catch (_) {
                return false;
            }
            return url.protocol === "http:" || url.protocol === "https:";
        },

        setPreview(ref, selft){
            var image = this.$refs[selft].files.item(0)

            for(var n of this.$refs[ref].querySelectorAll('.preview')){
                n.remove()
            }

            for(var n of this.$refs[ref].querySelectorAll('.apply-btn')){
                n.remove()
            }

            var preview = document.createElement('img')
            preview.src = URL.createObjectURL(image)
            preview.classList.add('preview')

            

            this.cropper[selft] = new Cropper(preview, {
				zoomable: false,
			});
            
            
            this.$refs[ref].appendChild(preview)
        },

      
    }

}
</script>
