<template>
<div class="add-cost">
    <div class="modal fade add-cost-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش هزینه <strong>{{cost.insideId}}</strong></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row m-0">

                          <div class="col-md-12">
                                <div class="row mot-modal-inputs-4 p-3" v-for="(costItem, index) in cost.items" :key="index">
                                    <div class="form-group mb-3">
                                        <i v-if="index != 0" @click="minusItem(index)" class="fa fa-times text-danger"></i><small>{{index + 1}}</small>
                                        <label for="key">اسم هزینه</label>
                                        <v-select @input="setPrice(costItem);getOptions(costItem)" id="key" v-model="costItem.key" :options="keys" @search:focus="search_params = 'CostType|name|keys'" v-debounce="dynamicSearch" />  
                                    </div>
                                    <div class="form-group mb-3">
                                            <label for="">جستجو</label>
                                            <v-select id="" :disabled="!costItem.key" @input="setPrice(costItem)" v-model="costItem.type" :options="type_ids" v-debounce="trackSearch" />
                                    </div>

                                    <div class="form-group mb-2">
                                            <label for="fund-card">واحد</label>
                                            <v-select id="fund-card" v-model="costItem.unit" :options="units" />
                                    </div>
                                    <div class="form-group mb-2">
                                            <label for="quantity">تعداد</label>
                                            <input @keyup="setPrice(costItem)" step="0.001" type="number" class="form-control" id="quantity" v-model="costItem.quantity" />  
                                    </div>
                                    <div class="form-group mb-2">
                                            <label for="price">قیمت واحد</label>
                                            <input  @keyup="setPrice(costItem)"  class="form-control" id="price" v-model="costItem.price"/>  
                                    </div>   
                                    <div class="form-group mb-2">
                                            <label for="discount">تخفیف هزینه</label>
                                            <input @keyup="setPrice(costItem)" type="number" class="form-control" id="discount" v-model="costItem.discount_price"  />  
                                    </div>
                                    <div class="form-group mb-2">
                                            <label for="box">باکس هزینه</label>
                                            <input @change="detectUnitPrice(costItem)" type="number" class="form-control" id="box" :value="parseInt((costItem.price * costItem.quantity) - costItem.discount_price)" />  
                                    </div>
                                    <div class="form-group mb-2">
                                            <label for="comment-item">توضیحات</label>
                                            <input  type="text" class="form-control" id="comment-item" v-model="costItem.comment"/>  
                                    </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-primary mt-2" @click="addItem">+</button>
                          </div>

                          <div class="col-md-6 mb-3 mt-3">
                                <label for="payment-discount">تخفیف روی فاکتور</label>
                                <input type="number" @keyup="setPrice" class="form-control" id="payment-discount" v-model="cost.pay_discount_price"  />  
                            </div>
                            <div class="col-md-6 mb-3 mt-3">
                                <label for="allprice">هزینه کل</label>
                                <input type="number" disabled class="form-control" id="allprice" v-model="cost.all_price"  />  
                            </div>
                    
                          <div class="col-md-12 mb-3 mt-3">
                                <label>هزینه پرداخت شده</label>
                                <div class="row mt-2  d-flex" v-for="way in cost.ways" :key="way.chash_way_id">
                                    <div class="col">
                                        <select class="form-control" v-model="way.chash_way_id">
                                            <option v-for="dw in paymentGateWays" :key="dw.id" :value="dw.id">{{dw.option_value}}</option>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <input type="number" class="form-control"  v-model="way.price" >
                                    </div>
                                    <div class="col">
                                        <date-picker id="date" format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="way.created_at"></date-picker>
                                    </div>
                                    <div class="col">
                                        <button type="button" class="btn btn-sm btn-warning" @click="minusWay(way)">-</button>
                                    </div>
                                    

                                </div>
                                <button type="button" class="btn btn-sm btn-primary mt-2" @click="addPaymentWay" :disabled="this.cost.ways.length >= Object.keys(this.paymentGateWays).length">+</button>
                            </div>


                            <div class="col-md-4 mb-3">
                                <label for="transaction-id">کد رهگیری</label>
                                <input class="form-control" id="transaction-id" v-model="cost.transaction_id"  />  
                          </div>
                          <div class="col-md-4 mb-3">
                                <label for="order-id">کد پیگیری سفارش (اختیاری)</label>
                                <input class="form-control" id="order-id" v-model="cost.order_id"  />  
                          </div>
                          <div class="col-md-4 mb-3">
                                <label for="branch">شعبه</label>
                                <v-select  id="branch" v-model="cost.branch" :options="branches" />  
                          </div>
                          
                          <div class="col-md-4 mb-3 mt-3">
                            <div class="d-flex">
                                <label for="fund-card">{{paymethod ? 'منبع مالی' : 'تنخواه'}} &nbsp;&nbsp;&nbsp;</label>
                                <div v-if="can('add_bank_payment')">
                                    <label for="paymethod">نمایش منابع مالی اصلی</label>
                                    <input type="checkbox" id="paymethod" @change="fundCards = [];cost.fundCard = null" v-model="paymethod" value="bank" />  
                                </div>
                            </div>
                            <v-select id="fund-card" v-model="cost.fundCard" :options="fundCards" v-debounce="searchFundCards" />
                          </div>
                          <div class="col-md-4 mb-3">
                                <label for="commission">کارمزد</label>
                                <input type="number" class="form-control" id="commission" v-model="cost.commission"  />  
                          </div>
                          <div class="col-md-4 mb-3 mt-3">
                                <label for="fund-card">فروشنده <small>(اگر لازم است وارد کنید)</small></label>
                                <v-select id="fund-card" v-model="cost.seller" :options="sellers" @search:focus="search_params = 'user|name,phone|sellers'"  v-debounce="dynamicSearch" />
                          </div>
                          
                          

                            <div class="col-md-12 mb-2">
                                <label for="comment">توضیحات</label>
                                <textarea id="comment" class="form-control"  v-model="cost.comment"></textarea>
                          </div>
                          <div class="col-md-12 mb-2">
                                <label for="date">تاریخ</label>
                                <date-picker id="date" format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="cost.created_at"></date-picker>
                            </div>
                       </div>
                       <div class="row m-0">
                           <div class="col form-group">
                                <input type="submit" class="form-control" :value="[cost.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
export default{
    name: "AddCost",

    computed: {
        ...mapGetters({
            cost: 'Cost/data'
        })
    },
    data(){
        return{
            keys: [],
            sellers: [],
            paymethod: null,
            trackable_table: null,
            paymentGateWays: window.gateWays,
            branches: window.branches,
            units: window.defined_enums.cost_units,
            type_ids : [],
            fundCards: []
          }
    },
    methods: {
        ...mapActions({
            update: 'Cost/update',
            addAllocation: 'Allocation/forceAdd',
        }),
        addData() {
 
            this.vr(this.cost.fundCard, 'تنخواه')
            this.vr(this.cost.branch, 'شعبه')
            this.vr(this.cost.transaction_id, 'کد رهگیری یا سریال')

      
            if(!this.v_error_check()) return;
            this.cost.paymethod = this.paymethod
            axios.post('/api/v1/cost', this.cost)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                this.addAllocation({cost: res.data.data})
                $('.add-cost-modal').modal('hide')
                $('.add-allocation-modal').modal('show')
            });
        },

        trackSearch(search, loading){
            console.log(this.trackable_table)
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/cost/search/${this.trackable_table}/${search}`)
                .then(res => {
                        this.type_ids = res.data
                        loading = false;
                });
        },

        searchFundCards(search, loading){
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/search/bank/name/${search}?filter_type=${this.paymethod ? 'source' : 'fund_card'}`)
                .then(res => {
                        this.fundCards = res.data
                        loading = false;
                });
        },

        setPrice(costItem = false){

            if(costItem && costItem.type && parseInt(costItem.type.price) && !costItem.price){
                costItem.price = costItem.type.price
            }
            
            if(costItem && costItem.key && parseInt(costItem.key.price) && !costItem.price){
                costItem.price = costItem.key.price
            }

            var price = 0
            this.cost.items.forEach(item => {
                price += parseInt((item.price * item.quantity) - item.discount_price)
            });
            this.cost.ways[0].price = price  - parseInt(this.cost.pay_discount_price)
            this.cost.all_price = price  - parseInt(this.cost.pay_discount_price)

       
        },

        addPaymentWay(){
            if(this.cost.ways.length <= Object.keys(this.paymentGateWays).length)
                this.cost.ways.push({id:null,price:null, created_at: null});
        },
        minusWay(way){
            this.cost.ways = this.cost.ways.filter(x => x.chash_way_id !== way.chash_way_id);
        },

        addItem(){
                this.cost.items.push({
                type: null,
                key: null,
                price: null,
                discount_price: 0,
                quantity: 1,
                unit: null,
                comment: null
            })
        },
        minusItem(index){
            if(this.cost.items.length > 1){
                
                this.cost.items = this.cost.items.filter(x => x != this.cost.items[index])
            }
        },

        getOptions(item){
            console.log(item)
            if(!item.key) return;
            this.trackable_table = item.key.costable.en_name
        },

        detectUnitPrice(costItem){
            costItem.price = Math.round(window.event.target.value / costItem.quantity)
            this.setPrice(costItem)
        }
    }
}
</script>