<template>
<div class="add-cost-type">
    <div class="modal fade add-cost-type-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش هزینه ها</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs-4 m-0">
                           <div class="form-group mt-1">
                                   <label for="name">نام</label>
                                   <input type="text" class="form-control" id="name" v-model="costType.name" >
                           </div>
                           <div class="form-group mt-1">
                                <label for="priec">هزینه</label>
                                <input type="number" class="form-control" id="priec" v-model="costType.price" >
                           </div>
                           <div class="form-group mt-1">
                                <label for="category">دسته هزینه</label>
                                <v-select id="category" multiple v-model="costType.category" :options="costsCategory"  />
                           </div>
                           <div class="form-group mt-1">
                                <label for="subject">موضوع</label>
                                <v-select id="subject" v-model="costType.costable_id" :options="costables"  />
                           </div>
                       </div>
                       <div class="row mot-modal-inputs">
                           <div class="col form-group">
                                <input type="submit" class="form-control" :value="[costType.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
export default{
    name: "AddCostType",

    computed: {
        ...mapGetters({
            costType: 'CostType/data'
        })
    },
    data(){
        return{
            costsCategory: window.costsCategory,
            costables: window.costables
        }
    },
    methods: {
        ...mapActions({
            update: 'CostType/update'
        }),
        addData() {
            this.vr(this.costType.name, 'نام');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/cost-type', this.costType)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                $('.add-cost-type-modal').modal('hide')
            });
        },
    }
}
</script>