<template>
    <!-- Modal -->
<div class="add-workjob">
    <div class="modal fade add-workjob-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                        </ul>
                       <div class="row mot-modal-inputs-5 m-0">

                            
                            <div class="form-group">
                                <label for="name">نام</label>
                                <input type="text" class="form-control" id="name" v-model="workjob.name">
                            </div>
                        
                            <div class="form-group">
                                <label for="comments">توضیحات</label>
                                <input type="text" class="form-control" id="comments" v-model="workjob.comments">
                            </div>
            
                        </div>
                        <hr>
                            <div class="form-group mt-3 row flex-column ">
                              <div class="d-flex align-items-center">
                                <h6 class="mb-0 ml-2"> شرح وظایف {{ workjob.name }}</h6>
                                <button type="button" class="btn btn-sm btn-primary  align-self-end mot-w-45"
                                                @click="addDuties">+</button>
                              </div>
                                        <hr>
                                        <div class="class-section max-300-scroll row mot-modal-inputs-5 mx-0">
                                            <div class="row col-12 px-0"
                                                v-for="(workjobDuties, index) in workjob.duties" :key="index">

                                                <!-- MYCLASS -->
                                                <div class="form-group mt-1">
                                                    <label for="key">
                                                        <i @click="minusDuties(index)"
                                                            class="fa fa-times text-danger"></i>
                                                    </label>
                                                    <label for="class_name">عنوان شرح وظایف </label>
                                                    <input type="text" class="w-100 mot-h-auto " id="class_name" 
                                                        v-model="workjobDuties.name">
                                                
                                                    <div class="w-100">
                                                     <label for="desc" class="mt-2 form-group"> توضیحات</label>
                                                             <textarea type="text" class="w-100 mot-h-auto "  id="desc"
                                                                 v-model="workjobDuties.description">
                                                             </textarea>
                                                    </div>
                                                </div>
                                            

                                                <!-- MYCLASS -->
                                            </div>
                                         
                                        </div>
                            </div>







                            <div class="row">
                                <div class="form-group">
                                        <input type="submit" class="form-control" :value="[workjob.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                                </div>
                            </div>
                          
                      
                   </form>
                </div>
            </div>
        </div>
    </div>

    </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddWorkJob",
    computed: {
        ...mapGetters({
            workjob: 'WorkJob/data'
        })
    },
    data(){
        return{
           
        }
    },
 
    methods: {
        ...mapActions({
            update: 'WorkJob/update'
        }),

        addData() {
            // this.vr(data,  alert);
            if(!this.v_error_check()) return;

            axios.post('/api/v1/workjob', this.workjob)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.workjob.insideId = res.data.data.id;
                this.workjob.insideType = 'update';


                this.update(res.data.data)
               
                $('.add-workjob-modal').modal('hide')
            });
        },
        minusDuties(index) {
            if (this.workjob.duties.length > 1) {
                this.workjob.duties = this.workjob.duties.filter(x => x != this.workjob.duties[index])
            }
        },
        addDuties() {
            this.workjob.duties.push({
                description: null,
                name: null,
         
            })
        },

    }

}
</script>