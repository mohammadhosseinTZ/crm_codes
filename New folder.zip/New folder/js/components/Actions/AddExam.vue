<template>
<div class="add-exam">
    <div class="modal fade add-exam-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش آزمون</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs m-0">
                           <div class="form-group mt-1">
                                   <label for="name">نام</label>
                                   <input type="text" class="form-control" id="name" v-model="exam.name">
                           </div>
                           <div class="form-group mt-1">
                                <label for="price">قیمت</label>
                                <input type="number" class="form-control" id="price" v-model="exam.price">
                           </div>
                           <div class="form-group mt-1">
                                <label for="free_use">تعداد رایگان</label>
                                <input type="number" class="form-control" id="free_use" v-model="exam.free_use">
                           </div>
                           <div class="form-group mt-1">
                                <label for="timer">تایمر(به ثانیه)</label>
                                <input type="number" class="form-control" id="timer" v-model="exam.timer">
                           </div>
                            <div class="form-group mt-1">
                                <label for="question_count">تعداد سوالات در آزمون</label>
                                <input type="number" class="form-control" id="question_count" v-model="exam.question_count">
                           </div>
                           <div class="form-group mt-1">
                                <label for="pass_score_percent">درصد قبولی</label>
                                <input type="number" class="form-control" id="pass_score_percent" v-model="exam.pass_score_percent">
                           </div>

                            <div class="form-group mt-1">
                                <label for="content">توضیحات</label>
                                <textarea class="form-control" id="content" v-model="exam.content"></textarea>
                           </div>

                            <div class="form-group mt-1">
                                <label for="main_course">دوره اصلی</label>
                                <v-select id="main_course" placeholder="دوره اصلی" v-model="exam.course_id" :options="courses" />
                            </div>

                            <div class="form-group mt-1">
                                <label for="courses">دوره ها</label>
                                <v-select id="courses" placeholder="دوره ها" multiple v-model="exam.courses" :options="courses" />
                            </div>

                            <div ref="add_image" class="form-group mt-1">
                                <label for="image">تصویر</label>
                                <input type="file" @change="setPreview('add_image', 'self_image')" ref="self_image" accept="image/*" class="form-control mb-3" id="image" >
                           </div>


                       </div>
                       
                       <div class="row mot-modal-inputs m-0">
                           <div class="col form-group">
                                <input type="submit" class="form-control" :value="[exam.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
import Cropper from 'cropperjs';
export default{
    name: "AddExam",
    data(){
        return {
            courses: window.courses,
            cropper: {},
        }
    },
    computed: {
        ...mapGetters({
            exam: 'Exam/data'
        })
    },
    watch:  {
        exam: {
            handler: function(newItem){
                for (const [key, value] of Object.entries(this.cropper)){
                    this.$refs[key].value = null
                    value.destroy()
                }
                $(this.$refs.self_image).parent().children('img').remove()
                this.cropper = {}
                if(newItem.image){
                    $(this.$refs.self_image).parent().append(`<img src="${newItem.image}" class="preview">`)
                }
                
            }
        }
    },
    methods: {
        ...mapActions({
            update: 'Exam/update'
        }),

        addData() {

            var promises = [
            this.vr(this.exam.name, 'نام'),
            this.vr(this.exam.course_id, 'دوره مربوط به آزمون'),
            this.vr(this.exam.price, 'قیمت'),
            this.vr(this.exam.free_use, 'تعداد استفاده رایگان'),
            this.vr(this.exam.question_count, 'تعداد سوالات در هر آزمون'),
            this.vr(this.exam.pass_score_percent, 'نمره قبولی'),
            ];
            
            Promise.all(promises).then(values => {
                if(!this.v_error_check()) return;

                var formdata = new FormData()
                var formdataset = [];

                for(var n of Object.entries(this.exam)){
                    if(typeof n[1] === 'object' && !Array.isArray(n[1])){
                        formdata.append(n[0], n[1] !== null ? n[1].id : null)
                    }else{
                        formdata.append(n[0], n[1])
                    }
                }

                for (const [key, value] of Object.entries(this.cropper)) {
                    var imageset = new Promise(resolve => {
                        value.getCroppedCanvas({
                            imageSmoothingEnabled: true,
                            imageSmoothingQuality: 'high',
                            maxWidth: 1300,
                            maxHeight: 1300,
                        }).toBlob((blob) => {
                            return resolve(formdata.append(key.replace('self_', ''), blob))	
                        }, "image/jpeg", 0.90)
                            
                    })

                    formdataset.push(imageset)
                }
        
                var courses = [];
                for(var n of this.exam.courses){
                    courses.push(n.id)
                }
                formdata.set('courses', courses.join(','))
                
                Promise.all(formdataset).then(res => {
                    axios.post('/api/v1/exam', formdata)
                    .then(res => {
                        if(res.data.alert && res.data.alert.type == 'error') return;
                        this.update(res.data.data)
                        $('.add-exam-modal').modal('hide')
                    });
                })
            })

        },


        setPreview(ref, selft){
            var image = this.$refs[selft].files.item(0)

            for(var n of this.$refs[ref].querySelectorAll('.preview')){
                n.remove()
            }

            var preview = document.createElement('img')
            preview.src = URL.createObjectURL(image)
            preview.classList.add('preview')


            this.cropper[selft] = new Cropper(preview, {
				zoomable: false,
			});
            
            
            this.$refs[ref].appendChild(preview)
        },

    }
}
</script>