<template>
    <!-- Modal -->
<div class="add-service">
    <div class="modal fade add-service-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش خدمت</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                        <div class="row mot-modal-inputs-4  m-0">
                            <div class="form-group mt-1 ">
                                <label for="name">نام خدمت</label>
                                <input type="text" id="name" class="form-control" v-model="service.name"> 
                            </div>
                            <div class="form-group mt-1 ">
                                <label for="price">هزینه خدمت</label>
                                <input type="number" id="price" class="form-control" v-model="service.price"> 
                            </div>
                            <div class="form-group mt-1 ">
                                <label for="category">دسته بندی</label>
                                <v-select @input="changeCat" id="category" multiple v-model="service.category" :options="servicesCategory"  />
                           </div>
                           <div class="form-group mt-1 ">
                                <label for="category">شعبه</label>
                                <v-select id="branches" placeholder="شعبه های ارائه دهنده" multiple v-model="service.branches" :options="branches" />
                            </div>
                            <div class="form-group mt-1 ">
                                <label for="parent">خدمت والد</label>
                                <v-select id="parent" placeholder="خدمت والد" v-model="service.parent_id" :options="services" @search:focus="search_params = 'service|name|services'"  v-debounce="dynamicSearch"  />
                            </div>
                            <div class="form-group mt-1 ">
                                <label for="service-courses">اگر این خدمت مربوط به دوره ای است وارد کنید</label>
                                <v-select id="service-courses" multiple placeholder="انتخاب دوره ها" v-model="service.courses" :options="courses"  />
                            </div>
                            <div class="form-group mt-1 ">
                                <label for="service-products">اگر این خدمت مربوط به محصولی است وارد کنید</label>
                                <v-select id="service-products" multiple placeholder="انتخاب محصولات" v-model="service.products" :options="products" @search:focus="search_params = 'product|name,code|products'"  v-debounce="dynamicSearch"  />
                            </div>

                            <div class="form-group mt-1 ">
                                <label for="service-products">کلید های برنامه نویسی</label>
                                <v-select id="service-products" multiple  taggable  placeholder="انتخاب کلید ها" v-model="service.keys" :options="keys"  />
                            </div>

                            <div class="form-group mt-1 ">
                                <input type="submit" class="form-control" :value="[service.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                            </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddCall",
    computed: {
        ...mapGetters({
            service: 'Service/data'
        })
    },
    data(){
        return{
            branches : window.branches,
            servicesCategory: window.servicesCategory,
            keys: window.keys,
            services: [],
            products: []
        }
    },
 
    methods: {
        ...mapActions({
            update: 'Service/update',
        }),
     
        addData() {
            this.vr(this.service.category, 'دسته بندی');
            this.vr(this.service.branches, 'شعبه ارائه دهنده');
            this.vr(this.service.name, 'نام');
            this.vr(this.service.price, 'قیمت');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/service', this.service)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                $('.add-service-modal').modal('hide')
            });
        },

        changeCat(){
            for(var cat of this.service.category){
                if(!cat.selectable){
                    this.service.category = this.service.category.filter(x => x.id != cat.id)
                }
            }
        },

    }

}
</script>

