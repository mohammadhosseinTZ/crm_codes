<template>
<div class="add-call">
    <div class="modal fade add-course-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش دوره</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs-5 m-0">
                           <div class="form-group mt-1">
                                   <label for="course">دوره</label>
                                   <input type="text" class="form-control" id="course" v-model="course.name">
                           </div>
                           <div class="form-group mt-1">
                                <label for="price">قیمت</label>
                                <input type="number" class="form-control" id="price" v-model="course.price">
                           </div>
   
         
                           <div class="form-group mt-1">
                                <label for="price">هزینه کلاس خصوصی برای هر ساعت</label>
                                <input type="number" class="form-control" id="price" v-model="course.private_price">
                           </div>
                           <div class="form-group mt-1">
                                <label for="price">هزینه کلاس آنلاین</label>
                                <input type="number" class="form-control" id="price" v-model="course.online_price">
                           </div>

                           <div class="form-group mt-1">
                                <label for="groups">گروه ها</label>
                                <v-select id="groups" placeholder="گروه ها" multiple v-model="course.groups" :options="grpups" />
                            </div>
                            <div class="form-group mt-1">
                                <label for="branches">شعبه ها</label>
                                <v-select id="branches" placeholder="شعبه های برگزار کننده" multiple v-model="course.branches" :options="branches" />
                            </div>

                       </div>
                        <div class="mt-3">
                          <fieldset class="border col-md-12 mb-2">
                            <legend class="w-auto">استاندارد ها برای مدارک</legend>
                                <div class="row mot-modal-inputs-4">
                                    <div class="form-group mt-1">
                                            <label for="standard_hours">ساعت استاندارد</label>
                                            <input type="number" class="form-control" id="standard_hours" v-model="course.standard_hours">
                                    </div>

                                    <div class="form-group mt-1">
                                            <label for="standard_name">نام استاندارد </label>
                                            <input type="text" class="form-control" id="standard_name" v-model="course.standard_name">
                                    </div>

                                    <div class="form-group mt-1">
                                            <label for="standard_code">کد استاندارد</label>
                                            <input type="text" class="form-control" id="standard_code" v-model="course.standard_code">
                                    </div>

                                    <div class="form-group mt-1">
                                            <label for="standard_headlines">سرفصل های استاندارد</label>
                                            <input type="text" class="form-control" id="standard_headlines" v-model="course.standard_headlines">
                                    </div>
                                </div>
                        </fieldset>


                       </div>
                       <div class="row m-0">
                           <div class="col form-group">
                                <input type="submit" class="form-control" :value="[course.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
export default{
    name: "AddCourse",
    data(){
        return {
            grpups: window.coursesCategory,
            branches : window.branches
        }
    },
    computed: {
        ...mapGetters({
            course: 'CourseIndex/course'
        })
    },
    methods: {
        ...mapActions({
            update: 'CourseIndex/update'
        }),

        addData() {
            this.vr(this.course.name, 'نام');
            this.vr(this.course.price, 'قیمت');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/course', this.course)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                $('.add-course-modal').modal('hide')
            });
        },
    }
}
</script>