<template>
    <div class="add-allocation">
        <div class="modal fade add-allocation-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">افزودن/ ویرایش تقسیمات هزینه</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                          <form action="" @submit.stop.prevent="addData">
                           <ul class="err-box">
                                <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                            </ul>
                           <div class="row mot-modal-inputs m-0">    
                                <div class="mb-2">
                                    <label for="costid">شماره هزینه </label>
                                    <v-select id="costid" @input="showItems" v-model="allocation.cost" :options="costs" v-debounce="searchCost" />
                                </div>

                                <div class="mb-2">
                                    <label for="date">تاریخ</label>
                                    <date-picker id="date" format="YYYY-MM-DD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="allocation.created_at"></date-picker>
                                </div>

                           </div>

                            <div class="items  mb-4" v-if="allocation.cost">
                                    <div class="row mot-modal-inputs-6 item mt-4" v-for="(alo, index) in allocation.items" :key="index">

                                        <div class="form-group">
                                            <i v-if="index != 0" @click="minusItem(index)" class="fa fa-times text-danger"></i>
                                            <label for="costitem">انتخاب آیتم هزینه</label>
                                            <v-select @input="detectValues(alo)" id="costitem"  v-model="alo.cost_item" :options="allocation.cost.items" />
                                        </div>

                                        <div class="form-group">
                                            <label for="class-course">تخصیص به کلاس</label>
                                            <v-select id="class-course"  v-model="alo.allocationable" :options="class_courses" v-debounce="searchClassCourse" />
                                        </div>

                                        <div class="form-group">
                                            <label for="allocationunit">واحد تخصیص</label>
                                            <v-select id="allocationunit"  v-model="alo.allocation_type" :options="allocation_units" />
                                        </div>

                                        <div class="form-group mt-1">
                                            <label for="allocationvalue">مقدار تخصیص</label>
                                            <input class="form-control" @keyup="calcValues(alo)" type="number" step="0.001" id="allocationvalue"  v-model="alo.type_value" />
                                        </div>

                                        <div class="form-group mt-1">
                                            <label for="allocationtypevalue">مقدار محاسبه شده</label>
                                            <input class="form-control" disabled v-model="alo.allocation_value">
                                        </div>

                                        <div class="form-group mt-1">
                                            <label for="allocationtypevalue">باقی مانده</label>
                                            <input class="form-control" disabled v-model="alo.glose"><small v-if="alo.cost_item">{{locate(alo.cost_item.unit.name)}}</small>
                                        </div>

                                        <div class="form-group mt-1">
                                            <label for="costitemprice">هزینه کل</label>
                                            <input v-if="alo.cost_item" class="form-control" disabled v-model="alo.cost_item.all_price">
                                        </div>

                                        <div class="form-group mt-1">
                                            <label for="allocationprice">هزینه محاسبه شده</label>
                                            <input class="form-control" disabled v-model="alo.price">
                                        </div>

                                        <div class="form-group mt-1">
                                            <label for="allocationcomment">توضیحات</label>
                                            <input id="allocationcomment" class="form-control" v-model="alo.comment">
                                        </div>

                                    </div>
                                    <button type="button" class="btn btn-sm btn-primary mt-2" @click="addItem">+</button>
                                </div>


                           <div class="row mot-modal-inputs m-0">
                               <div class="form-group">
                                    <input type="submit" class="form-control" :value="[allocation.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                               </div>
                           </div>
                       </form>
                    </div>
                </div>
            </div>
        </div>    
    </div>
    </template>
    
    <script>
    import { mapGetters,mapActions } from 'vuex';
    export default{
        name: "AddAllocationItem",
    
        computed: {
            ...mapGetters({
                allocation: 'Allocation/data'
            })
        },
        data(){
            return{
                allocation_units: window.defined_enums.allocation_units,
                costs: [],
                class_courses: []
              }
        },
        methods: {
            ...mapActions({
                update: 'Allocation/update'
            }),
            addData() {
     
                if(!this.v_error_check()) return;

                axios.post('/api/v1/allocation', this.allocation)
                .then(res => {
                    if(res.data.alert && res.data.alert.type == 'error') return;
                    for(var n of res.data.data){
                        this.update(n)
                    }
                    $('.add-allocation-modal').modal('hide')
                });
            },

            searchCost(search, loading){
                if(!search.length) return;
                loading = true;
                    axios.get(`/api/v1/cost/search/costspoly/${search}`)
                    .then(res => {
                            this.costs = res.data
                        loading = false;
                    });
            },

            searchClassCourse(search, loading){
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/class-course?search=${search}`)
                .then(res => {
                    this.class_courses = res.data.data
                    loading = false;
                });
            },

            addItem(){
                this.allocation.items.push({
                    allocation_type: window.defined_enums.allocation_units.find(x => x.name == 'by_unit'), /** */
                    cost_item: null,
                    type_value: 0,
                    allocationable: null,
                    comment: null, 
                    allocation_value: null,
                    price: null,
                    glose: null
                })
            },
            minusItem(index){
                if(this.allocation.items.length > 1){
                    this.allocation.items = this.allocation.items.filter(x => x != this.allocation.items[index])
                }
            },
            
            showItems(){
                if(!this.allocation.cost || this.allocation.cost != this.allocation.old) this.allocation.items = []
                this.allocation.old = this.allocation.cost
                this.allocation.items.push({
                    allocation_type: window.defined_enums.allocation_units.find(x => x.name == 'by_unit'), /** */
                    cost_item: null,
                    type_value: 0,
                    allocationable: null,
                    comment: null, 
                    allocation_value: null,
                    price: null,
                    glose: null
                })   
            },

            detectValues(item){
                if(!item.cost_item)  return;
                item.price = 0
                item.glose = item.cost_item.quantity - parseInt(item.cost_item.used_quantity || 0)
                return;
            },

            calcValues(item){
                if(!item.allocation_type || !item.cost_item)  return;
                var BeforItems = this.allocation.items.filter(x => x.cost_item.id == item.cost_item.id)
                .map(x => parseFloat(x.type_value)).reduce(function(a, b) { return parseInt(a) + parseInt(b); }, 0)

                if(item.allocation_type.name == 'by_unit'){
                    var CostItemValuePreQuantity = item.cost_item.all_price / item.cost_item.quantity
                    item.allocation_value = parseFloat(item.type_value).toFixed(2)
                    item.price = Math.round(CostItemValuePreQuantity * item.type_value)
                }
                if(item.allocation_type.name == 'by_percent'){
                    item.allocation_value = parseFloat(item.type_value / 100 * item.cost_item.quantity).toFixed(2)
                    item.price =  Math.round(item.type_value / 100 * item.cost_item.all_price)
                }

                for(var n of this.allocation.items.filter(x => x.cost_item.id == item.cost_item.id)){
                    if(n.allocation_type.name == 'by_unit'){
                        n.glose = (n.cost_item.quantity) - BeforItems - parseInt(item.cost_item.used_quantity || 0)
                    }
                    if(n.allocation_type.name == 'by_percent'){
                        n.glose = ((n.cost_item.quantity - (BeforItems / 100 * n.cost_item.quantity)).toFixed(2)) - parseInt(item.cost_item.used_quantity || 0)
                    }
                }

            },
        }
    }
    </script>