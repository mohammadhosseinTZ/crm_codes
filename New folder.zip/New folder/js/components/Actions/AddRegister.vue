<template>
    <!-- Modal -->
<div class="add-register">
    <div class="modal fade add-register-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <div class="d-flex align-items-center justify-content-between w-100">
                        <div class="d-flex">
                            <h5 class="modal-title">افزودن/ ویرایش ثبت نامی</h5>
                            <button v-if="can('see_logs') && register.insideType == 'update'" @click="getLogs" class="btn btn-sm btn-primary mx-2">مشاهده لاگ ها</button>
                        </div>
                        <button type="button" class="close mx-0" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    
                </div>
                <div class="model-body">
                     <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs-6 m-0">
                     
                               <div class="form-group mt-1 ">
                                    <label for="course">دوره</label>
                                   <v-select :disabled="register.insideType == 'update' && !can('change_course')" v-if="courses.length" @input="getCourse" v-model="register.course_id" :options="courses" />
                               </div>
                               <div class="form-group mt-1 ">
                                    <label for="class-course">انتخاب کلاس</label>
                                   <v-select :disabled="register.insideType == 'update' && !can('change_class_course')" id="class-course" @input="handlePrice" v-model="register.class_course_id" :options="class_courses" @search="searchClassCourse" />
                               </div>
                               <div class="form-group mt-1 ">
                                   <label for="comments">توضیحات</label>
                                   <textarea class="form-control" v-model="register.comments" id="comments"></textarea>
                               </div>
                               <div class="form-group mt-1 " v-if="register.price">
                                    <label for="reference" >معرفی کننده</label>
                                   <v-select id="reference" @input="setRef" :disabled="register.insideType == 'update' && !can('change_course')" v-model="register.user_reference_id" :options="users"  v-debounce="searchUsers" />
                               </div>
                               <div class="form-group mt-1 ">
                                    <label for="">تاریخ</label>
                                    <date-picker format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="register.created_at"></date-picker>
                                </div>
                                
                
                               <div class="form-group mt-1 ">
                                    <label for="reasons">دلیل ثبت نام</label>
                                   <v-select id="reasons" v-if="reasons.length" v-model="register.reason_id" :options="reasons" />
                               </div>
                               <div class="form-group mt-1 ">
                                    <label for="lreasons">دلیل انصراف / اگر انصراف داده است انتخاب کنید</label>
                                   <v-select id="lreasons" :disabled="!can('can_leave_users')" v-if="leave_reasons.length" v-model="register.leave_reason" :options="leave_reasons" />
                               </div>
                                <div class="form-group mt-1 ">
                                   <label for="price">هزینه</label>
                                   <input class="form-control" :disabled="disabledIf()" type="number" v-model="register.price" id="price">
                               </div>
                                <div class="form-group mt-1 " v-if="register.price">
                                   <label for="dpricefor">دلیل کسری/اضافه</label>
                                   <v-select id="dpricefor" multiple placeholder="دلیل کسری اضافه" @input="setDiscountPercent" v-model="register.discount_fors" :options="discount_fors" />
                               </div>

                               <div class="form-group mt-1 " v-if="register.price">
                                   <label for="discount-pecenter">مبلغ پراختی با احتساب کسری/اضافه</label>
                                   <input type="number" id="discount-pecenter" :disabled="!can('edit_price_manual')" @keyup="calcPercent" class="form-control" v-model="calcpercentVal" placeholder="محاسبه درصد کسری/اضافه">
                               </div>

                               <div class="form-group mt-1 " v-if="register.price">
                                   <label for="dprice">مبلغ پراختی با احتساب کسری/اضافه</label>
                                   <input class="form-control" :disabled="!can('edit_price_manual')" type="number" v-model="register.discount_price" id="dprice">
                               </div>
                              
                                <div class="form-group mt-1 " v-if="canOnline()">
                                    <label for="isonline">شیوه برگزاری کلاس برای ایشان آنلاین است؟</label>
                                    <input id="isonline" @input="calcOnline" type="checkbox" v-model="register.is_online_course"> 
                                </div>
                               
                                <div class="form-group mt-1 ">
                                    <input type="submit" class="form-control" :value="[register.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                                </div>
                
                       </div>
                   </form>

                   <hr>

                   <table class="table table-bordered" v-if="logs.length && can('see_logs') && register.insideType == 'update'">
                        <tr>
                            <th>نوع فعالیت</th>
                            <th>دوره</th>
                            <th>دلیل انطراف</th>
                            <th>هزینه</th>
                            <th>تاریخ</th>
                            <th>توسط</th>
                            <th>برای</th>
                        </tr>
                        <tr v-for="log in logs" :key="log.id">
                            <th>{{locate(log.log_key)}}</th>
                            <th>{{log.history.course}} - {{log.history.classCourse}}</th>
                            <th>{{log.history.leaveReason}}</th>
                            <th>{{log.history.price}}</th>
                            <th>{{log.created_at}}</th>
                            <th>{{log.user.name}}</th>
                            <th>{{log.history.user}}</th>
                        </tr>
                   </table>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddRegister",
    props: ['data', 'type'],
    computed: {
        ...mapGetters({register: 'Register/register'})
    },
    watch:    {
        register: {
            handler: function (newItem) {
            }
        }
    },
    data(){
        return{ 
            courses: window.courses,
            reasons:window.reasons,
            leave_reasons: window.leaveReasons,
            class_courses: window.classCourses,
            discount_fors: window.discountFor,
            calcpercentVal: 0,
            logs: [],
            users: []
        }
    },
    mounted(){
        var obj = this
        $('.add-register-modal').on('hidden.bs.modal', function (e) {
            obj.logs = []
        })
    },
    methods: {
        ...mapActions({addPayment: "Payment/addPayment", updatePersonRegisterData: "updatePersonRegisterData", updateRegisterData: 'Register/updateRegisterData'}),
        getCourse(){
            if(!this.register.course_id){
                this.register.price = null
                this.register.discount_fors = []
                this.register.discount_price = null
                this.calcpercentVal = 0
                return;
            }
            let selectedCouse = window.courses.find(x => x.id == this.register.course_id.id )
            if(selectedCouse){
                this.register.price = selectedCouse.price
                this.register.selectedCourse = selectedCouse
            }
        },
        searchClassCourse(search, loading){
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/class-course?search=${search}`)
                .then(res => {
                    this.class_courses = res.data.data
                    loading = false;
                });
        },
        addData() {

            this.vr(this.register.course_id, 'ایدی مرجع');
            this.vr(this.register.class_course_id, 'نام دوره');
            this.vr(this.register.reason_id, 'دلیل ثبت نام');
            this.vr(this.register.price, 'هزینه');

            if(!this.v_error_check()) return;

            axios.post('/api/v1/register', this.register)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.register.insideId = res.data.data.id;
                
                this.register.just_leave_reason = this.register.leave_reason
                 

                if(this.register.insideType == 'insert'){

                    Promise.all([
                        $('.add-person-modal').modal('hide'),
                        $('.add-register-modal').modal('hide'),
                       this.addPayment({
                        user_id: res.data.data.user_id,
                        price: res.data.data.price,
                        register_type: window.serviceList.find(x => x.en_name == 'courses'),
                        register_id: res.data.data.id,
                       })
                    ]).then(res => {
                        $('.add-payment-modal').modal('show')
                    })


                }else{
                    $('.add-person-modal').modal('hide')
                    $('.add-register-modal').modal('hide')
                }
                
                this.updatePersonRegisterData({data: res.data.data});
                this.updateRegisterData(res.data.data);
                this.register.insideType = 'update';
                     
            });
   
        },

        setDiscountPercent(){
            this.register.discount_price = null
            this.calcpercentVal = 0

            for(var n of this.register.discount_fors){
                if(!n.discount_percent) continue;
                this.calcpercentVal += parseInt(n.discount_percent);
            }
            this.calcPercent()

        },
        setRef(){
            if(!this.register.user_reference_id){
                this.register.discount_price = 0
                this.register.discount_fors = []
                this.calcpercentVal = 0
                return this.calcPercent()
            }
            this.calcpercentVal += parseInt(this.register.user_reference_id.target_discount);
            this.register.discount_fors.push(window.discountFor.find(x => x.id == this.register.user_reference_id.select_discount_for_id))
            return this.calcPercent()
        },

        calcPercent(){
            let price = this.register.price
            let percent = this.calcpercentVal
            this.register.discount_price = parseInt(price) - (parseInt(percent) / 100 ) * parseInt(price)
        },
        

        disabledIf(){
            if(this.can('edit_price_manual')){
                return false
            }

            if(!this.register.class_course_id|| !this.register.course_id){
                return true
            }
            if(this.register.class_course_id.course_code == 999){
                return false
            }
           return false;
        },

        handlePrice(){
            this.register.discount_price = null
            this.register.discount_fors = []
            this.calcpercentVal = 0

            if(this.register.class_course_id && this.register.class_course_id.course_code == 999){
                return;
            }

            this.register.price = this.register.selectedCourse.price
            this.calcPercent()
            return;
        

        },

        canOnline(){
            return this.register.selectedCourse
        },

        calcOnline(){
            if(this.register.class_course_id.course_code == 999 || !this.register.selectedCourse.online_price){
                return;
            }
            
            if(!this.register.is_online_course == false){
                this.register.price = this.register.selectedCourse.price
                this.calcPercent()
                return;
            }
            this.register.price = this.register.selectedCourse.online_price
            this.calcPercent()
        },

        getLogs(){
            axios.get(`/api/v1/register/${this.register.insideId}/logs`).then(res => this.logs = res.data.data)
        },

        
        searchUsers(search, loading){
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/search-refs-users/${search}/${this.register.user_id || this.register.insideId}/${this.register.insideType == 'update' ? '?register_id=' + this.register.insideId : ''}`)
                .then(res => {
                        this.users = res.data
                    loading = false;
                });
        },

        setReference(){
            
        }


    }

}
</script>
