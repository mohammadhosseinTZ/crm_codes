<template>
    <!-- Modal -->
<div class="add-category">
    <div class="modal fade add-category-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش دسته بندی</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                        <div class="row mot-modal-inputs-4 m-0">
                            <div class="form-group mt-1">
                                <label for="name">نام دسته بندی</label>
                                <input type="text" id="name" class="form-control" v-model="category.name"> 
                            </div>
                            <div class="form-group mt-1">
                                <label for="type">نوع دسته بندی</label>
                                <v-select id="type" placeholder="نوع دسته بندی" v-model="category.type" :options="servicesList"  />
                            </div>
                            <div class="form-group mt-1">
                                <label for="parent">دسته والد</label>
                                <v-select id="parent" placeholder="خدمت والد" v-model="category.parent_id" :options="categories" @search:focus="search_params = 'category|name|categories'" v-debounce="dynamicSearch"  />
                            </div>
                       
                            <div class="form-group mt-1">
                                <label for="selectable">قابل انتخاب است؟</label>
                                <input type="checkbox" id="selectable" v-model="category.selectable"> 
                            </div>
                            
                            <div class="form-group">
                                <input type="submit" class="form-control" :value="[category.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                            </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddCall",
    computed: {
        ...mapGetters({
            category: 'Category/data'
        })
    },
    data(){
        return{
            servicesList: window.serviceList,
            categories: [],
        }
    },
 
    methods: {
        ...mapActions({
            update: 'Category/update',
        }),
     
        addData() {
            this.vr(this.category.name, 'نام');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/category', this.category)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                $('.add-category-modal').modal('hide')
            });
        }

    }

}
</script>

