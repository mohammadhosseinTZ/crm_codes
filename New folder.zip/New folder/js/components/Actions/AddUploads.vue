<template>
    <!-- Modal -->
<div class="add-uploads">
    <div class="modal fade add-uploads-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                        </ul>
                       <div class="row mot-modal-inputs-6 m-0">

                            
                        <div class="form-group">
                            <label for="upload_type_id">upload_type_id</label>
                            <input type="text" class="form-control" id="upload_type_id" v-model="uploads.upload_type_id">
                        </div>
            
                        <div class="form-group">
                            <label for="attachment_id">attachment_id</label>
                            <input type="text" class="form-control" id="attachment_id" v-model="uploads.attachment_id">
                        </div>
            
                        <div class="form-group">
                            <label for="uploadable_id">uploadable_id</label>
                            <input type="text" class="form-control" id="uploadable_id" v-model="uploads.uploadable_id">
                        </div>
            
                        <div class="form-group">
                            <label for="uploadable_type">uploadable_type</label>
                            <input type="text" class="form-control" id="uploadable_type" v-model="uploads.uploadable_type">
                        </div>
            
                        <div class="form-group">
                            <label for="comments">comments</label>
                            <input type="text" class="form-control" id="comments" v-model="uploads.comments">
                        </div>
            
                        <div class="form-group">
                            <label for="status">status</label>
                            <input type="text" class="form-control" id="status" v-model="uploads.status">
                        </div>
            

                            <div class="row">
                                <div class="form-group">
                                        <input type="submit" class="form-control" :value="[uploads.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                                </div>
                            </div>
                          
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

    </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddUploads",
    computed: {
        ...mapGetters({
            uploads: 'Uploads/data'
        })
    },
    data(){
        return{
           
        }
    },
 
    methods: {
        ...mapActions({
            update: 'Uploads/update'
        }),

        addData() {
            // this.vr(data,  alert);
            if(!this.v_error_check()) return;

            axios.post('/api/v1/upload', this.uploads)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.uploads.insideId = res.data.data.id;
                this.uploads.insideType = 'update';


                this.update(res.data.data)
               
                $('.add-uploads-modal').modal('hide')
            });
        }

    }

}
</script>