<template>
    <!-- Modal -->
<div class="add-exam-question">
    <div class="modal fade add-exam-question-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش سوال</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs m-0">
                           <div class="form-group mt-1">
                                <label for="question">سوال</label>
                                <input type="text" v-model="question.question" class="form-control" id="question">
                           </div>
                           <div class="form-group mt-1">
                                <label for="choose_1">گزینه 1</label>
                                <input type="text" v-model="question.choose_1" class="form-control" id="choose_1">
                           </div>
                           <div class="form-group mt-1">
                                <label for="choose_2">گزینه 2</label>
                                <input type="text" v-model="question.choose_2" class="form-control" id="choose_2">
                           </div>
                           <div class="form-group mt-1">
                                <label for="choose_3">گزینه 3</label>
                                <input type="text" v-model="question.choose_3" class="form-control" id="choose_3">
                           </div>
                           <div class="form-group mt-1">
                                <label for="choose_4">گزینه 4</label>
                                <input type="text" v-model="question.choose_4" class="form-control" id="choose_4">
                           </div>
                           <div class="form-group mt-1">
                                <label for="answer">پاسخ</label>
                                <input type="number" min="1" max="4" v-model="question.answer" class="form-control" id="answer">
                           </div>
                            <div class="form-group mt-1">
                                <input type="submit" class="form-control" :value="[question.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddExamQuestion",
    computed: {
        ...mapGetters({
            exam: 'Exam/data',
            question: 'ExamQuestion/data'
        })
    },

    methods: {
        ...mapActions({
            update: 'ExamQuestion/update',
            updateExamQuestionCount: 'Exam/updateExamQuestionCount'
        }),
        addData() {
            this.vr(this.question.question, 'سوال');
            this.vr(this.question.choose_1, 'گزینه 1');
            this.vr(this.question.choose_2, 'گزینه 2');
            this.vr(this.question.choose_3, 'گزینه 3');
            this.vr(this.question.choose_4, 'گزینه 4');
            this.vr(this.question.answer, 'پاسخ');
            if(!this.v_error_check()) return;
            this.question.exam_id = this.exam.id || this.exam.insideId
            axios.post('/api/v1/exam-question', this.question)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.question.insideId = res.data.data.id;
                this.question.insideType = 'update';
                this.updateExamQuestionCount({id: this.exam.id || this.exam.insideId, count: res.data.meta.exam_question_count})
                this.update(res.data.data)
                
                $('.add-exam-question-modal').modal('hide')
            });
        }

    }

}
</script>

