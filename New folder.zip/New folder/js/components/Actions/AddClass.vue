<template>
<div class="add-call">
    <div class="modal fade add-class-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش کلاس</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs-5 m-0">
                           <div class="form-group mt-1">
                                   <label for="name">نام کلاس</label>
                                   <input type="text" class="form-control" id="name" v-model="classd.name" >
                           </div>
                           <div class="form-group mt-1">
                                <label for="capacity">ظرفیت</label>
                                <input type="text" class="form-control" id="capacity" v-model="classd.capacity" >
                           </div>
                           <div class="form-group mt-1">
                                <label for="area">مساحت</label>
                                <input type="number" class="form-control" id="area" v-model="classd.area" >
                           </div>
                           <div class="form-group mt-1">
                                <label for="color">رنگ</label>
                                <input type="color" class="form-control" id="color" v-model="classd.color" >
                           </div>
                           <div class="form-group mb-3">
                                 <label for="branches">مربوط به شعبه</label>
                                <v-select id="branches" placeholder="شعبه برگزار کننده" v-model="classd.branch" :options="branches" />
                            </div>
                       </div>
                       
                       <div class="row">
                           <div class="form-group">
                                <input type="submit" class="form-control" :value="[classd.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
export default{
    name: "AddClass",

    computed: {
        ...mapGetters({
            classd: 'ClassIndex/class'
        })
    },
    data(){
        return{
            branches: window.branches
        }
    },
    methods: {
        ...mapActions({
            update: 'ClassIndex/update'
        }),
        addData() {
            this.vr(this.classd.name, 'نام');
            this.vr(this.classd.capacity, 'ظرفیت');
            this.vr(this.classd.color, 'رنگ');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/class', this.classd)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.update(res.data.data)
                $('.add-class-modal').modal('hide')
            });
        },
    }
}
</script>