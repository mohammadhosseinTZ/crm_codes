<template>
<div class="add-check">
    <div class="modal fade add-check-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش چک</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                        <div class="row mot-modal-inputs m-0">
                                <div class="form-group mt-1">
                                    <label for="serial">سریال</label>
                                    <input type="number" v-model="data.serial" class="form-control" id="serial">
                                </div>
                                <div class="form-group mt-1">
                                    <label for="saiyad">شناسه صیاد</label>
                                    <input type="number" v-model="data.saiyad" class="form-control" id="saiyad">
                                </div>
                                <div class="form-group mt-1">
                                    <label for="price">قیمت</label>
                                    <input type="number" v-model="data.price" class="form-control" id="price">
                                </div>
                                <div class="form-group">
                                    <label for="banks">بانک</label>
                                   <v-select id="banks" v-model="data.bank" :options="banks" />
                               </div>
                                <div class="form-group">
                                    <label for="receipt">تاریخ وصول</label>
                                    <date-picker id="receipt" format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="data.receipt"></date-picker>
                                </div>
                                <div class="form-group">
                                    <label for="date">تاریخ دریافت</label>
                                    <date-picker id="date" format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="data.created_at"></date-picker>
                                </div>
                                <div class="form-group">
                                    <label for="payment">پیوست به فیش</label>
                                    <v-select id="payment" v-model="data.payment" :options="payments" @search="searchPayment" />
                                </div>
                        </div>
                       <div class="row mot-modal-inputs">
                           <div class="form-group">
                                <input type="submit" class="form-control" :value="[data.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>

import { mapGetters,mapActions } from 'vuex';
export default{
    name: "AddCheck",
    data(){
        return {
            banks: window.banks,
            payments: []
        }
    },
    computed: {
        ...mapGetters({
            data: 'Check/data',
        }),
    },

    methods: {
        ...mapActions({
            update: 'Check/update',
        }),
        searchPayment(search, loading){
            if(!search.length) return;
            loading = true;
                axios.get(`/api/v1/payment?search=10&payment-search=${search}`)
                .then(res => {
                    this.payments = res.data.data
                    loading = false;
                });
        },
        addData() {
           this.vr(this.data.serial, 'سریال');
           this.vr(this.data.price, 'قیمت');
           this.vr(this.data.bank, 'بانک');
           this.vr(this.data.payment, 'الصاق به فیش');
           this.vr(this.data.receipt, 'وصول');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/check', this.data)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return; 
                this.update(res.data.data)
               $('.add-check-modal').modal('hide')
            });
        },
    }
}
</script>