<template>
    <!-- Modal -->
     <popup name="person-service">
        <template v-slot:header><h5 class="modal-title">افزودن/ ویرایش خدمات</h5></template>
        <template v-slot:content>
            <form action="" @submit.stop.prevent="addData">
                <ul class="err-box">
                    <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                </ul>
                <div class="row m-0">


                    <div class="product-items max-500-scroll mb-3 col-12">
                        <div class="product-item mt-3  p-0 row mot-modal-inputs-5"
                            v-for="(item, index) in register.items" :key="index">

                            <div class="form-group">
                                <label for="prodcut" class="d-flex">
                                    <i v-if="index != 0" @click="minusItem(index)"
                                        class="fa fa-times text-danger px-2"></i>
                                    انتخاب خدمت
                                </label>
                                <v-select @input="getService(item)"
                                    :disabled="item.insideType == 'update' && !can('change_service_register')"
                                    id="prodcut" v-model="item.supplier" :options="services"
                                    @search:focus="search_params = 'service|name|services'"  v-debounce="dynamicSearch" />
                            </div>
                            <div class="form-group d-flex gap-1">
                                <div v-if="item.supplier && hasKey('quantifiable',item.supplier.keys) ">
                                    <label for="quantity">تعداد</label> 
                                    <input @keyup="setPrice(item)" step="1" type="number" class="form-control"
                                        id="quantity" v-model="item.quantity" placeholder="تعداد" />
                                </div>

                                <div :class="[!item.supplier || !hasKey('quantifiable',item.supplier.keys) ? 'w-100' : ''] ">
                                    <label for="price">هزینه واحد</label>
                                    <input @keyup="setPrice(item)" class="form-control"
                                        :disabled="disabledIf(item)" type="number" v-model="item.unit_price"
                                        id="price">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="price">هزینه کل</label>
                                <input class="form-control" :disabled="disabledIf(item)" type="number"
                                    v-model="item.price" id="price">
                            </div>

                            <div class="form-group d-flex gap-1">
                                <div class="min-w-200">
                                    <label for="dpricefor">دلیل کسری/اضافه</label>
                                    <v-select id="dpricefor" multiple placeholder="دلیل کسری اضافه"
                                        @input="setDiscountPercent(item)" v-model="item.discount_fors"
                                        :options="discount_fors" />
                                </div>

                                <div  class="max-w-60">
                                    <label for="calc-percent">درصد</label>
                                    <input id="calc-percent" type="number" :disabled="!can('edit_price_manual')"
                                        @keyup="calcPercent(item)" v-model="item.calcpercentVal"
                                        class="form-control">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="price">هزینه کل با تخفیف</label>
                                <input class="form-control" :disabled="disabledIf(item)" type="number"
                                    v-model="item.discount_price" id="price">
                            </div>

                        </div>
                        <button type="button" class="btn btn-sm btn-primary mt-2"
                            @click="addItem">+</button>
                    </div>

                    <div class="row col-12 m-0 p-0 mot-modal-inputs-5">
                        <div class="form-group">
                            <label for="comments">توضیحات</label>
                            <textarea class="form-control" v-model="register.comments"
                                id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="payment-discount">تخفیف روی فاکتور</label>
                            <input type="number" @keyup="calcPercent" class="form-control"
                                id="payment-discount" v-model="register.pay_discount_price" />
                        </div>
                        <div class="form-group">
                            <label for="dprice">مبلغ پراختی با احتساب کسری/اضافه</label>
                            <input class="form-control" disabled v-model="register.all_price" type="number"
                                id="dprice">
                        </div>


                        <div class="form-group">
                            <label for="">تاریخ</label>
                            <date-picker format="jYYYY-jMM-jDD" display-format="jYYYY-jMM-jDD" auto-submit
                                v-model="register.created_at"></date-picker>
                        </div>

                    </div>

                    <div class="form-group mt-1">
                        <input type="submit" class="form-control"
                            :value="[register.insideType == 'update' ? 'ویرایش' : 'افزودن']">
                    </div>

                </div>
            </form>
        </template>
     </popup>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
export default {
    name: "AddPersonService",
    props: ['data', 'type'],
    computed: {
        ...mapGetters({ register: 'ServiceRegister/register' })
    },

    data() {
        return {
            categories: window.servicesCategory,
            services: [],
            leave_reasons: window.leaveReasons,
            discount_fors: window.discountFor,
            calcpercentVal: 0,
        }
    },
    methods: {
        ...mapActions({ addPayment: "Payment/addPayment", updatePersonRegisterData: "updatePersonRegisterData", updateRegisterData: 'ServiceRegister/updateRegisterData' }),
        getService(item) {
            if (!item.supplier) {
                item.price = null
                item.unit_price = 0
                item.discount_fors = []
                item.discount_price = null
            } else {
                item.unit_price = item.supplier.sale_price
                item.discount_fors = []
                item.price = item.unit_price * item.quantity
                item.discount_price = 0
            }
            this.calcPercent(item)
        },
        searchUsers(search, loading) {
            if (!search.length) return;
            loading = true;
            axios.get(`/api/v1/search-refs-users/${search}/${this.register.user_id || this.register.insideId}/${this.register.insideType == 'update' ? '?register_id=' + this.register.insideId : ''}`)
                .then(res => {
                    this.users = res.data
                    loading = false;
                });
        },
        minusItem(index) {
            if (this.register.items.length > 1) {
                this.register.items = this.register.items.filter(x => x != this.register.items[index])
                this.calcPercent();
            }
        },
        addItem() {
            this.register.items.push({
                supplier: null,
                discount_price: null,
                discount_fors: null,
                unit_price: null,
                price: null,
                quantity: 1,
                leave_reason: null,
                calcpercentVal: 0
            })
        },
        addData() {


            if (!this.v_error_check()) return;

            axios.post('/api/v1/service-register', this.register)
                .then(res => {
                    if (res.data.alert && res.data.alert.type == 'error') return;
                    this.register.insideId = res.data.data.id;

                    this.register.just_leave_reason = this.register.leave_reason


                    if (this.register.insideType == 'insert') {

                        Promise.all([
                            $('.add-person-modal').modal('hide'),
                            $('.add-person-service-modal').modal('hide'),
                            this.addPayment({
                                user_id: res.data.data.user_id,
                                price: res.data.data.price,
                                register_type: window.serviceList.find(x => x.en_name == 'services'),
                                register_id: res.data.data.id,
                            })
                        ]).then(res => {
                            $('.add-payment-modal').modal('show')
                        })


                    } else {
                        $('.add-person-modal').modal('hide')
                        $('.add-person-service-modal').modal('hide')
                    }

                    this.updatePersonRegisterData({ data: res.data.data, type: "services" });
                    this.updateRegisterData(res.data.data);
                    this.register.insideType = 'update';

                });

        },


        setDiscountPercent(item) {
            item.discount_price = null
            item.calcpercentVal = 0

            for (var n of item.discount_fors) {
                if (!n.discount_percent) continue;
                item.calcpercentVal += parseInt(n.discount_percent);
            }

            this.calcPercent(item)

        },

        calcPercent(item = false) {
            if (item) {
                let price = item.price
                let percent = item.calcpercentVal
                item.discount_price = (parseInt(price) - (parseInt(percent) / 100) * parseInt(price))
            }
            this.register.all_price = this.register.items.map(x => x.discount_price).reduce(function (a, b) { return parseInt(a) + parseInt(b); }, 0) - parseInt(this.register.pay_discount_price)
        },


        disabledIf() {
            if (this.can('edit_price_manual')) {
                return false
            }
            if (this.register.supplier && this.register.supplier.price == 0) {
                return false;
            }
            return true;
        },

        setPrice(data) {
            data.price = data.unit_price * data.quantity
            this.calcPercent(data)
        }


    }

}
</script>
