<template>
<div class="add-call">
    <div class="modal fade add-class-course-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش دوره کلاس</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs-5 m-0">
                      
                            <div class="form-group mt-1">
                                <label for="coursecode">کد دوره</label>
                                <input type="text"  id="coursecode" v-model="classcourse.course_code" class="form-control">
                            </div>
                            <div class="form-group mt-1">
                                <label for="course">دوره</label>
                                <v-select id="course" v-if="courses.length" v-model="classcourse.course" :options="courses" />
                            </div>
                            <div class="form-group mt-1">
                                <label for="status">وضعیت</label>
                                <select class="form-control" v-model="classcourse.status" id="status">
                                    <option v-for="d in statuses" :key="d.id" :value="d.id">{{locate(d.option_value)}}</option>
                                </select>
                            </div>

                            <div class="form-group mt-1">
                                <label for="day">روز</label>
                                <input type="text"  id="day" v-model="classcourse.day" class="form-control">
                            </div>

                            <div class="form-group mt-1">
                                <label for="price">هزینه</label>
                                <input type="text"  id="price" v-model="classcourse.price" class="form-control">
                            </div>

                            <div class="form-group mt-1" v-if="classcourse.sale_price">
                                <label for="sale-price-from">تاریخ شروع تخفیف</label>
                                <date-picker id="sale-price-from" clearable format="YYYY-MM-DD HH:mm" type="datetime" compact-time display-format="jYYYY-jMM-jDD HH:mm" auto-submit v-model="classcourse.sale_price_date_from"></date-picker>
                            </div>

                            <div class="form-group mt-1">
                                <label for="time">تعداد ساعت کلاس</label>
                                <input type="number" step="0.1"  id="time" v-model="classcourse.time" class="form-control">
                            </div>

                            <div class="form-group mt-1">
                                <label for="time_to">حداکثر ساعت کلاس</label>
                                <input type="number" step="0.1"  id="time_to" v-model="classcourse.time_to" class="form-control">
                            </div>

                            <div class="form-group mt-1">
                                <label for="course_duration_unit">واحد زمان کلاس</label>
                                <v-select id="course" v-model="classcourse.course_duration_unit" :options="units" />
                            </div>

                            <div class="form-group mt-1">
                                <label for="course_duration">کلاس چند {{classcourse.course_duration_unit ? classcourse.course_duration_unit.label : null}} طول می کشد</label>
                                <input type="number" step="0.1" id="course_duration" v-model="classcourse.course_duration" class="form-control">
                            </div>

                            <div class="form-group  mt-1">
                                <label for="course_type">نوع برگذاری دوره</label>
                                <select id="course_type" v-model="classcourse.course_type" class="form-control">
                                    <option value="">بدون مقدار و تکی</option>
                                    <option value="مقدماتی">مقدماتی</option>
                                    <option value="پیشرفته">پیشرفته</option>
                                    <option value="جامع (مقدماتی و پیشرفته)">جامع</option>
                                </select>
                                <span class="disconted">هشدار: پس از انتخاب این گزینه تمامی دوره های قبلی و بعدی در سایت تغییر می کنند و چند وجهی می شوند. برای از بین بردن تغییرات و نوع دوره در سایت به پشتیبان سایت اطلاع دهید</span>
                            </div>
                            

                            <div class="form-group  mt-1">
                                <label for="">تاریخ برگذاری</label>
                                <date-picker format="YYYY-MM-DD" clearable  display-format="jYYYY-jMM-jDD" auto-submit v-model="classcourse.begin_date"></date-picker>
                            </div>

                            <div class="form-group  mt-1">
                                <label for="class">کلاس</label>
                                <v-select id="class" v-if="classes.length" v-model="classcourse.class" :options="classes" />
                            </div>
                            <div class="form-group  mt-1">
                                <label for="teacher">مدرس</label>
                                <v-select id="teacher" v-model="classcourse.teacher" :options="users" @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                            </div>

                            
                            <div class="form-group  mt-1">
                                <label for="start_time">ساعت شروع</label>
                                <input type="text"  id="start_time" v-model="classcourse.start_time" class="form-control">
                            </div>

                            <div class="form-group  mt-1">
                                <label for="end_time">ساعت پایان</label>
                                <input type="text"  id="end_time" v-model="classcourse.end_time" class="form-control">
                            </div>

                            <div class="form-group  mt-1">
                                <label for="sale_price">هزینه فروش ویژه</label>
                                <input type="text"  id="sale_price" v-model="classcourse.sale_price" class="form-control">
                            </div>

                            <div class="form-group mt-1" v-if="classcourse.sale_price">
                                <label for="sale-price-to">تاریخ پایان تخفیف</label>
                                <date-picker id="sale-price-to" clearable format="YYYY-MM-DD HH:mm" type="datetime" compact-time display-format="jYYYY-jMM-jDD HH:mm" auto-submit v-model="classcourse.sale_price_date_to"></date-picker>
                            </div>

                            <div class="form-group  mt-1">
                                <label for="comments">توضیحات</label>
                                <textarea id="comments" v-model="classcourse.comments" class="form-control"></textarea>
                            </div>

                            <div class="form-group mot-input-md mt-1">
                                <label for="has_online">آیا این دوره آنلاین برگذار می شود؟</label>
                                <input type="checkbox" @change="cleanOnline" v-model="classcourse.has_online" id="has_online">
                            </div>

                            <div class="form-group mot-input-md mt-1">
                                <label for="has_presence">آیا این دوره حضوری است؟</label>
                                <input type="checkbox" v-model="classcourse.has_presence" id="has_presence">
                            </div>

                            <div class="form-group mot-input-md mt-1">
                                <label for="sync_with_site">آیا میخواهید این دوره با سایت همگام شود؟</label>
                                <input type="checkbox" v-model="classcourse.sync_with_site" id="sync_with_site">
                            </div>
                     
                       </div>
                       <div v-if="classcourse.has_online" class="row mot-modal-inputs">
                            <div class="form-group">
                                <label for="price">هزینه</label>
                                <input type="text"  id="price" v-model="classcourse.online_price" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="sale_price">هزینه فروش ویژه</label>
                                <input type="text"  id="sale_price" v-model="classcourse.online_sale_price" class="form-control">
                            </div>

                            <div class="form-group" v-if="classcourse.online_sale_price">
                                <label for="sale-price-from">تاریخ شروع تخفیف</label>
                                <date-picker id="sale-price-from" clearable format="YYYY-MM-DD HH:mm" type="datetime" compact-time display-format="jYYYY-jMM-jDD HH:mm" auto-submit v-model="classcourse.online_sale_price_date_from"></date-picker>
                            </div>

                            <div class="form-group" v-if="classcourse.online_sale_price">
                                <label for="sale-price-to">تاریخ پایان تخفیف</label>
                                <date-picker id="sale-price-to" clearable format="YYYY-MM-DD HH:mm" type="datetime" compact-time display-format="jYYYY-jMM-jDD HH:mm" auto-submit v-model="classcourse.online_sale_price_date_to"></date-picker>
                            </div>

                        </div>
                       <div class="row mot-modal-inputs">
                           <div class="form-group mt-2">
                                <input type="submit" class="form-control" :value="[classcourse.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                           </div>
                       </div>
                   </form>
                   
                </div>
            </div>
        </div>
    </div>    
</div>
</template>

<script>
import { mapGetters,mapActions } from 'vuex';
export default{
    name: "AddClassCourse",
    data(){
        return {
            courses: window.courses,
            classes: window.classRooms,
            statuses: window.statuses,
            users: [],
            units: [{label: 'روز', val: 'days'},{label: 'هفته', val: 'weeks'}, {label: 'ماه', val: 'months'}]
        }
    },
    computed: {
        ...mapGetters({
            classcourse: 'ClassCourse/classcourse'
        })
    },
 
    methods: {
        ...mapActions({
            update: 'ClassCourse/update'
        }),

        cleanOnline(){
            if(!this.classcourse.has_online == false){
                this.classcourse.online_price = null
                this.classcourse.online_sale_price = null
                this.classcourse.online_sale_price_date_from = null
                this.classcourse.online_sale_price_date_to = null
            }
        },
        addData() {
            this.vr(this.classcourse.course_code, 'کد دوره');
            this.vr(this.classcourse.course, 'نام دوره');
            this.vr(this.classcourse.class, 'نام کلاس');
            this.vr(this.classcourse.teacher, 'نام مدرس');
            this.vr(this.classcourse.day, 'روز');
            this.vr(this.classcourse.start_time, 'ساعت شروع');
            this.vr(this.classcourse.end_time, 'ساعت پایان');
            this.vr(this.classcourse.begin_date, 'تاریخ شروع');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/class-course', this.classcourse)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                    this.update(res.data.data)
                $('.add-class-course-modal').modal('hide')
            });
        },
    }
}
</script>