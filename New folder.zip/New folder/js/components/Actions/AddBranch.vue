<template>
    <div class="add-branch">
        <div class="modal fade add-branch-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">افزودن/ ویرایش شعبه</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="model-body">
                        <form action="" @submit.stop.prevent="addData">
                            <ul class="err-box">
                                <li class="error" v-for="error in v_get_errors()" :key="error">{{ error }}</li>
                            </ul>
                            <div class="row mot-modal-inputs-6 m-0">
                                <div class="form-group mt-1">
                                    <label for="name">نام کلاس</label>
                                    <input type="text" class="form-control" id="name" v-model="branch.name">
                                </div>
                                <div class="form-group mt-1">
                                    <label for="capacity">آدرس</label>
                                    <input type="text" class="form-control" id="capacity" v-model="branch.address">
                                </div>
                                <div class="form-group mt-1">
                                    <label for="sign">کد شعبه (انگلیسی)</label>
                                    <input type="text" class="form-control" id="sign" v-model="branch.en_sign">
                                </div>

                                <div class="form-group mt-1">
                                    <label for="insta">اینستاگرام شعبه</label>
                                    <input type="text" class="form-control" id="insta" v-model="branch.insta">
                                </div>

                                <div class="form-group mt-1">
                                    <label for="telegram">تگرام شعبه</label>
                                    <input type="text" class="form-control" id="telegram" v-model="branch.telegram">
                                </div>

                                <div class="form-group mt-1">
                                    <label for="phone">شماره تماس شعبه</label>
                                    <input type="text" class="form-control" id="phone" v-model="branch.phone">
                                </div>

                                <div class="form-group mt-1">
                                    <label for="postal_code">کد پستی شعبه</label>
                                    <input type="text" class="form-control" id="postal_code"
                                        v-model="branch.postal_code">
                                </div>

                                <div class="form-group mt-1">
                                    <label for="market_url">آدرس سایت شعبه</label>
                                    <input type="text" class="form-control" id="market_url" v-model="branch.market_url">
                                </div>

                                <div class="form-group mt-1 ">
                                    <label for="market_id">کاربر انتخابی جهت ثبت اتوماتیک</label>
                                    <v-select id="market_id" v-model="branch.market_user" :options="users"
                                    @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                                </div>

                                <div class="form-group mt-1 ">
                                    <label for="manager_id">مدیریت</label>
                                    <v-select id="manager_id" v-model="branch.manager" :options="users"
                                    @search:focus="search_params = 'user|name,phone|users'"  v-debounce="dynamicSearch" />
                                </div>

                                <div class="form-group mt-1 ">
                                    <label for="sections">بخش ها</label>
                                    <v-select id="manager_id" v-model="branch.sections" multiple :options="sections"
                                    @search:focus="search_params = 'workSection|name|sections'"  v-debounce="dynamicSearch" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <hr>
                                    <h6>طبقات</h6>
                                    <hr>
                                    <div class="class-section max-300-scroll">
                                        <div class="row mot-modal-inputs-3 class-wrapper  mb-3"
                                            v-for="(branchClass, index) in branch.classes" :key="index">
                                            <div class="form-group mt-1">
                                                <label for="key"><i @click="minusItem(index)"
                                                        class="fa fa-times text-danger"></i></label>
                                                <label for="class_name">نام طبقه</label>
                                                <input type="text" class="form-control" id="class_name"
                                                    v-model="branchClass.name">
                                            </div>
                                            <div class="form-group mt-1">
                                                <label for="area">مساحت به سانتیمتر</label>
                                                <input type="text" class="form-control" id="area"
                                                    v-model="branchClass.area">
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-sm btn-primary mt-2 align-self-end mb-3"
                                            @click="addItem">+</button>

                                    </div>

                                </div>
                                <div class="col-md-8">
                                    <hr>
                                    <h6>اتاق ها</h6>
                                    <hr>
                                    <div class="class-section max-300-scroll">
                                        <div class="row mot-modal-inputs-4 class-wrapper mb-3"
                                            v-for="(branchRooms, index) in branch.rooms" :key="index">

                                            <!-- MYCLASS -->
                                            <div class="form-group mt-1">
                                                <label for="key"><i @click="minusRooms(index)"
                                                        class="fa fa-times text-danger"></i></label>
                                                <label for="class_name">نام اتاق</label>
                                                <input type="text" class="form-control" id="class_name"
                                                    v-model="branchRooms.name">
                                            </div>
                                            <div class="form-group mt-1">
                                                <label for="area">مساحت به سانتیمتر</label>
                                                <input type="text" class="form-control" id="area"
                                                    v-model="branchRooms.area">
                                            </div>
                                            <div class="form-group mt-1">
                                                <label for="capacity"> ظرفیت </label>
                                                <input type="text" class="form-control" id="capacity"
                                                    v-model="branchRooms.capacity">
                                            </div>
                                            <div class="form-group mt-1">
                                                <label for="color"> رنگ </label>
                                                <input type="color" class="form-control" id="color"
                                                    v-model="branchRooms.color">
                                            </div>

                                            <!-- MYCLASS -->
                                        </div>
                                        <button type="button" class="btn btn-sm btn-primary mt-2 align-self-end mb-3"
                                            @click="addRooms">+</button>
                                    </div>
                                
                 
                     
             

                                </div>
                                <hr>
                                    <h6>ساعت کاری</h6>
                                    <hr>
                                    <div class="class-section col-12">
                                            <div class="row m-0  class-wrapper" v-for="(work_hour , index) in branch.work_hours">
                                                <div class=" d-flex mb-2">
                                                    <label for="saturday" class="mot-w-50 mb-0 d-flex align-items-center ml-2">{{ locate(work_hour.week_day) }}</label>
                                                    <div class="d-flex flex-row ml-3">
                                                        <label for="from" class="mb-0 d-flex align-items-center ml-2">از ساعت</label>
                                                        <input type="text" :id="`from` + index"  v-model="work_hour.from" >
                                                    </div>
                                                    <div class="d-flex flex-row ml-3">
                                                        <label for="to" class="mb-0 d-flex align-items-center ml-2">تا ساعت</label>
                                                        <input type="text" :id="`to` + index"  v-model="work_hour.to">

                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    <hr>
                            </div>

                            <div class="row mot-modal-inputs m-2">
                                <div class="form-group">
                                    <input type="submit" class="form-control"
                                        :value="[branch.insideType == 'update' ? 'ویرایش' : 'افزودن']">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
export default {
    name: "AddBranch",

    computed: {
        ...mapGetters({
            branch: 'Branch/data'
        })
    },
    data() {
        return {
            users: [],
            sections: []
        }
    },
    methods: {
        ...mapActions({
            update: 'Branch/update'
        }),
        addData() {
            this.vr(this.branch.name, 'نام');
            this.vr(this.branch.address, 'آدرس');
            if (!this.v_error_check()) return;
            axios.post('/api/v1/branch', this.branch)
                .then(res => {
                    if (res.data.alert && res.data.alert.type == 'error') return;
                    this.update(res.data.data)
                    $('.add-branch-modal').modal('hide')
                });
        },
        addItem() {
            this.branch.classes.push({
                name: null,
                area: null,
            })
        },
        minusItem(index) {
            if (this.branch.classes.length > 1) {
                this.branch.classes = this.branch.classes.filter(x => x != this.branch.classes[index])
            }
        },
        addRooms() {
            this.branch.rooms.push({
                name: null,
                area: null,
            })
        },
        minusRooms(index) {
            if (this.branch.rooms.length > 1) {
                this.branch.rooms = this.branch.rooms.filter(x => x != this.branch.rooms[index])
            }
        },
    }
}
</script>