<template>
        <!-- Modal -->
<div class="add-call">
    <div class="modal fade group-send-message mot-modal-table" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">کار گروهی (ارسال پیام)</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body p-3">
                    <p>متغیر ها</p>
                    <p>%name% قرار گیری نام اشخاص</p>

                    <label for="sms-template">انتخاب قالب پیامکی</label>
                    <v-select id="sms-template" class="mb-3" @input="changemessage" v-model="selected_message" :options="person_messages" placeholder="برای انتخاب قالب پیامکی ارسال کلیک کنید" />
                    
                    <div v-if="selected_message" class="alert alert-warning mb-3">
                        <ul>
                            <li><strong>نام: </strong>{{selected_message.label}}</li>
                            <li><strong>متن sms: </strong>{{selected_message.placeholder}}</li>
                            <li><strong>طریقه استفاده: </strong><span dir="ltr">{{selected_message.hint}}</span></li>
                        </ul>
                        لطفا در قالب مشخص شده اطلاعات را وارد کنید. در غیر این صورت پیام شما ارسال نخواهد شد
                    </div>

                      <form action="" @submit.stop.prevent="sendMessage">
                              <div class="form-group">
                                  <textarea rows="10" style="min-height: 150px;" class="form-control" v-model="message" placeholder="پیام شما"></textarea>
                              </div>
                              <button class="btn btn-primary btn-sm mt-2">ارسال</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
</template>
<script>

export default {
    props: ['uri', 'type', 'incs', 'filts',],
    data(){
        return{
            message: null,
            person_messages: window.person_messages,
            selected_message: null
        }
    },
    methods: {
        sendMessage(){
            let objects = {
                'message': this.message,
                'includes': this.incs,
                'group_type': this.type,
                'group_action': 'sms'
            }
            let entries = {}
            for(var n of [objects, this.filts]){
                var keys = Object.keys(n);
                for (var i=0; i<keys.length; i++) entries[keys[i]] = n[keys[i]]
            }

            axios.get(this.uri + this.compileParamsToUrl(entries))
            .then(res => {
                $('.group-send-message').modal('hide')
                this.message= null
            })

        },

        changemessage(){
            if(!this.selected_message) return;
            let message = this.selected_message.hint.replace('name', "%name%")
            this.message = message
        }
    }
}
</script>
