<template>
    <!-- Modal -->
<div class="add-call">
    <div class="modal fade add-call-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">افزودن/ ویرایش تماس</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="model-body">
                      <form action="" @submit.stop.prevent="addData">
                       <ul class="err-box">
                            <li class="error" v-for="error in v_get_errors()" :key="error">{{error}}</li>
                        </ul>
                       <div class="row mot-modal-inputs-6 m-0">

                               <div class="form-group">
                                   <label for="service_type">موضوع تماس</label>
                                   <v-select @input="changeType" id="service_type" v-model="call.callableType" :options="serviceList" />
                               </div>
                               <div v-if="call.callableType" class="form-group">
                                   <label for="course">انتخاب آیتم</label>
                                   <v-select v-model="call.callable" :options="callables" @search:focus="search_params = call.callableType.model.split('\\').at(-1) + '|name|callables'" v-debounce="dynamicSearch" />
                               </div>
                               <div class="form-group">
                                    <label for="lreasons">دلیل انصراف / اگر انصراف داده است انتخاب کنید</label>
                                   <v-select id="lreasons" v-if="leave_reasons.length" v-model="call.leave_reason" :options="leave_reasons" />
                               </div>
                               <div class="form-group">
                                   <label for="comments">توضیحات</label>
                                   <textarea class="form-control" v-model="call.comments" id="comments"></textarea>
                               </div>
                               <div class="form-group">
                                    <label for="">تاریخ</label>
                                    <date-picker format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="call.created_at"></date-picker>
                                </div>
                                <div class="form-group">
                                    <label for="">پیگیری</label>
                                    <date-picker format="jYYYY-jMM-jDD"  display-format="jYYYY-jMM-jDD" auto-submit v-model="call.pursuit_date"></date-picker>
                                </div>
                                <div class="form-group">
                                    <input type="submit" class="form-control" :value="[call.insideType == 'update' ? 'ویرایش' : 'افزودن']"> 
                                </div>
                       </div>
                   </form>
                </div>
            </div>
        </div>
    </div>

       
    </div>
</template>

<script>

import { mapActions, mapGetters } from 'vuex';
export default {
    name:"AddCall",
    computed: {
        ...mapGetters({
            selectedPerson: 'selectedPerson',
            call: 'Call/call'
        })
    },
    data(){
        return{
            leave_reasons:window.leaveReasons,
            callables: [],
            serviceList: window.serviceList
        }
    },
 
    methods: {
        ...mapActions({
            updatePersonCallData: 'updatePersonCallData',
            updateCallData: 'Call/updateCallData'
        }),
        changeType(){
            this.call.callable = null
        },
        addData() {
            this.vr(this.call.callable, 'ایدی دسته بندی');
            if(!this.v_error_check()) return;
            axios.post('/api/v1/call', this.call)
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                this.call.insideId = res.data.data.id;
                this.call.insideType = 'update';

                this.updatePersonCallData(res.data.data)
                this.updateCallData(res.data.data)
                
                $('.add-person-modal').modal('hide')
                $('.add-call-modal').modal('hide')
            });
        }

    }

}
</script>

