<template>

            <div>
                    <AddPerson />
                    <AddCall />
                    <AddRegister />
                    <AddPersonProduct />
                    <AddPersonService />
                    <AddPayment/>
                    <AddData />
                    <ManageClassSessions />
            </div>
    
</template>

<script>

import AddPerson from './AddPerson';
import AddCall from './AddCall';
import AddRegister from './AddRegister';
import AddPersonProduct from './AddPersonProduct';
import AddPersonService from './AddPersonService';
import AddData from './AddData';
import AddPayment from './AddPayment';
import ManageClassSessions from '../Class/ManageClassSessions.vue'
import { mapGetters } from 'vuex';

export default {
    name: "AllAction",
    components: {
        AddPerson,
        AddCall,
        AddRegister,
        AddData,
        AddPersonProduct,
        AddPersonService,
        AddPayment,
        ManageClassSessions
    },
    computed: {
        ...mapGetters(['selectedPerson']),
    }
}
</script>
