window.strings = window.local


const Mylocate = {
    install(Vue, options) {
        Vue.mixin({
            methods: {
                locate(string) {
                    string = string ? string.toLowerCase() : ''
                    if (window.strings[string]) return window.strings[string]
                    return string
                }
            }
        });

    }
};

export default Mylocate;