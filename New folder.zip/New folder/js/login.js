if(document.querySelector('.force-login-body')){
    timer = 60
    var timerInterval
    const _ = elm => document.querySelector(elm)
    const __ = elm => document.querySelectorAll(elm)

    const authAlert = (query , data) => {
        _(query).classList.add(data.status)
        _(query + ' .feedback strong').innerHTML = data.message
        return;
    }
    
    const clearAlert = query => {
        _(query).classList.contains('valid') ?  _(query).classList.remove('valid') : null
        _(query).classList.contains('invalid') ? _(query).classList.remove('invalid')  : null

        _(query + ' .feedback strong').innerHTML = ""
        return
    }

    _('#sendCode').addEventListener('click', sendCode)
    function sendCode(){
        x = this
        phone = _('#phone').value
        clearAlert('#register .phone')
        
        if(phone.length != 11 || (phone.substr(0,2) != "09" && phone.substr(0,2) != "۰۹")){
            authAlert('#register .phone', {
                status: 'invalid',
                message: 'لطفا شماره تلفن خود را به درستی وارد کنید'
            });

            return;
        }
 
     

        // fix dependencies
        _('#register .code').classList.add('active')
        _('#register #submit').classList.add('active')
        
        
        // send code
    
        fetch(`/send-code/${phone}`).then(res => res.json()).then(res => {
            for(item of res.messages){
                authAlert('#register .'+ item.input, {
                        status: item.status,
                        message: item.message
                });
            }

            if(!res.user_register_status){
                _('#namefield').classList.add('active')
            }else{
                _('#namefield').classList.contains('active') ? _('#namefield').classList.remove('active') : null
            }

            if(res.status && res.status == 200){
            x.classList.add('send');
            runTimer(x);
            }

        })
      

    }

    function runTimer(x){
        timerInterval = setInterval(() => {
            timer--
            x.innerHTML = "ارسال مجدد بعد از " + timer + " ثانیه "
            if(timer == 0){
                clearInterval(timerInterval)
                x.innerHTML = "ارسال کد تایید"
                x.classList.remove('send');
                timer = 60;
            }
        }, 1000);
    }

    function setStateCode(val){
        submitButton = document.getElementById('submit');
        codeAlert = document.getElementById('code-alert');
        if(val.value.length != 4){
            submitButton.classList.add('unactive')
        }else{
            submitButton.classList.remove('unactive')
        }
    
    }

    

    _('#register').addEventListener('submit', submitAuthForm);
    function submitAuthForm(e){
        e.preventDefault();
        if(!validatingAuthForm()) return;


        const form = new FormData();
        form.append('phone', _('#phone').value);
        form.append('name', _('#name').value);
        form.append('code', _('#code').value);
        form.append('_token', _('input[name=_token]').value);
        form.append('action', 'auth_send');
        const params = new URLSearchParams(form);

        fetch('/code-login', {
            method: 'POST',
            body: form
        }).then(res => res.json()).then(res => {
            
            if(res.status && res.status == 200){

                if(_('#register').getAttribute('data-redirect') != "false"){
                    window.location = res.redirect_to || _('#register').getAttribute('data-redirect')
                }

                if(_('#register').getAttribute('data-close')){
                        setTimeout(function(){
                            _('.mfp-close').click()
                        }, 1000)
                }

                if(_('#register').getAttribute('data-callback')){
                    window[_('#register').getAttribute('data-callback')]()
                }

                for(var n of __('.guest-none')){
                    n.classList.remove('guest-none')
                }
                for(var n of __('.guest-show')){
                    n.classList.remove('guest-show')
                }

                _('#name').classList.add('unactive');
                _('#code').classList.add('unactive');
                _('#phone').classList.add('unactive');
                _('#submit').classList.add('dnone');
                _('#sendCode').classList.add('dnone');

                if(_('#billing_first_name')){
                    _('#billing_first_name').value = res.user.name;
                }

                if(_('#billing_phone')){
                    _('#billing_phone').value = res.user.phone;
                }

                for(item of res.messages){
                    authAlert('#register .'+ item.input, {
                            status: item.status,
                            message: item.message
                    });
                }
                
            }else{
                for(item of res.messages){
                    authAlert('#register .'+ item.input, {
                            status: item.status,
                            message: item.message
                    });
                }
            }
            
        })
        
        


    

    }


const validatingAuthForm = () => {

        phone = _('#phone').value
        clearAlert('#register .phone')
        
        if(phone.length != 11 || (phone.substr(0,2) != "09" && phone.substr(0,2) != "۰۹")){
            authAlert('#register .phone', {
                status: 'invalid',
                message: 'لطفا شماره تلفن خود را به درستی وارد کنید'
            });

            return false;
        }

        clearAlert('#register .code')
        if(_('#code').value.length != 4){
            authAlert('#register .code', {
                status: 'invalid',
                message: 'لطفا کد تایید 4 رقمی را وارد کنید'
            });

            return false;
        }


        clearAlert('#register .name')
        if(_('#namefield').classList.contains('active') && _('#name').value.length < 2){
            authAlert('#register .name', {
                status: 'invalid',
                message: 'لطفا نام خود را وارد کنید'
            });

            return false;
        }

        return true;
    }
}