const paginate = {
    props: ['paginate'],
    template: `
    <div class="mot-paginate-wrapper">
        <ul class="pagination m-0" dir="ltr">
           
             <li  v-bind:class="[{disabled: !paginate.next_page}]" class="page-item"><a @click="$emit('changePage', paginate.next_page)" class="page-link" href="#"><span class="material-symbols-rounded">
            arrow_back_ios
            </span></a></li>
            
            <li class="page-item disabled"><a class="page-link" href="#">صفحه {{paginate.current_page}} از {{paginate.last_page}}</a></li>
            <li class="page-item"><form @submit.stop.prevent="get"><input class="form-control" type="number" v-model="pageNum" :min="1" :max="paginate.last_page"></form></li>
           
            <li v-bind:class="[{disabled: !paginate.prev_page}]" class="page-item"><a @click="$emit('changePage', paginate.prev_page)" class="page-link" href="#"><span class="material-symbols-rounded">
            arrow_forward_ios
            </span></a></li>
        </ul>
    </div>
    `,
    data() {
        return {
            pageNum: null
        }
    },
    methods: {
        get() {
            var url = new URL(this.paginate.prev_page || this.paginate.next_page);
            var search_params = url.searchParams;
            search_params.set('page', this.pageNum);
            this.$emit('changePage', url.toString())
        }
    }
}
export default paginate;