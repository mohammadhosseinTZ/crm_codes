/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */
import Vue from 'vue';
import VueRouter from 'vue-router';
import VuePersianDatetimePicker from 'vue-persian-datetime-picker';
import vSelect from 'vue-select'
import paginate from './paginate.js'
import popup from './popup.js'
import groupwork from './groupwork.js'
import VueMyValidation from './vue-validate-my.js';
import Mylocate from './locate.js';
import Gate from './gate.js';
import store from './store'
import { mapActions, mapGetters } from 'vuex';
import VueApexCharts from 'vue-apexcharts'
import SmartTable from 'vuejs-smart-table'
import Notifications from 'vue-notification'
import PersonButtons from './components/Person/PersonButtons.js'
import vueDebounce from 'vue-debounce'
import VuePictureSwipe from 'vue-picture-swipe';
require('./bootstrap');

window.Vue = require('vue');


/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))
Vue.use(VueRouter);
Vue.use(vueDebounce, {
    defaultTime: '700ms',
    listenTo: ['input', 'search'],
    lock: false,
    fireOnEmpty: false,
    trim: true
  })
Vue.component('v-select', vSelect)
Vue.component('paginate', paginate)
Vue.component('popup', popup)
Vue.component('groupwork', groupwork)
Vue.component('vue-picture-swipe', VuePictureSwipe);

import routes from './routes.js';
import { data } from 'jquery';
import axios from 'axios';

const router = new VueRouter({
    routes: routes,
    mode: 'history'
});
// Vue.component('crm', require('./components/ExampleComponent.vue').default);

Vue.component('date-picker', VuePersianDatetimePicker);
Vue.use(VuePersianDatetimePicker, {
    name: 'date-picker',
    props: {
        highlight: function (formatted, dateMoment, checkingFor) {
            let attributes = {'title': 'Today is ' + formatted};
            for(var n of window.calendarEvents){
                if (checkingFor === 'day' && formatted.split(' ')[0] === n.date_orginal){
                    attributes['class'] = n.day_type;
                    attributes['title'] = n.event;
                }
            }
            return attributes;
        }
    }
  });
Vue.component('pursuitbutton', require('./components/Person/Pursuit.vue').default);
Vue.component('loading', require('./components/global/Loading.vue').default);
Vue.component('v-select', vSelect)
Vue.component('apexchart', VueApexCharts)
Vue.component('PersonButtons',PersonButtons)


Vue.use(VueMyValidation);
Vue.use(Mylocate);
Vue.use(Gate);
Vue.use(VueApexCharts)
Vue.use(SmartTable)
Vue.use(Notifications)



Vue.mixin({
    computed: {
        ...mapGetters(['selectedPerson']),
        ...mapGetters({
            getLoadingStatus: 'Loading/status',
        }),
    },
    data() {
        return {
            pagination: {},
            datas: null,
            count: 0,
            errors: [],
            params: {},
            courses: window.courses,
            classCourses: window.classCourses,
            includes: [],
            is_group: false,
            metadata: [],
            search_params : null,
            filters: {
                courses: [],
                categories: [],
                date: [],
                classCourses: [],
                userInsert: [],
                classRooms: [],
                gateWays: [],
                places: [],
                user_branches: [],
                course_branches: [],
                groups: [],
                teacher_delay_status: [],
                session_teaching_type: []
            }
        }
    },
    filters: {
        format(number) {
            return new Intl.NumberFormat().format(number)
        },
        getPrice: function(value){
            if(!value.length) return 0;
            var prices =  value.map(x => x.price);
            return prices.reduce(function(total, num){
                return parseInt(total) + parseInt(num);
            });
        },
        getWays: function(values){
            var ways =  values.map(function(value,index) {
                if(value.chash_way){
                    if(values.length > 1){
                        let price = new Intl.NumberFormat().format(value.price);
                        return value.chash_way.option_value + ` (${price})`
                    }
                    return value.chash_way.option_value ;
                }
            }); 
            return ways.join(' و ');
        },
    },
    methods: {
        ...mapActions(['setSelectedPerson', 'getPersonCalls', 'getPersonRegisters', 'getPersonExams', 'getPersonPayments', 'getPersonData', 'getPyamentsRegister', 'addPerson', 'editPerson']),
        ...mapActions({
            setLoadingStatus: 'Loading/setStatus',
            addPayment: 'Payment/addPayment',
            editPayment: 'Payment/editPayment',
        }),
        paginator: function(meta, links) {
            if(!meta || !links) return;
            let pagination = {
                current_page: meta.current_page,
                last_page: meta.last_page,
                next_page: links.next,
                prev_page: links.prev
            };
            this.pagination = pagination;
        },
        searchMeta(data, key) {
            let d = data.filter(elm => elm.meta_key == key);
            if (d.length) return d[0];
            else return {};
        },

        hasKey(target, keys){
            if(typeof target == 'object'){
                let status = false;
                for(var n of target){
                    status = keys.some(x => x.name == n)
                }

                return status
            }
            return keys.some(x => x.name == target)
        },

        // filters and get data
        getData(url = false) {
            return new Promise((resolve, rej) => {
                axios.get(url || this.url)
                .then(res => {
                    this.datas = res.data.data;
                    this.metadata = res.data.metadata
                    res.data.metadata ? this.count = res.data.metadata.count : null
                    this.paginator(res.data.meta, res.data.links)
                    return resolve(res)
                })
            })
        },
        extractUrlParam(url, action = 'replace') {
            const tmpUrl = new URL(url);
            for (const entry of tmpUrl.searchParams.entries())
                this.setUrlParam(entry[0], entry[1], action);
        },
        setUrlParam(key, value, action = 'replace') {
            if (action == 'replace') this.params[key] = value;
            if (action == 'remove') {
                if (value == true) this.params[key] = value
                else delete this.params[key];
            }
            if (value == '' || value == null || value == [] || value == ',') delete this.params[key];
            this.compileParamsToUrl();
        },
        compileParamsToUrl(prm = null) {
            var tmpUrl = "?";
            for (const [key, value] of Object.entries(prm || this.params)) {
                tmpUrl += `${key}=${value}&`;
            }
            return tmpUrl;

        },
        applyUrl(isback = 'back') {
            if(isback == 'back') delete this.params['page']
            var tmpUrl = this.url + this.compileParamsToUrl();
            this.getData(tmpUrl);
        },

        changePage(page) {
            this.extractUrlParam(page);
            this.applyUrl('not_back')
        },

        vselectfilter(model, name, type = null, apply = true, options = null) {
            if (type == 'multiple') {
                let ids = [];
                model.map(x => ids.push(x.id))
                this.setUrlParam(name, ids)
            } else {
                this.setUrlParam(name, model ? model.id : [])
            }
            if (apply) this.applyUrl()
        },
        setFilter(name, value, type = null) {
            if (type != 'vselect') {
                this.setUrlParam(name, value)
                this.applyUrl()
            } else {
                this.vselectfilter(value, name, 'multiple')
            }
        },
        manageIncludes(datas, value, allresult = null) {
            if(allresult == 'allresult') return this.includes.push('allresult');
            this.includes = []
            if (!value) return;
            for (var data of datas) this.includes.push(data.id)
        },
        groupWork(value) {
            if (value && $('.' + value)) $('.' + value).modal('show')
        },
        getPercent(one, two, propety, value) {
            two = two == 0 ? 1 : two
            propety[value] = ((one * 100) / two) && ((one * 100) / two) != Infinity ? Math.round((one * 100) / two) : null
            return propety[value] ? propety[value] + "%" : 0 + "%"
        },
        deleteItem(url, id = null, callback = null) {
            let prefix = '/api/v1' + url;
            if (!confirm('آیا از انجام این عملیات مطمئن هستید؟')) return;
            axios.delete(prefix).then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                
                if(!id && !callback){
                    this.applyUrl()
                }
                if(id && callback){
                    callback(id)
                }
            })
        },
        dynamicSearch(search, loading) {
            var params = this.search_params.split('|')
            if (!search.length)
                return;
            loading = true;
            axios.get(`/api/v1/search/${params[0]}/${params[1]}/${search}`)
                .then(res => {
                this[params[2]] = res.data;
                loading = false;

            });
        },
        singleExport(url){
            return window.open(url);
        }
    },
})


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

const app = new Vue({
    store,
    el: '#app',
    router
});

$('body').tooltip({ selector: '[data-toggle="tooltip"]' });



// NEW SCRIPT

$(".mot-navbar-toggler").on("click", function() {
    $(".navbar").toggleClass("navbar-toggle-show");
    if (window.matchMedia("(max-width: 768px)").matches) {
        if ($(".navbar").hasClass("navbar-toggle-show"))
            $("#mot-header .material-symbols-rounded").text("close");
        else $("#mot-header .material-symbols-rounded").text("menu");
    }
});

$(".container-fluid").on("click", function(e) {
    $(".navbar").removeClass("navbar-toggle-show");
});

// const requireHTTPS = (req, res, next) => {
//     if (req.headers["x-forwarded-proto"] !== "https") {
//         return res.redirect("https://" + req.get("host") + req.url);
//     }
//     next();
// };