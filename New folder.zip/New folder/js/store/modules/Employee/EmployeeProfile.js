import axios from "axios"

const state = {
    datas: [],
   

}
const getters = {
    datas: state => state.datas,
    

}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),

}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data;
        })
    },

    

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}