import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        user: null,
        code: null,
        work_type: null,
        work_job: null,
        work_section: null,
        branch: null,
        director: null,
        comments: null,
        job_duties: [],
        work_histories: [],
        dependents: [],
        relations: [],
        skills: [],
        contracts: [],
        phones: [],
        uploads: [],
        extra_data: [],
        work_hours: [
            {week_day: "saturday", from: null, to: null},
            {week_day: "sunday", from: null, to: null},
            {week_day: "monday", from: null, to: null},
            {week_day: "tuesday", from: null, to: null},
            {week_day: "wednesday", from: null, to: null},
            {week_day: "thursday", from: null, to: null},
            {week_day: "friday", from: null, to: null},
        ],
        insideId: null,
        insideType: 'insert',
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, {id, data }) => commit('edit', {id:id,  data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
           
            user: null,
            code: null,
            work_type: null,
            work_job: null,
            work_section: null,
            branch: null,
            director: null,
            comments: null,
            job_duties: [],
 
            work_histories: [],
            dependents: [],
            relations: [],
            skills: [],
            contracts: [],
            phones: [],
            uploads: [],
            extra_data: [],
            work_hours: [
                {week_day: "saturday", from: null, to: null},
                {week_day: "sunday", from: null, to: null},
                {week_day: "monday", from: null, to: null},
                {week_day: "tuesday", from: null, to: null},
                {week_day: "wednesday", from: null, to: null},
                {week_day: "thursday", from: null, to: null},
                {week_day: "friday", from: null, to: null},
            ],
            insideId: null,
            insideType: 'insert',
        }
    },
    edit: (state, {data}) =>{

        data.user.label = data.user.name
        data.work_type.label = data.work_type.name
        if(data.work_job) data.work_job.label = data.work_job.name
        if(data.branch) data.branch.label = data.branch.name
        if(data.work_section) data.work_section.label = data.work_section.name

        state.data = {
            
            user: data.user,
            code: data.code,
            work_type: data.work_type,
            work_job: data.work_job,
            work_section: data.work_section,
            branch: data.branch,
            director: data.director,
            comments: data.comments,
            job_duties: data.job_duties,
            // work_hours: data.work_hours, //
            work_histories: data.work_histories, //
            dependents: data.dependents,//
            relations: data.relations, //
            skills: data.skills,//
            contracts: data.contracts, 
            phones: data.phones,
            uploads: data.uploads, //
            extra_data: data.extra_data, //
            insideId: data.id,
            insideType: 'update',
            work_hours: data.work_hours.length ? data.work_hours : [
                {week_day: "saturday", from: null, to: null},
                {week_day: "sunday", from: null, to: null},
                {week_day: "monday", from: null, to: null},
                {week_day: "tuesday", from: null, to: null},
                {week_day: "wednesday", from: null, to: null},
                {week_day: "thursday", from: null, to: null},
                {week_day: "friday", from: null, to: null},
            ],
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

 
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}