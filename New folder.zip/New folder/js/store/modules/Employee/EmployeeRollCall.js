import axios from "axios"

const state = {
    datas: [],
    meta_data: [],
    employee: null,
    // count: 0,

}
const getters = {
    datas: state => state.datas,
    meta_data: state => state.meta_data,
    employee: state => state.employee
    // count: (state) => state.count,

}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),


}

const mutations = {
    get: (state, { data }) => {

        axios.get(data).then(res => {
            state.datas = res.data.data
            if(res.data.meta){
                state.meta_data = res.data.meta
            }
    
            if(res.data.employee){
                state.employee = res.data.employee
            }
                
    
            // state.count = res.data.metadata.count
            // state.pagination = {
            //     current_page: res.data.meta.current_page,
            //     last_page: res.data.meta.last_page,
            //     next_page: res.data.links.next,
            //     prev_page: res.data.links.prev
            // }
        })
    },
 
    

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}