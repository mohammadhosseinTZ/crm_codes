import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    statistics: [],
    data: {
        name: null,
        price: null,
        sale_price: null,
        sale_price_date_from: null,
        sale_price_date_to: null,
        sync_with_site:true,
        quantity: null,
        primitive_quantity: null,
        category: null,
        buy_price: null,
        is_infinite: false,
        store: null,
        unit: null,
        product_image: null,
        branches: null,
        stores: [
            {
                store: null,
                quantity: null,
                primitive_quantity: null
            }
        ],
        code: Date.now(),
        parent_id: null,
        commission_unit: null,
        commission_value: null,
        commission_market_value: null,
        commission_user: null,
        product_type: null,
        comment: '',
        insideId: null,
        insideType: null,
    },

    sells: [],
    sellCount: 0,
    sellStatistics: [],
    sellPagination: {}
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    statistics: (state) => state.statistics,
    data: state => state.data,
    


    sells: state => state.sells,
    sellCount: state => state.sellCount,
    sellStatistics: state => state.sellStatistics,
    sellPagination: state => state.sellPagination,
}

const actions = {
    get: ({ commit }, { date = null }) => commit('get', { date: date }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
    getSells: ({ commit }, {data = null, id}) => commit('getSells', {data: data, id:id}),
}

const mutations = {
    get: (state, { date }) => {
        axios.get(date).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.statistics = res.data.metadata ? res.data.metadata.statistics : null
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
            name: null,
            price: null,
            sale_price: null,
            sale_price_date_from: null,
            sale_price_date_to: null,
            sync_with_site:true,
            quantity: null,
            primitive_quantity: null,
            stores: [
                {
                    store: null,
                    quantity: null,
                    primitive_quantity: null
                }
            ],
            category: null,
            buy_price: null,
            is_infinite: false,
            store: null,
            branches: null,
            unit: null,
            product_image: null,
            code: Date.now(),
            parent_id: null,
            commission_unit: null,
            commission_value: null,
            commission_market_value: null,
            commission_user: null,
            product_type: null,
            comment: '',
            insideId: null,
            insideType: null,
        }
    },
    edit: (state, {data}) =>{
        if(data.commission_user) data.commission_user.label = data.commission_user.name
        state.data = {
            name: data.name,
            price: data.price,
            sale_price: data.sale_price,
            sale_price_date_from: data.sale_price_date_from,
            sale_price_date_to: data.sale_price_date_to,
            sync_with_site: parseInt(data.sync_with_site),
            category: data.category,
            branches: data.branches,
            buy_price: data.buy_price,
            is_infinite: parseInt(data.is_infinite),
            unit: window.defined_enums.cost_units.find(x => x.name == data.unit),
            store: window.stores.find(x => x.id == data.store_id),
            product_image: data.product_image,
            code: data.code,
            quantity: data.quantity,
            primitive_quantity: data.primitive_quantity,
            stores: data.stores,
            parent_id: data.parent,
            commission_unit: window.defined_enums.commission_units.find(x => x.name == data.commission_unit),
            commission_value: data.commission_value,
            commission_market_value: data.commission_market_value,
            commission_user: data.commission_user,
            product_type: data.product_type,
            comment: data.comment,
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

    getSells: (state, { data, id }) => {
        if(!id) return;
        data = data ? data : `/api/v1/product/sell/${id}`;
        axios.get(data).then(res => {
            state.sells = res.data.data
            state.sellCount = res.data.metadata.count
            state.sellStatistics = res.data.metadata ? res.data.metadata.statistics : null
            state.sellPagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}