import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        name: null,
        address: null,
        postal_code: null,
        en_sign: null,
        insta: null,
        telegram: null,
        phone: null,
        market_url: null,
        market_user: null,
        manager: null,
        sections: [],
        classes: [],
        rooms: [],
        work_hours: [
            {week_day: "saturday", from: "22", to: null},
            {week_day: "sunday", from: null, to: null},
            {week_day: "monday", from: null, to: null},
            {week_day: "tuesday", from: null, to: null},
            {week_day: "wednesday", from: null, to: null},
            {week_day: "thursday", from: null, to: null},
            {week_day: "friday", from: null, to: null},
        ],
        insideId: null,
        insideType: null,
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data
            state.count = res.data.data.length  
        })
    },

    add: (state) => {
        state.data = {
            name: null,
            address: null,
            postal_code: null,
            en_sign: null,
            insta: null,
            telegram: null,
            phone: null,
            market_url: null,
            market_user: null,
            manager: null,
            sections: [],
            classes: [],
            rooms: [],
            work_hours: [
                {week_day: "saturday", from: null, to: null},
                {week_day: "sunday", from: null, to: null},
                {week_day: "monday", from: null, to: null},
                {week_day: "tuesday", from: null, to: null},
                {week_day: "wednesday", from: null, to: null},
                {week_day: "thursday", from: null, to: null},
                {week_day: "friday", from: null, to: null},
            ],
            insideId: null,
            insideType: null,
        }
    },
    edit: (state, {data}) => {
        if(data.market_user) data.market_user.label = data.market_user.name + " - " + data.market_user.phone
        state.data = {
            name: data.name,
            address: data.address,
            postal_code:  data.postal_code,
            en_sign:  data.en_sign,
            insta:  data.insta,
            telegram:  data.telegram,
            phone:  data.phone,
            market_url:  data.market_url,
            market_user:  data.market_user, 
            manager: data.manager,
            sections: data.sections,
            classes: data.classes,
            rooms: data.class_rooms,
            work_hours: data.work_hours.length ? data.work_hours : [
                {week_day: "saturday", from: null, to: null},
                {week_day: "sunday", from: null, to: null},
                {week_day: "monday", from: null, to: null},
                {week_day: "tuesday", from: null, to: null},
                {week_day: "wednesday", from: null, to: null},
                {week_day: "thursday", from: null, to: null},
                {week_day: "friday", from: null, to: null},
            ],
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)

    },

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}