import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    course: {
        name: null,
        price: null,
        evidence_price: null,
        sp_evidence_price: null,
        technical_evidence_price: null,
        sp_technical_evidence_price: null,
        re_written_test_price: null,
        re_practice_test_price: null,
        practice_test_entry_price: null,
        private_price: null,
        online_price: null,
        standard_hours: null,
        standard_name: null,
        standard_code: null,
        standard_headlines: null,
        groups: [],
        branches: [],
        insideId: null,
        insideType: null,
    },
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    course: state => state.course
}

const actions = {
    add:({ commit }) => commit('add'),
    edit:({commit}, {id, data = null, user_id = null}) => commit('edit', {id: id, data:data, user_id:user_id}),
    get: ({ commit }, {data = null}) => commit('get', {data: data}),
    update:({ commit }, data) => commit('update', data),
    delete:({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data || '/api/v1/course').then(res => {
            state.datas = res.data.data
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    add: (state) =>{
            state.course = {
                name: null,
                price: null,
                evidence_price: null,
                sp_evidence_price: null,
                technical_evidence_price: null,
                sp_technical_evidence_price: null,
                re_written_test_price: null,
                re_practice_test_price: null,
                practice_test_entry_price: null,
                private_price: null,
                online_price: null,
                standard_hours: null,
                standard_name: null,
                standard_code: null,
                standard_headlines: null,
                groups: [],
                branches: [],
                insideId: null,
                insideType: 'insert',
            }
    },
    edit: (state, {id, data, user_id}) => {
        var course = null
        course = new Promise((resolve, reject) => {
            resolve(data)
        });

        if(!data){
            course = new Promise((resolve, reject) => {
            axios.get("/api/v1/course/"+ id)
                .then(res => dump = resolve(res.data.data))
                ;
            });
        }
        
        course.then(dump => {
            state.course = {
                name: dump.name,
                price: dump.price,
                evidence_price: dump.evidence_price,
                sp_evidence_price: dump.sp_evidence_price,
                technical_evidence_price: dump.technical_evidence_price,
                sp_technical_evidence_price: dump.sp_technical_evidence_price,
                re_written_test_price: dump.re_written_test_price,
                re_practice_test_price: dump.re_practice_test_price,
                practice_test_entry_price: dump.practice_test_entry_price,
                private_price: dump.private_price,
                online_price: dump.online_price,
                standard_hours: dump.standard_hours,
                standard_name: dump.standard_name,
                standard_code: dump.standard_code,
                standard_headlines: dump.standard_headlines,
                groups: dump.groups,
                branches: dump.branches.map(x => {
                    x.label = x.name
                    return x
                }),
                insideId: id,
                insideType: 'update',
            }
        })
        
        
    },

    update(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
            window.courses.push(data)
        }
    },
    
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
        window.courses = window.courses.filter(x => x.id != id)

    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}