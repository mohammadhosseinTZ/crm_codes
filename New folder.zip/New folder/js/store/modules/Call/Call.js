import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    call: {
        callableType: null,
        callable: null,
        comments: null,
        pursuit_date: null,
        created_at: null,
        insideId: null,
        insideType: null,
        leave_reason: null,
    },
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    call: state => state.call
}

const actions = {
    addCall:({ commit }, id) => commit('addCall', id),
    editCall:({commit}, {id, data = null, user_id = null}) => commit('editCall', {id: id, data:data, user_id:user_id}),
    getDatas: ({ commit }, {data = null}) => commit('getDatas', {data: data}),
    updateCallData:({ commit }, data) => commit('updateCallData', data),
    delete:({ commit }, id) => commit('delete', id),
}

const mutations = {
    getDatas: (state, { data }) => {
        axios.get(data || '/api/v1/call').then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    addCall: (state, id) =>{
            state.call = {
                callableType: null,
                callable: null,
                comments: null,
                pursuit_date: null,
                created_at: null,
                insideId: id,
                insideType: 'insert',
                leave_reason: null,
            }
    },
    editCall: (state, {id, data, user_id}) => {
        var call = null
        call = new Promise((resolve, reject) => {
            resolve(data)
        });

        if(!data){
            call = new Promise((resolve, reject) => {
            axios.get("/api/v1/call/"+ id)
                .then(res => dump = resolve(res.data.data))
                ;
            });
        }
        
        call.then(dump => {
            let service = window.serviceList.find(x => x.model == dump.callable_type);
            dump.callable.label = dump.callable.name
            state.call = {
                callableType: service,
                callable: dump.callable,
                comments: dump.comment,
                pursuit_date: dump.pursuit_date,
                created_at: dump.created_at,
                insideId: id,
                insideType: 'update',
                leave_reason: window.leaveReasons.find(x => x.id == dump.leave_reason_id),
            }

    
        })
        
        
    },

    updateCallData(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            
            if(data.leave_reason_id){
                state.datas = state.datas.filter(x => x.id != data.id)
            }else if(state.datas.find(item => item.id == data.id).category_id != data.category_id){
                state.datas = state.datas.filter(x => x.id != data.id)
            }else{
                state.datas = state.datas.filter(item => item.id !== data.id)
                state.datas.splice(index , 0 , data)
            }

        }else{
            state.datas.push(data)
        }
    },

    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    }

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}