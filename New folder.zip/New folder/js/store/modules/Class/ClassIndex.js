import axios from "axios"

const state = {
    datas: [],
    class: {
        name: null,
        capacity: null,
        color: null,
        branch: null,
        area: null,
        insideId: null,
        insideType: null,
    }
}

const getters = {
    datas: state => state.datas,
    class: state => state.class
}

const actions = {
    add:({ commit }) => commit('add'),
    edit:({commit}, {id, data = null, user_id = null}) => commit('edit', {id: id, data:data, user_id:user_id}),
    get: ({ commit }, {data = null}) => commit('get', {data: data}),
    update:({ commit }, data) => commit('update', data),
    delete:({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data || '/api/v1/class').then(res => {
            state.datas = res.data.data
        })
    },
    add: (state) =>{
            state.class = {
                name: null,
                capacity: null,
                color: null,
                branch: null,
                area: null,
                insideId: null,
                insideType: 'insert',
            }
    },
    edit: (state, {id, data, user_id}) => {
        var cls = null
        cls = new Promise((resolve, reject) => {
            resolve(data)
        });

        if(!data){
            cls = new Promise((resolve, reject) => {
            axios.get("/api/v1/class/"+ id)
                .then(res => dump = resolve(res.data.data))
                ;
            });
        }
        
        cls.then(dump => {
            state.class = {
                name: dump.name,
                capacity: dump.capacity,
                color: dump.color,
                branch: dump.branch,
                area: dump.area,
                insideId: id,
                insideType: 'update',
            }
        })
        
        
    },

    update(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
            window.classRooms.push(data)
        }
    },

    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
        window.classRooms = window.classRooms.filter(x => x.id != id)

    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}