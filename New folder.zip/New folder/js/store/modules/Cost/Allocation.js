import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    statistics: [],
    data: {
        cost: null,
        items: [],
        created_at: null,
        insideId: null,
        insideType: 'insert',
    },
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    statistics: (state) => state.statistics,
    data: state => state.data
}

const actions = {
    get: ({ commit }, { date = null }) => commit('get', { date: date }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
    changeStatus: ({commit}, id) => commit('changeStatus', id),
    forceAdd: ({commit}, {cost}) => commit('forceAdd' , {cost: cost})
}

const mutations = {
    get: (state, { date }) => {
        axios.get(date).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.statistics = res.data.metadata.statistics
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
            cost: null,
            items: [],
            created_at: null,
            insideId: null,
            insideType: 'insert',
        }
    },

    forceAdd: (state, {cost}) => {
        let items = [];
        cost.label = cost.id + " " + cost.items.map(x => x.costableName)[0] || " "
        for(var n of cost.items){
            items.push({
                allocation_type: window.defined_enums.allocation_units.find(x => x.name == 'by_unit'), /** */
                cost_item: n,
                type_value: 0,
                allocationable: null,
                comment: null, 
                allocation_value: null,
                price: null,
                glose: null
            })
        }
        state.data = {
            cost: cost,
            items: items,
            created_at: null,
            insideId: null,
            insideType: 'insert',
        }
    },

    edit: (state, {data}) =>{
        data.cost_item.cost.label = data.cost_item.cost.id
        state.data = {
            cost: data.cost_item.cost,
            items: [
                {
                    cost_item: data.cost_item,
                    allocationable: data.allocationable,
                    allocation_type: window.defined_enums.allocation_units.find(x => x.name == data.allocation_type),
                    allocation_value: data.allocation_value,
                    type_value: data.type_value,
                    price: data.price,
                    comment: data.comment,
                    glose: data.cost_item.quantity - parseInt(data.cost_item.used_quantity || 0),
                    id: data.id
                }
            ],
            insideId: data.id,
            insideType: 'update',
            created_at: data.created_at,
        }
    },


    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

    changeStatus(state, id){
        axios.get(`/api/v1/allocation/${id}/changestatus`)
        .then(res => {
            state.datas.find(x => x.id == id).status = res.data.data.status
        })
    }

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}