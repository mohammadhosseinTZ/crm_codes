import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    statistics: [],
    data: {
        items: [
            {
                type: null,
                key: null,
                price: null,
                discount_price: 0,
                quantity: 1,
                unit: null,
                comment: null,
            }
        ],
        fundCard: null,
        pay_discount_price: 0,
        all_price: null,
        branch: null,
        transaction_id: null,
        order_id: null,
        seller: null,
        comment: null,
        commission: null,
        created_at: null,
        ways: [
            {
                chash_way_id: null,
                price: null,
                created_at: null,
            }
        ],
        insideId: null,
        insideType: 'insert',
    },
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    statistics: (state) => state.statistics,
    data: state => state.data
}

const actions = {
    get: ({ commit }, { date = null }) => commit('get', { date: date }),
    add: ({ commit }) => commit('add'),
    addProduct: ({commit}, product) => commit('addProduct',product),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
    changeStatus: ({commit}, id) => commit('changeStatus', id),
    getCostByRegisterId: ({commit}, id) => commit('getCostByRegisterId', id),
    getPurchases: ({ commit }, {data = null, id}) => commit('getPurchases', {data: data, id:id}),
}

const mutations = {
    get: (state, { date }) => {
        axios.get(date).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.statistics = res.data.metadata.statistics
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        axios.get('/api/v1/cost/get-code').then(res => {
            state.data = {
                items: [
                    {
                        type: null,
                        key: null,
                        price: null,
                        discount_price: 0,
                        quantity: 1,
                        unit: null,
                        comment: null,
                    }
                ],
                fundCard: null,
                pay_discount_price: 0,
                all_price: null,
                branch: null,
                transaction_id: null,
                order_id: null,
                seller: null,
                comment: null,
                created_at: null,
                commission: null,
                ways: [
                    {
                        chash_way_id: null,
                        price: null,
                        created_at: null,
                    }
                ],
                insideId: res.data.id,
                insideType: 'insert',
            }
        })
    },

    addProduct(state, product){
        axios.get('/api/v1/cost/get-code').then(res => {
            state.data = {
                items: [
                    {
                        type: {
                            label: product.name,
                            id: product.id || product.insideId
                        },
                        key: null,
                        price: product.buy_price,
                        discount_price: 0,
                        quantity: 1,
                        unit: null,
                        comment: null,
                    }
                ],
                fundCard: null,
                pay_discount_price: 0,
                all_price: null,
                transaction_id: null,
                order_id: null,
                branch: null,
                seller: null,
                comment: null,
                commission: null,
                created_at: null,
                ways: [
                    {
                        chash_way_id: null,
                        price: null,
                        created_at: null
                    }
                ],
                insideId: res.data.id,
                insideType: null,
            }
        })
    },

    edit: (state, {data}) =>{
        if(data.seller){
            data.seller.label = data.seller.name
        }
        var allPrice = 0;
        data.items.forEach(item => {
            allPrice += (item.price * item.quantity) - item.discount_price
        });
        state.data = {
            fundCard: data.fund_card,
            pay_discount_price: data.pay_discount_price || 0,
            all_price: allPrice - (data.pay_discount_price || 0),
            branch: data.branch,
            transaction_id: data.transaction_id,
            order_id: data.order_id,
            items: data.items,
            seller: data.seller,
            comment: data.comment,
            commission: null,
            ways: data.gates,
            insideId: data.id,
            insideType: 'update',
            created_at: data.created_at,
        }
    },

    getPurchases: (state, { data, id }) => {
        if(!id) return;
        var url = data != null ? data : `/api/v1/product/purchase/${id}`;
        axios.get(url).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.statistics = res.data.metadata ? res.data.metadata.statistics : null
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

    changeStatus(state, id){
        axios.get(`/api/v1/cost/${id}/changestatus`)
        .then(res => {
            state.datas.find(x => x.id == id).status = res.data.data.status
        })
    },

    getCostByRegisterId(state, id){
        axios.get(`/api/v1/cost/?registers=${id}`)
        .then(res => state.datas = res.data.data)
    }

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}