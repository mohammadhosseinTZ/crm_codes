import axios from "axios"
import { update } from "lodash"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    classcourse: {
        course_code: null,
        course: null,
        class: null,
        teacher: null,
        comments: null,
        course_type: null,
        has_online: null,
        has_presence: 1,
        sync_with_site: 1,
        status: null,
        day: null,
        start_time: null,
        end_time: null,
        time: null,
        time_to: null,
        course_duration: null,
        course_duration_unit: null,
        begin_date: null,
        price: null,
        sale_price: null,
        sale_price_date_from: null,
        sale_price_date_to: null,

        online_price: null,
        online_sale_price: null,
        online_sale_price_date_from: null,
        online_sale_price_date_to: null,
        insideId: null,
        insideType: null,
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    classcourse: state => state.classcourse
}

const actions = {
    add:({ commit }) => commit('add'),
    edit:({commit}, {id, data = null, user_id = null}) => commit('edit', {id: id, data:data, user_id:user_id}),
    get: ({ commit }, {data = null}) => commit('get', {data: data}),
    update:({ commit }, data) => commit('update', data),
    delete:({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data || '/api/v1/class-course').then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    add: (state) =>{
            state.classcourse = {
                course_code: null,
                course: null,
                class: null,
                teacher: null,
                comments: null,
                course_type: null,
                has_online: null,
                has_presence: 1,
                sync_with_site: 1,
                status: null,
                day: null,
                start_time: null,
                end_time: null,
                time: null,
                time_to: null,
                course_duration: null,
                course_duration_unit: null,
                begin_date: null,
                price: null,
                sale_price: null,
                sale_price_date_from: null,
                sale_price_date_to: null,
                online_price: null,
                online_sale_price: null,
                online_sale_price_date_from: null,
                online_sale_price_date_to: null,
                insideId: null,
                insideType: 'insert',
            } 
    },
    edit: (state, {id, data, user_id}) => {
        var classcourse = null
        classcourse = new Promise((resolve, reject) => {
            resolve(data)
        });

        if(!data){
            classcourse = new Promise((resolve, reject) => {
            axios.get(`/api/v1/class-course/${id}`)
                .then(res => resolve(res.data.data))
                ;
            });
        }
        
        classcourse.then(dump => {   
            let units = [{label: 'روز', val: 'days'},{label: 'هفته', val: 'weeks'}, {label: 'ماه', val: 'months'}];
            dump.teacher.label = dump.teacher.name;    
            state.classcourse = {
                course_code: dump.course_code,
                course: window.courses.find(x => x.id == dump.course_id),
                class: window.classRooms.find(x => x.id == dump.class_id),
                teacher: dump.teacher,
                comments: dump.comment,
                course_type: dump.course_type,
                has_online: parseInt(dump.has_online),
                has_presence: parseInt(dump.has_presence),
                sync_with_site: parseInt(dump.sync_with_site),
                status: dump.status,
                day: dump.day,
                start_time: dump.start_time,
                end_time: dump.end_time,
                time: dump.time,
                time_to: dump.time_to,
                course_duration: dump.course_duration,
                course_duration_unit: units.find(x => x.val == dump.course_duration_unit),
                begin_date: dump.begin_date,
                price: dump.price,
                sale_price: dump.sale_price,
                sale_price_date_from: dump.sale_price_date_from,
                sale_price_date_to: dump.sale_price_date_to,
                online_price: dump.online_price,
                online_sale_price: dump.online_sale_price,
                online_sale_price_date_from: dump.online_sale_price_date_from,
                online_sale_price_date_to: dump.online_sale_price_date_to,
                insideId: id,
                insideType: 'update',
            } 
        }) 
    },

    update(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },

    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}