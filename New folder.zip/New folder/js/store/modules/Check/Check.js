import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        serial: null,
        price: null,
        saiyad: null,
        receipt: null,
        created_at: null,
        bank: null,
        payment: null,
        insideId: null,
        insideType: null,
    },
}

const getters = {
    datas: (state) => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: (state) => state.data,
}

const actions = {
    get: ({ commit }, { date = null }) => commit('get', { date: date }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { date }) => {
        axios.get(date).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
            serial: null,
            price: null,
            saiyad: null,
            receipt: null,
            created_at: null,
            bank: null,
            payment: null,
            insideId: null,
            insideType: null,
        }
    },
    edit: (state, {data}) =>{
        data.bank.label = data.bank.option_value
        data.payment.label = data.payment.code

        state.data = {
            serial: data.serial,
            price: data.price,
            saiyad: data.saiyad,
            receipt: data.receipt,
            created_at: data.created_at,
            bank: data.bank,
            payment: data.payment,
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}