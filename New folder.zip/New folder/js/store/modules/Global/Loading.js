import axios from "axios"

const state = {
    status: false,
}

const getters = {
    status: (state) => state.status
}

const actions = {
    setStatus: ({ commit }, { status }) => {
        commit('setStatus', { status: status })
    },
}

const mutations = {
    setStatus: (state, { status }) => {
        state.status = status
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}