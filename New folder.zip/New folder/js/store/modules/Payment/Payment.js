import axios from "axios"

const state = {
    datas: [],
    count: 0,
    statistics: [],
    pagination: {},
    payment: {
        register_id: null,
        register_type: null,
        code: null,
        created_at: null,
        desc: null,
        ways: [
            {
                chash_way_id: null,
                price: null
            }
        ],
        insideId: null,
        insideType: null,
    },
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    statistics: (state) => state.statistics,
    pagination: (state) => state.pagination,
    payment: state => state.payment
}

const actions = {
    addPayment:({ commit }, {user_id, price = 0, register_type = null, register_id = null}) => commit('addPayment', {
        user_id: user_id,
        price: price,
        register_type: register_type,
        register_id: register_id
    }),
    editPayment:({commit}, {id, data = null, user_id = null}) => commit('editPayment', {id: id, data:data, user_id:user_id}),
    getDatas: ({ commit }, {data = null}) => commit('getDatas', {data: data}),
    updatePaymentData: ({ commit }, data) => commit('updatePaymentData', data),
    delete:({ commit }, id) => commit('delete', id),
}

const mutations = {
    getDatas: (state, { data }) => {
        axios.get(data || '/api/v1/payment').then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.statistics = res.data.metadata.statistics
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    addPayment: (state, {user_id, price = 0,  register_type = null, register_id = null} ) =>{
   
        axios.get('/api/v1/payment/get-code').then(res => {
            state.payment = {
                register_id: register_id,
                user_id: user_id,
                register_type: register_type,
                code: res.data.code,
                created_at: null,
                desc: null,
                ways: [
                    {
                        chash_way_id: null,
                        price: price 
                    }
                ],
                insideId: user_id,
                insideType: 'insert',
            }
        })
        
    },
    editPayment: (state, {id, data, user_id}) => {
        var payment = null
        payment = new Promise((resolve, reject) => {
            resolve(data)
        });

        if(!data){
        payment = new Promise((resolve, reject) => {
            axios.get("/api/v1/payment/"+ id)
                .then(res => dump = resolve(res.data.data))
                ;
            });
        }
        
        payment.then(dump => {
            
            state.payment = {
                register_id: dump.paymentable_id,
                register_type: dump.sr,
                code: dump.code,
                created_at: dump.created_at,
                desc: dump.comment,
                ways: dump.gates,
                insideId: id,
                insideType: 'update',
                user_id: user_id
            }
        })
        
        
    },

    updatePaymentData(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}