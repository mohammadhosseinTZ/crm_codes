import axios from "axios"

const state = {
    datas: [],
}

const getters = {
    datas: (state) => state.datas,
}

const actions = {
    get: ({ commit }, { date = null }) => commit('get', { date: date }),
}

const mutations = {
    get: (state, { date }) => {
        axios.get(date).then(res => {
            state.datas = res.data.data
        })
    },
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}