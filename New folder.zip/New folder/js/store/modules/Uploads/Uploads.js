import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        
        upload_type_id: null,
        uploadable_id: null,
        uploadable_type: null,
        comments: null,
        status: null,
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, {id, data }) => commit('edit', {id:id,  data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
           
        upload_type_id: null,
        uploadable_id: null,
        uploadable_type: null,
        comments: null,
        status: null, 
        }
    },
    edit: (state, {data}) =>{
        state.data = {
            
        upload_type_id: data.upload_type_id,
        uploadable_id: data.uploadable_id,
        uploadable_type: data.uploadable_type,
        comments: data.comments,
        status: data.status,
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

 
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}