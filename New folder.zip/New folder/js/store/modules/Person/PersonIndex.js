import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    person: {
        acquaintance: null,
        acquaintance_param: null,
        reason: null,
        role: null,
        name: null,
        phone: null,
        date:null ,
        gender: "0",
        comments: null,
        email: null,
        branch: null,
        password: null,
        is_teacher: null,
        insideId: null,
        insideType: null,        
    },
    selectedPerson: {
        id: null,
        data: {},
        calls: [],
        registers: [],
        products: [],
        services: [],
        payments: [],
        data: [],
        registerPyaments: [],


        call: [],
        register: [],
        payment: [],
        sdata: [],
        exams: [],
    }
}

const getters = {
    datas: (state) => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    person: (state) => state.person,
    selectedPerson: (state) => state.selectedPerson,
    calls: (state) => state.selectedPerson.calls, 
    registers: (state) => state.selectedPerson.registers, 
    products: (state) => state.selectedPerson.products, 
    services: (state) => state.selectedPerson.services, 
    payments: (state) => state.selectedPerson.payments, 
    data: (state) => state.selectedPerson.data, 
    registerPyaments: (state) => state.selectedPerson.registerPyaments, 

    call: (state) => state.selectedPerson.call, 
    register: (state) => state.selectedPerson.register, 
    payment: (state) => state.selectedPerson.payment, 
    sdata: (state) => state.selectedPerson.sdata,
    exams: (state) => state.selectedPerson.exams,
}

const actions = {
    setSelectedPerson: ({ commit }, {id, data = null}) => {
        commit('setSelectedPerson', {id: id, data:data})
    },
    getPersonCalls:({ commit }, id) => commit('getPersonCalls', id),
    getPersonRegisters:({ commit }, {id, type = "registers"}) => commit('getPersonRegisters', {id, type}),
    getPersonPayments: ({ commit }, id) => commit('getPersonPayments', id),
    getPersonExams: ({ commit }, id) => commit('getPersonExams', id),
    getPersonData:({ commit }, {id, data = null}) => commit('getPersonData', {id: id, data: data}),
    getPyamentsRegister:({ commit }, {id, type = "register"}) => commit('getPyamentsRegister', {id, type}),
    updatePersonPaymentData: ({ commit }, data) => commit('updatePersonPaymentData', data),
    updatePersonRegisterData: ({ commit }, {data, type="registers"}) => commit('updatePersonRegisterData', {data, type}),
    addPerson: ({commit}) => commit('addPerson'),
    editPerson: ({commit}, {id, data= null}) => commit('editPerson', {id:id, data:data}),
    updatePersonData: ({commit}, data) => commit('updatePersonData', data),
    updatePersonCallData: ({commit}, data) => commit('updatePersonCallData', data),
    getDatas: ({ commit }, {data = null}) => commit('getDatas', {data: data}),
    delete:({ commit }, id) => commit('delete', id),
    deletePersonCalls:({ commit }, id) => commit('deletePersonCalls', id),
    deletePersonRegisters:({ commit }, {id, type="registers"}) => commit('deletePersonRegisters',  {id, type}),
    deletePersonPayments:({ commit }, id) => commit('deletePersonPayments', id),
    deletePersonExams:({ commit }, id) => commit('deletePersonExams', id),
}

const mutations = {
    getDatas: (state, { data }) => {
        axios.get(data || '/api/v1/person').then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    setSelectedPerson(state, {id, data = null}) {
        state.selectedPerson.id = id;
        state.selectedPerson.data = data
    },
    getPersonCalls(state, id){
        axios(`/api/v1/person/${id}/call`)
        .then(res => {
            state.selectedPerson.calls = res.data.data;
        })
    },
    getPersonPayments(state, id){
        axios(`/api/v1/person/${id}/payment`)
            .then(res => {
            state.selectedPerson.payments = res.data.data;
            })
    },
    getPersonRegisters(state, {id, type}){
        axios(`/api/v1/person/${id}/${type}`)
           .then(res => state.selectedPerson[type] = res.data.data)
    },
    getPersonExams(state, id){
        axios(`/api/v1/person/${id}/exam`)
           .then(res => state.selectedPerson.exams = res.data.data)
    },
    getPersonData(state, {id, data}){
        var mdata = null
        mdata = new Promise((resolve, reject) => {
            resolve(data)
        });
        if(!data){
            mdata = new Promise((resolve, reject) => {
            axios.get(`/api/v1/person/${id}/data`)
                .then(res => resolve(res.data.data))
                ;
            });
        }
        mdata.then(dump => {
            state.selectedPerson.sdata = dump
        })
    },
    getPyamentsRegister(state, {id, type}){
    axios(`/api/v1/${type}/${id}/payment`)
        .then(res => {
        state.selectedPerson.payments = res.data.data;
        }) 
    },
    

    updatePersonPaymentData(state, data){

        if(state.selectedPerson.payments.some(item => item.id == data.id)){
            let index = state.selectedPerson.payments.findIndex(item => item.id == data.id)
            state.selectedPerson.payments = state.selectedPerson.payments.filter(item => item.id !== data.id)
            state.selectedPerson.payments.splice(index , 0 , data)
        }else{
            state.selectedPerson.payments.push(data)
        }

        let findRegister = state.selectedPerson.registers.find(item => item.id == data.paymentable_id)
        if(findRegister && !findRegister.payments.find(item => item.id == data.id)){
            findRegister.payments.push(data)
        }
        
    },

    updatePersonRegisterData(state, {data, type}){
        if(state.selectedPerson[type].some(item => item.id == data.id)){
            let index = state.selectedPerson[type].findIndex(item => item.id == data.id)
             state.selectedPerson[type] = state.selectedPerson[type].filter(item => item.id !== data.id)
             state.selectedPerson[type].splice(index , 0 , data)
        }else{
            state.selectedPerson[type].push(data)
       }
    },

    updatePersonCallData(state, data){
        if(state.selectedPerson.calls.some(item => item.id == data.id)){
            let index = state.selectedPerson.calls.findIndex(item => item.id == data.id)
             state.selectedPerson.calls = state.selectedPerson.calls.filter(item => item.id !== data.id)
             state.selectedPerson.calls.splice(index , 0 , data)
        }else{
            state.selectedPerson.calls.push(data)
       }
    },

    addPerson(state){
        state.person = {
            acquaintance: null,
            acquaintance_param: null,
            reason: null,
            role: null,
            name: null,
            phone: null,
            date:null ,
            gender: "0",
            branch: null,
            comments: null,
            email: null,
            password: null,
            is_teacher: null,
            insideId: null,
            insideType: null,        
        }
    },

    editPerson(state, {id, data}){
        state.person = {
            acquaintance: window.acquaintances.find(x => x.id == data.acquaintance_id),
            acquaintance_param: data.acquaintance_param,
            reason: window.reasons.find(x => x.id == data.reason_id),
            role: window.roles.find(x => x.id == data.role_id),
            name: data.name,
            phone: data.phone,
            date:data.created_at ,
            gender: data.gender,
            comments: data.comments,
            branch: window.branches.find(x => x.id == data.branch_id),
            email: data.email,
            is_teacher: data.is_teacher,
            password: data.password ? '****' : null,
            insideId: data.id,
            insideType: 'update',        
        }
    },
    updatePersonData(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },

    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

    deletePersonCalls(state, id){
        state.selectedPerson.calls = state.selectedPerson.calls.filter(item => item.id != id)
    },
    deletePersonRegisters(state,{id, type}){
        state.selectedPerson[type] = state.selectedPerson[type].filter(item => item.id != id)
    },
    deletePersonExams(state, id){
        state.selectedPerson.exams = state.selectedPerson.exams.filter(item => item.id != id)
    },
    deletePersonPayments(state, id){
        state.selectedPerson.payments = state.selectedPerson.payments.filter(item => item.id != id)
    },
}

export default {
    state,
    getters,
    actions,
    mutations
}