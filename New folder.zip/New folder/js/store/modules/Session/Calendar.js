import axios from "axios"
import { data } from "jquery"

const state = {
    events: [],
    rooms: [],
    count: 0,
    statistics: [],
    pagination: {},
    selected: {
        id: 1,
        data: {},
        action: {
            id: null,
            type: null,
            status: null,
            key: 99999
        },
        key: 0
    },
    grabData: {
        resourceId: null,
        start: null,
        end: null,
        from: null,
        to: null,
    },
    classcoursesession: {
        class: null,
        teacher: null,
        comment: null,
        status: null,
        from: null,
        to: null,
        session_type: null,
        insideId: null,
        insideType: null,
        online_link: null,
        type: null,
        mainLoops: [],
        sendCancelSms: null,
        sendChangeTimeSms: null,
        class_course_id: null,
        teacher_start: null,
        teacher_end: null,
    }
}

const getters = {
    events: (state) => state.events,
    count: (state) => state.count,
    statistics: (state) => state.statistics,
    rooms: (state) => state.rooms,
    grabData: (state) => state.grabData,
    pagination: (state) => state.pagination,
    classcoursesession: (state) => state.classcoursesession
}

const actions = {
    getEvetns: ({ commit }, { date = null }) => commit('getEvetns', { data: date }),
    getRooms: ({ commit }) => commit('getRooms'),
    drop: ({ commit }, { resource, id, start, end }) => commit('drop', { resource, id, start, end }),
    resize: ({ commit }, { id, start, end }) => commit('resize', { id, start, end }),
    grap: ({ commit }, { resourceId, start, end, fastart, faend }) => commit('grab', { resourceId: resourceId, start: start, end: end, fastart: fastart, faend: faend }),
    addEvent: ({ commit }, { data }) => commit('addEvent', { data: data }),
    updateEvent: ({ commit }, { data }) => commit('updateEvent', { data }),
    delete: ({commit}, id) => commit('delete', id),

    addSession: ({commit}, {id, type = null}) => commit('addSession', {id: id, type:type}),
    editSession: ({commit}, {data}) => commit('editSession', {data}),
    updateSession: ({commit}, data) => commit('updateSession', data)
}

const mutations = {
    getEvetns: (state, { data }) => {
        axios.get(data).then(res => {
            state.events = res.data.data
            state.count = res.data.metadata ? res.data.metadata.count : null
            state.statistics = res.data.metadata ? res.data.metadata.statistics : null
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    getRooms: (state) => {
        axios.get('/api/v1/class').then(res => state.rooms = res.data.data)
    },
    drop: (state, { resource, id, start, end }) => {
        let index = state.events.findIndex(x => x.id == id)
        state.events[index].from = start
        state.events[index].to = end
        state.events[index].mainLoops = start
        state.events[index].insideId = id
        state.events[index].insideType = 'update'
        if (resource) {
            state.events[index].resourceId = resource
            state.events[index].class.id = resource
        }
        axios.post(`/api/v1/class-course/${state.events[index].class_course_id}/session`, state.events[index])
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                state.events[index].start = res.data.data.start
                state.events[index].end = res.data.data.end

                state.events[index].from = res.data.data.from
                state.events[index].to = res.data.data.to

                state.events[index].resourceId = res.data.data.resourceId
                state.selected.key++

                if(confirm('آیا پیام تغییر زمان جلسه برای شاگردان ارسال شود؟')){
                    axios.post(`/api/v1/session/${id}/send-changne-message`)
                }
            });

    },
    resize: (state, { id, start, end }) => {
        let index = state.events.findIndex(x => x.id == id)
        state.events[index].from = start
        state.events[index].to = end
        state.events[index].mainLoops = start
        state.events[index].insideId = id
        state.events[index].insideType = 'update'

        axios.post(`/api/v1/class-course/${state.events[index].class_course_id}/session`, state.events[index])
            .then(res => {
                if(res.data.alert && res.data.alert.type == 'error') return;
                state.events[index].start = res.data.data.start
                state.events[index].mainLoops = res.data.data.start
                state.events[index].end = res.data.data.end
                state.events[index].from = res.data.data.from
                state.events[index].to = res.data.data.to
                state.events[index].resourceId = res.data.data.resourceId
                state.selected.key++

                if(confirm('آیا پیام تغییر زمان جلسه برای شاگردان ارسال شود؟')){
                    axios.post(`/api/v1/session/${id}/send-changne-message`)
                }
            });

    },
    grab: (state, { resourceId, start, end, fastart, faend }) => {
        state.grabData.resourceId = resourceId
        state.grabData.start = start
        state.grabData.end = end
        state.grabData.mainLoops = start
        state.grabData.from = fastart
        state.grabData.to = faend
        state.grabData.insideType = 'insert'
    },
    addEvent: (state, { data }) => {
        state.events.push(data)
    },
    updateEvent: (state, { data }) => {
        let index = state.events.findIndex(x => x.id == data.id)
        state.events[index].title = data.title
        state.events[index].start = data.start
        state.events[index].mainLoops = data.start
        state.events[index].end = data.end
        state.events[index].from = data.from
        state.events[index].to = data.to
        state.events[index].session_type = data.session_type
        state.events[index].resourceId = data.resourceId
        state.events[index].class = data.class
        state.events[index].status = data.status
        state.events[index].teacher_start = data.teacher_start
        state.events[index].teacher_end = data.teacher_end
        state.events[index].online_link = data.online_link
        state.events[index].statusopt = data.statusopt
        state.selected.key++
    },
    delete(state, id){
        state.events = state.events.filter(x => x.id != id)
    },

    addSession(state, {id, type}){
        state.classcoursesession = {
            class: null,
            teacher: null,
            comment: null,
            status: null,
            from: null,
            to: null,
            session_type: null,
            online_link: null,
            insideId: id,
            class_course_id: id,
            insideType: 'insert',
            type: type || 'classcourse',
            mainLoops: [],
            sendCancelSms: null,
            sendChangeTimeSms: null,
            teacher_start: null,
            teacher_end: null,
        }
        if(type != 'register'){
            axios.get(`/api/v1/class-course/${id}`)
                .then(res => {
                res.data.data.class.label = res.data.data.class.name;
                state.classcoursesession.class = res.data.data.class
                res.data.data.teacher.label = res.data.data.teacher.name;
                state.classcoursesession.teacher = res.data.data.teacher;
            });
        }
    },
    editSession(state, {data}){
        data.teacher.label = data.teacher.name
        data.class.label = data.class.name

        state.classcoursesession = {
            class: data.class,
            teacher: data.teacher,
            status: data.status,
            from: data.start,
            to: data.end,
            session_type: window.defined_enums.session_type.find(x => x.name == data.session_type),
            insideId: data.id,
            online_link: data.online_link,
            class_course_id: data.class_course_id,
            insideType: 'update',
            comment: data.comment,
            type: null,
            mainLoops: data.start,
            sendCancelSms: null,
            sendChangeTimeSms: null,
            teacher_start: data.teacher_start,
            teacher_end: data.teacher_end,
        }
      
    },

    updateSession(state, data){
        if(state.events.some(item => item.id == data.id)){
            let index = state.events.findIndex(item => item.id == data.id)
            state.events = state.events.filter(item => item.id !== data.id)
            state.events.splice(index , 0 , data)
        }else{
            state.events.push(data)
        }
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}