import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        date: null,
        event: null,
        day_type: null,
        insideId: null,
        insideType: null,
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    add: ({ commit }, { data = null }) => commit('add', { data: data }),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data
            state.count = res.data.data.length  
        })
    },

    add: (state, {data}) => {
        state.data = {
            date: null,
            event: null,
            day_type: null,
            insideId: null,
            insideType: null,
        }
    },
    edit: (state, {data}) => {
        state.data = {
            date: data.date,
            event: data.event,
            day_type: window.defined_enums.date_type.find(x => x.name == data.day_type),
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)

    },
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}