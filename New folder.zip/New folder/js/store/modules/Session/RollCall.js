import axios from "axios"
import { data } from "jquery"

const state = {
    datas: [],
    session: {},
}

const getters = {
    get: state => state.datas,
    session: state => state.session
}

const actions = {
    getDatas:({ commit }, {session}) => commit('getDatas', {session: session}),
    setStart: ({ commit }, {item, params = {}}) => commit('setStart', {item: item, params: params}),
    setEnd: ({ commit }, {item, params = {}}) => commit('setEnd', {item: item, params: params}),
    changeStatus:({ commit }, {item, status}) => commit('changeStatus', {item: item, status: status}),
    addComment:({ commit }, data = null) => commit('addComment', data),
    addRollCallComment:({ commit }, data) => commit('addRollCallComment', data),
    getByRegister:({ commit }, {register}) => commit('getByRegister', {register: register}),
}

const mutations = {
    getByRegister: (state, {register}) => {
        axios.get(`/api/v1/register/${register}/rollcall`).then(res => {
            state.datas = res.data.data
        })
    },
    getDatas: (state, { session }) => {
        axios.get(`/api/v1/session/${session.insideId || session.id}/rollcall`).then(res => {
            state.datas = res.data.data
            state.session = session
        })
    },

    setStart(state, {item, params}){
        var session = item || state.session
        axios.post(`/api/v1/session/${session.insideId || session.id}/set-teacher-start?start_time=${session.teacher_start}`, {
            ...params
        }).then(res => {
            if(res.data.alert && res.data.alert.type == 'error') return;
            state.session.teacher_start = res.data.data.teacher_start
        })
    },

    setEnd(state, {item, params}){
        var session = item || state.session
        axios.post(`/api/v1/session/${session.insideId || session.id}/set-teacher-end?teacher_end=${session.teacher_end}`, {
            ...params
        }).then(res => {
            if(res.data.alert && res.data.alert.type == 'error') return;
            state.session.teacher_end = res.data.data.teacher_end
        })
    },

    addComment(state, data){
        var session = data || state.session
        axios.post(`/api/v1/session/${session.insideId || session.id}/set-session-comment`, {
            comment: session.comment
        })
    },

    addRollCallComment(state, data){
        axios.post(`/api/v1/session/${data.rollcall_id}/set-rollcall-comment`, {
            comment: data.comment
        })
    },
    changeStatus: (state, {item, status}) => {
        
        axios.post(`/api/v1/session/${item.session.id}/rollcall`, {
            register_id: item.id,
            user_id: item.user_id,
            status: status,
        }).then(res => {
            if(res.data.alert && res.data.alert.type == 'error') return;
            state.datas.find(res => res.id == item.id).rollcall_session_status = status
            state.datas.find(res => res.id == item.id).rollcall_id = res.data.data.id
            state.datas.find(res => res.id == item.id).rollcall_created_at = res.data.data.rollcall_created_at
            state.datas.find(res => res.id == item.id).rollcall_presence_time = res.data.data.rollcall_presence_time
            state.datas.find(res => res.id == item.id).comment = res.data.data.comment
        })

    },

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}