import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        name: null,
        content: null,
        course_id: null,
        short_description: null,
        image: null,
        price: null,
        free_use: null,
        timer: null,
        question_count: null,
        pass_score_percent: null,
        courses: [],
        insideId: null,
        insideType: null,
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),

    updateExamQuestionCount: ({commit} ,{id, count}) => commit('updateExamQuestionCount', {id: id, count: count}),
    decrementUserExamCount: ({commit}, id) => commit('decrementUserExamCount', id)
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data
            state.count = res.data.data.length  
        })
    },

    add: (state) => {
        state.data = {
            name: null,
            content: null,
            course_id: null,
            short_description: null,
            image: null,
            price: null,
            free_use: null,
            timer: null,
            question_count: null,
            pass_score_percent: null,
            courses: [],
            insideId: null,
            insideType: null,
        }
    },
    edit: (state, {data}) => {
        state.data = {
            name: data.name,
            course_id: window.courses.find(x => x.id == data.course_id),
            content: data.content,
            short_description: data.short_description,
            image: data.image,
            price: data.price,
            free_use: data.free_use,
            timer: data.timer,
            question_count: data.question_count,
            pass_score_percent: data.pass_score_percent,
            courses: data.courses.map(x => {
                x.label = x.name
                return x
            }),
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)

    },

    updateExamQuestionCount(state, {id, count}){
        if(!state.datas.some(x => x.id == id)) return;
        state.datas.find(x => x.id == id).exam_questions_count = count
    },


    decrementUserExamCount(state, id){
        if(!state.datas.some(x => x.id == id)) return;
        var count = state.datas.find(x => x.id == id).user_exams_count
        count = parseInt(count)
        state.datas.find(x => x.id == id).user_exams_count = count - 1
    }

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}