import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        question: null,
        choose_1: null,
        choose_2: null,
        choose_3: null,
        choose_4: null,
        answer: null,
        exam_id: null,
        insideId: null,
        insideType: null,
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),

    getExamQuestions: ({ commit }, { exam_id }) => commit('getExamQuestions', { exam_id: exam_id }),

}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data
            state.count = res.data.data.length  
        })
    },

    add: (state) => {
        state.data = {
            question: null,
            choose_1: null,
            choose_2: null,
            choose_3: null,
            choose_4: null,
            answer: null,
            exam_id: null,
            insideId: null,
            insideType: null,
        }
    },
    edit: (state, {data}) => {
        state.data = {
            question: data.question,
            choose_1: data.choose_1,
            choose_2: data.choose_2,
            choose_3: data.choose_3,
            choose_4: data.choose_4,
            answer: data.answer,
            exam_id: data.exam_id,
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)

    },

    getExamQuestions(state, {exam_id}){
        axios.get(`/api/v1/exam/${exam_id}/questions`).then(res => state.datas = res.data.data)
    }

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}