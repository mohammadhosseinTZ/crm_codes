import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    report: [],
    data: {
        name: null,
        shaba:null,
        user: null,
        comment: null,
        charge_sources: null,
        card_number: null,
        account_number: null,
        current_amount: null,
        primitive_amount: null,
        calc_from: null,
        calc_to: null,
        branches: null,
        type: null,
        insideId: null,
        insideType: null
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
    report: state => state.report,
}

const actions = {
    get: ({ commit }, { date = null }) => commit('get', { date: date }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
    report: ({ commit }, { data }) => commit('report', {data: data}),
}

const mutations = {
    get: (state, { date }) => {
        axios.get(date).then(res => {
            state.datas = res.data.data
            // state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
            name: null,
            shaba:null,
            user: null,
            charge_sources: null,
            comment: null,
            card_number: null,
            account_number: null,
            current_amount: null,
            primitive_amount: null,
            calc_from: null,
            calc_to: null,
            branches: null,
            type: null,
            insideId: null,
            insideType: null
        }
    },
    edit: (state, {data}) =>{
        var user = null;
        if(data.user){
            data.user.label = data.user.name
            user = data.user
        }
        state.data = {
            name: data.name,
            shaba:data.shaba, 
            user: user,
            comment: data.comment,
            card_number: data.card_number,
            account_number: data.account_number,
            current_amount: data.current_amount,
            primitive_amount: data.primitive_amount,
            calc_from: data.calc_from,
            calc_to: data.calc_to,
            branches: data.branches,
            charge_sources: data.charge_sources.map(x => {
                x.label = x.option_value
                return x
            }),
            type: window.defined_enums.bank_types.find(x => x.name == data.type),
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

    report(state, {data}){
        axios.get(`/api/v1/accounting/bank/${data.id}/report`).then(res => {
            state.report = res.data
        })
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}