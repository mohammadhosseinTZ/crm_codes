import axios from "axios"

const state = {
    datas: [],
    pagination: {},
    selected: {},
    data: {
        bank: null,
        fundCard: null,
        price: null,
        commission: null,
        comment: null,
        created_at: null,
        insideId: null,
        insideType: null
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
    selected: state => state.selected,
}

const actions = {
    get: ({ commit }, { date = null, id, type = 'fund-cards', calc_from = null, calc_to = null }) => commit('get', { date: date, id: id, type: type, calc_from, calc_to  }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { date, id, type, calc_from, calc_to }) => {
        axios.get(`/api/v1/accounting/card-charge/?${type ? type + "=" + id: null}${calc_from && calc_to ? '&date=' + calc_from + "," + calc_to : null }`).then(res => {
            state.datas = res.data.data
            // state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }

            if(id){
                state.selected = id
            }
        })
        
    },

    add: (state) => {
        state.data = {
            bank: null,
            fundCard: null,
            price: null,
            commission: null,
            comment: null,
            created_at: null,
            insideId: null,
            insideType: null
        }
    },
    edit: (state, {data}) =>{
        data.user.label = data.user.name
        state.data = {
            bank: data.bank,
            fundCard: data.fund_card,
            price: data.price,
            commission: data.commission,
            comment: data.comment,
            created_at: data.created_at,
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}