import axios from "axios"

const state = {
    teachers: [],
    salary_report: [],
    datas: [],
    courses: [],
    count: 0,
    pagination: {},
    data: {
        teacher: null,
        course: null,
        course_type: null,
        session_type: null,
        price: null,
        holiday_price: null,
        overtime_price: 0,
        unit: null,
        start_date: window.defined_enums.default_salary_start_date,
        expiry_date: window.defined_enums.default_salary_expriy_date,
        insideId: null,
        insideType: null,
    },
}

const getters = {
    teachers: state => state.teachers,
    salary_report: state => state.salary_report,
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    courses: (state) => state.courses,
    data: state => state.data,
}

const actions = {
    teachers: ({ commit }, { date = null }) => commit('teachers', { date: date }),
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    salaryReport: ({ commit }, { data = null, queries = {} }) => commit('salaryReport', { data: data, queries: queries }),
    add: ({ commit }, {teacher = null, datas = {}}) => commit('add', {teacher: teacher, datas: datas}),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    teachers: (state, { date }) => {
        axios.get(date).then(res => {
            state.teachers = res.data.data
        })
    },
    
    get: (state, { data }) => {
        state.data.teacher = data
        axios.get('/api/v1/accounting/salary/teachers-salary-schema/' + data.id).then(res => {
            state.datas = res.data.data
            state.courses = res.data.teacher_courses
        })
    },

    salaryReport: (state, { data , queries}) => {
        state.data.teacher = data
        axios.get('/api/v1/accounting/salary/teachers-salary-schema/' + data.id + '/report', {
            params: queries
        }).then(res => {
            state.salary_report = res.data
        })
    },

    add: (state, {teacher, datas}) => {
        if(datas.course){
            datas.course.label = datas.course.name
        }
        state.data = {
            teacher: teacher,
            course: datas.course ? datas.course : null,
            course_type: datas.course_type ? window.defined_enums.course_type.find(x => x.name == datas.course_type) : null,
            session_type: datas.session_type ? window.defined_enums.session_type.find(x => x.name == datas.session_type) : null,
            price: null,
            holiday_price: null,
            overtime_price: 0,
            unit: window.defined_enums.teacher_salary_calc_units.find(x => x.name == "hour"),
            start_date: window.defined_enums.default_salary_start_date,
            expiry_date: window.defined_enums.default_salary_expriy_date,
            insideType: 'insert',
            insideType: null,
        }
    },
    edit: (state, {data}) =>{
        state.data = {
            teacher: data.teacher,
            course: window.courses.find(x => x.id == data.course_id),
            course_type:  window.defined_enums.course_type.find(x => x.name == data.course_type),
            session_type: window.defined_enums.session_type.find(x => x.name == data.session_type),
            price: data.price,
            holiday_price: data.holiday_price,
            overtime_price: data.overtime_price,
            unit: window.defined_enums.teacher_salary_calc_units.find(x => x.name == data.unit),
            start_date: data.start_date,
            expiry_date: data.expiry_date,
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)

    },


}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}