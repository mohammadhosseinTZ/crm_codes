import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    register: {
        class_course_id: null,
        category: null,
        course_id: null,
        discount_price: '',
        discount_fors: [],
        price: null,
        return_price: null,
        reason_id: null,
        leave_reason: null,
        comments: null,
        is_online_course: false,
        created_at: null,
        user_id: null,
        user_reference_id: null,
        insideId: null,
        insideType: null,
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    register: state => state.register
}

const actions = {
    addRegister:({ commit }, id) => commit('addRegister', id),
    editRegister:({commit}, {id, data = null, user_id = null}) => commit('editRegister', {id: id, data:data, user_id:user_id}),
    getDatas: ({ commit }, {data = null}) => commit('getDatas', {data: data}),
    updateRegisterData:({ commit }, data) => commit('updateRegisterData', data),
    updateRegistersPayment:({ commit }, data) => commit('updateRegistersPayment', data),
    delete:({ commit }, id) => commit('delete', id),
}

const mutations = {
    getDatas: (state, { data }) => {
        axios.get(data || '/api/v1/register').then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    addRegister: (state, id) =>{
            state.register = {
                class_course_id: null,
                category: null,
                course_id: null,
                discount_price: '',
                discount_fors: [],
                price: null,
                return_price: null,
                reason_id: null,
                leave_reason: null,
                comments: null,
                is_online_course: false,
                created_at: null,
                user_id: null,
                user_reference_id: null,
                insideId: id,
                insideType: 'insert',
            }
    },
    editRegister: (state, {id, data, user_id}) => {
        var register = null
        register = new Promise((resolve, reject) => {
            resolve(data)
        });

        if(!data){
            register = new Promise((resolve, reject) => {
            axios.get("/api/v1/register/"+ id)
                .then(res => dump = resolve(res.data.data))
                ;
            });
        }
        
        register.then(dump => {
            var day = ''
            var hour = ''
            var fors = [];
            if(dump.class_course.day){
                day = dump.class_course.day
            }
            if(dump.class_course.start_time && dump.class_course.end_time){
                hour = dump.class_course.start_time + " الی " + dump.class_course.end_time
            }
            dump.class_course.label = dump.class_course.course_code + " - " + dump.course.name + " " + day  + " " + hour

            var discount_price = dump.price
            var price = parseInt(dump.price) + parseInt(dump.discount_price || 0)
            

            for(var n of dump.discount_fors){
                if(window.discountFor.some(x => x.id == n.meta_value)){
                    fors.push(window.discountFor.find(x => x.id == n.meta_value))
                }
            }

            if(dump.bonus){
                dump.user_reference = dump.bonus.user_reference
                dump.user_reference.label = dump.bonus.user_reference.name
            }

            state.register = {
                class_course_id:  dump.class_course,
                category: dump.category_id,
                course_id: window.courses.find(x => x.id == dump.course_id),
                discount_price: discount_price,
                discount_fors: fors,
                price: price,
                return_price: dump.return_price,
                reason_id: window.reasons.find(x => x.id == dump.reason_id),
                leave_reason: window.leaveReasons.find(x => x.id == dump.leave_reason_id),
                comments: dump.comment,
                is_online_course: parseInt(dump.is_online_course),
                created_at: dump.created_at,
                user_id: dump.user_id,
                user_reference_id: dump.user_reference,
                insideId: id,
                insideType: 'update',

                selectedCourse: window.courses.find(x => x.id == dump.course_id),
                just_leave_reason: window.leaveReasons.find(x => x.id == dump.leave_reason_id)
            }

    
        })
        
        
    },

    updateRegisterData(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },

    updateRegistersPayment(state, data){
        
        let findRegister = state.datas.find(item => item.id == data.paymentable_id)
        if(findRegister && !findRegister.payments.find(item => item.id == data.id)){
            findRegister.payments.push(data)
        }
    },

    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}