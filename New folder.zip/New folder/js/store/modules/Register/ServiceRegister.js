import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    register: {
        items: [
            // {
            //     supplier: null,
            //     discount_price: null,
            //     discount_fors: null,
            //     unit_price: null,
            //     price: null,
            //     quantity: 1,
            //     return_price: null,
            //     leave_reason: null,
            //     calcpercentVal: 0
            // }
        ],
        comments: null,
        created_at: null,
        all_price: 0,
        pay_discount_price: 0, 
        user_reference_id: null,
        user_id: null,
        insideId: null,
        insideType: 'insert',
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    register: state => state.register
}

const actions = {
    addRegister:({ commit }, id) => commit('addRegister', id),
    editRegister:({commit}, {id, data = null, user_id = null}) => commit('editRegister', {id: id, data:data, user_id:user_id}),
    getDatas: ({ commit }, {data = null}) => commit('getDatas', {data: data}),
    updateRegisterData:({ commit }, data) => commit('updateRegisterData', data),
    updateRegistersPayment:({ commit }, data) => commit('updateRegisterData', data),
    delete:({ commit }, id) => commit('delete', id),
}

const mutations = {
    getDatas: (state, { data }) => {
        axios.get(data || '/api/v1/register').then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },
    addRegister: (state, id) =>{

            state.register = {
                items: [
                    // {
                    //     supplier: null,
                    //     discount_price: null,
                    //     discount_fors: null,
                    //     unit_price: null,
                    //     price: null,
                    //     quantity: 1,
                    //     return_price: null,
                    //     leave_reason: null,
                    //     calcpercentVal: 0
                    // }
                ],
                comments: null,
                created_at: null,
                user_id: null,
                all_price: 0,
                pay_discount_price: 0, 
                user_reference_id: null,
                insideId: id,
                insideType: 'insert',
            }
    },
    editRegister: (state, {id, data, user_id}) => {


let items = [];
        let allPrice = 0;
        for(var n of data.items){
            var fors = [];

                var discount_price =   n.price
                var price = parseInt(n.price) + parseInt(n.discount_price || 0)
            
            for(var n2 of n.discount_fors){
                if(window.discountFor.some(x => x.id == n2.meta_value)){
                    fors.push(window.discountFor.find(x => x.id == n2.meta_value))
                }
            }
            allPrice += parseInt(discount_price)
            items.push({
                supplier: n.supplier,
                discount_price: discount_price,
                discount_fors: fors,
                unit_price: n.unit_price,
                price: price,
                id: n.id,
                quantity: n.quantity,
                leave_reason: window.leaveReasons.find(x => x.id == n.leave_reason_id),
                calcpercentVal: 0
            })
        }
        if(data.bonus){
            data.user_reference = data.bonus.user_reference
            data.user_reference.label = data.bonus.user_reference.name
        }
        allPrice -= data.pay_discount_price || 0

        state.register = {
            fast_shop: false,
            items: items,
            comments: data.comment,
            created_at: data.created_at,
            user_id: data.user_id,
            all_price: allPrice,
            pay_discount_price: parseInt(data.pay_discount_price) ? parseInt(data.pay_discount_price) : 0, 
            user_reference_id: data.user_reference,
            insideId: id,
            id: id,
            insideType: 'update',
        }
    },

    updateRegisterData(state, data){
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },

    updateRegistersPayment(state, data){
        
        let findRegister = state.datas.find(item => item.id == data.paymentable_id)
        if(findRegister && !findRegister.payments.find(item => item.id == data.id)){
            findRegister.payments.push(data)
        }
    },

    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    }
}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}