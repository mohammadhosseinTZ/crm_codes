import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    statistics: [],
    data: {
        register: null,
        register_item: null,
        quantity: null,
        price: null,
        leave_reason: null,
        status: null,
        comment: null,
        created_at: null,
        insideId: null,
        insideType: 'insert',
    },
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    statistics: (state) => state.statistics,
    data: state => state.data
}

const actions = {
    get: ({ commit }, { data = null }) => commit('get', { data: data }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
    changeStatus: ({commit}, id) => commit('changeStatus', id)
}

const mutations = {
    get: (state, { data }) => {
        axios.get(data).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.statistics = res.data.metadata.statistics
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
            register: null,
            register_item: null,
            quantity: null,
            price: null,
            leave_reason: null,
            status: null,
            comment: null,
            created_at: null,
            insideId: null,
            insideType: 'insert',
        }
    },

    edit: (state, {data}) =>{
        data.register_item.label = data.register_item.supplier.name
        data.leave_reason.label = data.leave_reason.option_value
        state.data = {
            register: data.register,
            register_item: data.register_item,
            quantity: data.quantity,
            price: data.price,
            leave_reason: data.leave_reason,
            status: parseInt(data.status),
            comment: data.comment,
            created_at: data.created_at,
            insideId: data.id,
            insideType: 'update',
        }
    },


    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

    changeStatus(state, id){
        axios.get(`/api/v1/return-product/${id}/changestatus`)
        .then(res => {
            state.datas.find(x => x.id == id).status = res.data.data.status
        })
    }

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}