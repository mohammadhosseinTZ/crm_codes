import axios from "axios"

const state = {
    datas: [],
    count: 0,
    pagination: {},
    data: {
        name: null,
        price: null,
        category: null,
        branches: null,
        courses: null,
        keys: null,
        products: null,
        parent_id: null,
        insideId: null,
        insideType: null
    }
}

const getters = {
    datas: state => state.datas,
    count: (state) => state.count,
    pagination: (state) => state.pagination,
    data: state => state.data,
}

const actions = {
    get: ({ commit }, { date = null }) => commit('get', { date: date }),
    add: ({ commit }) => commit('add'),
    edit: ({ commit }, { data }) => commit('edit', { data: data }),
    update: ({ commit }, data) => commit('update', data),
    delete: ({ commit }, id) => commit('delete', id),
}

const mutations = {
    get: (state, { date }) => {
        axios.get(date).then(res => {
            state.datas = res.data.data
            state.count = res.data.metadata.count
            state.pagination = {
                current_page: res.data.meta.current_page,
                last_page: res.data.meta.last_page,
                next_page: res.data.links.next,
                prev_page: res.data.links.prev
            }
        })
    },

    add: (state) => {
        state.data = {
            name: null,
            price: null,
            category: null,
            courses: null,
            products: null,
            keys: null,
            branches: null,
            parent_id: null,
            insideId: null,
            insideType: null
        }
    },
    edit: (state, {data}) =>{
        state.data = {
            name: data.name,
            price: data.price,
            category: data.category,
            branches: data.branches,
            keys: data.keys,
            courses: data.courses.map(x => {x.label = x.name; return x}),
            products: data.products,
            parent_id: data.parent,
            insideId: data.id,
            insideType: 'update',
        }
    },
    update: (state, data) => {
        if(state.datas.some(item => item.id == data.id)){
            let index = state.datas.findIndex(item => item.id == data.id)
            state.datas = state.datas.filter(item => item.id !== data.id)
            state.datas.splice(index , 0 , data)
        }else{
            state.datas.push(data)
        }
    },
    delete(state, id){
        state.datas = state.datas.filter(x => x.id != id)
    },

}

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
}