import Vuex from 'vuex'
import Vue from 'vue'
import PersonIndex from './modules/Person/PersonIndex'
import CourseIndex from './modules/Course/CourseIndex'
import ClassIndex from './modules/Class/ClassIndex'
import ClassCourse from './modules/ClassCourse/ClassCourse'
import Calendar from './modules/Session/Calendar'
import CalendarEvent from './modules/Session/CalendarEvent'
import RollCall from './modules/Session/RollCall'
import Branch from './modules/Branch/Branch'
import Payment from './modules/Payment/Payment'
import Cost from './modules/Cost/Cost'
import CostType from './modules/Cost/CostType'
import Allocation from './modules/Cost/Allocation'
import Category from './modules/Category/Category'
import Product from './modules/Product/Product'
import Service from './modules/Service/Service'
import Register from './modules/Register/Register'
import ProductRegister from './modules/Register/ProductRegister'
import ProductRegisterReturn from './modules/Register/ReturnProduct'
import ServiceRegister from './modules/Register/ServiceRegister'
import Call from './modules/Call/Call'
import Exam from './modules/Exam/Exam'
import ExamQuestion from './modules/Exam/ExamQuestion'
import UserExam from './modules/Exam/UserExam'
import Check from './modules/Check/Check'
import Report from './modules/Admin/Report'
import Loading from './modules/global/Loading'
import TeachersSalary from './modules/Accounting/TeachersSalary'
import Bank from './modules/Accounting/Bank'
import CardCharge from './modules/Accounting/CardCharge'
import WorkType from './modules/WorkType/WorkType'
import WorkSection from './modules/WorkSection/WorkSection'
import WorkJob from './modules/WorkJob/WorkJob' 
 import Employee from './modules/Employee/Employee' 
 import EmployeeRollCall from './modules/Employee/EmployeeRollCall' 
 import Uploads from './modules/Uploads/Uploads' 
 import Contract from './modules/Contract/Contract' 
 //{{ SnameImport }}
Vue.use(Vuex)

export default new Vuex.Store({
    modules: {
        PersonIndex,
        CourseIndex,
        ClassIndex,
        ClassCourse,
        Calendar,
        CalendarEvent,
        RollCall,
        Payment,
        Cost,
        CostType,
        Allocation,
        Category,
        Product,
        Service,
        Register,
        ProductRegister,
        ProductRegisterReturn,
        ServiceRegister,
        Call,
        Branch,
        Exam,
        ExamQuestion,
        UserExam,
        Check,
        Report,
        Loading,
        TeachersSalary,
        Bank,
        CardCharge,
        WorkType,
        WorkSection,
        WorkJob, 
        Employee, 
        Uploads, 
        Contract, 
        EmployeeRollCall
//{{ Sname }}
    },
});