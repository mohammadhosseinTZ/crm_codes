window._ = require('lodash');
import Cropper from 'cropperjs';
/**
 * We'll load jQuery and the Bootstrap jQuery plugin which provides support
 * for JavaScript based Bootstrap features such as modals and tabs. This
 * code may be modified to fit the specific needs of your application.
 */

try {
    window.Popper = require('popper.js').default;
    window.$ = window.jQuery = require('jquery');

    require('bootstrap');
} catch (e) {}

/**
 * We'll load the axios HTTP library which allows us to easily issue requests
 * to our Laravel back-end. This library automatically handles sending the
 * CSRF token as a header based on the value of the "XSRF" token cookie.
 */

window.axios = require('axios');

window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
window.axios.defaults.headers.common['X-CSRF-TOKEN'] = window.csrf;
window.axios.defaults.headers.common['Authorization'] = `Bearer ${window.api_token}`;

import '../select2.js'
import '../jalalidatepicker.min.js'




$(document).ready(function() {
    const cropper = {};
    const imagesBlob = {}
    $('.select2').select2()

  

    $('.select-image').on('change', function(){
        var image = this.files[0]

        if(cropper[$(this).attr('name')]){
            cropper[$(this).attr('name')].destroy()
            delete cropper[$(this).attr('name')] 
        }

        $(this).parent().children('img').remove()
        $(this).parent().children('button').remove()
        $(this).parent().append(`<img class="preview mt-2" src="${URL.createObjectURL(image)}"><button data-target="${$(this).attr('name')}" type="button" class="btn btn-sm btn-primary mt-3 apply-button">اعمال تغییرات</button`);
        var img = this.parentNode.querySelector('.preview')
        cropper[$(this).attr('name')] = new Cropper(img, {
            zoomable: false,
        }); 

        $('.apply-button').on('click', function(){
            var selectedVal = cropper[$(this).data('target')]

            selectedVal.getCroppedCanvas({
                imageSmoothingEnabled: true,
                imageSmoothingQuality: 'high',
                maxWidth: 1300,
                maxHeight: 1300,
            }).toBlob((blob) => {
                    var imageUrl = URL.createObjectURL(blob);
                    $(this).parent().children('img').remove()
                    $(this).parent().children('button').remove()

                    imagesBlob[$(this).data('target')] = blob
                    setImageBlob()

                    selectedVal.destroy()

                    

            }, "image/jpeg", 0.90)

        })

    function setImageBlob(){
		for(const [key, value] of Object.entries(imagesBlob)){
			var imageData = URL.createObjectURL(value)
			$(`input[name=${key}]`).parent().children('img').remove()
			$(`input[name=${key}]`).parent().append(`<img class="preview mt-2" src="${imageData}">`)
		}	
	}


    $('#user-info-form').on('submit', function(e){
        e.preventDefault();

        $('#loader').css('display', 'flex')

        const formElement = document.getElementById('user-info-form');
        const request = new XMLHttpRequest();
        var formdata = new FormData(formElement);
        var formdataset = [];
        
        for (const [key, value] of Object.entries(imagesBlob)) {
            var imageset = new Promise(resolve => {
                    return resolve(formdata.set(key, value))	
            })

            formdataset.push(imageset)
        }


        Promise.all(formdataset).then(res => {
            request.open("POST", "/api/v1/person/null/data");
            request.setRequestHeader('Authorization', 'Bearer ' + $('#token').val())
            request.setRequestHeader('from_site', 'aryatehran.com')
            request.send(formdata);
            request.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    $('#loader').css('display', 'none')
                    for (const [key, value] of Object.entries(cropper)){
                            value.destroy()
                    }
               }
                window.location.reload();
            };	
        })


    })

});
for (var n of document.querySelectorAll('select[class*=window_]')) {
    for (var cl of n.classList) {
        if (cl.substring(0, 7) == 'window_') {
            $(n).html();
            for (var option of window[cl.substring(7)]) {
                var status = option.id == $(n).attr('value') ? 'selected' : ''
                $(n).append(`<option value="${option.id}" ${status}>${option.option_value}</option>`);
            }

            break
        }
    }

}

//  ST 1400-06-05 For Persian Date   
jalaliDatepicker.startWatch({
    separatorChar: "-",
    minDate: "attr",
    maxDate: "attr",
    changeMonthRotateYear: true,
    showTodayBtn: true,
    showEmptyBtn: true
});



  

})