const routes = [{
        path: '/',
        component: require('./components/Section/Index.vue').default
    },
    {
        path: '/persons',
        component: require('./components/Section/PersonList.vue').default
    },
    {
        path: '/courses',
        component: require('./components/Section/CourseList.vue').default
    },
    {
        path: '/calls',
        component: require('./components/Section/CallList.vue').default
    },
    {
        path: '/registers',
        component: require('./components/Section/RegistersList.vue').default
    },
    {
        path: '/product-registers',
        component: require('./components/Section/ProductRegisterList.vue').default
    },
    {
        path: '/service-registers',
        component: require('./components/Section/ServiceRegisterList.vue').default
    },
    {
        path: '/payments',
        component: require('./components/Section/PaymentList.vue').default
    },
    {
        path: '/classes',
        component: require('./components/Section/ClassList.vue').default
    },
    {
        path: '/classes-course',
        component: require('./components/Section/ClassCourseList.vue').default
    }, {
        path: '/calendar',
        component: require('./components/Class/Calendar.vue').default
    }, {
        path: '/payments',
        component: require('./components/Section/PaymentList.vue').default
    }, {
        path: '/costs',
        component: require('./components/Section/CostList.vue').default
    },{
        path: '/cost-types',
        component: require('./components/Section/CostTypeList.vue').default
    },{
        path: '/allocations',
        component: require('./components/Section/AllocationList.vue').default
    },{
        path: '/categories',
        component: require('./components/Section/CategoryList.vue').default
    },{
        path: '/products',
        component: require('./components/Section/ProductList.vue').default
    },{
        path: '/static-products',
        component: require('./components/Section/StaticProductList.vue').default
    },{
        path: '/services',
        component: require('./components/Section/ServiceList.vue').default
    }, {
        path: '/sessions',
        component: require('./components/Section/SessionList.vue').default
    }, {
        path: '/checks',
        component: require('./components/Section/CheckList.vue').default
    }, {
        path: '/phonebook',
        component: require('./components/Section/PhoneBook.vue').default
    }, {
        path: '/exams',
        component: require('./components/Section/ExamList.vue').default
    }, {
        path: '/user-exams',
        component: require('./components/Section/UserExamList.vue').default
    }
    // admin routs

    , {
        path: '/admin/definition',
        component: require('./components/Admin/Definition/DefineManager.vue').default
    }, {
        path: '/admin/reports',
        component: require('./components/Admin/Reports/Reports.vue').default
    }, {
        path: '/admin/survey',
        component: require('./components/Admin/Survey/Survey.vue').default
    }, {
        path: '/admin/survey-comments',
        component: require('./components/Admin/Survey/SurveyComments.vue').default
    }, {
        path: '/complaint',
        component: require('./components/Admin/Complaint.vue').default
    }, {
        path: '/admin/branch',
        component: require('./components/Admin/Branch/Branch.vue').default
    },
    {
        path: '/admin/contracts',
        component: require('./components/Admin/WorkSheet/ContractList.vue').default
    },

        {
            path: '/admin/work-types',
            component: require('./components/Admin/WorkSheet/WorkTypeList.vue').default
        },
        {
            path: '/admin/work-sections',
            component: require('./components/Admin/WorkSheet/WorkSectionList.vue').default
        },

        {
            path: '/admin/jobs',
            component: require('./components/Admin/WorkSheet/WorkJobList.vue').default
        },

        {
            path: '/employees',
            component: require('./components/Employee/EmployeeList.vue').default
        },

        {
            path: '/employees/rollcalls',
            component: require('./components/Employee/EmployeeRollCallCalendar.vue').default
        },
        {
            path: '/employees/profile/:id',
            component: require('./components/Employee/EmployeeProfile.vue').default,
            name:"EmployeeProfile",
            // props:true
        },
        {
            path:'/employee/salary',
            component: require('./components/Employee/EmployeeSalary.vue').default,
            name:"EmployeeSalary"
        },

        {
            path: '/uploads',
            component: require('./components/Section/UploadList.vue').default
        },

//{{add_default_here}}

    // Accounting
    {
        path: '/accounting/salary/teachers-schema',
        component: require('./components/Accounting/Salary/TeachersSalarySchema.vue').default
    },
    {
        path: '/accounting/banks',
        component: require('./components/Accounting/BankList.vue').default
    },
];
export default routes;