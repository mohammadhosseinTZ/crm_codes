window._ = require('lodash');
import store from './store'; // path to your Vuex store
import JsBarcode from './jsbarcode.js'

/**
 * We'll load jQuery and the Bootstrap jQuery plugin which provides support
 * for JavaScript based Bootstrap features such as modals and tabs. This
 * code may be modified to fit the specific needs of your application.
 */

try {
    window.Popper = require('popper.js').default;
    window.$ = window.jQuery = require('jquery');

    require('bootstrap');
} catch (e) {}

/**
 * We'll load the axios HTTP library which allows us to easily issue requests
 * to our Laravel back-end. This library automatically handles sending the
 * CSRF token as a header based on the value of the "XSRF" token cookie.
 */

window.axios = require('axios');

window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
window.axios.defaults.headers.common['X-CSRF-TOKEN'] = window.csrf;
window.axios.defaults.headers.common['Authorization'] = `Bearer ${window.api_token}`;
// window.axios.defaults.headers.common[
//   "Authorization"
// ] = `Bearer ${window.api_token}`;
// window.axios.defaults.baseURL = `https://demo.portal.atgo.ir`;

/**
 * Echo exposes an expressive API for subscribing to channels and listening
 * for events that are broadcast by Laravel. Echo and event broadcasting
 * allows your team to easily build robust real-time web applications.
 */

// import Echo from 'laravel-echo';

// window.Pusher = require('pusher-js');

// window.Echo = new Echo({
//     broadcaster: 'pusher',
//     key: process.env.MIX_PUSHER_APP_KEY,
//     cluster: process.env.MIX_PUSHER_APP_CLUSTER,
//     forceTLS: true
// });


// Add a request interceptor
window.axios.interceptors.request.use(function (config) {
    // Do something before request is sent

    if(!store.getters['Loading/status']){
        store.dispatch('Loading/setStatus',{status: true})
    }

    return config;
  }, function (error) {
    // Do something with request error
    return Promise.reject(error);
  });

// Add a response interceptor
window.axios.interceptors.response.use(function (response) {
    // Do something with response data

    if(store.getters['Loading/status']){
        store.dispatch('Loading/setStatus',{status: false})
    }

    if(response.data.alert){

      Vue.notify({
        title: response.data.alert.title,
        text: response.data.alert.message,
        type: response.data.alert.type || 'success',
      })

    }
    

    return response;
  }, function (error) {


    if(store.getters['Loading/status']){
        store.dispatch('Loading/setStatus',{status: false})
    }


    if(error != 'Error: Request failed with status code 404'){
      Vue.notify({
        title: 'خطا',
        text: 'مشکلی نامشخص پیش آمده. لطفا به پشتیبانی اطلاع دهید',
        type: 'error',
      })
    }

    
    // Do something with response error
    return Promise.reject(error);
  });


  window.debounce = (cb, delay = 1000) => {
    let timeout
  
    return (...args) => {
      clearTimeout(timeout)
      timeout = setTimeout(() => {
        cb(...args)
      }, delay)
    }
  }


  // access notification

   function notify({
    title = null,
    body = null
  }) {
    if (!("Notification" in window)) {
      alert("This browser does not support desktop notification");
    } else if (Notification.permission === "granted") {
      var notification = new Notification(title, {
        body: body
      });      // …
    } else if (Notification.permission !== "denied") {
      Notification.requestPermission().then((permission) => {
        if (permission === "granted") {
          var notification = new Notification(title, {
            body: body
          });      
        }
      });
    }
  }

//TABLE IN MOBILE SIZE

function updateTableStructure() {
  $(".table:not(.mot-modal-table) tr:not(first-child)").each(function() {

      $(this)
          .find("td")
          .each(function(index) {
              let headerText = $(".table th")
                  .eq(index)
                  .text();
              $(this).attr("data-th", headerText);
          });
  });
}
updateTableStructure();
updateTableStructure2();
window.axios.interceptors.response.use( function(response) {

  setTimeout(() => {
      updateTableStructure();
      updateTableStructure2()
  }, 100);

//   $(window).resize(function() {
//       updateTableStructure();
//   });
  return response;
});

export default notify;


function updateTableStructure2() {
    $(".table:not(.mot-modal-table) tbody>tr").each(function() {
        console.log($(this).find("td") , "asdasdasd");
        $(this)
            .find("td")
            .each(function(index) {
                let headerText = $(".table th")
                    .eq(index)
                    .text();
                $(this).attr("data-th", headerText);
                console.log( $(".table th").eq(index).text());
                console.log( $(".table th").eq(index).html());
            });
    });
  }